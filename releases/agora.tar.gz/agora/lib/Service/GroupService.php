<?php

declare(strict_types=1);
/**
 * @copyright 2025 Agora contributors
 * @license   AGPL-3.0-or-later
 */

namespace OCA\Agora\Service;

use OCP\IGroupManager;
use OCP\IUser;

class GroupService
{

}
