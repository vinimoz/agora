<?php

declare(strict_types=1);
/**
 * SPDX-FileCopyrightText: 2017 Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */

namespace OCA\Agora\Db;

use OCP\AppFramework\Db\QBMapper;
use OCP\DB\QueryBuilder\IQueryBuilder;
use OCP\IDBConnection;

/**
 * @template-extends QBMapper<Preferences>
 */
class PreferencesMapper extends QBMapper
{
    public const TABLE = Preferences::TABLE;

    /**
     * @psalm-suppress PossiblyUnusedMethod 
     */
    public function __construct(IDBConnection $db)
    {
        parent::__construct($db, Preferences::TABLE, Preferences::class);
    }

    /**
     * @throws \OCP\AppFramework\Db\DoesNotExistException if not found
     * @throws \OCP\AppFramework\Db\MultipleObjectsReturnedException if more than one result
     * @return Preferences
     */
    public function find(?string $userId): Preferences
    {
        $qb = $this->db->getQueryBuilder();

        $qb->select('*')
            ->from($this->getTableName())
            ->where(
                $qb->expr()->eq('user_id', $qb->createNamedParameter($userId, IQueryBuilder::PARAM_STR))
            );

        return $this->findEntity($qb);
    }

    /**
     * @return void
     */
    public function deleteByUserId(string $userId): void
    {
        $query = $this->db->getQueryBuilder();
        $query->delete($this->getTableName())
            ->where('user_id = :userId')
            ->setParameter('userId', $userId);
        $query->executeStatement();
    }
}
