(function() {
  "use strict";
  try {
    if (typeof document != "undefined") {
      var elementStyle = document.createElement("style");
      elementStyle.appendChild(document.createTextNode(`@charset "UTF-8";/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-e17a2190] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.app-navigation-toggle-wrapper[data-v-e17a2190] {
  position: absolute;
  top: var(--app-navigation-padding);
  inset-inline-end: calc(0px - var(--app-navigation-padding));
  margin-inline-end: calc(-1 * var(--default-clickable-area));
}
button.app-navigation-toggle[data-v-e17a2190] {
  background-color: var(--color-main-background);
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.app-navigation,
.app-content {
  /** Distance of the app navigation toggle and the first navigation item to the top edge of the app content container */
  --app-navigation-padding: calc(var(--default-grid-baseline, 4px) * 2);
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-0d73a3a1] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.app-navigation[data-v-0d73a3a1] {
  --color-text-maxcontrast: var(--color-text-maxcontrast-background-blur, var(--color-text-maxcontrast-default));
  transition: transform var(--animation-quick), margin var(--animation-quick);
  width: 300px;
  --app-navigation-max-width: calc(100vw - (var(--app-navigation-padding) + var(--default-clickable-area) + var(--default-grid-baseline)));
  max-width: var(--app-navigation-max-width);
  position: relative;
  top: 0;
  inset-inline-start: 0;
  padding: 0px;
  z-index: 1800;
  height: 100%;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  flex-grow: 0;
  flex-shrink: 0;
  background-color: var(--color-main-background-blur, var(--color-main-background));
  -webkit-backdrop-filter: var(--filter-background-blur, none);
  backdrop-filter: var(--filter-background-blur, none);
}
.app-navigation--closed[data-v-0d73a3a1] {
  margin-inline-start: calc(-1 * min(300px, var(--app-navigation-max-width)));
}
.app-navigation__search[data-v-0d73a3a1] {
  width: 100%;
}
.app-navigation__body[data-v-0d73a3a1] {
  overflow-y: scroll;
}
.app-navigation__content > ul[data-v-0d73a3a1] {
  position: relative;
  width: 100%;
  overflow-x: hidden;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: var(--default-grid-baseline, 4px);
  padding: var(--app-navigation-padding);
}
.app-navigation .app-navigation__list[data-v-0d73a3a1] {
  height: 100%;
}
.app-navigation__body--no-list[data-v-0d73a3a1] {
  flex: 1 1 auto;
  overflow: auto;
  height: 100%;
}
.app-navigation__content[data-v-0d73a3a1] {
  height: 100%;
  display: flex;
  flex-direction: column;
}
[data-themes*=highcontrast] .app-navigation[data-v-0d73a3a1] {
  border-inline-end: 1px solid var(--color-border);
}
@media only screen and (max-width: 1024px) {
.app-navigation[data-v-0d73a3a1] {
    position: absolute;
    border-inline-end: 1px solid var(--color-border);
}
}
@media only screen and (max-width: 512px) {
.app-navigation[data-v-0d73a3a1] {
    z-index: 1400;
}
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-57437e4a] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.app-navigation-list[data-v-57437e4a] {
  position: relative;
  width: 100%;
  overflow-x: hidden;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: var(--default-grid-baseline, 4px);
  padding: var(--app-navigation-padding);
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-08119e68] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}

/* 'New' button */
.app-navigation-new[data-v-08119e68] {
  display: block;
  padding: calc(var(--default-grid-baseline, 4px) * 2);
}
.app-navigation-new button[data-v-08119e68] {
  width: 100%;
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-a21d21e6] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.button-vue.icon-collapse[data-v-a21d21e6] {
  position: relative;
  z-index: 105;
  color: var(--color-main-text);
  inset-inline-end: 0;
}
.button-vue.icon-collapse--open[data-v-a21d21e6] {
  color: var(--color-main-text);
}
.button-vue.icon-collapse--open[data-v-a21d21e6]:hover {
  color: var(--color-primary-element);
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-7c1c910e] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}

/**
 * SPDX-FileCopyrightText: 2023 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
.app-navigation-entry[data-v-7c1c910e] {
  position: relative;
  display: flex;
  flex-shrink: 0;
  flex-wrap: wrap;
  width: 100%;
  min-height: var(--default-clickable-area);
  transition: background-color var(--animation-quick) ease-in-out;
  transition: background-color 200ms ease-in-out;
  border-radius: var(--border-radius-element);
  /* hide deletion/collapse of subitems */
}
.app-navigation-entry-wrapper[data-v-7c1c910e] {
  position: relative;
  display: flex;
  flex-shrink: 0;
  flex-wrap: wrap;
  width: 100%;
}
.app-navigation-entry-wrapper.app-navigation-entry--collapsible:not(.app-navigation-entry--opened) > ul[data-v-7c1c910e] {
  display: none;
}
.app-navigation-entry.active[data-v-7c1c910e] {
  background-color: var(--color-primary-element) !important;
}
.app-navigation-entry.active[data-v-7c1c910e]:hover {
  background-color: var(--color-primary-element-hover) !important;
}
.app-navigation-entry.active .app-navigation-entry-link[data-v-7c1c910e], .app-navigation-entry.active .app-navigation-entry-button[data-v-7c1c910e] {
  color: var(--color-primary-element-text) !important;
}
.app-navigation-entry[data-v-7c1c910e]:focus-within, .app-navigation-entry[data-v-7c1c910e]:hover {
  background-color: var(--color-background-hover);
}
.app-navigation-entry.active .app-navigation-entry__children[data-v-7c1c910e], .app-navigation-entry:focus-within .app-navigation-entry__children[data-v-7c1c910e], .app-navigation-entry:hover .app-navigation-entry__children[data-v-7c1c910e] {
  background-color: var(--color-main-background);
}
.app-navigation-entry.active .app-navigation-entry__utils .app-navigation-entry__actions[data-v-7c1c910e], .app-navigation-entry.app-navigation-entry--deleted .app-navigation-entry__utils .app-navigation-entry__actions[data-v-7c1c910e], .app-navigation-entry:focus .app-navigation-entry__utils .app-navigation-entry__actions[data-v-7c1c910e], .app-navigation-entry:focus-within .app-navigation-entry__utils .app-navigation-entry__actions[data-v-7c1c910e], .app-navigation-entry:hover .app-navigation-entry__utils .app-navigation-entry__actions[data-v-7c1c910e] {
  display: inline-block;
}
.app-navigation-entry.app-navigation-entry--deleted > ul[data-v-7c1c910e] {
  display: none;
}
.app-navigation-entry:not(.app-navigation-entry--editing) .app-navigation-entry-link[data-v-7c1c910e], .app-navigation-entry:not(.app-navigation-entry--editing) .app-navigation-entry-button[data-v-7c1c910e] {
  padding-inline-end: calc((var(--default-clickable-area) - 16px) / 2);
}
.app-navigation-entry .app-navigation-entry-link[data-v-7c1c910e], .app-navigation-entry .app-navigation-entry-button[data-v-7c1c910e] {
  z-index: 100; /* above the bullet to allow click*/
  display: flex;
  overflow: hidden;
  flex: 1 1 0;
  min-height: var(--default-clickable-area);
  padding: 0;
  white-space: nowrap;
  color: var(--color-main-text);
  background-repeat: no-repeat;
  background-position: calc((var(--default-clickable-area) - 16px) / 2) center;
  background-size: 16px 16px;
  line-height: var(--default-clickable-area);
}
.app-navigation-entry .app-navigation-entry-link .app-navigation-entry-icon[data-v-7c1c910e], .app-navigation-entry .app-navigation-entry-button .app-navigation-entry-icon[data-v-7c1c910e] {
  display: flex;
  align-items: center;
  flex: 0 0 var(--default-clickable-area);
  justify-content: center;
  width: var(--default-clickable-area);
  height: var(--default-clickable-area);
  background-size: 16px 16px;
  background-repeat: no-repeat;
  background-position: calc((var(--default-clickable-area) - 16px) / 2) center;
}
.app-navigation-entry .app-navigation-entry-link .app-navigation-entry__name[data-v-7c1c910e], .app-navigation-entry .app-navigation-entry-button .app-navigation-entry__name[data-v-7c1c910e] {
  overflow: hidden;
  max-width: 100%;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.app-navigation-entry .app-navigation-entry-link .editingContainer[data-v-7c1c910e], .app-navigation-entry .app-navigation-entry-button .editingContainer[data-v-7c1c910e] {
  width: calc(100% - var(--default-clickable-area));
  margin: auto;
}
.app-navigation-entry .app-navigation-entry-link[data-v-7c1c910e]:focus-visible, .app-navigation-entry .app-navigation-entry-button[data-v-7c1c910e]:focus-visible {
  box-shadow: 0 0 0 4px var(--color-main-background);
  outline: 2px solid var(--color-main-text);
  border-radius: var(--border-radius-element);
}

/* Second level nesting for lists */
.app-navigation-entry__children[data-v-7c1c910e] {
  --app-navigation-item-child-offset: 10px;
  position: relative;
  display: flex;
  flex: 0 1 auto;
  flex-direction: column;
  width: 100%;
  gap: var(--default-grid-baseline, 4px);
  padding-inline-start: var(--app-navigation-item-child-offset);
}
.app-navigation-entry__children .app-navigation-entry[data-v-7c1c910e] {
  display: inline-flex;
  flex-wrap: wrap;
}
.app-navigation-entry__children .app-navigation-entry__children .app-navigation-entry__children .app-navigation-entry__children .app-navigation-entry__children .app-navigation-entry__children .app-navigation-entry__children[data-v-7c1c910e] {
  --app-navigation-item-child-offset: 0;
}

/* Deleted entries */
.app-navigation-entry__deleted[data-v-7c1c910e] {
  display: inline-flex;
  flex: 1 1 0;
  padding-inline-start: calc(var(--default-clickable-area) - (var(--default-clickable-area) - 16px) / 2) !important;
}
.app-navigation-entry__deleted .app-navigation-entry__deleted-description[data-v-7c1c910e] {
  position: relative;
  overflow: hidden;
  flex: 1 1 0;
  white-space: nowrap;
  text-overflow: ellipsis;
  line-height: var(--default-clickable-area);
}

/* counter and actions */
.app-navigation-entry__utils[data-v-7c1c910e] {
  display: flex;
  min-width: var(--default-clickable-area);
  align-items: center;
  flex: 0 1 auto;
  justify-content: flex-end;
  /* counter */
  /* actions */
}
.app-navigation-entry__utils.app-navigation-entry__utils--display-actions .action-item.app-navigation-entry__actions[data-v-7c1c910e] {
  display: inline-block;
}
.app-navigation-entry__utils .app-navigation-entry__counter-wrapper[data-v-7c1c910e] {
  margin-inline-end: calc(var(--default-grid-baseline) * 2);
  display: flex;
  align-items: center;
  flex: 0 1 auto;
}
.app-navigation-entry__utils .action-item.app-navigation-entry__actions[data-v-7c1c910e] {
  display: none;
}

/* editing state */
.app-navigation-entry--editing .app-navigation-entry-edit[data-v-7c1c910e] {
  z-index: 250;
  opacity: 1;
}

/* deleted state */
.app-navigation-entry--deleted .app-navigation-entry-deleted[data-v-7c1c910e] {
  z-index: 250;
  transform: translateX(0);
}

/* pinned state */
.app-navigation-entry--pinned[data-v-7c1c910e] {
  order: 2;
  margin-top: auto;
}
.app-navigation-entry--pinned ~ .app-navigation-entry--pinned[data-v-7c1c910e] {
  margin-top: 0;
}
[data-themes*=highcontrast] .app-navigation-entry[data-v-7c1c910e]:active {
  background-color: var(--color-primary-element-light-hover) !important;
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-71f6ed5a] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.app-navigation-input-confirm[data-v-71f6ed5a] {
  flex: 1 0 100%;
  width: 100%;
}
.app-navigation-input-confirm form[data-v-71f6ed5a] {
  display: flex;
}
.app-navigation-input-confirm__input[data-v-71f6ed5a] {
  height: 34px;
  flex: 1 1 100%;
  font-size: 100% !important;
  margin: 5px !important;
  margin-inline-start: -8px !important;
  padding: 7px !important;
}
.app-navigation-input-confirm__input[data-v-71f6ed5a]:active, .app-navigation-input-confirm__input[data-v-71f6ed5a]:focus, .app-navigation-input-confirm__input[data-v-71f6ed5a]:hover {
  outline: none;
  background-color: var(--color-main-background);
  color: var(--color-main-text);
  border-color: var(--color-primary-element);
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-5481b656] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.counter-bubble__counter[data-v-5481b656] {
  --counter-bubble-height: 22px;
  font-size: var(--font-size-small, 13px);
  overflow: hidden;
  width: fit-content;
  min-width: var(--counter-bubble-height);
  text-align: center;
  line-height: var(--counter-bubble-height);
  padding: 0 calc(1.5 * var(--default-grid-baseline));
  border-radius: 0.5lh;
  background-color: var(--color-primary-element-light);
  font-weight: bold;
  color: var(--color-primary-element-light-text);
}
.counter-bubble__counter .active[data-v-5481b656] {
  color: var(--color-main-background);
  background-color: var(--color-primary-element-light);
}
.counter-bubble__counter--highlighted[data-v-5481b656] {
  color: var(--color-primary-element-text);
  background-color: var(--color-primary-element);
}
.counter-bubble__counter--highlighted.active[data-v-5481b656] {
  color: var(--color-primary-element);
  background-color: var(--color-main-background);
}
.counter-bubble__counter--outlined[data-v-5481b656] {
  color: var(--color-primary-element);
  background: transparent;
  box-shadow: inset 0 0 0 2px;
}
.counter-bubble__counter--outlined.active[data-v-5481b656] {
  color: var(--color-main-background);
  box-shadow: inset 0 0 0 2px;
}.badge {
  display: flex;
  align-items: center;
  gap: 5px;
  border-radius: var(--border-radius);
  padding: 5px;
  text-align: center;
  line-height: 1.1em;
  font-size: 0.9em;
  overflow: hidden;
}
.badge span {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
h2 .badge {
  font-size: 0.6em;
}
.badge.error {
  border-color: var(--color-error);
  background-color: var(--color-error);
  color: var(--color-primary-element-text) !important;
}
.badge.success {
  border-color: var(--color-success);
  background-color: var(--color-success);
  color: var(--color-primary-element-text) !important;
}.left-card-side {
  flex: 1 0 180px;
}
.left-card-side ul {
  list-style: initial;
  margin-inline-start: 2rem;
}
.right-card-side {
  flex: 0;
  padding-inline-end: 8px;
}
.notecard > * {
  display: flex;
  flex-direction: column;
}
.notecard .card-content {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  flex: 1;
  column-gap: 8px;
}.config-box__header {
  display: flex;
  align-content: center;
  align-items: center;
  gap: 5px;
  margin: 8px 0 8px 0;
}
.config-box {
  display: flex;
  flex-direction: column;
  padding: 8px 0;
}
.config-box .icon-container {
  width: 20px;
}
.config-box .config-box__title {
  display: flex;
  flex: 1;
  opacity: 0.7;
  font-weight: bold;
  margin: 0;
}
.config-box .config-box__container {
  display: flex;
  flex-direction: column;
  padding-inline-start: 24px;
}
.indented {
  margin-inline-start: 24px !important;
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-f356c0a6] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.native-datetime-picker[data-v-f356c0a6] {
  display: flex;
  flex-direction: column;
}
.native-datetime-picker .native-datetime-picker__label[data-v-f356c0a6] {
  margin-block-end: 2px;
}
.native-datetime-picker .native-datetime-picker__input[data-v-f356c0a6] {
  --input-border-width-offset: calc(var(--border-width-input-focused, 2px) - var(--border-width-input, 2px));
  width: 100%;
  flex: 0 0 auto;
  margin: 0;
  padding-inline-start: calc(var(--border-radius-element) + var(--input-border-width-offset));
  padding-inline-end: calc(var(--default-grid-baseline) + var(--input-border-width-offset));
  border: var(--border-width-input, 2px) solid var(--color-border-maxcontrast);
}
.native-datetime-picker .native-datetime-picker__input[data-v-f356c0a6]:active:not([disabled]), .native-datetime-picker .native-datetime-picker__input[data-v-f356c0a6]:hover:not([disabled]), .native-datetime-picker .native-datetime-picker__input[data-v-f356c0a6]:focus:not([disabled]), .native-datetime-picker .native-datetime-picker__input[data-v-f356c0a6]:focus-within:not([disabled]) {
  border-color: var(--color-main-text);
  border-width: var(--border-width-input-focused, 2px);
  box-shadow: 0 0 0 2px var(--color-main-background) !important;
  --input-border-width-offset: 0px;
}
[data-theme-light] .native-datetime-picker__input[data-v-f356c0a6],
[data-themes*=light] .native-datetime-picker__input[data-v-f356c0a6] {
  color-scheme: light;
}
[data-theme-dark] .native-datetime-picker__input[data-v-f356c0a6],
[data-themes*=dark] .native-datetime-picker__input[data-v-f356c0a6] {
  color-scheme: dark;
}
@media (prefers-color-scheme: light) {
[data-theme-default] .native-datetime-picker__input[data-v-f356c0a6],
  [data-themes*=default] .native-datetime-picker__input[data-v-f356c0a6] {
    color-scheme: light;
}
}
@media (prefers-color-scheme: dark) {
[data-theme-default] .native-datetime-picker__input[data-v-f356c0a6],
  [data-themes*=default] .native-datetime-picker__input[data-v-f356c0a6] {
    color-scheme: dark;
}
}.flex_settings {
  display: flex;
  flex-wrap: wrap;
  align-items: stretch;
}
.flex_settings .settings-section {
  flex: 1 0 480px;
  margin-bottom: 0;
  border-bottom: 1px solid var(--color-border);
}
.settings-description {
  margin-top: -0.2em;
  margin-bottom: 1em;
  opacity: 0.7;
}
.user_settings {
  padding-top: 8px;
}
.user_settings textarea {
  width: 99%;
  resize: vertical;
  height: 230px;
}
.settings_details {
  padding-bottom: 16px;
  margin-inline-start: 36px;
}.spacer {
  flex: 1;
}.page--scrolled .header_bar_bottom {
  display: none;
}
.header_bar {
  margin-inline: -8px;
  padding-inline: 56px 8px;
  background-color: var(--color-main-background);
  transition: all var(--animation-slow) linear;
}
.header_bar.sticky-top {
  z-index: 9;
}
.header_bar::after {
  border-top: 1px solid var(--color-border);
}
.header_bar .header_bar_top {
  display: flex;
  flex-wrap: wrap-reverse;
  justify-content: flex-end;
  gap: 8px;
  min-height: 3em;
}
.header_bar .header_bar_top .bar_top_left {
  display: flex;
  flex-direction: column;
  flex: 1 180px;
  justify-content: center;
}
.header_bar .header_bar_top .bar_top_right {
  display: flex;
  flex: 1;
  justify-content: flex-end;
  align-content: center;
  gap: 8px;
  flex-wrap: wrap;
}
.header_bar .header_bar_top .header_title {
  font-weight: bold;
  font-size: 1em;
  line-height: 1.5em;
}
.header_bar .header_bar_top .sub {
  display: flex;
  flex-wrap: wrap;
}
.header_bar .header_bar_bottom {
  margin-bottom: 1rem;
}
.header_bar [class*=bar_] {
  flex: 0;
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.nc-button-group-base > div {
  text-align: center;
  color: var(--color-text-maxcontrast);
}
.nc-button-group-base ul.nc-button-group-content {
  display: flex;
  gap: 4px;
  justify-content: space-between;
}
.nc-button-group-base ul.nc-button-group-content li {
  flex: 1 1;
}
.nc-button-group-base ul.nc-button-group-content .action-button {
  padding: 0 !important;
  width: 100%;
  display: flex;
  justify-content: center;
}
.nc-button-group-base ul.nc-button-group-content .action-button.action-button--active {
  background-color: var(--color-primary-element);
  border-radius: var(--border-radius-element);
  color: var(--color-primary-element-text);
}
.nc-button-group-base ul.nc-button-group-content .action-button.action-button--active:hover, .nc-button-group-base ul.nc-button-group-content .action-button.action-button--active:focus, .nc-button-group-base ul.nc-button-group-content .action-button.action-button--active:focus-within {
  background-color: var(--color-primary-element-hover);
}
.nc-button-group-base ul.nc-button-group-content .action-button .action-button__pressed-icon {
  display: none;
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-1009e96c] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.app-navigation-caption[data-v-1009e96c] {
  color: var(--color-text-maxcontrast);
  line-height: var(--default-clickable-area);
  white-space: nowrap;
  text-overflow: ellipsis;
  box-shadow: none !important;
  user-select: none;
  pointer-events: none;
  margin-inline-start: 12px;
  padding-inline-end: 14px;
  height: var(--default-clickable-area);
  display: flex;
  align-items: center;
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-8e31d57f] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}

/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
li.action[data-v-8e31d57f]:hover, li.action.active[data-v-8e31d57f] {
  border-radius: 6px;
  padding: 0;
}
li.action[data-v-8e31d57f]:hover {
  background-color: var(--color-background-hover);
}
.action--disabled[data-v-8e31d57f] {
  pointer-events: none;
  opacity: 0.5;
}
.action--disabled[data-v-8e31d57f]:hover, .action--disabled[data-v-8e31d57f]:focus {
  cursor: default;
  opacity: 0.5;
}
.action--disabled[data-v-8e31d57f] * {
  opacity: 1 !important;
}
.action-checkbox[data-v-8e31d57f] {
  display: flex;
  align-items: flex-start;
  width: 100%;
  height: auto;
  margin: 0;
  padding: 0;
  cursor: pointer;
  white-space: nowrap;
  color: var(--color-main-text);
  border: 0;
  border-radius: 0;
  background-color: transparent;
  box-shadow: none;
  font-weight: normal;
  line-height: var(--default-clickable-area);
  /* checkbox/radio fixes */
}
.action-checkbox__checkbox[data-v-8e31d57f] {
  position: absolute;
  inset-inline-start: 0 !important;
  z-index: -1;
  opacity: 0;
}
.action-checkbox__label[data-v-8e31d57f] {
  display: flex;
  align-items: center;
  width: 100%;
  padding: 0 !important;
  padding-inline-end: calc((var(--default-clickable-area) - 16px) / 2) !important;
}
.action-checkbox__label[data-v-8e31d57f]::before {
  margin-block: 0 !important;
  margin-inline: calc((var(--default-clickable-area) - 14px) / 2) !important;
}
.action-checkbox--disabled[data-v-8e31d57f],
.action-checkbox--disabled .action-checkbox__label[data-v-8e31d57f] {
  cursor: pointer;
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-7607f0e9] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}

/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/* Default global values */
button[data-v-7607f0e9]:not(.button-vue),
input[data-v-7607f0e9]:not([type=range]),
textarea[data-v-7607f0e9] {
  margin: 0;
  padding: 7px 6px;
  cursor: text;
  color: var(--color-main-text);
  border: 1px solid var(--color-border-dark);
  border-radius: var(--border-radius-element);
  outline: none;
  background-color: var(--color-main-background);
  font-size: 13px;
  /* Primary action button, use sparingly */
}
button[data-v-7607f0e9]:not(.button-vue):not(:disabled):not(.primary):hover, button[data-v-7607f0e9]:not(.button-vue):not(:disabled):not(.primary):focus, button:not(.button-vue):not(:disabled):not(.primary).active[data-v-7607f0e9],
input[data-v-7607f0e9]:not([type=range]):not(:disabled):not(.primary):hover,
input[data-v-7607f0e9]:not([type=range]):not(:disabled):not(.primary):focus,
input:not([type=range]):not(:disabled):not(.primary).active[data-v-7607f0e9],
textarea[data-v-7607f0e9]:not(:disabled):not(.primary):hover,
textarea[data-v-7607f0e9]:not(:disabled):not(.primary):focus,
textarea:not(:disabled):not(.primary).active[data-v-7607f0e9] {
  /* active class used for multiselect */
  border-color: var(--color-primary-element);
  outline: none;
}
button[data-v-7607f0e9]:not(.button-vue):not(:disabled):not(.primary):active,
input[data-v-7607f0e9]:not([type=range]):not(:disabled):not(.primary):active,
textarea[data-v-7607f0e9]:not(:disabled):not(.primary):active {
  color: var(--color-main-text);
  outline: none;
  background-color: var(--color-main-background);
}
button[data-v-7607f0e9]:not(.button-vue):disabled,
input[data-v-7607f0e9]:not([type=range]):disabled,
textarea[data-v-7607f0e9]:disabled {
  cursor: default;
  opacity: 0.5;
  color: var(--color-text-maxcontrast);
  background-color: var(--color-background-dark);
}
button[data-v-7607f0e9]:not(.button-vue):required,
input[data-v-7607f0e9]:not([type=range]):required,
textarea[data-v-7607f0e9]:required {
  box-shadow: none;
}
button[data-v-7607f0e9]:not(.button-vue):invalid,
input[data-v-7607f0e9]:not([type=range]):invalid,
textarea[data-v-7607f0e9]:invalid {
  border-color: var(--color-border-error, var(--color-error));
  box-shadow: none !important;
}
button:not(.button-vue).primary[data-v-7607f0e9],
input:not([type=range]).primary[data-v-7607f0e9],
textarea.primary[data-v-7607f0e9] {
  cursor: pointer;
  color: var(--color-primary-element-text);
  border-color: var(--color-primary-element);
  background-color: var(--color-primary-element);
}
button:not(.button-vue).primary[data-v-7607f0e9]:not(:disabled):hover, button:not(.button-vue).primary[data-v-7607f0e9]:not(:disabled):focus, button:not(.button-vue).primary[data-v-7607f0e9]:not(:disabled):active,
input:not([type=range]).primary[data-v-7607f0e9]:not(:disabled):hover,
input:not([type=range]).primary[data-v-7607f0e9]:not(:disabled):focus,
input:not([type=range]).primary[data-v-7607f0e9]:not(:disabled):active,
textarea.primary[data-v-7607f0e9]:not(:disabled):hover,
textarea.primary[data-v-7607f0e9]:not(:disabled):focus,
textarea.primary[data-v-7607f0e9]:not(:disabled):active {
  border-color: var(--color-primary-element-light);
  background-color: var(--color-primary-element-light);
}
button:not(.button-vue).primary[data-v-7607f0e9]:not(:disabled):active,
input:not([type=range]).primary[data-v-7607f0e9]:not(:disabled):active,
textarea.primary[data-v-7607f0e9]:not(:disabled):active {
  color: var(--color-primary-element-text-dark);
}
button:not(.button-vue).primary[data-v-7607f0e9]:disabled,
input:not([type=range]).primary[data-v-7607f0e9]:disabled,
textarea.primary[data-v-7607f0e9]:disabled {
  cursor: default;
  color: var(--color-primary-element-text-dark);
  background-color: var(--color-primary-element);
}

/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
li.action[data-v-7607f0e9]:hover, li.action.active[data-v-7607f0e9] {
  border-radius: 6px;
  padding: 0;
}
li.action[data-v-7607f0e9]:hover {
  background-color: var(--color-background-hover);
}
.action--disabled[data-v-7607f0e9] {
  pointer-events: none;
  opacity: 0.5;
}
.action--disabled[data-v-7607f0e9]:hover, .action--disabled[data-v-7607f0e9]:focus {
  cursor: default;
  opacity: 0.5;
}
.action--disabled[data-v-7607f0e9] * {
  opacity: 1 !important;
}
.action-input[data-v-7607f0e9] {
  display: flex;
  align-items: flex-start;
  width: 100%;
  height: auto;
  margin: 0;
  padding: 0;
  cursor: pointer;
  white-space: nowrap;
  color: var(--color-main-text);
  border: 0;
  border-radius: 0;
  background-color: transparent;
  box-shadow: none;
  font-weight: normal;
}
.action-input__icon-wrapper[data-v-7607f0e9] {
  display: flex;
  align-self: center;
  align-items: center;
  justify-content: center;
}
.action-input__icon-wrapper[data-v-7607f0e9] .material-design-icon {
  width: var(--default-clickable-area);
  height: var(--default-clickable-area);
  opacity: 1;
}
.action-input__icon-wrapper[data-v-7607f0e9] .material-design-icon .material-design-icon__svg {
  vertical-align: middle;
}
.action-input > span[data-v-7607f0e9] {
  cursor: pointer;
  white-space: nowrap;
}
.action-input__icon[data-v-7607f0e9] {
  min-width: 0; /* Overwrite icons*/
  min-height: 0;
  padding: calc(var(--default-clickable-area) / 2) 0 calc(var(--default-clickable-area) / 2) var(--default-clickable-area);
  background-position: calc((var(--default-clickable-area) - 16px) / 2) center;
  background-size: 16px;
}
.action-input__form[data-v-7607f0e9] {
  display: flex;
  align-items: center;
  flex: 1 1 auto;
  margin: 4px 0;
  padding-inline-end: calc((var(--default-clickable-area) - 16px) / 2);
}
.action-input__container[data-v-7607f0e9] {
  position: relative;
  width: 100%;
}
.action-input__input-container[data-v-7607f0e9] {
  display: flex;
}
.action-input__input-container .colorpicker__trigger[data-v-7607f0e9], .action-input__input-container .colorpicker__preview[data-v-7607f0e9] {
  width: 100%;
}
.action-input__input-container .colorpicker__preview[data-v-7607f0e9] {
  width: 100%;
  height: 36px;
  border-radius: var(--border-radius-element);
  border: 2px solid var(--color-border-maxcontrast);
  box-shadow: none !important;
}
.action-input__text-label[data-v-7607f0e9] {
  padding: 4px 0;
  display: block;
}
.action-input__text-label--hidden[data-v-7607f0e9] {
  position: absolute;
  inset-inline-start: 0;
  width: 1px;
  height: 1px;
  overflow: hidden;
  z-index: -1;
  opacity: 0;
}
.action-input__datetimepicker[data-v-7607f0e9] {
  width: 100%;
}
.action-input__datetimepicker[data-v-7607f0e9] .mx-input {
  margin: 0;
}
.action-input__multi[data-v-7607f0e9] {
  width: 100%;
}
li:last-child > .action-input[data-v-7607f0e9] {
  padding-bottom: calc((var(--default-clickable-area) - 16px) / 2 - 4px);
}
li:first-child > .action-input[data-v-7607f0e9]:not(.action-input--visible-label) {
  padding-top: calc((var(--default-clickable-area) - 16px) / 2 - 4px);
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-929be55a] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
[data-v-929be55a] .password-field__input--secure-text {
  -webkit-text-security: disc;
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-4e9c727c] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}

/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
li.action[data-v-4e9c727c]:hover, li.action.active[data-v-4e9c727c] {
  border-radius: 6px;
  padding: 0;
}
li.action[data-v-4e9c727c]:hover {
  background-color: var(--color-background-hover);
}
.action--disabled[data-v-4e9c727c] {
  pointer-events: none;
  opacity: 0.5;
}
.action--disabled[data-v-4e9c727c]:hover, .action--disabled[data-v-4e9c727c]:focus {
  cursor: default;
  opacity: 0.5;
}
.action--disabled[data-v-4e9c727c] * {
  opacity: 1 !important;
}
.action-radio[data-v-4e9c727c] {
  display: flex;
  align-items: flex-start;
  width: 100%;
  height: auto;
  margin: 0;
  padding: 0;
  cursor: pointer;
  white-space: nowrap;
  color: var(--color-main-text);
  border: 0;
  border-radius: 0;
  background-color: transparent;
  box-shadow: none;
  font-weight: normal;
  line-height: var(--default-clickable-area);
  /* checkbox/radio fixes */
}
.action-radio__radio[data-v-4e9c727c] {
  position: absolute;
  inset-inline-start: 0 !important;
  z-index: -1;
  opacity: 0;
}
.action-radio__label[data-v-4e9c727c] {
  display: flex;
  align-items: center;
  width: 100%;
  padding: 0 !important;
  padding-inline-end: calc((var(--default-clickable-area) - 16px) / 2) !important;
}
.action-radio__label[data-v-4e9c727c]::before {
  margin: calc((var(--default-clickable-area) - 14px) / 2) !important;
}
.action-radio--disabled[data-v-4e9c727c],
.action-radio--disabled .action-radio__label[data-v-4e9c727c] {
  cursor: pointer;
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-3e2324b7] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.action-separator[data-v-3e2324b7] {
  height: 0;
  margin: 5px 10px 5px 15px;
  border-bottom: 1px solid var(--color-border-dark);
  cursor: default;
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-df9c1bf0] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}

/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/* Default global values */
button[data-v-df9c1bf0]:not(.button-vue),
input[data-v-df9c1bf0]:not([type=range]),
textarea[data-v-df9c1bf0] {
  margin: 0;
  padding: 7px 6px;
  cursor: text;
  color: var(--color-main-text);
  border: 1px solid var(--color-border-dark);
  border-radius: var(--border-radius-element);
  outline: none;
  background-color: var(--color-main-background);
  font-size: 13px;
  /* Primary action button, use sparingly */
}
button[data-v-df9c1bf0]:not(.button-vue):not(:disabled):not(.primary):hover, button[data-v-df9c1bf0]:not(.button-vue):not(:disabled):not(.primary):focus, button:not(.button-vue):not(:disabled):not(.primary).active[data-v-df9c1bf0],
input[data-v-df9c1bf0]:not([type=range]):not(:disabled):not(.primary):hover,
input[data-v-df9c1bf0]:not([type=range]):not(:disabled):not(.primary):focus,
input:not([type=range]):not(:disabled):not(.primary).active[data-v-df9c1bf0],
textarea[data-v-df9c1bf0]:not(:disabled):not(.primary):hover,
textarea[data-v-df9c1bf0]:not(:disabled):not(.primary):focus,
textarea:not(:disabled):not(.primary).active[data-v-df9c1bf0] {
  /* active class used for multiselect */
  border-color: var(--color-primary-element);
  outline: none;
}
button[data-v-df9c1bf0]:not(.button-vue):not(:disabled):not(.primary):active,
input[data-v-df9c1bf0]:not([type=range]):not(:disabled):not(.primary):active,
textarea[data-v-df9c1bf0]:not(:disabled):not(.primary):active {
  color: var(--color-main-text);
  outline: none;
  background-color: var(--color-main-background);
}
button[data-v-df9c1bf0]:not(.button-vue):disabled,
input[data-v-df9c1bf0]:not([type=range]):disabled,
textarea[data-v-df9c1bf0]:disabled {
  cursor: default;
  opacity: 0.5;
  color: var(--color-text-maxcontrast);
  background-color: var(--color-background-dark);
}
button[data-v-df9c1bf0]:not(.button-vue):required,
input[data-v-df9c1bf0]:not([type=range]):required,
textarea[data-v-df9c1bf0]:required {
  box-shadow: none;
}
button[data-v-df9c1bf0]:not(.button-vue):invalid,
input[data-v-df9c1bf0]:not([type=range]):invalid,
textarea[data-v-df9c1bf0]:invalid {
  border-color: var(--color-border-error, var(--color-error));
  box-shadow: none !important;
}
button:not(.button-vue).primary[data-v-df9c1bf0],
input:not([type=range]).primary[data-v-df9c1bf0],
textarea.primary[data-v-df9c1bf0] {
  cursor: pointer;
  color: var(--color-primary-element-text);
  border-color: var(--color-primary-element);
  background-color: var(--color-primary-element);
}
button:not(.button-vue).primary[data-v-df9c1bf0]:not(:disabled):hover, button:not(.button-vue).primary[data-v-df9c1bf0]:not(:disabled):focus, button:not(.button-vue).primary[data-v-df9c1bf0]:not(:disabled):active,
input:not([type=range]).primary[data-v-df9c1bf0]:not(:disabled):hover,
input:not([type=range]).primary[data-v-df9c1bf0]:not(:disabled):focus,
input:not([type=range]).primary[data-v-df9c1bf0]:not(:disabled):active,
textarea.primary[data-v-df9c1bf0]:not(:disabled):hover,
textarea.primary[data-v-df9c1bf0]:not(:disabled):focus,
textarea.primary[data-v-df9c1bf0]:not(:disabled):active {
  border-color: var(--color-primary-element-light);
  background-color: var(--color-primary-element-light);
}
button:not(.button-vue).primary[data-v-df9c1bf0]:not(:disabled):active,
input:not([type=range]).primary[data-v-df9c1bf0]:not(:disabled):active,
textarea.primary[data-v-df9c1bf0]:not(:disabled):active {
  color: var(--color-primary-element-text-dark);
}
button:not(.button-vue).primary[data-v-df9c1bf0]:disabled,
input:not([type=range]).primary[data-v-df9c1bf0]:disabled,
textarea.primary[data-v-df9c1bf0]:disabled {
  cursor: default;
  color: var(--color-primary-element-text-dark);
  background-color: var(--color-primary-element);
}

/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
li.action[data-v-df9c1bf0]:hover, li.action.active[data-v-df9c1bf0] {
  border-radius: 6px;
  padding: 0;
}
li.action[data-v-df9c1bf0]:hover {
  background-color: var(--color-background-hover);
}
.action--disabled[data-v-df9c1bf0] {
  pointer-events: none;
  opacity: 0.5;
}
.action--disabled[data-v-df9c1bf0]:hover, .action--disabled[data-v-df9c1bf0]:focus {
  cursor: default;
  opacity: 0.5;
}
.action--disabled[data-v-df9c1bf0] * {
  opacity: 1 !important;
}
.action-text-editable[data-v-df9c1bf0] {
  display: flex;
  align-items: flex-start;
  width: 100%;
  height: auto;
  margin: 0;
  padding: 0;
  cursor: pointer;
  white-space: nowrap;
  color: var(--color-main-text);
  border: 0;
  border-radius: 0;
  background-color: transparent;
  box-shadow: none;
  font-weight: normal;
  line-height: var(--default-clickable-area);
  /* Inputs inside popover supports text, submit & reset */
}
.action-text-editable > span[data-v-df9c1bf0] {
  cursor: pointer;
  white-space: nowrap;
}
.action-text-editable__icon[data-v-df9c1bf0] {
  min-width: 0; /* Overwrite icons*/
  min-height: 0;
  /* Keep padding to define the width to
  	assure correct position of a possible text */
  padding: calc(var(--default-clickable-area) / 2) 0 calc(var(--default-clickable-area) / 2) var(--default-clickable-area);
  background-position: calc((var(--default-clickable-area) - 16px) / 2) center;
  background-size: 16px;
}
.action-text-editable[data-v-df9c1bf0] .material-design-icon {
  width: var(--default-clickable-area);
  height: var(--default-clickable-area);
  opacity: 1;
}
.action-text-editable[data-v-df9c1bf0] .material-design-icon .material-design-icon__svg {
  vertical-align: middle;
}
.action-text-editable__form[data-v-df9c1bf0] {
  display: flex;
  flex: 1 1 auto;
  flex-direction: column;
  position: relative;
  margin: 4px 0;
  padding-inline-end: calc((var(--default-clickable-area) - 16px) / 2);
}
.action-text-editable__submit[data-v-df9c1bf0] {
  position: absolute;
  inset-inline-start: 0;
  top: auto;
  width: 1px;
  height: 1px;
  overflow: hidden;
  z-index: -1;
  opacity: 0;
}
.action-text-editable__label[data-v-df9c1bf0] {
  display: flex;
  align-items: center;
  justify-content: center;
  position: absolute;
  inset-inline-end: calc((var(--default-clickable-area) - 16px) / 2 + 1px);
  bottom: 1px;
  width: calc(var(--default-clickable-area) - 8px);
  height: calc(var(--default-clickable-area) - 8px);
  box-sizing: border-box;
  margin: 0;
  padding: 7px 6px;
  border: 0;
  border-radius: 50%;
  /* Avoid background under border */
  background-color: var(--color-main-background);
  background-clip: padding-box;
}
.action-text-editable__label[data-v-df9c1bf0], .action-text-editable__label[data-v-df9c1bf0] * {
  cursor: pointer;
}
.action-text-editable__textarea[data-v-df9c1bf0] {
  flex: 1 1 auto;
  color: inherit;
  border-color: var(--color-border-maxcontrast);
  min-height: calc(var(--default-clickable-area) * 2 - 8px); /* twice the element margin-y */
  max-height: calc(var(--default-clickable-area) * 3 - 8px); /* twice the element margin-y */
  min-width: calc(var(--default-clickable-area) * 4);
  width: 100% !important;
  margin: 0;
  /* only show confirm borders if input is not focused */
}
.action-text-editable__textarea[data-v-df9c1bf0]:disabled {
  cursor: default;
}
.action-text-editable__textarea:not(:active):not(:hover):not(:focus):invalid + .action-text-editable__label[data-v-df9c1bf0] {
  background-color: var(--color-error);
}
.action-text-editable__textarea:not(:active):not(:hover):not(:focus):not(:disabled) + .action-text-editable__label[data-v-df9c1bf0]:active, .action-text-editable__textarea:not(:active):not(:hover):not(:focus):not(:disabled) + .action-text-editable__label[data-v-df9c1bf0]:hover, .action-text-editable__textarea:not(:active):not(:hover):not(:focus):not(:disabled) + .action-text-editable__label[data-v-df9c1bf0]:focus {
  background-color: var(--color-primary-element);
  color: var(--color-primary-element-text);
}
.action-text-editable__textarea:active:not(:disabled) + .action-text-editable__label[data-v-df9c1bf0], .action-text-editable__textarea:hover:not(:disabled) + .action-text-editable__label[data-v-df9c1bf0], .action-text-editable__textarea:focus:not(:disabled) + .action-text-editable__label[data-v-df9c1bf0] {
  /* above previous input */
  z-index: 2;
  border-color: var(--color-primary-element);
  border-inline-start-color: transparent;
}
li:last-child > .action-text-editable[data-v-df9c1bf0] {
  margin-bottom: calc((var(--default-clickable-area) - 16px) / 2 - 4px);
}
li:first-child > .action-text-editable[data-v-df9c1bf0] {
  margin-top: calc((var(--default-clickable-area) - 16px) / 2 - 4px);
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-a5fd2a54] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.app-details-toggle[data-v-a5fd2a54] {
  position: sticky;
  width: var(--default-clickable-area);
  height: var(--default-clickable-area);
  padding: calc((var(--default-clickable-area) - 16px) / 2);
  cursor: pointer;
  opacity: 0.6;
  transform: rotate(180deg);
  background-color: var(--color-main-background);
  z-index: 2000;
  top: var(--app-navigation-padding);
  inset-inline-start: calc(var(--default-clickable-area) + var(--app-navigation-padding) * 2);
}
.app-details-toggle--mobile[data-v-a5fd2a54] {
  inset-inline-start: var(--app-navigation-padding);
}
.app-details-toggle[data-v-a5fd2a54]:active, .app-details-toggle[data-v-a5fd2a54]:hover, .app-details-toggle[data-v-a5fd2a54]:focus {
  opacity: 1;
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-8d2eca70] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.app-content[data-v-8d2eca70] {
  position: initial;
  z-index: 1000;
  flex-basis: 100vw;
  height: 100%;
  margin: 0 !important;
  background-color: var(--color-main-background);
  min-width: 0;
}
.app-content[data-v-8d2eca70]:not(.app-content--has-list) {
  overflow: auto;
}
.app-content-wrapper[data-v-8d2eca70] {
  position: relative;
  width: 100%;
  height: 100%;
}
.app-content-wrapper--no-split.app-content-wrapper--show-list[data-v-8d2eca70]  .app-content-list {
  display: flex;
}
.app-content-wrapper--no-split.app-content-wrapper--show-list[data-v-8d2eca70]  .app-content-details {
  display: none;
}
.app-content-wrapper--no-split.app-content-wrapper--show-details[data-v-8d2eca70]  .app-content-list {
  display: none;
}
.app-content-wrapper--no-split.app-content-wrapper--show-details[data-v-8d2eca70]  .app-content-details {
  display: block;
}
[data-v-8d2eca70] .splitpanes.default-theme .app-content-list {
  max-width: none;
  /* Thin scrollbar is hard to catch on resizable columns */
  scrollbar-width: auto;
}
[data-v-8d2eca70] .splitpanes.default-theme .splitpanes__pane {
  background-color: transparent;
  transition: none;
}
[data-v-8d2eca70] .splitpanes.default-theme .splitpanes__pane-list {
  min-width: 300px;
  position: sticky;
}
@media only screen and (width < 1024px) {
[data-v-8d2eca70] .splitpanes.default-theme .splitpanes__pane-list {
    display: none;
}
}
[data-v-8d2eca70] .splitpanes.default-theme .splitpanes__pane-details {
  overflow-y: auto;
}
@media only screen and (width < 1024px) {
[data-v-8d2eca70] .splitpanes.default-theme .splitpanes__pane-details {
    min-width: 100%;
}
}
[data-v-8d2eca70] .splitpanes.default-theme .splitpanes__splitter {
  background-color: var(--color-main-background);
}
[data-v-8d2eca70] .splitpanes.default-theme .splitpanes__splitter::before,[data-v-8d2eca70] .splitpanes.default-theme .splitpanes__splitter::after {
  background-color: var(--color-border);
}
[data-v-8d2eca70] .splitpanes.default-theme.splitpanes--vertical .splitpanes__splitter {
  border-inline-start: 1px solid var(--color-border);
}
[data-v-8d2eca70] .splitpanes.default-theme.splitpanes--horizontal .splitpanes__splitter {
  border-top: 1px solid var(--color-border);
}
.app-content-wrapper--show-list[data-v-8d2eca70] .app-content-list {
  max-width: none;
}.splitpanes{display:flex;width:100%;height:100%}.splitpanes--vertical{flex-direction:row}.splitpanes--horizontal{flex-direction:column}.splitpanes--dragging .splitpanes__pane,*:has(.splitpanes--dragging){-webkit-user-select:none;user-select:none;pointer-events:none}.splitpanes__pane{width:100%;height:100%;overflow:hidden}.splitpanes--vertical .splitpanes__pane{transition:width .2s ease-out;will-change:width}.splitpanes--horizontal .splitpanes__pane{transition:height .2s ease-out;will-change:height}.splitpanes--dragging .splitpanes__pane{transition:none}.splitpanes__splitter{touch-action:none}.splitpanes--vertical>.splitpanes__splitter{min-width:1px;cursor:col-resize}.splitpanes--horizontal>.splitpanes__splitter{min-height:1px;cursor:row-resize}.default-theme.splitpanes .splitpanes__pane{background-color:#f2f2f2}.default-theme.splitpanes .splitpanes__splitter{background-color:#fff;box-sizing:border-box;position:relative;flex-shrink:0}.default-theme.splitpanes .splitpanes__splitter:before,.default-theme.splitpanes .splitpanes__splitter:after{content:"";position:absolute;top:50%;left:50%;background-color:#00000026;transition:background-color .3s}.default-theme.splitpanes .splitpanes__splitter:hover:before,.default-theme.splitpanes .splitpanes__splitter:hover:after{background-color:#00000040}.default-theme.splitpanes .splitpanes__splitter:first-child{cursor:auto}.default-theme.splitpanes .splitpanes .splitpanes__splitter{z-index:1}.default-theme.splitpanes--vertical>.splitpanes__splitter,.default-theme .splitpanes--vertical>.splitpanes__splitter{width:7px;border-left:1px solid #eee;margin-left:-1px}.default-theme.splitpanes--vertical>.splitpanes__splitter:before,.default-theme.splitpanes--vertical>.splitpanes__splitter:after,.default-theme .splitpanes--vertical>.splitpanes__splitter:before,.default-theme .splitpanes--vertical>.splitpanes__splitter:after{transform:translateY(-50%);width:1px;height:30px}.default-theme.splitpanes--vertical>.splitpanes__splitter:before,.default-theme .splitpanes--vertical>.splitpanes__splitter:before{margin-left:-2px}.default-theme.splitpanes--vertical>.splitpanes__splitter:after,.default-theme .splitpanes--vertical>.splitpanes__splitter:after{margin-left:1px}.default-theme.splitpanes--horizontal>.splitpanes__splitter,.default-theme .splitpanes--horizontal>.splitpanes__splitter{height:7px;border-top:1px solid #eee;margin-top:-1px}.default-theme.splitpanes--horizontal>.splitpanes__splitter:before,.default-theme.splitpanes--horizontal>.splitpanes__splitter:after,.default-theme .splitpanes--horizontal>.splitpanes__splitter:before,.default-theme .splitpanes--horizontal>.splitpanes__splitter:after{transform:translate(-50%);width:30px;height:1px}.default-theme.splitpanes--horizontal>.splitpanes__splitter:before,.default-theme .splitpanes--horizontal>.splitpanes__splitter:before{margin-top:-2px}.default-theme.splitpanes--horizontal>.splitpanes__splitter:after,.default-theme .splitpanes--horizontal>.splitpanes__splitter:after{margin-top:1px}
/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-4d22a675] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.app-navigation-caption[data-v-4d22a675] {
  display: flex;
  justify-content: space-between;
}
.app-navigation-caption--heading[data-v-4d22a675] {
  padding: var(--app-navigation-padding);
}
.app-navigation-caption--heading[data-v-4d22a675]:not(:first-child):not(:last-child) {
  padding: 0 var(--app-navigation-padding);
}
.app-navigation-caption__name[data-v-4d22a675] {
  font-weight: bold;
  color: var(--color-main-text);
  font-size: var(--default-font-size);
  line-height: var(--default-clickable-area);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  box-shadow: none !important;
  flex-shrink: 0;
  padding-block: 0;
  padding-inline: calc(var(--default-grid-baseline, 4px) * 2) 0;
  margin-top: 0px;
  margin-bottom: var(--default-grid-baseline);
}
.app-navigation-caption__actions[data-v-4d22a675] {
  flex: 0 0 var(--default-clickable-area);
}
.app-navigation-caption[data-v-4d22a675]:not(:first-child) {
  margin-top: calc(var(--default-clickable-area) / 2);
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-938dadb1] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.app-navigation-entry__icon-bullet[data-v-938dadb1] {
  display: block;
  padding: calc((var(--default-clickable-area) - 16px) / 2 + 1px);
}
.app-navigation-entry__icon-bullet div[data-v-938dadb1] {
  width: 14px;
  height: 14px;
  cursor: pointer;
  transition: background 100ms ease-in-out;
  border: none;
  border-radius: 50%;
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-489f71a9] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}

/**
 * SPDX-FileCopyrightText: 2023 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
.app-navigation-entry[data-v-489f71a9] {
  position: relative;
  display: flex;
  flex-shrink: 0;
  flex-wrap: wrap;
  width: 100%;
  min-height: var(--default-clickable-area);
  transition: background-color var(--animation-quick) ease-in-out;
  transition: background-color 200ms ease-in-out;
  border-radius: var(--border-radius-element);
  /* hide deletion/collapse of subitems */
}
.app-navigation-entry-wrapper[data-v-489f71a9] {
  position: relative;
  display: flex;
  flex-shrink: 0;
  flex-wrap: wrap;
  width: 100%;
}
.app-navigation-entry-wrapper.app-navigation-entry--collapsible:not(.app-navigation-entry--opened) > ul[data-v-489f71a9] {
  display: none;
}
.app-navigation-entry.active[data-v-489f71a9] {
  background-color: var(--color-primary-element) !important;
}
.app-navigation-entry.active[data-v-489f71a9]:hover {
  background-color: var(--color-primary-element-hover) !important;
}
.app-navigation-entry.active .app-navigation-entry-link[data-v-489f71a9], .app-navigation-entry.active .app-navigation-entry-button[data-v-489f71a9] {
  color: var(--color-primary-element-text) !important;
}
.app-navigation-entry[data-v-489f71a9]:focus-within, .app-navigation-entry[data-v-489f71a9]:hover {
  background-color: var(--color-background-hover);
}
.app-navigation-entry.active .app-navigation-entry__children[data-v-489f71a9], .app-navigation-entry:focus-within .app-navigation-entry__children[data-v-489f71a9], .app-navigation-entry:hover .app-navigation-entry__children[data-v-489f71a9] {
  background-color: var(--color-main-background);
}
.app-navigation-entry.active .app-navigation-entry__utils .app-navigation-entry__actions[data-v-489f71a9], .app-navigation-entry.app-navigation-entry--deleted .app-navigation-entry__utils .app-navigation-entry__actions[data-v-489f71a9], .app-navigation-entry:focus .app-navigation-entry__utils .app-navigation-entry__actions[data-v-489f71a9], .app-navigation-entry:focus-within .app-navigation-entry__utils .app-navigation-entry__actions[data-v-489f71a9], .app-navigation-entry:hover .app-navigation-entry__utils .app-navigation-entry__actions[data-v-489f71a9] {
  display: inline-block;
}
.app-navigation-entry.app-navigation-entry--deleted > ul[data-v-489f71a9] {
  display: none;
}
.app-navigation-entry:not(.app-navigation-entry--editing) .app-navigation-entry-link[data-v-489f71a9], .app-navigation-entry:not(.app-navigation-entry--editing) .app-navigation-entry-button[data-v-489f71a9] {
  padding-inline-end: calc((var(--default-clickable-area) - 16px) / 2);
}
.app-navigation-entry .app-navigation-entry-link[data-v-489f71a9], .app-navigation-entry .app-navigation-entry-button[data-v-489f71a9] {
  z-index: 100; /* above the bullet to allow click*/
  display: flex;
  overflow: hidden;
  flex: 1 1 0;
  min-height: var(--default-clickable-area);
  padding: 0;
  white-space: nowrap;
  color: var(--color-main-text);
  background-repeat: no-repeat;
  background-position: calc((var(--default-clickable-area) - 16px) / 2) center;
  background-size: 16px 16px;
  line-height: var(--default-clickable-area);
}
.app-navigation-entry .app-navigation-entry-link .app-navigation-entry-icon[data-v-489f71a9], .app-navigation-entry .app-navigation-entry-button .app-navigation-entry-icon[data-v-489f71a9] {
  display: flex;
  align-items: center;
  flex: 0 0 var(--default-clickable-area);
  justify-content: center;
  width: var(--default-clickable-area);
  height: var(--default-clickable-area);
  background-size: 16px 16px;
  background-repeat: no-repeat;
  background-position: calc((var(--default-clickable-area) - 16px) / 2) center;
}
.app-navigation-entry .app-navigation-entry-link .app-navigation-entry__name[data-v-489f71a9], .app-navigation-entry .app-navigation-entry-button .app-navigation-entry__name[data-v-489f71a9] {
  overflow: hidden;
  max-width: 100%;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.app-navigation-entry .app-navigation-entry-link .editingContainer[data-v-489f71a9], .app-navigation-entry .app-navigation-entry-button .editingContainer[data-v-489f71a9] {
  width: calc(100% - var(--default-clickable-area));
  margin: auto;
}
.app-navigation-entry .app-navigation-entry-link[data-v-489f71a9]:focus-visible, .app-navigation-entry .app-navigation-entry-button[data-v-489f71a9]:focus-visible {
  box-shadow: 0 0 0 4px var(--color-main-background);
  outline: 2px solid var(--color-main-text);
  border-radius: var(--border-radius-element);
}

/* Second level nesting for lists */
.app-navigation-entry__children[data-v-489f71a9] {
  --app-navigation-item-child-offset: 10px;
  position: relative;
  display: flex;
  flex: 0 1 auto;
  flex-direction: column;
  width: 100%;
  gap: var(--default-grid-baseline, 4px);
  padding-inline-start: var(--app-navigation-item-child-offset);
}
.app-navigation-entry__children .app-navigation-entry[data-v-489f71a9] {
  display: inline-flex;
  flex-wrap: wrap;
}
.app-navigation-entry__children .app-navigation-entry__children .app-navigation-entry__children .app-navigation-entry__children .app-navigation-entry__children .app-navigation-entry__children .app-navigation-entry__children[data-v-489f71a9] {
  --app-navigation-item-child-offset: 0;
}

/* Deleted entries */
.app-navigation-entry__deleted[data-v-489f71a9] {
  display: inline-flex;
  flex: 1 1 0;
  padding-inline-start: calc(var(--default-clickable-area) - (var(--default-clickable-area) - 16px) / 2) !important;
}
.app-navigation-entry__deleted .app-navigation-entry__deleted-description[data-v-489f71a9] {
  position: relative;
  overflow: hidden;
  flex: 1 1 0;
  white-space: nowrap;
  text-overflow: ellipsis;
  line-height: var(--default-clickable-area);
}

/* counter and actions */
.app-navigation-entry__utils[data-v-489f71a9] {
  display: flex;
  min-width: var(--default-clickable-area);
  align-items: center;
  flex: 0 1 auto;
  justify-content: flex-end;
  /* counter */
  /* actions */
}
.app-navigation-entry__utils.app-navigation-entry__utils--display-actions .action-item.app-navigation-entry__actions[data-v-489f71a9] {
  display: inline-block;
}
.app-navigation-entry__utils .app-navigation-entry__counter-wrapper[data-v-489f71a9] {
  margin-inline-end: calc(var(--default-grid-baseline) * 2);
  display: flex;
  align-items: center;
  flex: 0 1 auto;
}
.app-navigation-entry__utils .action-item.app-navigation-entry__actions[data-v-489f71a9] {
  display: none;
}

/* editing state */
.app-navigation-entry--editing .app-navigation-entry-edit[data-v-489f71a9] {
  z-index: 250;
  opacity: 1;
}

/* deleted state */
.app-navigation-entry--deleted .app-navigation-entry-deleted[data-v-489f71a9] {
  z-index: 250;
  transform: translateX(0);
}

/* pinned state */
.app-navigation-entry--pinned[data-v-489f71a9] {
  order: 2;
  margin-top: auto;
}
.app-navigation-entry--pinned ~ .app-navigation-entry--pinned[data-v-489f71a9] {
  margin-top: 0;
}
[data-themes*=highcontrast] .app-navigation-entry[data-v-489f71a9]:active {
  background-color: var(--color-primary-element-light-hover) !important;
}
.app-navigation-new-item__name[data-v-489f71a9] {
  overflow: hidden;
  max-width: 100%;
  white-space: nowrap;
  text-overflow: ellipsis;
  padding-inline-start: 7px;
  font-size: 14px;
}
.newItemContainer[data-v-489f71a9] {
  width: calc(100% - var(--default-clickable-area));
  margin: auto;
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-26ea0724] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.app-navigation-search[data-v-26ea0724] {
  display: flex;
  gap: var(--app-navigation-padding);
  padding: var(--app-navigation-padding);
}
.app-navigation-search--has-actions .app-navigation-search__input[data-v-26ea0724] {
  flex-grow: 1;
  z-index: 3;
}
.app-navigation-search__actions[data-v-26ea0724] {
  display: flex;
  gap: var(--default-grid-baseline);
  margin-inline-start: 0;
  max-width: calc(2 * var(--default-clickable-area) + var(--default-grid-baseline));
  max-height: var(--default-clickable-area);
  transition: margin-inline-start var(--animation-quick);
}
.app-navigation-search__actions--hidden[data-v-26ea0724] {
  margin-inline-start: calc(-1 * var(--default-clickable-area));
}
._container_svdcj_2 {
	margin-top: auto;
	padding: var(--default-grid-baseline);
}
._header_svdcj_7 {
	margin-block: 0 var(--default-grid-baseline);
	margin-inline: var(--default-grid-baseline);
}

/* Overwrite the padding to match NcAppNavigationItem */
._button_svdcj_13 {
	padding-left: 0 !important;
	padding-inline-end: calc((var(--default-clickable-area) - 16px) / 2) !important;
.button-vue__text {
		font-weight: normal;
}
}
._content_svdcj_22 {
	display: block;
	padding: 10px;

	/* prevent scrolled contents from stopping too early */
	margin-bottom: calc(-1 * var(--default-grid-baseline));

	/* restrict height of settings and make scrollable */
	max-height: 300px;
	overflow-y: auto;
}
._animationActive_svdcj_34 {
	transition-duration: var(--animation-slow);
	transition-property: max-height, padding;
	overflow-y: hidden !important;
}
._animationStop_svdcj_40 {
	max-height: 0 !important;
	padding: 0 10px !important;
}

.app-navigation-spacer[data-v-277fa710] {
		flex-shrink: 0;
		height: 22px;
}

/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-92616d32] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
[data-v-92616d32] .app-settings__navigation {
  min-width: 200px;
  margin-inline-end: calc(4 * var(--default-grid-baseline));
  overflow-x: hidden;
  overflow-y: auto;
  position: relative;
}
[data-v-92616d32] .app-settings__content {
  padding-inline: calc(4 * var(--default-grid-baseline));
}
.navigation-list[data-v-92616d32] {
  height: 100%;
  overflow-y: auto;
  padding: calc(3 * var(--default-grid-baseline));
}
.navigation-list__link[data-v-92616d32] {
  display: flex;
  align-content: center;
  font-size: 16px;
  height: var(--default-clickable-area);
  margin: 4px 0;
  line-height: var(--default-clickable-area);
  border-radius: var(--border-radius-element);
  font-weight: bold;
  padding: 0 calc(4 * var(--default-grid-baseline));
  cursor: pointer;
  white-space: nowrap;
  text-overflow: ellipsis;
  overflow: hidden;
  background-color: transparent;
  border: none;
}
.navigation-list__link[data-v-92616d32]:hover, .navigation-list__link[data-v-92616d32]:focus {
  background-color: var(--color-background-hover);
}
.navigation-list__link--active[data-v-92616d32] {
  background-color: var(--color-primary-element-light) !important;
}
.navigation-list__link--icon[data-v-92616d32] {
  padding-inline-start: calc(2 * var(--default-grid-baseline));
  gap: var(--default-grid-baseline);
}
.navigation-list__link-icon[data-v-92616d32] {
  display: flex;
  justify-content: center;
  align-content: center;
  width: calc(var(--default-clickable-area) - 2 * var(--default-grid-baseline));
  max-width: calc(var(--default-clickable-area) - 2 * var(--default-grid-baseline));
}
@media only screen and (max-width: 512px) {
.app-settings[data-v-92616d32] .dialog__name {
    padding-inline-start: 16px;
}
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-ce8fac13] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.app-settings-section[data-v-ce8fac13] {
  margin-bottom: 80px;
}
.app-settings-section__name[data-v-ce8fac13] {
  font-size: 1.6em;
  margin: 0;
  padding: 20px 0;
  font-weight: bold;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-9a713930] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.app-sidebar-tabs[data-v-9a713930] {
  display: flex;
  flex-direction: column;
  min-height: 0;
  flex: 1 1 100%;
}
.app-sidebar-tabs__nav[data-v-9a713930] {
  display: flex;
  justify-content: stretch;
  margin: 10px 8px 0 8px;
  border-bottom: 1px solid var(--color-border);
}
.app-sidebar-tabs__nav[data-v-9a713930] .checkbox-radio-switch--button-variant {
  border: unset !important;
  border-radius: 0 !important;
}
.app-sidebar-tabs__nav[data-v-9a713930] .checkbox-radio-switch--button-variant .checkbox-content {
  padding: var(--default-grid-baseline);
  border-radius: var(--default-grid-baseline) var(--default-grid-baseline) 0 0 !important;
  margin: 0 !important;
  border-bottom: var(--default-grid-baseline) solid transparent !important;
}
.app-sidebar-tabs__nav[data-v-9a713930] .checkbox-radio-switch--button-variant .checkbox-content .checkbox-content__icon > * {
  color: var(--color-main-text) !important;
}
.app-sidebar-tabs__nav[data-v-9a713930] .checkbox-radio-switch--button-variant.checkbox-radio-switch--checked .checkbox-radio-switch__content {
  background: transparent !important;
  color: var(--color-main-text) !important;
  border-bottom: var(--default-grid-baseline) solid var(--color-primary-element) !important;
}
.app-sidebar-tabs__tab[data-v-9a713930] {
  flex: 1 1;
}
.app-sidebar-tabs__tab.active[data-v-9a713930] {
  color: var(--color-primary-element);
}
.app-sidebar-tabs__tab-caption[data-v-9a713930] {
  flex: 0 1 100%;
  width: 100%;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  text-align: center;
}
.app-sidebar-tabs__tab-icon[data-v-9a713930] {
  display: flex;
  align-items: center;
  justify-content: center;
  background-size: 20px;
}
.app-sidebar-tabs__tab[data-v-9a713930] .checkbox-radio-switch__content {
  max-width: unset;
}
.app-sidebar-tabs__content[data-v-9a713930] {
  position: relative;
  min-height: 256px;
  height: 100%;
}
.app-sidebar-tabs__content--multiple[data-v-9a713930] > :not(section) {
  display: none;
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
@property --app-sidebar-offset {
  syntax: "<length>";
  initial-value: 0;
  inherits: true;
}
body {
  /**
   * The padding between the toggle button and the page border
   */
  --app-sidebar-padding: calc(var(--default-grid-baseline, 4px) * 2);
  /**
   * The minimal offset width required to be reserved for the toggle button.
   * Automatically changes to 0 when there is no toggle button.
   */
  --app-sidebar-offset: 0;
  transition: --app-sidebar-offset 0ms !important;
}
body:has(.app-sidebar.slide-right-enter-active),
body:has(.app-sidebar.slide-right-leave-active) {
  transition: --app-sidebar-offset var(--animation-quick);
}
body:has(.app-sidebar__toggle) {
  --app-sidebar-offset: calc(var(--app-sidebar-padding) + var(--default-clickable-area));
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-75d9d903] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}

/*
	Sidebar: to be used within #content
	app-content will be shrinked properly
*/
.app-sidebar[data-v-75d9d903] {
  --app-sidebar-width: clamp(300px, 27vw, 500px);
  --app-sidebar-padding: calc(var(--default-grid-baseline, 4px) * 2);
  width: var(--app-sidebar-width);
  z-index: 1500;
  top: 0;
  inset-inline-end: 0;
  display: flex;
  overflow-x: hidden;
  overflow-y: auto;
  flex-direction: column;
  flex-shrink: 0;
  height: 100%;
  border-inline-start: 1px solid var(--color-border);
  background: var(--color-main-background);
  position: relative;
}
.app-sidebar__toggle[data-v-75d9d903] {
  position: absolute !important;
  inset-block-start: var(--app-sidebar-padding);
  inset-inline-end: var(--app-sidebar-padding);
  z-index: 1001;
}
.app-sidebar .app-sidebar-header[data-v-75d9d903] {
  --app-sidebar-close-button-offset: calc(var(--default-clickable-area) + var(--app-sidebar-padding));
}
.app-sidebar .app-sidebar-header > .app-sidebar__close[data-v-75d9d903] {
  position: absolute;
  z-index: 100;
  top: var(--app-sidebar-padding);
  inset-inline-end: var(--app-sidebar-padding);
  width: var(--default-clickable-area);
  height: var(--default-clickable-area);
}
.app-sidebar .app-sidebar-header--compact.app-sidebar-header--with-figure .app-sidebar-header__info[data-v-75d9d903] {
  flex-direction: row;
}
.app-sidebar .app-sidebar-header--compact.app-sidebar-header--with-figure .app-sidebar-header__info .app-sidebar-header__figure[data-v-75d9d903] {
  --figure-size: calc($desc-height + var(--app-sidebar-padding));
  z-index: 2;
  width: var(--figure-size);
  height: var(--figure-size);
  margin: calc(var(--app-sidebar-padding) / 2);
  border-radius: 3px;
  flex: 0 0 auto;
}
.app-sidebar .app-sidebar-header--compact.app-sidebar-header--with-figure .app-sidebar-header__info .app-sidebar-header__desc[data-v-75d9d903] {
  padding-inline-start: 0;
  flex: 1 1 auto;
  min-width: 0;
  padding-inline-end: calc(var(--default-clickable-area) + var(--app-sidebar-close-button-offset));
  padding-top: var(--app-sidebar-padding);
}
.app-sidebar .app-sidebar-header--compact.app-sidebar-header--with-figure .app-sidebar-header__info .app-sidebar-header__desc.app-sidebar-header__desc--without-actions[data-v-75d9d903] {
  padding-inline-end: var(--app-sidebar-close-button-offset);
}
.app-sidebar .app-sidebar-header--compact.app-sidebar-header--with-figure .app-sidebar-header__info .app-sidebar-header__desc .app-sidebar-header__tertiary-actions[data-v-75d9d903] {
  z-index: 3;
  position: absolute;
  top: calc(var(--app-sidebar-padding) / 2);
  inset-inline-start: calc(-1 * var(--default-clickable-area));
  gap: 0;
}
.app-sidebar .app-sidebar-header--compact.app-sidebar-header--with-figure .app-sidebar-header__info .app-sidebar-header__desc .app-sidebar-header__menu[data-v-75d9d903] {
  top: var(--app-sidebar-padding);
  inset-inline-end: var(--app-sidebar-close-button-offset);
  position: absolute;
}
.app-sidebar .app-sidebar-header:not(.app-sidebar-header--with-figure) .app-sidebar-header__menu[data-v-75d9d903] {
  position: absolute;
  top: var(--app-sidebar-padding);
  inset-inline-end: var(--app-sidebar-close-button-offset);
}
.app-sidebar .app-sidebar-header:not(.app-sidebar-header--with-figure) .app-sidebar-header__desc[data-v-75d9d903] {
  padding-inline-end: calc(var(--default-clickable-area) + var(--app-sidebar-close-button-offset));
}
.app-sidebar .app-sidebar-header:not(.app-sidebar-header--with-figure) .app-sidebar-header__desc.app-sidebar-header__desc--without-actions[data-v-75d9d903] {
  padding-inline-end: var(--app-sidebar-close-button-offset);
}
.app-sidebar .app-sidebar-header .app-sidebar-header__info[data-v-75d9d903] {
  display: flex;
  flex-direction: column;
}
.app-sidebar .app-sidebar-header__figure[data-v-75d9d903] {
  width: 100%;
  height: 250px;
  max-height: 250px;
  background-repeat: no-repeat;
  background-position: center;
  background-size: contain;
}
.app-sidebar .app-sidebar-header__figure--with-action[data-v-75d9d903] {
  cursor: pointer;
}
.app-sidebar .app-sidebar-header__desc[data-v-75d9d903] {
  position: relative;
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  padding-inline: var(--app-sidebar-padding);
  padding-block: var(--app-sidebar-padding) calc(var(--app-sidebar-padding) / 2);
  gap: 0 4px;
}
.app-sidebar .app-sidebar-header__desc--with-tertiary-action[data-v-75d9d903] {
  padding-inline-start: 6px;
}
.app-sidebar .app-sidebar-header__desc--editable .app-sidebar-header__mainname-form[data-v-75d9d903], .app-sidebar .app-sidebar-header__desc--with-subname--editable .app-sidebar-header__mainname-form[data-v-75d9d903] {
  margin-top: -2px;
  margin-bottom: -2px;
}
.app-sidebar .app-sidebar-header__desc--with-subname--editable .app-sidebar-header__subname[data-v-75d9d903] {
  margin-top: -2px;
}
.app-sidebar .app-sidebar-header__desc .app-sidebar-header__tertiary-actions[data-v-75d9d903] {
  display: flex;
  height: var(--default-clickable-area);
  width: var(--default-clickable-area);
  justify-content: center;
  flex: 0 0 auto;
}
.app-sidebar .app-sidebar-header__desc .app-sidebar-header__tertiary-actions .app-sidebar-header__star[data-v-75d9d903] {
  box-shadow: none;
}
.app-sidebar .app-sidebar-header__desc .app-sidebar-header__tertiary-actions .app-sidebar-header__star[data-v-75d9d903]:not([aria-pressed=true]):hover {
  box-shadow: none;
  background-color: var(--color-background-hover);
}
.app-sidebar .app-sidebar-header__desc .app-sidebar-header__name-container[data-v-75d9d903] {
  flex: 1 1 auto;
  display: flex;
  flex-direction: column;
  justify-content: center;
  min-width: 0;
}
.app-sidebar .app-sidebar-header__desc .app-sidebar-header__name-container .app-sidebar-header__mainname-container[data-v-75d9d903] {
  display: flex;
  align-items: center;
  min-height: var(--default-clickable-area);
}
.app-sidebar .app-sidebar-header__desc .app-sidebar-header__name-container .app-sidebar-header__mainname-container .app-sidebar-header__mainname[data-v-75d9d903] {
  padding: 0;
  min-height: 30px;
  font-size: 20px;
  line-height: 30px;
}
.app-sidebar .app-sidebar-header__desc .app-sidebar-header__name-container .app-sidebar-header__mainname-container .app-sidebar-header__mainname[data-v-75d9d903] .linkified {
  cursor: pointer;
  text-decoration: underline;
  margin: 0;
}
.app-sidebar .app-sidebar-header__desc .app-sidebar-header__name-container .app-sidebar-header__mainname-container .app-sidebar-header__mainname-form[data-v-75d9d903] {
  display: flex;
  flex: 1 1 auto;
  align-items: center;
}
.app-sidebar .app-sidebar-header__desc .app-sidebar-header__name-container .app-sidebar-header__mainname-container .app-sidebar-header__mainname-form input.app-sidebar-header__mainname-input[data-v-75d9d903] {
  flex: 1 1 auto;
  margin: 0;
  padding: 7px;
  font-size: 20px;
  font-weight: bold;
}
.app-sidebar .app-sidebar-header__desc .app-sidebar-header__name-container .app-sidebar-header__mainname-container .app-sidebar-header__menu[data-v-75d9d903] {
  margin-inline-start: 5px;
}
.app-sidebar .app-sidebar-header__desc .app-sidebar-header__name-container .app-sidebar-header__mainname[data-v-75d9d903],
.app-sidebar .app-sidebar-header__desc .app-sidebar-header__name-container .app-sidebar-header__subname[data-v-75d9d903] {
  overflow: hidden;
  width: 100%;
  margin: 0;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.app-sidebar .app-sidebar-header__desc .app-sidebar-header__name-container .app-sidebar-header__subname[data-v-75d9d903] {
  color: var(--color-text-maxcontrast);
  font-size: var(--default-font-size);
  padding: 0;
}
.app-sidebar .app-sidebar-header__desc .app-sidebar-header__name-container .app-sidebar-header__subname[data-v-75d9d903] * {
  vertical-align: text-bottom;
}
.app-sidebar .app-sidebar-header .app-sidebar-header__mainname--hidden[data-v-75d9d903] {
  position: absolute;
  top: 0;
  inset-inline-start: 0;
  margin: 0;
  width: 1px;
  height: 1px;
  overflow: hidden;
}
.app-sidebar .app-sidebar-header__description[data-v-75d9d903] {
  display: flex;
  align-items: center;
  margin: 0 10px;
}
@media only screen and (max-width: 512px) {
.app-sidebar[data-v-75d9d903] {
    position: absolute;
    --app-sidebar-width: 100vw;
}
}
.slide-right-leave-active[data-v-75d9d903],
.slide-right-enter-active[data-v-75d9d903] {
  transition-duration: var(--animation-quick);
  transition-property: margin-inline-end;
}
.slide-right-enter-to[data-v-75d9d903],
.slide-right-leave[data-v-75d9d903] {
  margin-inline-end: 0;
}
.slide-right-enter-from[data-v-75d9d903],
.slide-right-leave-to[data-v-75d9d903] {
  margin-inline-end: calc(-1 * var(--app-sidebar-width));
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-9d737d13] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.app-sidebar__tab[data-v-9d737d13] {
  display: none;
  padding: 10px;
  min-height: 100%;
  max-height: 100%;
  height: 100%;
  overflow: auto;
}
.app-sidebar__tab[data-v-9d737d13]:focus {
  border-color: var(--color-primary-element);
  box-shadow: 0 0 0.2em var(--color-primary-element);
  outline: 0;
}
.app-sidebar__tab--active[data-v-9d737d13] {
  display: block;
}
._fadeTransition_13rtj_2 {
	transition: all var(--animation-quick) ease;
}
._fadeTransitionActive_13rtj_6 {
	opacity: 0;
	position: absolute;
}
/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-01b9af70] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.vue-crumb[data-v-01b9af70] {
  background-image: none;
  display: inline-flex;
  height: var(--default-clickable-area);
  padding: 0;
}
.vue-crumb[data-v-01b9af70]:last-child {
  min-width: 0;
}
.vue-crumb:last-child .vue-crumb__separator[data-v-01b9af70] {
  display: none;
}
.vue-crumb--hidden[data-v-01b9af70] {
  display: none;
}
.vue-crumb__separator[data-v-01b9af70] {
  padding: 0;
  color: var(--color-text-maxcontrast);
}
.vue-crumb.vue-crumb--hovered[data-v-01b9af70] .button-vue {
  background-color: var(--color-background-dark);
  color: var(--color-main-text);
}
.vue-crumb[data-v-01b9af70]:not(:last-child)  .button-vue {
  color: var(--color-text-maxcontrast);
}
.vue-crumb[data-v-01b9af70]:not(:last-child)  .button-vue:hover, .vue-crumb[data-v-01b9af70]:not(:last-child)  .button-vue:focus {
  background-color: var(--color-background-dark);
  color: var(--color-main-text);
}
.vue-crumb[data-v-01b9af70]:not(:last-child)  .button-vue__text {
  font-weight: normal;
}
.vue-crumb[data-v-01b9af70] .button-vue__text {
  margin: 0;
}
.vue-crumb[data-v-01b9af70]:not(.dropdown) .action-item {
  max-width: 100%;
}
.vue-crumb[data-v-01b9af70]:not(.dropdown) .action-item .button-vue {
  padding: 0 4px 0 16px;
  max-width: 100%;
}
.vue-crumb[data-v-01b9af70]:not(.dropdown) .action-item .button-vue__wrapper {
  flex-direction: row-reverse;
}
.vue-crumb[data-v-01b9af70]:not(.dropdown) .action-item.action-item--open .action-item__menutoggle {
  background-color: var(--color-background-dark);
  color: var(--color-main-text);
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-b3c47ad6] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.breadcrumb[data-v-b3c47ad6] {
  width: 100%;
  flex-grow: 1;
  display: inline-flex;
  align-items: center;
}
.breadcrumb--collapsed[data-v-b3c47ad6] .vue-crumb:last-child {
  min-width: 100px;
}
.breadcrumb nav[data-v-b3c47ad6] {
  flex-shrink: 1;
  min-width: 0;
}
.breadcrumb .breadcrumb__crumbs[data-v-b3c47ad6] {
  max-width: 100%;
}
.breadcrumb .breadcrumb__crumbs[data-v-b3c47ad6], .breadcrumb .breadcrumb__actions[data-v-b3c47ad6] {
  display: inline-flex;
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-2a555c9b] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.nc-chip[data-v-2a555c9b] {
  --chip-size: 24px;
  --chip-radius: calc(var(--chip-size) / 2);
  height: var(--chip-size);
  max-width: fit-content;
  display: flex;
  flex-direction: row;
  align-items: center;
  border-radius: var(--chip-radius);
  background-color: var(--color-background-hover);
}
.nc-chip--primary[data-v-2a555c9b] {
  background-color: var(--color-primary-element);
  color: var(--color-primary-element-text);
}
.nc-chip--secondary[data-v-2a555c9b] {
  background-color: var(--color-primary-element-light);
  color: var(--color-primary-element-light-text);
}
.nc-chip--no-actions .nc-chip__text[data-v-2a555c9b] {
  padding-inline-end: calc(1.5 * var(--default-grid-baseline));
}
.nc-chip--no-icon .nc-chip__text[data-v-2a555c9b] {
  padding-inline-start: calc(1.5 * var(--default-grid-baseline));
}
.nc-chip__text[data-v-2a555c9b] {
  flex: 1 auto;
  overflow: hidden;
  text-overflow: ellipsis;
  text-wrap: nowrap;
}
.nc-chip__icon[data-v-2a555c9b] {
  flex: 0 0 var(--chip-size);
  margin-inline-end: var(--default-grid-baseline);
  line-height: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  height: var(--chip-size);
  width: var(--chip-size);
}
.nc-chip__actions[data-v-2a555c9b] {
  flex: 0 0 var(--chip-size);
  --default-clickable-area: var(--chip-size);
  --border-radius-element: var(--chip-radius);
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-8f8504e3] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.fade-enter-active[data-v-8f8504e3], .fade-leave-active[data-v-8f8504e3] {
  transition: opacity 0.3s ease;
}
.fade-enter[data-v-8f8504e3], .fade-leave-to[data-v-8f8504e3] {
  opacity: 0;
}
.linked-icons[data-v-8f8504e3] {
  display: flex;
}
.linked-icons img[data-v-8f8504e3] {
  padding: 12px;
  height: var(--default-clickable-area);
  display: block;
  background-repeat: no-repeat;
  background-position: center;
  opacity: 0.7;
}
.linked-icons img[data-v-8f8504e3]:hover {
  opacity: 1;
}
.popovermenu[data-v-8f8504e3] {
  display: none;
}
.popovermenu.open[data-v-8f8504e3] {
  display: block;
}
li.collection-list-item[data-v-8f8504e3] {
  flex-wrap: wrap;
  height: auto;
  cursor: pointer;
  margin-bottom: 0 !important;
}
li.collection-list-item .collection-avatar[data-v-8f8504e3] {
  margin-top: 0;
}
li.collection-list-item form[data-v-8f8504e3], li.collection-list-item .collection-item-name[data-v-8f8504e3] {
  flex-basis: 10%;
  flex-grow: 1;
  display: flex;
}
li.collection-list-item .collection-item-name[data-v-8f8504e3] {
  padding: 12px 9px;
}
li.collection-list-item input[data-v-8f8504e3] {
  margin-top: 4px;
  border-color: var(--color-border-maxcontrast);
}
li.collection-list-item input[type=text][data-v-8f8504e3] {
  flex-grow: 1;
}
li.collection-list-item .error[data-v-8f8504e3] {
  flex-basis: 100%;
  width: 100%;
}
li.collection-list-item .resource-list-details[data-v-8f8504e3] {
  flex-basis: 100%;
  width: 100%;
}
li.collection-list-item .resource-list-details li[data-v-8f8504e3] {
  display: flex;
  margin-inline-start: var(--default-clickable-area);
  border-radius: 3px;
  cursor: pointer;
}
li.collection-list-item .resource-list-details li[data-v-8f8504e3]:hover {
  background-color: var(--color-background-dark);
}
li.collection-list-item .resource-list-details li a[data-v-8f8504e3] {
  flex-grow: 1;
  padding: 3px;
  max-width: calc(100% - 30px);
  display: flex;
}
li.collection-list-item .resource-list-details span[data-v-8f8504e3] {
  display: inline-block;
  vertical-align: top;
  margin-inline-end: 10px;
}
li.collection-list-item .resource-list-details span.resource-name[data-v-8f8504e3] {
  text-overflow: ellipsis;
  overflow: hidden;
  position: relative;
  vertical-align: top;
  white-space: nowrap;
  flex-grow: 1;
  padding: 4px;
}
li.collection-list-item .resource-list-details img[data-v-8f8504e3] {
  width: 24px;
  height: 24px;
}
li.collection-list-item .resource-list-details .icon-close[data-v-8f8504e3] {
  opacity: 0.7;
}
li.collection-list-item .resource-list-details .icon-close[data-v-8f8504e3]:hover, li.collection-list-item .resource-list-details .icon-close[data-v-8f8504e3]:focus {
  opacity: 1;
}
.should-shake[data-v-8f8504e3] {
  animation: shake-8f8504e3 0.6s 1 linear;
}
@keyframes shake-8f8504e3 {
0% {
    transform: translate(15px);
}
20% {
    transform: translate(-15px);
}
40% {
    transform: translate(7px);
}
60% {
    transform: translate(-7px);
}
80% {
    transform: translate(3px);
}
100% {
    transform: translate(0px);
}
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-a28f0c9a] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.collection-list[data-v-a28f0c9a] * {
  box-sizing: border-box;
}
.collection-list > li[data-v-a28f0c9a] {
  display: flex;
  align-items: center;
  gap: 12px;
}
.collection-list > li > .avatar[data-v-a28f0c9a] {
  margin-top: 0;
}
#collection-select-container[data-v-a28f0c9a] {
  display: flex;
  flex-direction: column;
}
.v-select span.avatar[data-v-a28f0c9a] {
  display: block;
  padding: 16px;
  opacity: 0.7;
  background-repeat: no-repeat;
  background-position: center;
}
.v-select span.avatar[data-v-a28f0c9a]:hover {
  opacity: 1;
}
p.hint[data-v-a28f0c9a] {
  z-index: 1;
  margin-top: -16px;
  padding: 8px 8px;
  color: var(--color-text-maxcontrast);
  line-height: normal;
}
div.avatar[data-v-a28f0c9a] {
  width: 32px;
  height: 32px;
  margin: 0;
  padding: 8px;
  background-color: var(--color-background-dark);
  margin-top: 30px;
}

/** TODO provide white icon in core */
.icon-projects[data-v-a28f0c9a] {
  display: block;
  padding: 8px;
  background-repeat: no-repeat;
  background-position: center;
}
.option__wrapper[data-v-a28f0c9a] {
  display: flex;
}
.option__wrapper .avatar[data-v-a28f0c9a] {
  display: block;
  width: 32px;
  height: 32px;
  background-color: var(--color-background-darker) !important;
}
.option__wrapper .option__title[data-v-a28f0c9a] {
  padding: 4px;
}
.fade-enter-active[data-v-a28f0c9a], .fade-leave-active[data-v-a28f0c9a] {
  transition: opacity 0.5s;
}
.fade-enter[data-v-a28f0c9a], .fade-leave-to[data-v-a28f0c9a] {
  opacity: 0;
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-3ec4b698] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.color-picker[data-v-3ec4b698] {
  display: flex;
  overflow: hidden;
  align-content: flex-end;
  flex-direction: column;
  justify-content: space-between;
  width: 176px;
  padding: 8px;
  border-radius: 3px;
}
.color-picker--advanced-fields[data-v-3ec4b698] {
  width: 264px;
}
.color-picker__simple[data-v-3ec4b698] {
  display: grid;
  grid-template-columns: repeat(auto-fit, var(--default-clickable-area));
  grid-auto-rows: var(--default-clickable-area);
}
.color-picker__simple-color-circle[data-v-3ec4b698] {
  display: flex;
  align-items: center;
  justify-content: center;
  width: calc(var(--default-clickable-area) - 10px);
  height: calc(var(--default-clickable-area) - 10px);
  min-height: calc(var(--default-clickable-area) - 10px);
  margin: auto;
  padding: 0;
  color: white;
  border: 1px solid rgba(0, 0, 0, 0.25);
  border-radius: 50%;
  font-size: 16px;
}
.color-picker__simple-color-circle[data-v-3ec4b698]:focus-within {
  outline: 2px solid var(--color-main-text);
}
.color-picker__simple-color-circle[data-v-3ec4b698]:hover {
  opacity: 0.6;
}
.color-picker__simple-color-circle--active[data-v-3ec4b698] {
  width: calc(var(--default-clickable-area) - 6px);
  height: calc(var(--default-clickable-area) - 6px);
  min-height: calc(var(--default-clickable-area) - 6px);
  transition: all 100ms ease-in-out;
  opacity: 1 !important;
}
.color-picker__advanced[data-v-3ec4b698] {
  box-shadow: none !important;
}
.color-picker__navigation[data-v-3ec4b698] {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  margin-top: 10px;
}
[data-v-3ec4b698]  .vc-chrome {
  width: unset;
  background-color: var(--color-main-background);
}
[data-v-3ec4b698]  .vc-chrome-color-wrap {
  width: 30px;
  height: 30px;
}
[data-v-3ec4b698]  .vc-chrome-active-color {
  border-radius: 17px;
}
[data-v-3ec4b698]  .vc-chrome-body {
  padding: 14px 0 0 0;
  background-color: var(--color-main-background);
}
[data-v-3ec4b698]  .vc-chrome-body .vc-input__input {
  --input-border-radius: var(--border-radius-element);
  --input-border-width-offset: calc(var(--border-width-input-focused, 2px) - var(--border-width-input, 2px));
  width: 100%;
  height: var(--default-clickable-area);
  margin: 0;
  padding-inline: calc(var(--border-radius-element) + var(--input-border-width-offset));
  padding-block: var(--input-border-width-offset);
  border: var(--border-width-input, 2px) solid var(--color-border-maxcontrast);
  border-radius: var(--input-border-radius);
  font-size: var(--default-font-size);
  color: var(--color-main-text);
  box-shadow: none;
}
[data-v-3ec4b698]  .vc-chrome-body .vc-input__input:active:not([disabled]),[data-v-3ec4b698]  .vc-chrome-body .vc-input__input:hover:not([disabled]),[data-v-3ec4b698]  .vc-chrome-body .vc-input__input:focus:not([disabled]) {
  --input-border-width-offset: 0px;
  border-color: var(--color-main-text);
  border-width: var(--border-width-input-focused, 2px);
  box-shadow: 0 0 0 2px var(--color-main-background) !important;
}
[data-v-3ec4b698]  .vc-chrome-body .vc-input__input:active:not([disabled]) + .vc-input__label,[data-v-3ec4b698]  .vc-chrome-body .vc-input__input:hover:not([disabled]) + .vc-input__label,[data-v-3ec4b698]  .vc-chrome-body .vc-input__input:focus:not([disabled]) + .vc-input__label {
  color: var(--color-main-text);
}
[data-v-3ec4b698]  .vc-chrome-body .vc-input__label {
  position: absolute;
  inset-inline: var(--border-width-input-focused, 2px);
  inset-block-start: calc(-1.5 * var(--font-size-small, 13px) / 2);
  max-width: fit-content;
  margin-inline: calc(var(--border-radius-element) - var(--default-grid-baseline));
  margin-block: 0;
  padding-inline: var(--default-grid-baseline);
  font-family: var(--font-face);
  font-size: var(--font-size-small, 13px);
  line-height: 1.5;
  font-weight: 500;
  color: var(--color-text-maxcontrast);
  background-color: var(--color-main-background);
  pointer-events: none;
}
[data-v-3ec4b698]  .vc-chrome-toggle-btn {
  display: flex;
  justify-content: center;
  align-items: center;
  width: var(--default-clickable-area);
  height: var(--default-clickable-area);
  margin-inline-start: 6px;
  filter: var(--background-invert-if-dark);
}
[data-v-3ec4b698]  .vc-chrome-toggle-icon {
  width: 24px;
  height: 24px;
  margin: 0;
}
[data-v-3ec4b698]  .vc-chrome-toggle-icon-highlight {
  width: var(--default-clickable-area);
  height: var(--default-clickable-area);
  inset: 0;
}
[data-v-3ec4b698]  .vc-chrome-saturation-wrap {
  border-radius: 3px;
}
[data-v-3ec4b698]  .vc-chrome-saturation-circle {
  width: 20px;
  height: 20px;
}
.slide-enter-from[data-v-3ec4b698] {
  transform: translateX(-50%);
  opacity: 0;
}
.slide-enter-to[data-v-3ec4b698] {
  transform: translateX(0);
  opacity: 1;
}
.slide-leave-from[data-v-3ec4b698] {
  transform: translateX(0);
  opacity: 1;
}
.slide-leave-to[data-v-3ec4b698] {
  transform: translateX(-50%);
  opacity: 0;
}
.slide-enter-active[data-v-3ec4b698], .slide-leave-active[data-v-3ec4b698] {
  transition: all 50ms ease-in-out;
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
#skip-actions.vue-skip-actions:focus-within {
  top: 0 !important;
  inset-inline-start: 0 !important;
  width: 100vw;
  height: 100vh;
  padding: var(--body-container-margin) !important;
  backdrop-filter: brightness(50%);
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-225e6d1b] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.vue-skip-actions__container[data-v-225e6d1b] {
  background-color: var(--color-main-background);
  border-radius: var(--border-radius-element);
  padding: 22px;
}
.vue-skip-actions__headline[data-v-225e6d1b] {
  font-weight: bold;
  font-size: 20px;
  line-height: 30px;
  margin-bottom: 12px;
}
.vue-skip-actions__buttons[data-v-225e6d1b] {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
}
.vue-skip-actions__buttons[data-v-225e6d1b] > * {
  flex: 1 0 fit-content;
}
.vue-skip-actions__image[data-v-225e6d1b] {
  margin-top: 12px;
}
.vue-skip-actions__image[data-v-225e6d1b]:dir(rtl) {
  transform: rotateY(180deg);
}
.content[data-v-225e6d1b] {
  display: flex;
  width: calc(100% - var(--body-container-margin) * 2);
  border-radius: var(--body-container-radius);
  height: var(--body-height);
  overflow: hidden;
  padding: 0;
}
.content[data-v-225e6d1b]:not(.with-sidebar--full) {
  position: fixed;
}
.content[data-v-225e6d1b], .content[data-v-225e6d1b] * {
  box-sizing: border-box;
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-27474da0] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.vue-date-time-picker__wrapper[data-v-27474da0] {
  --dp-common-transition: all var(--animation-quick) ease-in;
  --dp-menu-padding: 6px 8px;
  --dp-animation-duration: var(--animation-quick);
  --dp-menu-appear-transition-timing: cubic-bezier(.4, 0, 1, 1);
  --dp-transition-timing: ease-out;
  --dp-action-row-transtion: all 0.2s ease-in;
  --dp-font-family: var(--font-face);
  --dp-border-radius: var(--border-radius-element);
  --dp-cell-border-radius: var(--border-radius-small);
  --dp-transition-length: 22px;
  --dp-transition-timing-general: var(--animation-quick);
  --dp-button-height: var(--default-clickable-area);
  --dp-month-year-row-height: var(--default-clickable-area);
  --dp-month-year-row-button-size: var(--clickable-area-small);
  --dp-button-icon-height: 20px;
  --dp-calendar-wrap-padding: 0 5px;
  --dp-cell-size: var(--default-clickable-area);
  --dp-cell-padding: 5px;
  --dp-common-padding: 10px;
  --dp-input-icon-padding: var(--default-clickable-area);
  --dp-input-padding: 6px 12px;
  --dp-menu-min-width: 260px;
  --dp-action-buttons-padding: 1px 6px;
  --dp-row-margin: 5px 0;
  --dp-calendar-header-cell-padding: 0.5rem;
  --dp-multi-calendars-spacing: 10px;
  --dp-overlay-col-padding: 3px;
  --dp-time-inc-dec-button-size: var(--default-clickable-area);
  --dp-font-size: 1rem;
  --dp-preview-font-size: var(--font-size-small);
  --dp-time-font-size: 2rem;
  --dp-action-button-height: var(--clickable-area-small);
  --dp-action-row-padding: 8px;
  --dp-direction: ltr;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  {
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__input_wrap {
  position: relative;
  width: 100%;
  box-sizing: unset;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__input_wrap:focus {
  border-color: var(--dp-border-color-hover);
  outline: none;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__input_valid {
  box-shadow: 0 0 var(--dp-border-radius) var(--dp-success-color);
  border-color: var(--dp-success-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__input_valid:hover {
  border-color: var(--dp-success-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__input_invalid {
  box-shadow: 0 0 var(--dp-border-radius) var(--dp-danger-color);
  border-color: var(--dp-danger-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__input_invalid:hover {
  border-color: var(--dp-danger-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__input {
  background-color: var(--dp-background-color);
  border-radius: var(--dp-border-radius);
  font-family: var(--dp-font-family);
  border: 1px solid var(--dp-border-color);
  outline: none;
  transition: border-color 0.2s cubic-bezier(0.645, 0.045, 0.355, 1);
  width: 100%;
  font-size: var(--dp-font-size);
  line-height: calc(var(--dp-font-size) * 1.5);
  padding: var(--dp-input-padding);
  color: var(--dp-text-color);
  box-sizing: border-box;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__input::placeholder {
  opacity: 0.7;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__input:hover:not(.dp__input_focus) {
  border-color: var(--dp-border-color-hover);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__input_reg {
  caret-color: rgba(0, 0, 0, 0);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__input_focus {
  border-color: var(--dp-border-color-focus);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__disabled {
  background: var(--dp-disabled-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__disabled::placeholder {
  color: var(--dp-disabled-color-text);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__input_icons {
  display: inline-block;
  width: var(--dp-font-size);
  height: var(--dp-font-size);
  stroke-width: 0;
  font-size: var(--dp-font-size);
  line-height: calc(var(--dp-font-size) * 1.5);
  padding: 6px 12px;
  color: var(--dp-icon-color);
  box-sizing: content-box;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__input_icon {
  cursor: pointer;
  position: absolute;
  top: 50%;
  inset-inline-start: 0;
  transform: translateY(-50%);
  color: var(--dp-icon-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--clear-btn {
  position: absolute;
  top: 50%;
  inset-inline-end: 0;
  transform: translateY(-50%);
  cursor: pointer;
  color: var(--dp-icon-color);
  background: rgba(0, 0, 0, 0);
  border: none;
  display: inline-flex;
  align-items: center;
  padding: 0;
  margin: 0;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__input_icon_pad {
  padding-inline-start: var(--dp-input-icon-padding);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__menu {
  background: var(--dp-background-color);
  border-radius: var(--dp-border-radius);
  min-width: var(--dp-menu-min-width);
  font-family: var(--dp-font-family);
  font-size: var(--dp-font-size);
  user-select: none;
  border: 1px solid var(--dp-menu-border-color);
  box-sizing: border-box;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__menu::after {
  box-sizing: border-box;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__menu::before {
  box-sizing: border-box;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__menu:focus {
  border: 1px solid var(--dp-menu-border-color);
  outline: none;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--menu-wrapper {
  position: absolute;
  z-index: 99999;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__menu_inner {
  padding: var(--dp-menu-padding);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--menu--inner-stretched {
  padding: 6px 0;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__menu_index {
  z-index: 99999;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp-menu-loading, .vue-date-time-picker__wrapper[data-v-27474da0]  .dp__menu_readonly, .vue-date-time-picker__wrapper[data-v-27474da0]  .dp__menu_disabled {
  position: absolute;
  inset: 0;
  z-index: 999999;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__menu_disabled {
  background: hsla(0, 0%, 100%, 0.5);
  cursor: not-allowed;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__menu_readonly {
  background: rgba(0, 0, 0, 0);
  cursor: default;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp-menu-loading {
  background: hsla(0, 0%, 100%, 0.5);
  cursor: default;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--menu-load-container {
  display: flex;
  height: 100%;
  width: 100%;
  justify-content: center;
  align-items: center;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--menu-loader {
  width: 48px;
  height: 48px;
  border: var(--dp-loader);
  border-bottom-color: rgba(0, 0, 0, 0);
  border-radius: 50%;
  display: inline-block;
  box-sizing: border-box;
  animation: dp-load-rotation-27474da0 1s linear infinite;
  position: absolute;
}
@keyframes dp-load-rotation-27474da0 {
0% {
    transform: rotate(0deg);
}
100% {
    transform: rotate(360deg);
}
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__arrow_top {
  left: var(--dp-arrow-left);
  top: 0;
  height: 12px;
  width: 12px;
  background-color: var(--dp-background-color);
  position: absolute;
  border-inline-end: 1px solid var(--dp-menu-border-color);
  border-top: 1px solid var(--dp-menu-border-color);
  transform: translate(-50%, -50%) rotate(-45deg);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__arrow_bottom {
  left: var(--dp-arrow-left);
  bottom: 0;
  height: 12px;
  width: 12px;
  background-color: var(--dp-background-color);
  position: absolute;
  border-inline-end: 1px solid var(--dp-menu-border-color);
  border-bottom: 1px solid var(--dp-menu-border-color);
  transform: translate(-50%, 50%) rotate(45deg);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__action_extra {
  text-align: center;
  padding: 2px 0;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--preset-dates {
  padding: 5px;
  border-inline-end: 1px solid var(--dp-border-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--preset-dates[data-dp-mobile] {
  display: flex;
  align-self: center;
  border: none;
  overflow-x: auto;
  max-width: calc(var(--dp-menu-width) - var(--dp-action-row-padding) * 2);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--preset-dates-collapsed {
  display: flex;
  align-self: center;
  border: none;
  overflow-x: auto;
  max-width: calc(var(--dp-menu-width) - var(--dp-action-row-padding) * 2);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__sidebar_left {
  padding: 5px;
  border-inline-end: 1px solid var(--dp-border-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__sidebar_right {
  padding: 5px;
  margin-inline-end: 1px solid var(--dp-border-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--preset-range {
  display: block;
  width: 100%;
  padding: 5px;
  text-align: left;
  white-space: nowrap;
  color: var(--dp-text-color);
  border-radius: var(--dp-border-radius);
  transition: var(--dp-common-transition);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--preset-range:hover {
  background-color: var(--dp-hover-color);
  color: var(--dp-hover-text-color);
  cursor: pointer;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--preset-range[data-dp-mobile] {
  border: 1px solid var(--dp-border-color);
  margin: 0 3px;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--preset-range[data-dp-mobile]:first-child {
  margin-left: 0;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--preset-range[data-dp-mobile]:last-child {
  margin-right: 0;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--preset-range-collapsed {
  border: 1px solid var(--dp-border-color);
  margin: 0 3px;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--preset-range-collapsed:first-child {
  margin-left: 0;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--preset-range-collapsed:last-child {
  margin-right: 0;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__menu_content_wrapper {
  display: flex;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__menu_content_wrapper[data-dp-mobile] {
  flex-direction: column-reverse;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--menu-content-wrapper-collapsed {
  flex-direction: column-reverse;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__calendar_header {
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  color: var(--dp-text-color);
  white-space: nowrap;
  font-weight: bold;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__calendar_header_item {
  text-align: center;
  flex-grow: 1;
  height: var(--dp-cell-size);
  padding: var(--dp-cell-padding);
  width: var(--dp-cell-size);
  box-sizing: border-box;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__calendar_row {
  display: flex;
  justify-content: center;
  align-items: center;
  margin: var(--dp-row-margin);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__calendar_item {
  text-align: center;
  flex-grow: 1;
  box-sizing: border-box;
  color: var(--dp-text-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__calendar {
  position: relative;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__calendar_header_cell {
  border-bottom: thin solid var(--dp-border-color);
  padding: var(--dp-calendar-header-cell-padding);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__cell_inner {
  display: flex;
  align-items: center;
  text-align: center;
  justify-content: center;
  border-radius: var(--dp-cell-border-radius);
  height: var(--dp-cell-size);
  padding: var(--dp-cell-padding);
  width: var(--dp-cell-size);
  border: 1px solid rgba(0, 0, 0, 0);
  box-sizing: border-box;
  position: relative;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__cell_inner:hover {
  transition: all 0.2s;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__cell_auto_range_start, .vue-date-time-picker__wrapper[data-v-27474da0]  .dp__date_hover_start:hover, .vue-date-time-picker__wrapper[data-v-27474da0]  .dp__range_start {
  border-end-end-radius: 0;
  border-start-end-radius: 0;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__cell_auto_range_end, .vue-date-time-picker__wrapper[data-v-27474da0]  .dp__date_hover_end:hover, .vue-date-time-picker__wrapper[data-v-27474da0]  .dp__range_end {
  border-end-start-radius: 0;
  border-start-start-radius: 0;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__range_end, .vue-date-time-picker__wrapper[data-v-27474da0]  .dp__range_start, .vue-date-time-picker__wrapper[data-v-27474da0]  .dp__active_date {
  background: var(--dp-primary-color);
  color: var(--dp-primary-text-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__date_hover_end:hover, .vue-date-time-picker__wrapper[data-v-27474da0]  .dp__date_hover_start:hover, .vue-date-time-picker__wrapper[data-v-27474da0]  .dp__date_hover:hover {
  background: var(--dp-hover-color);
  color: var(--dp-hover-text-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__cell_offset {
  color: var(--dp-secondary-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__cell_disabled {
  color: var(--dp-secondary-color);
  cursor: not-allowed;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__range_between {
  background: var(--dp-range-between-dates-background-color);
  color: var(--dp-range-between-dates-text-color);
  border-radius: 0;
  border: 1px solid var(--dp-range-between-border-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__range_between_week {
  background: var(--dp-primary-color);
  color: var(--dp-primary-text-color);
  border-radius: 0;
  border-top: 1px solid var(--dp-primary-color);
  border-bottom: 1px solid var(--dp-primary-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__today {
  border: 1px solid var(--dp-primary-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__week_num {
  color: var(--dp-secondary-color);
  text-align: center;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__cell_auto_range {
  border-radius: 0;
  border-top: 1px dashed var(--dp-primary-color);
  border-bottom: 1px dashed var(--dp-primary-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__cell_auto_range_start {
  border-start-start-radius: var(--dp-cell-border-radius);
  border-end-start-radius: var(--dp-cell-border-radius);
  border-inline-start: 1px dashed var(--dp-primary-color);
  border-top: 1px dashed var(--dp-primary-color);
  border-bottom: 1px dashed var(--dp-primary-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__cell_auto_range_end {
  border-start-end-radius: var(--dp-cell-border-radius);
  border-end-end-radius: var(--dp-cell-border-radius);
  border-top: 1px dashed var(--dp-primary-color);
  border-bottom: 1px dashed var(--dp-primary-color);
  border-inline-end: 1px dashed var(--dp-primary-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__calendar_header_separator {
  width: 100%;
  height: 1px;
  background: var(--dp-border-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__calendar_next {
  margin-inline-start: var(--dp-multi-calendars-spacing);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__marker_line, .vue-date-time-picker__wrapper[data-v-27474da0]  .dp__marker_dot {
  height: 5px;
  background-color: var(--dp-marker-color);
  position: absolute;
  bottom: 0;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__marker_dot {
  width: 5px;
  border-radius: 50%;
  left: 50%;
  transform: translateX(-50%);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__marker_line {
  width: 100%;
  left: 0;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__marker_tooltip {
  position: absolute;
  border-radius: var(--dp-border-radius);
  background-color: var(--dp-tooltip-color);
  padding: 5px;
  border: 1px solid var(--dp-border-color);
  z-index: 99999;
  box-sizing: border-box;
  cursor: default;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__tooltip_content {
  white-space: nowrap;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__tooltip_text {
  display: flex;
  align-items: center;
  flex-flow: row nowrap;
  color: var(--dp-text-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__tooltip_mark {
  height: 5px;
  width: 5px;
  border-radius: 50%;
  background-color: var(--dp-text-color);
  color: var(--dp-text-color);
  margin-inline-end: 5px;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__arrow_bottom_tp {
  bottom: 0;
  height: 8px;
  width: 8px;
  background-color: var(--dp-tooltip-color);
  position: absolute;
  border-inline-end: 1px solid var(--dp-border-color);
  border-bottom: 1px solid var(--dp-border-color);
  transform: translate(-50%, 50%) rotate(45deg);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__instance_calendar {
  position: relative;
  width: 100%;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__flex_display[data-dp-mobile] {
  flex-direction: column;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--flex-display-collapsed {
  flex-direction: column;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__cell_highlight {
  background-color: var(--dp-highlight-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__month_year_row {
  display: flex;
  align-items: center;
  height: var(--dp-month-year-row-height);
  color: var(--dp-text-color);
  box-sizing: border-box;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__inner_nav {
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  height: var(--dp-month-year-row-button-size);
  width: var(--dp-month-year-row-button-size);
  color: var(--dp-icon-color);
  text-align: center;
  border-radius: 50%;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__inner_nav svg {
  height: var(--dp-button-icon-height);
  width: var(--dp-button-icon-height);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__inner_nav:hover {
  background: var(--dp-hover-color);
  color: var(--dp-hover-icon-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  [dir=rtl] .dp__inner_nav {
  transform: rotate(180deg);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__inner_nav_disabled:hover, .vue-date-time-picker__wrapper[data-v-27474da0]  .dp__inner_nav_disabled {
  background: var(--dp-disabled-color);
  color: var(--dp-disabled-color-text);
  cursor: not-allowed;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--year-select, .vue-date-time-picker__wrapper[data-v-27474da0]  .dp__month_year_select {
  text-align: center;
  cursor: pointer;
  height: var(--dp-month-year-row-height);
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: var(--dp-border-radius);
  box-sizing: border-box;
  color: var(--dp-text-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--year-select:hover, .vue-date-time-picker__wrapper[data-v-27474da0]  .dp__month_year_select:hover {
  background: var(--dp-hover-color);
  color: var(--dp-hover-text-color);
  transition: var(--dp-common-transition);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__month_year_select {
  width: 50%;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--year-select {
  width: 100%;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__month_year_wrap {
  display: flex;
  flex-direction: row;
  width: 100%;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__year_disable_select {
  justify-content: space-around;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--header-wrap {
  display: flex;
  width: 100%;
  flex-direction: column;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__overlay {
  width: 100%;
  background: var(--dp-background-color);
  transition: opacity 1s ease-out;
  z-index: 99999;
  font-family: var(--dp-font-family);
  color: var(--dp-text-color);
  box-sizing: border-box;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--overlay-absolute {
  position: absolute;
  height: 100%;
  top: 0;
  left: 0;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--overlay-relative {
  position: relative;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__overlay_container::-webkit-scrollbar-track {
  box-shadow: var(--dp-scroll-bar-background);
  background-color: var(--dp-scroll-bar-background);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__overlay_container::-webkit-scrollbar {
  width: 5px;
  background-color: var(--dp-scroll-bar-background);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__overlay_container::-webkit-scrollbar-thumb {
  background-color: var(--dp-scroll-bar-color);
  border-radius: 10px;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__overlay:focus {
  border: none;
  outline: none;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__container_flex {
  display: flex;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__container_block {
  display: block;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__overlay_container {
  flex-direction: column;
  overflow-y: auto;
  height: var(--dp-overlay-height);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__time_picker_overlay_container {
  height: 100%;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__overlay_row {
  padding: 0;
  box-sizing: border-box;
  display: flex;
  margin-inline: auto;
  flex-wrap: wrap;
  max-width: 100%;
  width: 100%;
  align-items: center;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__flex_row {
  flex: 1;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__overlay_col {
  box-sizing: border-box;
  width: 33%;
  padding: var(--dp-overlay-col-padding);
  white-space: nowrap;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__overlay_cell_pad {
  padding: var(--dp-common-padding) 0;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__overlay_cell_active {
  cursor: pointer;
  border-radius: var(--dp-border-radius);
  text-align: center;
  background: var(--dp-primary-color);
  color: var(--dp-primary-text-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__overlay_cell {
  cursor: pointer;
  border-radius: var(--dp-border-radius);
  text-align: center;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__overlay_cell:hover {
  background: var(--dp-hover-color);
  color: var(--dp-hover-text-color);
  transition: var(--dp-common-transition);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__cell_in_between {
  background: var(--dp-hover-color);
  color: var(--dp-hover-text-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__over_action_scroll {
  right: 5px;
  box-sizing: border-box;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__overlay_cell_disabled {
  cursor: not-allowed;
  background: var(--dp-disabled-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__overlay_cell_disabled:hover {
  background: var(--dp-disabled-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__overlay_cell_active_disabled {
  cursor: not-allowed;
  background: var(--dp-primary-disabled-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__overlay_cell_active_disabled:hover {
  background: var(--dp-primary-disabled-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__btn, .vue-date-time-picker__wrapper[data-v-27474da0]  .dp--qr-btn, .vue-date-time-picker__wrapper[data-v-27474da0]  .dp--time-overlay-btn, .vue-date-time-picker__wrapper[data-v-27474da0]  .dp--time-invalid {
  border: none;
  font: inherit;
  transition: var(--dp-common-transition);
  line-height: normal;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--year-mode-picker {
  display: flex;
  width: 100%;
  align-items: center;
  justify-content: space-between;
  height: var(--dp-cell-size);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--tp-wrap {
  max-width: var(--dp-menu-min-width);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--tp-wrap[data-dp-mobile] {
  max-width: 100%;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__time_input {
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  user-select: none;
  font-family: var(--dp-font-family);
  color: var(--dp-text-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__time_col_reg_block {
  padding: 0 20px;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__time_col_reg_inline {
  padding: 0 10px;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__time_col_reg_with_button {
  padding: 0 15px;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__time_col_reg_with_button[data-compact~=true] {
  padding: 0 5px;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__time_col_sec {
  padding: 0 10px;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__time_col_sec_with_button {
  padding: 0 5px;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__time_col_sec_with_button[data-collapsed~=true] {
  padding: 0;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__time_col {
  text-align: center;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__time_col_block {
  font-size: var(--dp-time-font-size);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__time_display_block {
  padding: 0 3px;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__time_display_inline {
  padding: 5px;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__time_picker_inline_container {
  display: flex;
  width: 100%;
  justify-content: center;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__inc_dec_button {
  padding: 5px;
  margin: 0;
  height: var(--dp-time-inc-dec-button-size);
  width: var(--dp-time-inc-dec-button-size);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  border-radius: 50%;
  color: var(--dp-icon-color);
  box-sizing: border-box;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__inc_dec_button svg {
  height: var(--dp-time-inc-dec-button-size);
  width: var(--dp-time-inc-dec-button-size);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__inc_dec_button:hover {
  background: var(--dp-hover-color);
  color: var(--dp-primary-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__time_display {
  cursor: pointer;
  color: var(--dp-text-color);
  border-radius: var(--dp-border-radius);
  display: flex;
  align-items: center;
  justify-content: center;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__time_display:hover:enabled {
  background: var(--dp-hover-color);
  color: var(--dp-hover-text-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__inc_dec_button_inline {
  width: 100%;
  padding: 0;
  height: 8px;
  cursor: pointer;
  display: flex;
  align-items: center;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__inc_dec_button_disabled, .vue-date-time-picker__wrapper[data-v-27474da0]  .dp__inc_dec_button_disabled:hover {
  background: var(--dp-disabled-color);
  color: var(--dp-disabled-color-text);
  cursor: not-allowed;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__pm_am_button {
  background: var(--dp-primary-color);
  color: var(--dp-primary-text-color);
  border: none;
  padding: var(--dp-common-padding);
  border-radius: var(--dp-border-radius);
  cursor: pointer;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__pm_am_button[data-compact~=true] {
  padding: 7px;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__tp_inline_btn_bar {
  width: 100%;
  height: 4px;
  background-color: var(--dp-secondary-color);
  transition: var(--dp-common-transition);
  border-collapse: collapse;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__tp_inline_btn_top:hover .dp__tp_btn_in_r {
  background-color: var(--dp-primary-color);
  transform: rotate(12deg) scale(1.15) translateY(-2px);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__tp_inline_btn_top:hover .dp__tp_btn_in_l {
  background-color: var(--dp-primary-color);
  transform: rotate(-12deg) scale(1.15) translateY(-2px);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__tp_inline_btn_bottom:hover .dp__tp_btn_in_r {
  background-color: var(--dp-primary-color);
  transform: rotate(-12deg) scale(1.15) translateY(-2px);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__tp_inline_btn_bottom:hover .dp__tp_btn_in_l {
  background-color: var(--dp-primary-color);
  transform: rotate(12deg) scale(1.15) translateY(-2px);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--time-overlay-btn {
  background: none;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--time-invalid {
  background-color: var(--dp-disabled-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__action_row {
  display: flex;
  align-items: center;
  width: 100%;
  padding: var(--dp-action-row-padding);
  box-sizing: border-box;
  color: var(--dp-text-color);
  flex-flow: row nowrap;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__action_row svg {
  height: var(--dp-button-icon-height);
  width: auto;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__selection_preview {
  display: block;
  color: var(--dp-text-color);
  font-size: var(--dp-preview-font-size);
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__action_buttons {
  display: flex;
  flex: 0;
  white-space: nowrap;
  align-items: center;
  justify-content: flex-end;
  margin-inline-start: auto;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__action_button {
  display: inline-flex;
  align-items: center;
  background: rgba(0, 0, 0, 0);
  border: 1px solid rgba(0, 0, 0, 0);
  padding: var(--dp-action-buttons-padding);
  line-height: var(--dp-action-button-height);
  margin-inline-start: 3px;
  height: var(--dp-action-button-height);
  cursor: pointer;
  border-radius: var(--dp-border-radius);
  font-size: var(--dp-preview-font-size);
  font-family: var(--dp-font-family);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__action_cancel {
  color: var(--dp-text-color);
  border: 1px solid var(--dp-border-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__action_cancel:hover {
  border-color: var(--dp-primary-color);
  transition: var(--dp-action-row-transtion);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__action_buttons .dp__action_select {
  background: var(--dp-primary-color);
  color: var(--dp-primary-text-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__action_buttons .dp__action_select:hover {
  background: var(--dp-primary-color);
  transition: var(--dp-action-row-transtion);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__action_buttons .dp__action_select:disabled {
  background: var(--dp-primary-disabled-color);
  cursor: not-allowed;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp-quarter-picker-wrap {
  display: flex;
  flex-direction: column;
  height: 100%;
  min-width: var(--dp-menu-min-width);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--qr-btn-disabled {
  cursor: not-allowed;
  background: var(--dp-disabled-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--qr-btn-disabled:hover {
  background: var(--dp-disabled-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--qr-btn {
  width: 100%;
  padding: var(--dp-common-padding);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--qr-btn:not(.dp--highlighted, .dp--qr-btn-active, .dp--qr-btn-disabled, .dp--qr-btn-between) {
  background: none;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--qr-btn:hover:not(.dp--qr-btn-active, .dp--qr-btn-disabled) {
  background: var(--dp-hover-color);
  color: var(--dp-hover-text-color);
  transition: var(--dp-common-transition);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--quarter-items {
  display: flex;
  flex-direction: column;
  flex: 1;
  width: 100%;
  height: 100%;
  justify-content: space-evenly;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--qr-btn-active {
  background: var(--dp-primary-color);
  color: var(--dp-primary-text-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--qr-btn-between {
  background: var(--dp-hover-color);
  color: var(--dp-hover-text-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  :root {
  --dp-common-transition: all 0.1s ease-in;
  --dp-menu-padding: 6px 8px;
  --dp-animation-duration: 0.1s;
  --dp-menu-appear-transition-timing: cubic-bezier(.4, 0, 1, 1);
  --dp-transition-timing: ease-out;
  --dp-action-row-transtion: all 0.2s ease-in;
  --dp-font-family: -apple-system, blinkmacsystemfont, "Segoe UI", roboto, oxygen, ubuntu, cantarell, "Open Sans", "Helvetica Neue", sans-serif;
  --dp-border-radius: 4px;
  --dp-cell-border-radius: 4px;
  --dp-transition-length: 22px;
  --dp-transition-timing-general: 0.1s;
  --dp-button-height: 35px;
  --dp-month-year-row-height: 35px;
  --dp-month-year-row-button-size: 25px;
  --dp-button-icon-height: 20px;
  --dp-calendar-wrap-padding: 0 5px;
  --dp-cell-size: 35px;
  --dp-cell-padding: 5px;
  --dp-common-padding: 10px;
  --dp-input-icon-padding: 35px;
  --dp-input-padding: 6px 30px 6px 12px;
  --dp-menu-min-width: 260px;
  --dp-action-buttons-padding: 1px 6px;
  --dp-row-margin: 5px 0;
  --dp-calendar-header-cell-padding: 0.5rem;
  --dp-multi-calendars-spacing: 10px;
  --dp-overlay-col-padding: 3px;
  --dp-time-inc-dec-button-size: 32px;
  --dp-font-size: 1rem;
  --dp-preview-font-size: 0.8rem;
  --dp-time-font-size: 2rem;
  --dp-action-button-height: 22px;
  --dp-action-row-padding: 8px;
  --dp-direction: ltr;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__theme_dark {
  --dp-background-color: #212121;
  --dp-text-color: #fff;
  --dp-hover-color: #484848;
  --dp-hover-text-color: #fff;
  --dp-hover-icon-color: #959595;
  --dp-primary-color: #005cb2;
  --dp-primary-disabled-color: #61a8ea;
  --dp-primary-text-color: #fff;
  --dp-secondary-color: #a9a9a9;
  --dp-border-color: #2d2d2d;
  --dp-menu-border-color: #2d2d2d;
  --dp-border-color-hover: #aaaeb7;
  --dp-border-color-focus: #aaaeb7;
  --dp-disabled-color: #737373;
  --dp-disabled-color-text: #d0d0d0;
  --dp-scroll-bar-background: #212121;
  --dp-scroll-bar-color: #484848;
  --dp-success-color: #00701a;
  --dp-success-color-disabled: #428f59;
  --dp-icon-color: #959595;
  --dp-danger-color: #e53935;
  --dp-marker-color: #e53935;
  --dp-tooltip-color: #3e3e3e;
  --dp-highlight-color: rgb(0 92 178 / 20%);
  --dp-range-between-dates-background-color: var(--dp-hover-color, #484848);
  --dp-range-between-dates-text-color: var(--dp-hover-text-color, #fff);
  --dp-range-between-border-color: var(--dp-hover-color, #fff);
  --dp-loader: 5px solid #005cb2;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__theme_light {
  --dp-background-color: #fff;
  --dp-text-color: #212121;
  --dp-hover-color: #f3f3f3;
  --dp-hover-text-color: #212121;
  --dp-hover-icon-color: #959595;
  --dp-primary-color: #1976d2;
  --dp-primary-disabled-color: #6bacea;
  --dp-primary-text-color: #fff;
  --dp-secondary-color: #c0c4cc;
  --dp-border-color: #ddd;
  --dp-menu-border-color: #ddd;
  --dp-border-color-hover: #aaaeb7;
  --dp-border-color-focus: #aaaeb7;
  --dp-disabled-color: #f6f6f6;
  --dp-scroll-bar-background: #f3f3f3;
  --dp-scroll-bar-color: #959595;
  --dp-success-color: #76d275;
  --dp-success-color-disabled: #a3d9b1;
  --dp-icon-color: #959595;
  --dp-danger-color: #ff6f60;
  --dp-marker-color: #ff6f60;
  --dp-tooltip-color: #fafafa;
  --dp-disabled-color-text: #8e8e8e;
  --dp-highlight-color: rgb(25 118 210 / 10%);
  --dp-range-between-dates-background-color: var(--dp-hover-color, #f3f3f3);
  --dp-range-between-dates-text-color: var(--dp-hover-text-color, #212121);
  --dp-range-between-border-color: var(--dp-hover-color, #f3f3f3);
  --dp-loader: 5px solid #1976d2;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__flex {
  display: flex;
  align-items: center;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__btn {
  background: none;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__main {
  font-family: var(--dp-font-family);
  user-select: none;
  box-sizing: border-box;
  position: relative;
  width: 100%;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__main * {
  direction: var(--dp-direction, ltr);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__pointer {
  cursor: pointer;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__icon {
  stroke: currentcolor;
  fill: currentcolor;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__button {
  width: 100%;
  text-align: center;
  color: var(--dp-icon-color);
  cursor: pointer;
  display: flex;
  align-items: center;
  place-content: center center;
  padding: var(--dp-common-padding);
  box-sizing: border-box;
  height: var(--dp-button-height);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__button.dp__overlay_action {
  position: absolute;
  bottom: 0;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__button:hover {
  background: var(--dp-hover-color);
  color: var(--dp-hover-icon-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__button svg {
  height: var(--dp-button-icon-height);
  width: auto;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__button_bottom {
  border-bottom-left-radius: var(--dp-border-radius);
  border-bottom-right-radius: var(--dp-border-radius);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__flex_display {
  display: flex;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__flex_display_with_input {
  flex-direction: column;
  align-items: flex-start;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp__relative {
  position: relative;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .calendar-next-enter-active, .vue-date-time-picker__wrapper[data-v-27474da0]  .calendar-next-leave-active, .vue-date-time-picker__wrapper[data-v-27474da0]  .calendar-prev-enter-active, .vue-date-time-picker__wrapper[data-v-27474da0]  .calendar-prev-leave-active {
  transition: all var(--dp-transition-timing-general) ease-out;
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .calendar-next-enter-from {
  opacity: 0;
  transform: translateX(var(--dp-transition-length));
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .calendar-next-leave-to {
  opacity: 0;
  transform: translateX(calc(var(--dp-transition-length) * -1));
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .calendar-prev-enter-from {
  opacity: 0;
  transform: translateX(calc(var(--dp-transition-length) * -1));
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .calendar-prev-leave-to {
  opacity: 0;
  transform: translateX(var(--dp-transition-length));
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp-menu-appear-bottom-enter-active, .vue-date-time-picker__wrapper[data-v-27474da0]  .dp-menu-appear-bottom-leave-active, .vue-date-time-picker__wrapper[data-v-27474da0]  .dp-menu-appear-top-enter-active, .vue-date-time-picker__wrapper[data-v-27474da0]  .dp-menu-appear-top-leave-active, .vue-date-time-picker__wrapper[data-v-27474da0]  .dp-slide-up-enter-active, .vue-date-time-picker__wrapper[data-v-27474da0]  .dp-slide-up-leave-active, .vue-date-time-picker__wrapper[data-v-27474da0]  .dp-slide-down-enter-active, .vue-date-time-picker__wrapper[data-v-27474da0]  .dp-slide-down-leave-active {
  transition: all var(--dp-animation-duration) var(--dp-transition-timing);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp-menu-appear-top-enter-from, .vue-date-time-picker__wrapper[data-v-27474da0]  .dp-menu-appear-top-leave-to, .vue-date-time-picker__wrapper[data-v-27474da0]  .dp-slide-down-leave-to, .vue-date-time-picker__wrapper[data-v-27474da0]  .dp-slide-up-enter-from {
  opacity: 0;
  transform: translateY(var(--dp-transition-length));
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp-menu-appear-bottom-enter-from, .vue-date-time-picker__wrapper[data-v-27474da0]  .dp-menu-appear-bottom-leave-to, .vue-date-time-picker__wrapper[data-v-27474da0]  .dp-slide-down-enter-from, .vue-date-time-picker__wrapper[data-v-27474da0]  .dp-slide-up-leave-to {
  opacity: 0;
  transform: translateY(calc(var(--dp-transition-length) * -1));
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--arrow-btn-nav {
  transition: var(--dp-common-transition);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--highlighted {
  background-color: var(--dp-highlight-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0]  .dp--hidden-el {
  visibility: hidden;
}
.vue-date-time-picker__wrapper .vue-date-time-picker--clearable[data-v-27474da0] .dp__input {
  padding-inline-end: var(--default-clickable-area);
}
.vue-date-time-picker__wrapper .vue-date-time-picker__timezone[data-v-27474da0] {
  min-width: unset;
  width: 100%;
}
.vue-date-time-picker__wrapper[data-v-27474da0] .icon-vue {
  opacity: 1 !important;
}
.vue-date-time-picker__wrapper[data-v-27474da0] .dp--tp-wrap,
.vue-date-time-picker__wrapper[data-v-27474da0] .dp__action_extra {
  padding: var(--dp-menu-padding);
  padding-top: 0;
}
.vue-date-time-picker__wrapper[data-v-27474da0] .dp__overlay.dp--overlay-absolute {
  padding: var(--dp-menu-padding);
}
.vue-date-time-picker__wrapper[data-v-27474da0] .dp__overlay.dp--overlay-absolute .dp__btn.dp__button.dp__button_bottom {
  inset-block-end: 6px;
}
.vue-date-time-picker__wrapper[data-v-27474da0] .dp__btn.dp__button.dp__button_bottom,
.vue-date-time-picker__wrapper[data-v-27474da0] .dp--tp-wrap .dp__button {
  width: 100%;
}
.vue-date-time-picker__wrapper[data-v-27474da0] .dp__btn.dp__button.dp__overlay_action {
  width: calc(100% - 16px);
}
.vue-date-time-picker__wrapper[data-v-27474da0] input {
  padding-inline-start: var(--dp-input-icon-padding) !important;
}
.vue-date-time-picker__wrapper[data-v-27474da0] .dp__btn {
  margin: 0;
}
.vue-date-time-picker__wrapper[data-v-27474da0] .dp__inner_nav {
  height: fit-content;
  width: fit-content;
}
.vue-date-time-picker__wrapper[data-v-27474da0] .dp__btn.dp__button.dp__button_bottom {
  color: var(--color-primary-element-light);
  background-color: var(--color-primary-element-light);
}
.vue-date-time-picker__wrapper[data-v-27474da0] .dp--header-wrap .dp__btn:not(.dp__button_bottom),
.vue-date-time-picker__wrapper[data-v-27474da0] .dp__time_col .dp__btn {
  background-color: var(--color-main-background);
}
.vue-date-time-picker__wrapper[data-v-27474da0] .dp--header-wrap .dp__btn:not(.dp__button_bottom):hover,
.vue-date-time-picker__wrapper[data-v-27474da0] .dp__time_col .dp__btn:hover {
  background: var(--dp-hover-color);
  color: var(--dp-hover-icon-color);
}
.vue-date-time-picker__wrapper[data-v-27474da0] .dp__month_year_select {
  flex: 1;
}
.vue-date-time-picker__wrapper[data-v-27474da0] .dp--time-overlay-btn {
  font-size: calc(2 * var(--default-font-size)) !important;
}
.vue-date-time-picker__wrapper[data-v-27474da0] .dp__time_input .dp__time_col_reg_block {
  padding: 0 calc(4 * var(--default-grid-baseline));
}
.vue-date-time-picker__wrapper .vue-date-time-picker.dp__theme_dark[data-v-27474da0],
.vue-date-time-picker__wrapper .vue-date-time-picker.dp__theme_light[data-v-27474da0],
.vue-date-time-picker__wrapper[data-v-27474da0] .dp__theme_dark,
.vue-date-time-picker__wrapper[data-v-27474da0] .dp__theme_light {
  --dp-background-color: var(--color-main-background);
  --dp-text-color: var(--color-main-text);
  --dp-hover-color: var(--color-primary-element-light-hover);
  --dp-hover-text-color: var(--color-primary-element-light-text);
  --dp-hover-icon-color: var(--color-primary-element-light-text);
  --dp-primary-color: var(--color-primary-element);
  --dp-primary-disabled-color: var(--color-primary-element-hover);
  --dp-primary-text-color: var(--color-primary-element-text);
  --dp-secondary-color: var(--color-text-maxcontrast);
  --dp-border-color: var(--color-border);
  --dp-menu-border-color: var(--color-border-dark);
  --dp-border-color-hover: var(--color-border-maxcontrast);
  --dp-border-color-focus: var(--color-border-maxcontrast);
  --dp-disabled-color: var(--color-background-dark);
  --dp-disabled-color-text: var(--color-text-maxcontrast);
  --dp-scroll-bar-background: var(--color-scrollbar);
  --dp-scroll-bar-color: var(--color-scrollbar);
  --dp-success-color: var(--color-success);
  --dp-success-color-disabled: var(--color-success-hover);
  --dp-icon-color: var(--color-main-text);
  --dp-danger-color: var(--color-error);
  --dp-marker-color: var(--color-text-error, var(--color-error));
  --dp-tooltip-color: var(--color-main-text);
  --dp-highlight-color: var(--color-main-text);
}.emoji-mart,
.emoji-mart * {
  box-sizing: border-box;
  line-height: 1.15;
}
.emoji-mart {
  font-family: -apple-system, BlinkMacSystemFont, 'Helvetica Neue', sans-serif;
  font-size: 16px;
  /* display: inline-block; */
  display: flex;
  flex-direction: column;
  height: 420px;
  color: #222427;
  border: 1px solid #d9d9d9;
  border-radius: 5px;
  background: #fff;
}
.emoji-mart-emoji {
  padding: 6px;
  position: relative;
  display: inline-block;
  font-size: 0;
  border: none;
  background: none;
  box-shadow: none;
}
.emoji-mart-emoji span {
  display: inline-block;
}
.emoji-mart-preview-emoji .emoji-mart-emoji span {
  width: 38px;
  height: 38px;
  font-size: 32px;
}
.emoji-type-native {
  font-family: 'Segoe UI Emoji', 'Segoe UI Symbol', 'Segoe UI',
    'Apple Color Emoji', 'Twemoji Mozilla', 'Noto Color Emoji', 'EmojiOne Color',
    'Android Emoji';
  word-break: keep-all;
}
.emoji-type-image {
  /* Emoji sheet has 56 columns, see also utils/emoji-data.js, SHEET_COLUMNS variable */
  /* Here we use (56+1) * 100% to avoid visible edges of nearby icons when scaling for different
   * screen sizes */
  background-size: 6100%;
}
.emoji-type-image.emoji-set-apple {
  background-image: url('https://unpkg.com/emoji-datasource-apple@15.0.1/img/apple/sheets-256/64.png');
}
.emoji-type-image.emoji-set-facebook {
  background-image: url('https://unpkg.com/emoji-datasource-facebook@15.0.1/img/facebook/sheets-256/64.png');
}
.emoji-type-image.emoji-set-google {
  background-image: url('https://unpkg.com/emoji-datasource-google@15.0.1/img/google/sheets-256/64.png');
}
.emoji-type-image.emoji-set-twitter {
  background-image: url('https://unpkg.com/emoji-datasource-twitter@15.0.1/img/twitter/sheets-256/64.png');
}
.emoji-mart-bar {
  border: 0 solid #d9d9d9;
}
.emoji-mart-bar:first-child {
  border-bottom-width: 1px;
  border-top-left-radius: 5px;
  border-top-right-radius: 5px;
}
.emoji-mart-bar:last-child {
  border-top-width: 1px;
  border-bottom-left-radius: 5px;
  border-bottom-right-radius: 5px;
}
.emoji-mart-scroll {
  position: relative;
  overflow-y: scroll;
  flex: 1;
  padding: 0 6px 6px 6px;
  z-index: 0; /* Fix for rendering sticky positioned category labels on Chrome */
  will-change: transform; /* avoids "repaints on scroll" in mobile Chrome */
  -webkit-overflow-scrolling: touch;
}
.emoji-mart-anchors {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  padding: 0 6px;
  color: #858585;
  line-height: 0;
}
.emoji-mart-anchor {
  position: relative;
  display: block;
  flex: 1 1 auto;
  text-align: center;
  padding: 12px 4px;
  overflow: hidden;
  transition: color 0.1s ease-out;
  border: none;
  background: none;
  box-shadow: none;
}
.emoji-mart-anchor:hover,
.emoji-mart-anchor-selected {
  color: #464646;
}
.emoji-mart-anchor-selected .emoji-mart-anchor-bar {
  bottom: 0;
}
.emoji-mart-anchor-bar {
  position: absolute;
  bottom: -3px;
  left: 0;
  width: 100%;
  height: 3px;
  background-color: #464646;
}
.emoji-mart-anchors i {
  display: inline-block;
  width: 100%;
  max-width: 22px;
}
.emoji-mart-anchors svg {
  fill: currentColor;
  max-height: 18px;
}
.emoji-mart .scroller {
  height: 250px;
  position: relative;
  flex: 1;
  padding: 0 6px 6px 6px;
  z-index: 0; /* Fix for rendering sticky positioned category labels on Chrome */
  will-change: transform; /* avoids "repaints on scroll" in mobile Chrome */
  -webkit-overflow-scrolling: touch;
}
.emoji-mart-search {
  margin-top: 6px;
  padding: 0 6px;
}
.emoji-mart-search input {
  font-size: 16px;
  display: block;
  width: 100%;
  padding: 0.2em 0.6em;
  border-radius: 25px;
  border: 1px solid #d9d9d9;
  outline: 0;
}
.emoji-mart-search-results {
  height: 250px;
  overflow-y: scroll;
}
.emoji-mart-category {
  position: relative;
}
.emoji-mart-category .emoji-mart-emoji span {
  z-index: 1;
  position: relative;
  text-align: center;
  cursor: default;
}
.emoji-mart-category .emoji-mart-emoji:hover:before,
.emoji-mart-emoji-selected:before {
  z-index: 0;
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: #f4f4f4;
  border-radius: 100%;
  opacity: 0;
}
.emoji-mart-category .emoji-mart-emoji:hover:before,
.emoji-mart-emoji-selected:before {
  opacity: 1;
}
.emoji-mart-category-label {
  position: sticky;
  top: 0;
}
.emoji-mart-static .emoji-mart-category-label {
  z-index: 2;
  position: relative;
  /* position: sticky; */
  /* position: -webkit-sticky; */
}
.emoji-mart-category-label h3 {
  display: block;
  font-size: 16px;
  width: 100%;
  font-weight: 500;
  padding: 5px 6px;
  background-color: #fff;
  background-color: rgba(255, 255, 255, 0.95);
}
.emoji-mart-emoji {
  position: relative;
  display: inline-block;
  font-size: 0;
}
.emoji-mart-no-results {
  font-size: 14px;
  text-align: center;
  padding-top: 70px;
  color: #858585;
}
.emoji-mart-no-results .emoji-mart-category-label {
  display: none;
}
.emoji-mart-no-results .emoji-mart-no-results-label {
  margin-top: 0.2em;
}
.emoji-mart-no-results .emoji-mart-emoji:hover:before {
  content: none;
}
.emoji-mart-preview {
  position: relative;
  height: 70px;
}
.emoji-mart-preview-emoji,
.emoji-mart-preview-data,
.emoji-mart-preview-skins {
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
}
.emoji-mart-preview-emoji {
  left: 12px;
}
.emoji-mart-preview-data {
  left: 68px;
  right: 12px;
  word-break: break-all;
}
.emoji-mart-preview-skins {
  right: 30px;
  text-align: right;
}
.emoji-mart-preview-name {
  font-size: 14px;
}
.emoji-mart-preview-shortname {
  font-size: 12px;
  color: #888;
}
.emoji-mart-preview-shortname + .emoji-mart-preview-shortname,
.emoji-mart-preview-shortname + .emoji-mart-preview-emoticon,
.emoji-mart-preview-emoticon + .emoji-mart-preview-emoticon {
  margin-left: 0.5em;
}
.emoji-mart-preview-emoticon {
  font-size: 11px;
  color: #bbb;
}
.emoji-mart-title span {
  display: inline-block;
  vertical-align: middle;
}
.emoji-mart-title .emoji-mart-emoji {
  padding: 0;
}
.emoji-mart-title-label {
  color: #999a9c;
  font-size: 21px;
  font-weight: 300;
}
.emoji-mart-skin-swatches {
  font-size: 0;
  padding: 2px 0;
  border: 1px solid #d9d9d9;
  border-radius: 12px;
  background-color: #fff;
}
.emoji-mart-skin-swatches-opened .emoji-mart-skin-swatch {
  width: 16px;
  padding: 0 2px;
}
.emoji-mart-skin-swatches-opened .emoji-mart-skin-swatch-selected:after {
  opacity: 0.75;
}
.emoji-mart-skin-swatch {
  display: inline-block;
  width: 0;
  vertical-align: middle;
  transition-property: width, padding;
  transition-duration: 0.125s;
  transition-timing-function: ease-out;
}
.emoji-mart-skin-swatch:nth-child(1) {
  transition-delay: 0s;
}
.emoji-mart-skin-swatch:nth-child(2) {
  transition-delay: 0.03s;
}
.emoji-mart-skin-swatch:nth-child(3) {
  transition-delay: 0.06s;
}
.emoji-mart-skin-swatch:nth-child(4) {
  transition-delay: 0.09s;
}
.emoji-mart-skin-swatch:nth-child(5) {
  transition-delay: 0.12s;
}
.emoji-mart-skin-swatch:nth-child(6) {
  transition-delay: 0.15s;
}
.emoji-mart-skin-swatch-selected {
  position: relative;
  width: 16px;
  padding: 0 2px;
}
.emoji-mart-skin-swatch-selected:after {
  content: '';
  position: absolute;
  top: 50%;
  left: 50%;
  width: 4px;
  height: 4px;
  margin: -2px 0 0 -2px;
  background-color: #fff;
  border-radius: 100%;
  pointer-events: none;
  opacity: 0;
  transition: opacity 0.2s ease-out;
}
.emoji-mart-skin {
  display: inline-block;
  width: 100%;
  padding-top: 100%;
  max-width: 12px;
  border-radius: 100%;
}
.emoji-mart-skin-tone-1 {
  background-color: #ffc93a;
}
.emoji-mart-skin-tone-2 {
  background-color: #fadcbc;
}
.emoji-mart-skin-tone-3 {
  background-color: #e0bb95;
}
.emoji-mart-skin-tone-4 {
  background-color: #bf8f68;
}
.emoji-mart-skin-tone-5 {
  background-color: #9b643d;
}
.emoji-mart-skin-tone-6 {
  background-color: #594539;
}

/* vue-virtual-scroller/dist/vue-virtual-scroller.css */
.emoji-mart .vue-recycle-scroller {
  position: relative;
}
.emoji-mart .vue-recycle-scroller.direction-vertical:not(.page-mode) {
  overflow-y: auto;
}
.emoji-mart .vue-recycle-scroller.direction-horizontal:not(.page-mode) {
  overflow-x: auto;
}
.emoji-mart .vue-recycle-scroller.direction-horizontal {
  display: flex;
}
.emoji-mart .vue-recycle-scroller__slot {
  flex: auto 0 0;
}
.emoji-mart .vue-recycle-scroller__item-wrapper {
  flex: 1;
  box-sizing: border-box;
  overflow: hidden;
  position: relative;
}
.emoji-mart .vue-recycle-scroller.ready .vue-recycle-scroller__item-view {
  position: absolute;
  top: 0;
  left: 0;
  will-change: transform;
}
.emoji-mart
  .vue-recycle-scroller.direction-vertical
  .vue-recycle-scroller__item-wrapper {
  width: 100%;
}
.emoji-mart
  .vue-recycle-scroller.direction-horizontal
  .vue-recycle-scroller__item-wrapper {
  height: 100%;
}
.emoji-mart
  .vue-recycle-scroller.ready.direction-vertical
  .vue-recycle-scroller__item-view {
  width: 100%;
}
.emoji-mart
  .vue-recycle-scroller.ready.direction-horizontal
  .vue-recycle-scroller__item-view {
  height: 100%;
}
.emoji-mart .resize-observer[data-v-b329ee4c] {
  position: absolute;
  top: 0;
  left: 0;
  z-index: -1;
  width: 100%;
  height: 100%;
  border: none;
  background-color: transparent;
  pointer-events: none;
  display: block;
  overflow: hidden;
  opacity: 0;
}
.emoji-mart .resize-observer[data-v-b329ee4c] object {
  display: block;
  position: absolute;
  top: 0;
  left: 0;
  height: 100%;
  width: 100%;
  overflow: hidden;
  pointer-events: none;
  z-index: -1;
}
.emoji-mart-search .hidden {
  display: none;
  visibility: hidden;
}

/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */

/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */

/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.nc-emoji-picker.emoji-mart {
  background-color: var(--color-main-background) !important;
  border: 0;
  color: var(--color-main-text) !important;
  display: flex !important;
  /* Label element in the section grid */
  /* An actual heading inside the element */
}
.nc-emoji-picker.emoji-mart button {
  border: none;
  background: transparent;
  font-size: inherit;
}
.nc-emoji-picker.emoji-mart .emoji-mart-bar,
.nc-emoji-picker.emoji-mart .emoji-mart-anchors,
.nc-emoji-picker.emoji-mart .emoji-mart-search,
.nc-emoji-picker.emoji-mart .emoji-mart-search input,
.nc-emoji-picker.emoji-mart .emoji-mart-category,
.nc-emoji-picker.emoji-mart .emoji-mart-category-label,
.nc-emoji-picker.emoji-mart .emoji-mart-category-label span,
.nc-emoji-picker.emoji-mart .emoji-mart-skin-swatches {
  background-color: transparent !important;
  border-color: var(--color-border) !important;
  color: inherit !important;
}
.nc-emoji-picker.emoji-mart .emoji-mart-anchors {
  padding-block: 0;
  padding-inline: calc(2 * var(--default-grid-baseline));
}
.nc-emoji-picker.emoji-mart .emoji-mart-anchor {
  border-radius: 0;
  margin: 0 !important;
  padding: 0 !important;
  height: var(--clickable-area-small);
  min-width: var(--clickable-area-small);
}
.nc-emoji-picker.emoji-mart .emoji-mart-anchor:hover {
  background-color: var(--color-background-hover);
}
.nc-emoji-picker.emoji-mart .emoji-mart-anchor:focus-visible {
  outline: 2px solid var(--color-primary-element) !important;
  outline-offset: -2px;
}
.nc-emoji-picker.emoji-mart .emoji-mart-anchor div {
  display: grid;
  place-content: center;
}
.nc-emoji-picker.emoji-mart .emoji-mart-scroll {
  padding-inline: calc(2 * var(--default-grid-baseline));
  padding-block: 0 calc(2 * var(--default-grid-baseline));
}
.nc-emoji-picker.emoji-mart .emoji-mart-category {
  display: grid;
  grid-template-columns: repeat(8, 1fr);
  justify-items: stretch;
}
.nc-emoji-picker.emoji-mart .emoji-mart-category.emoji-mart-no-results {
  grid-template-columns: 1fr;
  font-size: inherit;
  color: var(--color-text-maxcontrast) !important;
}
.nc-emoji-picker.emoji-mart div.emoji-mart-category-label {
  grid-column: span 8;
  justify-self: stretch;
}
.nc-emoji-picker.emoji-mart h3.emoji-mart-category-label {
  display: flex;
  align-items: center;
  height: var(--default-clickable-area);
  margin: 0;
  padding-inline: calc(2 * var(--default-grid-baseline));
  padding-block: 0;
  user-select: none;
}
.nc-emoji-picker.emoji-mart .emoji-mart-emoji {
  aspect-ratio: 1/1;
  text-align: center;
  margin: 0 !important;
  padding: 0 !important;
}
.nc-emoji-picker.emoji-mart .emoji-mart-emoji:hover, .nc-emoji-picker.emoji-mart .emoji-mart-emoji:focus-visible, .nc-emoji-picker.emoji-mart .emoji-mart-emoji.emoji-mart-emoji-selected {
  background-color: var(--color-background-hover) !important;
  border: none;
  border-radius: var(--border-radius-element);
  box-shadow: none !important;
  outline: 2px solid var(--color-primary-element) !important;
  outline-offset: -2px;
}
.nc-emoji-picker.emoji-mart .emoji-mart-emoji::before {
  display: none;
}
.nc-emoji-picker.emoji-mart .emoji-mart-emoji span {
  cursor: pointer;
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-12f86ed6] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.search__wrapper[data-v-12f86ed6] {
  display: flex;
  flex-direction: row;
  gap: var(--default-grid-baseline);
  align-items: end;
  padding-block: var(--default-grid-baseline);
  padding-inline: calc(2 * var(--default-grid-baseline));
}
.row-selected button[data-v-12f86ed6], .row-selected span[data-v-12f86ed6] {
  vertical-align: middle;
}
.emoji-delete[data-v-12f86ed6] {
  vertical-align: top;
  margin-inline-start: -21px;
  margin-top: -3px;
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-26ad2498] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
#guest-content-vue[data-v-26ad2498] {
  color: var(--color-main-text);
  background-color: var(--color-main-background);
  min-width: 0;
  border-radius: var(--border-radius-element);
  box-shadow: 0 0 10px var(--color-box-shadow);
  height: fit-content;
  padding: 15px;
  margin: 20px auto;
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
#content.nc-guest-content {
  overflow: auto;
  margin-bottom: 0;
  height: calc(var(--body-height) + var(--body-container-margin));
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-dbefb31d] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}

/*!
 * SPDX-FileCopyrightText: 2024 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
.header-menu[data-v-dbefb31d] {
  position: relative;
  width: var(--header-height);
  height: var(--header-height);
}
.header-menu .header-menu__trigger[data-v-dbefb31d] {
  --button-size: var(--header-height) !important;
  height: var(--header-height);
  opacity: 0.85;
  filter: none !important;
  color: var(--color-background-plain-text, var(--color-primary-text)) !important;
}
.header-menu .header-menu__trigger[data-v-dbefb31d]:focus-visible {
  outline: none !important;
  box-shadow: none !important;
}
.header-menu .header-menu__trigger[data-v-dbefb31d] .button-vue__icon svg,
.header-menu .header-menu__trigger[data-v-dbefb31d] .button-vue__icon:not(:has(svg)) {
  mask: var(--header-menu-icon-mask, none);
}
.header-menu--opened .header-menu__trigger[data-v-dbefb31d], .header-menu__trigger[data-v-dbefb31d]:hover, .header-menu__trigger[data-v-dbefb31d]:focus, .header-menu__trigger[data-v-dbefb31d]:active {
  opacity: 1;
}
@media only screen and (max-width: 512px) {
.header-menu[data-v-dbefb31d] {
    width: var(--default-clickable-area);
}
.header-menu .header-menu__trigger[data-v-dbefb31d] {
    --button-size: var(--default-clickable-area) !important;
}
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-c1b2b551] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}

/*!
 * SPDX-FileCopyrightText: 2024 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
.header-menu[data-v-c1b2b551] {
  position: relative;
  width: var(--header-height);
  height: var(--header-height);
}
.header-menu .header-menu__trigger[data-v-c1b2b551] {
  --button-size: var(--header-height) !important;
  height: var(--header-height);
  opacity: 0.85;
  filter: none !important;
  color: var(--color-background-plain-text, var(--color-primary-text)) !important;
}
.header-menu .header-menu__trigger[data-v-c1b2b551]:focus-visible {
  outline: none !important;
  box-shadow: none !important;
}
.header-menu .header-menu__trigger[data-v-c1b2b551] .button-vue__icon svg,
.header-menu .header-menu__trigger[data-v-c1b2b551] .button-vue__icon:not(:has(svg)) {
  mask: var(--header-menu-icon-mask, none);
}
.header-menu--opened .header-menu__trigger[data-v-c1b2b551], .header-menu__trigger[data-v-c1b2b551]:hover, .header-menu__trigger[data-v-c1b2b551]:focus, .header-menu__trigger[data-v-c1b2b551]:active {
  opacity: 1;
}
@media only screen and (max-width: 512px) {
.header-menu[data-v-c1b2b551] {
    width: var(--default-clickable-area);
}
.header-menu .header-menu__trigger[data-v-c1b2b551] {
    --button-size: var(--default-clickable-area) !important;
}
}
.header-menu__wrapper[data-v-c1b2b551] {
  position: fixed;
  z-index: 2000;
  top: var(--header-height);
  inset-inline-end: 0;
  box-sizing: border-box;
  margin: 0 8px;
  border-radius: var(--border-radius-element);
  background-color: var(--color-main-background);
  filter: drop-shadow(0 1px 5px var(--color-box-shadow));
}
.header-menu__caret[data-v-c1b2b551] {
  position: absolute;
  z-index: 2001;
  bottom: 0;
  inset-inline-start: calc(50% - 10px);
  width: 0;
  height: 0;
  content: " ";
  pointer-events: none;
  border: 10px solid transparent;
  border-bottom-color: var(--color-main-background);
}
.header-menu__content[data-v-c1b2b551] {
  overflow: auto;
  width: 350px;
  max-width: calc(100vw - 16px);
  min-height: calc(var(--default-clickable-area) * 1.5);
  max-height: calc(100vh - var(--header-height) * 2);
}
.header-menu__content[data-v-c1b2b551] .empty-content {
  margin: 12vh 10px;
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-4c860755] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.list-item__wrapper[data-v-4c860755] {
  display: flex;
  position: relative;
  width: 100%;
  padding: 2px 4px;
}
.list-item__wrapper[data-v-4c860755]:first-of-type {
  padding-block-start: 4px;
}
.list-item__wrapper[data-v-4c860755]:last-of-type {
  padding-block-end: 4px;
}
.list-item__wrapper--active .list-item[data-v-4c860755], .list-item__wrapper.active .list-item[data-v-4c860755] {
  background-color: var(--color-primary-element);
  color: var(--color-primary-element-text) !important;
}
.list-item__wrapper--active .list-item[data-v-4c860755]:hover, .list-item__wrapper--active .list-item[data-v-4c860755]:focus-within, .list-item__wrapper--active .list-item[data-v-4c860755]:has(:focus-visible), .list-item__wrapper--active .list-item[data-v-4c860755]:has(:active), .list-item__wrapper.active .list-item[data-v-4c860755]:hover, .list-item__wrapper.active .list-item[data-v-4c860755]:focus-within, .list-item__wrapper.active .list-item[data-v-4c860755]:has(:focus-visible), .list-item__wrapper.active .list-item[data-v-4c860755]:has(:active) {
  background-color: var(--color-primary-element-hover);
}
.list-item__wrapper--active .list-item-content__name[data-v-4c860755],
.list-item__wrapper--active .list-item-content__subname[data-v-4c860755],
.list-item__wrapper--active .list-item-content__details[data-v-4c860755],
.list-item__wrapper--active .list-item-details__details[data-v-4c860755], .list-item__wrapper.active .list-item-content__name[data-v-4c860755],
.list-item__wrapper.active .list-item-content__subname[data-v-4c860755],
.list-item__wrapper.active .list-item-content__details[data-v-4c860755],
.list-item__wrapper.active .list-item-details__details[data-v-4c860755] {
  color: var(--color-primary-element-text) !important;
}
.list-item__wrapper .list-item-content__name[data-v-4c860755],
.list-item__wrapper .list-item-content__subname[data-v-4c860755],
.list-item__wrapper .list-item-content__details[data-v-4c860755],
.list-item__wrapper .list-item-details__details[data-v-4c860755] {
  white-space: nowrap;
  margin-block: 0;
  margin-inline: 0 auto;
  overflow: hidden;
  text-overflow: ellipsis;
}
.list-item-content__name[data-v-4c860755] {
  min-width: 100px;
  flex: 1 1 10%;
  font-weight: 500;
}
.list-item-content__subname[data-v-4c860755] {
  flex: 1 0;
  min-width: 0;
  color: var(--color-text-maxcontrast);
}
.list-item-content__subname--bold[data-v-4c860755] {
  font-weight: 500;
}
.list-item[data-v-4c860755] {
  --list-item-padding: var(--default-grid-baseline);
  --list-item-height: 2lh;
  --list-item-border-radius: var(--border-radius-element, 32px);
  box-sizing: border-box;
  display: flex;
  position: relative;
  flex: 0 0 auto;
  justify-content: flex-start;
  padding: var(--list-item-padding);
  width: 100%;
  border-radius: var(--border-radius-element, 32px);
  cursor: pointer;
  transition: background-color var(--animation-quick) ease-in-out;
  list-style: none;
}
.list-item[data-v-4c860755]:hover, .list-item[data-v-4c860755]:focus-within, .list-item[data-v-4c860755]:has(:active), .list-item[data-v-4c860755]:has(:focus-visible) {
  background-color: var(--color-background-hover);
}
.list-item[data-v-4c860755]:has(.list-item__anchor:focus-visible) {
  outline: 2px solid var(--color-main-text);
  box-shadow: 0 0 0 4px var(--color-main-background);
}
.list-item--compact[data-v-4c860755] {
  --list-item-padding: calc(0.5 * var(--default-grid-baseline)) var(--default-grid-baseline);
}
.list-item--compact[data-v-4c860755]:not(:has(.list-item-content__subname)) {
  --list-item-height: var(--default-clickable-area);
}
.list-item--one-line[data-v-4c860755] {
  --list-item-height: var(--default-clickable-area);
  --list-item-border-radius: var(--border-radius-element, calc(var(--default-clickable-area) / 2));
  --list-item-padding: var(--default-grid-baseline);
}
.list-item--one-line .list-item-content__main[data-v-4c860755] {
  display: flex;
  justify-content: start;
  gap: 12px;
  min-width: 0;
}
.list-item--one-line .list-item-content__details[data-v-4c860755] {
  flex-direction: row;
  align-items: center;
  justify-content: end;
}
.list-item--one-line .list-item-content__name[data-v-4c860755] {
  align-self: center;
  max-width: 300px;
}
.list-item__anchor[data-v-4c860755] {
  color: inherit;
  display: flex;
  flex: 1 0 auto;
  align-items: center;
  height: var(--list-item-height);
  min-width: 0;
}
.list-item__anchor[data-v-4c860755]:focus-visible {
  outline: none;
}
.list-item-content[data-v-4c860755] {
  display: flex;
  flex: 1 0;
  justify-content: space-between;
  padding-inline-start: calc(2 * var(--default-grid-baseline));
  min-width: 0;
}
.list-item-content__main[data-v-4c860755] {
  flex: 1 0;
  width: 0;
  margin: auto 0;
}
.list-item-content__main--oneline[data-v-4c860755] {
  display: flex;
}
.list-item-content__details[data-v-4c860755] {
  display: flex;
  flex-direction: column;
  justify-content: end;
  align-items: end;
}
.list-item-content__actions[data-v-4c860755], .list-item-content__extra-actions[data-v-4c860755] {
  flex: 0 0 auto;
  align-self: center;
  justify-content: center;
  margin-inline-start: var(--default-grid-baseline);
}
.list-item-content__extra-actions[data-v-4c860755] {
  display: flex;
  align-items: center;
  gap: var(--default-grid-baseline);
}
.list-item-details__details[data-v-4c860755] {
  color: var(--color-text-maxcontrast);
  margin: 0 9px !important;
  font-weight: normal;
}
.list-item-details__extra[data-v-4c860755] {
  margin: 2px 4px 0 4px;
  display: flex;
  align-items: center;
}
.list-item-details__indicator[data-v-4c860755] {
  margin: 0 5px;
}
.list-item__extra[data-v-4c860755] {
  margin-top: var(--default-grid-baseline);
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-f5135913] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.option[data-v-f5135913] {
  display: flex;
  align-items: center;
  width: 100%;
  height: var(--height);
  cursor: inherit;
}
.option__avatar[data-v-f5135913] {
  margin-inline-end: var(--margin);
}
.option__details[data-v-f5135913] {
  display: flex;
  flex: 1 1;
  flex-direction: column;
  justify-content: center;
  min-width: 0;
}
.option__lineone[data-v-f5135913] {
  color: var(--color-main-text);
}
.option__linetwo[data-v-f5135913] {
  color: var(--color-text-maxcontrast);
}
.option__lineone[data-v-f5135913], .option__linetwo[data-v-f5135913] {
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  line-height: 1.2;
}
.option__lineone strong[data-v-f5135913], .option__linetwo strong[data-v-f5135913] {
  font-weight: bold;
}
.option--compact .option__lineone[data-v-f5135913] {
  font-size: 14px;
}
.option--compact .option__linetwo[data-v-f5135913] {
  font-size: 11px;
  line-height: 1.5;
  margin-top: -4px;
}
.option__icon[data-v-f5135913] {
  width: var(--default-clickable-area);
  height: var(--default-clickable-area);
  color: var(--color-text-maxcontrast);
}
.option__icon.icon[data-v-f5135913] {
  flex: 0 0 var(--default-clickable-area);
  opacity: 0.7;
  background-position: center;
  background-size: 16px;
}
.option__details[data-v-f5135913], .option__lineone[data-v-f5135913], .option__linetwo[data-v-f5135913], .option__icon[data-v-f5135913] {
  cursor: inherit;
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-057b3c72] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.progress-bar[data-v-057b3c72] {
  display: block;
  height: var(--progress-bar-height);
  --progress-bar-color: var(--cd1c225c);
  --progress-bar-height: var(--fb577880);
}
.progress-bar--linear[data-v-057b3c72] {
  width: 100%;
  overflow: hidden;
  border: 0;
  padding: 0;
  background: var(--color-background-dark);
  border-radius: calc(var(--progress-bar-height) / 2);
}
.progress-bar--linear[data-v-057b3c72]::-webkit-progress-bar {
  height: var(--progress-bar-height);
  background-color: transparent;
}
.progress-bar--linear[data-v-057b3c72]::-webkit-progress-value {
  background: var(--progress-bar-color, var(--gradient-primary-background));
  border-radius: calc(var(--progress-bar-height) / 2);
}
.progress-bar--linear[data-v-057b3c72]::-moz-progress-bar {
  background: var(--progress-bar-color, var(--gradient-primary-background));
  border-radius: calc(var(--progress-bar-height) / 2);
}
.progress-bar--circular[data-v-057b3c72] {
  width: var(--progress-bar-height);
  color: var(--progress-bar-color);
}
.progress-bar--error[data-v-057b3c72] {
  color: var(--color-text-error, var(--color-error)) !important;
}
.progress-bar--error[data-v-057b3c72]::-moz-progress-bar {
  background: var(--color-text-error, var(--color-error)) !important;
}
.progress-bar--error[data-v-057b3c72]::-webkit-progress-value {
  background: var(--color-text-error, var(--color-error)) !important;
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-19be28f6] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.team-resources__header[data-v-19be28f6] {
  font-weight: bold;
  margin-bottom: 6px;
}
.related-team[data-v-19be28f6] {
  border-radius: var(--border-radius-container);
  border: 2px solid var(--color-border-dark);
  margin-bottom: 6px;
}
.related-team__open[data-v-19be28f6] {
  border-color: var(--color-primary-element);
}
.related-team__header[data-v-19be28f6] {
  padding: 6px;
  padding-inline-end: 24px;
  display: flex;
  gap: 12px;
}
.related-team__name[data-v-19be28f6] {
  display: flex;
  flex-grow: 1;
  align-items: center;
  gap: 12px;
  padding: 6px 12px;
  font-weight: bold;
  margin: 0;
}
.related-team .related-team-provider[data-v-19be28f6] {
  padding: 6px 12px;
}
.related-team .related-team-provider__name[data-v-19be28f6] {
  font-weight: bold;
  margin-bottom: 3px;
}
.related-team .related-team-provider__link[data-v-19be28f6] {
  display: flex;
  gap: 12px;
  padding: 6px 12px;
  font-weight: bold;
}
.related-team .related-team-resource__link[data-v-19be28f6] {
  display: flex;
  gap: 12px;
  height: var(--default-clickable-area);
  align-items: center;
  border-radius: var(--border-radius-element);
}
.related-team .related-team-resource__link[data-v-19be28f6]:hover {
  background-color: var(--color-background-hover);
}
.related-team .related-team-resource__link[data-v-19be28f6]:focus {
  background-color: var(--color-background-hover);
  outline: 2px solid var(--color-primary-element);
}
.related-team .related-team-resource .resource__icon[data-v-19be28f6] {
  width: var(--default-clickable-area);
  height: var(--default-clickable-area);
  display: flex;
  align-items: center;
  justify-content: center;
  text-align: center;
}
.related-team .related-team-resource .resource__icon > img[data-v-19be28f6] {
  border-radius: var(--border-radius-pill);
  overflow: hidden;
  width: 32px;
  height: 32px;
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-bcd84980] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.resource[data-v-bcd84980] {
  display: flex;
  align-items: center;
  height: var(--default-clickable-area);
}
.resource__button[data-v-bcd84980] {
  width: 100% !important;
  justify-content: flex-start !important;
  padding: 0 !important;
}
.resource__button[data-v-bcd84980] .button-vue__wrapper {
  justify-content: flex-start !important;
}
.resource__button[data-v-bcd84980] .button-vue__wrapper .button-vue__text {
  font-weight: normal !important;
  margin-inline-start: 2px !important;
}
.resource__icon[data-v-bcd84980] {
  width: 32px;
  height: 32px;
  background-color: var(--color-text-maxcontrast);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
}
.resource__icon img[data-v-bcd84980] {
  width: 16px;
  height: 16px;
  filter: var(--background-invert-if-dark);
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-2a2d0b30] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.related-resources__header h5[data-v-2a2d0b30] {
  font-weight: bold;
  margin-bottom: 6px;
}
.related-resources__header p[data-v-2a2d0b30] {
  color: var(--color-text-maxcontrast);
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-b62241e4] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.autocomplete-result[data-v-b62241e4] {
  display: flex;
  align-items: center;
  gap: var(--default-grid-baseline);
  line-height: 1.2;
  --auto-complete-result-avatar-size: var(--default-clickable-area);
}
.autocomplete-result__icon[data-v-b62241e4] {
  position: relative;
  flex: 0 0 var(--default-clickable-area);
  width: var(--default-clickable-area);
  min-width: var(--default-clickable-area);
  height: var(--default-clickable-area);
  border-radius: var(--default-clickable-area);
  background-color: var(--color-background-darker);
  background-repeat: no-repeat;
  background-position: center;
  background-size: contain;
}
.autocomplete-result__icon--with-avatar[data-v-b62241e4] {
  color: inherit;
  background-size: cover;
}
.autocomplete-result__status[data-v-b62241e4] {
  --auto-complete-result-status-icon-size: clamp(14px, var(--auto-complete-result-avatar-size) * 0.4, 18px);
  --auto-complete-result-status-icon-position: calc(var(--auto-complete-result-avatar-size) / 2 * (1 - 1 / sqrt(2)) - var(--auto-complete-result-status-icon-size) / 2);
  box-sizing: border-box;
  position: absolute;
  inset-inline-end: var(--auto-complete-result-status-icon-position);
  bottom: var(--auto-complete-result-status-icon-position);
  height: var(--auto-complete-result-status-icon-size);
  width: var(--auto-complete-result-status-icon-size);
  border: 2px solid var(--color-main-background);
  border-radius: 50%;
  background-color: var(--color-main-background);
  font-size: calc(var(--auto-complete-result-status-icon-size) / 1.2);
  line-height: 1.2;
  background-repeat: no-repeat;
  background-size: var(--auto-complete-result-status-icon-size);
  background-position: center;
}
.autocomplete-result__status--icon[data-v-b62241e4] {
  border: none;
  background-color: transparent;
}
.autocomplete-result__content[data-v-b62241e4] {
  display: flex;
  flex: 1 1 100%;
  flex-direction: column;
  justify-content: center;
  min-width: 0;
}
.autocomplete-result__title[data-v-b62241e4], .autocomplete-result__subline[data-v-b62241e4] {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.autocomplete-result__subline[data-v-b62241e4] {
  color: var(--color-text-maxcontrast);
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-8d63a41d] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.rich-contenteditable[data-v-8d63a41d] {
  --contenteditable-block-offset: calc(2 * var(--default-grid-baseline));
  --contenteditable-inline-start-offset: calc(2 * var(--default-grid-baseline));
  --contenteditable-inline-end-offset: calc(2 * var(--default-grid-baseline));
  position: relative;
  width: auto;
}
.rich-contenteditable__label[data-v-8d63a41d] {
  position: absolute;
  margin-inline: 14px;
  max-width: fit-content;
  inset-block-start: 11px;
  inset-inline: 0;
  color: var(--color-text-maxcontrast);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  pointer-events: none;
  transition: height var(--animation-quick), inset-block-start var(--animation-quick), font-size var(--animation-quick), color var(--animation-quick), background-color var(--animation-quick) var(--animation-slow);
}
.rich-contenteditable__input:focus + .rich-contenteditable__label[data-v-8d63a41d], .rich-contenteditable__input:not(.rich-contenteditable__input--empty) + .rich-contenteditable__label[data-v-8d63a41d] {
  inset-block-start: -10px;
  line-height: 1.5;
  font-size: 13px;
  font-weight: 500;
  border-radius: var(--default-grid-baseline) var(--default-grid-baseline) 0 0;
  background-color: var(--color-main-background);
  padding-inline: 5px;
  margin-inline: 9px;
  transition: height var(--animation-quick), inset-block-start var(--animation-quick), font-size var(--animation-quick), color var(--animation-quick);
}
.rich-contenteditable__input[data-v-8d63a41d] {
  overflow-y: auto;
  width: auto;
  margin: 0;
  padding-block: var(--contenteditable-block-offset);
  padding-inline: var(--contenteditable-inline-start-offset) var(--contenteditable-inline-end-offset);
  cursor: text;
  white-space: pre-wrap;
  overflow-wrap: break-word;
  color: var(--color-main-text);
  border: 2px solid var(--color-border-maxcontrast);
  border-radius: var(--border-radius-element);
  outline: none;
  background-color: var(--color-main-background);
  font-family: var(--font-face);
  font-size: inherit;
  tab-size: 4;
  min-height: var(--default-clickable-area);
  max-height: calc(var(--default-clickable-area) * 5.5);
}
.rich-contenteditable__input--has-label[data-v-8d63a41d] {
  margin-top: 10px;
}
.rich-contenteditable__input--empty[data-v-8d63a41d]:focus:before, .rich-contenteditable__input--empty[data-v-8d63a41d]:not(.rich-contenteditable__input--has-label):before {
  content: attr(aria-placeholder);
  color: var(--color-text-maxcontrast);
  position: absolute;
  width: calc(100% - var(--contenteditable-inline-start-offset) - var(--contenteditable-inline-end-offset));
  height: calc(100% - 2 * var(--contenteditable-block-offset));
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.rich-contenteditable__input[contenteditable=false][data-v-8d63a41d]:not(.rich-contenteditable__input--disabled) {
  cursor: default;
  background-color: transparent;
  color: var(--color-main-text);
  border-color: transparent;
  opacity: 1;
  border-radius: 0;
}
.rich-contenteditable__input--multiline[data-v-8d63a41d] {
  min-height: calc(var(--default-clickable-area) * 3);
  max-height: none;
}
.rich-contenteditable__input--disabled[data-v-8d63a41d] {
  opacity: 0.5;
  color: var(--color-text-maxcontrast);
  border: 2px solid var(--color-background-darker);
  border-radius: var(--border-radius-small);
  background-color: var(--color-background-dark);
}
.rich-contenteditable__input--overflow[data-v-8d63a41d], .rich-contenteditable__input--overflow[data-v-8d63a41d]:hover {
  border-color: var(--color-border-error, var(--color-error)) !important;
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
._material-design-icon_1xkrb_12 {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
._tribute-container_1xkrb_20 {
  z-index: 9000;
  overflow: auto;
  position: absolute;
  /* stylelint-disable-next-line csstools/use-logical */ /* upstream logic */
  left: -100vw;
  margin: var(--default-grid-baseline) 0;
  padding: var(--default-grid-baseline);
  color: var(--color-text-maxcontrast);
  border-radius: var(--border-radius-element);
  background: var(--color-main-background);
  box-shadow: 0 1px 5px var(--color-box-shadow);
}
._tribute-container_1xkrb_20, ._tribute-container_1xkrb_20 * {
  box-sizing: border-box;
}
._tribute-container_1xkrb_20 ul {
  display: flex;
  flex-direction: column;
  gap: var(--default-grid-baseline);
}
._tribute-container_1xkrb_20 ._tribute-container__item_1xkrb_41 {
  color: var(--color-text-maxcontrast);
  border-radius: var(--border-radius-small);
  padding: var(--default-grid-baseline);
  cursor: pointer;
  min-height: var(--clickable-area-small, auto);
}
._tribute-container_1xkrb_20 ._tribute-container__item_1xkrb_41.highlight {
  color: var(--color-main-text);
  background: var(--color-background-hover);
}
._tribute-container_1xkrb_20 ._tribute-container__item_1xkrb_41.highlight, ._tribute-container_1xkrb_20 ._tribute-container__item_1xkrb_41.highlight * {
  cursor: pointer;
}
._tribute-container_1xkrb_20._tribute-container--focus-visible_1xkrb_55 .highlight._tribute-container__item_1xkrb_41 {
  outline: 2px solid var(--color-main-text) !important;
}
._tribute-container-autocomplete_1xkrb_59 {
  min-width: 250px;
  max-width: 300px;
  max-height: calc((var(--default-clickable-area) + 3 * var(--default-grid-baseline)) * 4.5 - 1.5 * var(--default-grid-baseline));
}
._tribute-container-emoji_1xkrb_65,
._tribute-container-link_1xkrb_66 {
  min-width: 200px;
  max-width: 200px;
  max-height: calc((24px + 3 * var(--default-grid-baseline)) * 5.5 - 1.5 * var(--default-grid-baseline));
}
._tribute-container-emoji_1xkrb_65 ._tribute-item_1xkrb_71,
._tribute-container-link_1xkrb_66 ._tribute-item_1xkrb_71 {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
._tribute-container-link_1xkrb_66 {
  min-width: 200px;
  max-width: 300px;
}
._tribute-container-link_1xkrb_66 ._tribute-item_1xkrb_71 {
  display: flex;
  align-items: center;
}
._tribute-container-link_1xkrb_66 ._tribute-item__title_1xkrb_86 {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
._tribute-container-link_1xkrb_66 ._tribute-item__icon_1xkrb_91 {
  margin: auto 0;
  width: 20px;
  height: 20px;
  object-fit: contain;
  padding-inline-end: var(--default-grid-baseline);
  filter: var(--background-invert-if-dark);
}
.nc-select-users[data-v-085bfabd] .vs__selected {
	padding-inline: 0 5px !important;
}
/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-72a58313] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.input-wrapper[data-v-72a58313] {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  width: 100%;
  max-width: 400px;
}
.input-wrapper .action-input__label[data-v-72a58313] {
  margin-inline-end: 12px;
}
.input-wrapper[data-v-72a58313]:disabled {
  cursor: default;
}
.input-wrapper .hint[data-v-72a58313] {
  color: var(--color-text-maxcontrast);
  margin-inline-start: 8px;
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-dbbb3fd7] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.settings-section[data-v-dbbb3fd7] {
  display: block;
  padding: 0 0 calc(var(--default-grid-baseline) * 5) 0;
  margin: calc(var(--default-grid-baseline) * 7);
  width: min(900px, 100% - var(--default-grid-baseline) * 7 * 2);
}
.settings-section[data-v-dbbb3fd7]:not(:last-child) {
  border-bottom: 1px solid var(--color-border);
}
.settings-section__name[data-v-dbbb3fd7] {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  max-width: 900px;
  margin-top: 0;
}
.settings-section__info[data-v-dbbb3fd7] {
  display: flex;
  align-items: center;
  justify-content: center;
  width: var(--default-clickable-area);
  height: var(--default-clickable-area);
  margin: calc((var(--default-clickable-area) - 16px) / 2 * -1);
  margin-inline-start: 0;
  color: var(--color-text-maxcontrast);
}
.settings-section__info[data-v-dbbb3fd7]:hover, .settings-section__info[data-v-dbbb3fd7]:focus, .settings-section__info[data-v-dbbb3fd7]:active {
  color: var(--color-main-text);
}
.settings-section__desc[data-v-dbbb3fd7] {
  margin-top: -0.2em;
  margin-bottom: 1em;
  color: var(--color-text-maxcontrast);
  max-width: 900px;
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-1a32ff89] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.select-group-error[data-v-1a32ff89] {
  color: var(--color-text-error, var(--color-error));
  font-size: 13px;
  padding-inline-start: var(--border-radius-element);
}/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/**
 * SPDX-FileCopyrightText: 2021 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
/*
* Ensure proper alignment of the vue material icons
*/
.material-design-icon[data-v-58be798d] {
  display: flex;
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
}
.textarea[data-v-58be798d] {
  position: relative;
  width: 100%;
  border-radius: var(--border-radius-element);
  margin-block-start: 6px;
  resize: vertical;
}
.textarea__main-wrapper[data-v-58be798d] {
  position: relative;
}
.textarea--disabled[data-v-58be798d] {
  opacity: 0.7;
  filter: saturate(0.7);
}
.textarea__input[data-v-58be798d] {
  margin: 0;
  padding-inline: 10px 6px;
  width: 100%;
  height: calc(var(--default-clickable-area) * 2);
  font-size: var(--default-font-size);
  text-overflow: ellipsis;
  background-color: var(--color-main-background);
  color: var(--color-main-text);
  border: var(--border-width-input, 2px) solid var(--color-border-maxcontrast);
  border-radius: var(--border-radius-element);
  cursor: pointer;
}
.textarea__input[data-v-58be798d]:active:not([disabled]), .textarea__input[data-v-58be798d]:hover:not([disabled]), .textarea__input[data-v-58be798d]:focus:not([disabled]) {
  border-width: var(--border-width-input-focused, 2px);
  border-color: var(--color-main-text);
  box-shadow: 0 0 0 2px var(--color-main-background) !important;
}
.textarea__input[data-v-58be798d]:not(:focus, .textarea__input--label-outside)::placeholder {
  opacity: 0;
}
.textarea__input[data-v-58be798d]:focus {
  cursor: text;
}
.textarea__input[data-v-58be798d]:disabled {
  cursor: default;
}
.textarea__input[data-v-58be798d]:focus-visible {
  box-shadow: unset !important;
}
.textarea__input--success[data-v-58be798d] {
  border-color: var(--color-border-success, var(--color-success)) !important;
}
.textarea__input--success[data-v-58be798d]:focus-visible {
  box-shadow: rgb(248, 250, 252) 0px 0px 0px 2px, var(--color-primary-element) 0px 0px 0px 4px, rgba(0, 0, 0, 0.05) 0px 1px 2px 0px;
}
.textarea__input--error[data-v-58be798d] {
  border-color: var(--color-border-error, var(--color-error)) !important;
}
.textarea__input--error[data-v-58be798d]:focus-visible {
  box-shadow: rgb(248, 250, 252) 0px 0px 0px 2px, var(--color-primary-element) 0px 0px 0px 4px, rgba(0, 0, 0, 0.05) 0px 1px 2px 0px;
}
.textarea__label[data-v-58be798d] {
  position: absolute;
  margin-inline: 12px 0;
  max-width: fit-content;
  inset-block-start: 11px;
  inset-inline: 0;
  color: var(--color-text-maxcontrast);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  pointer-events: none;
  transition: height var(--animation-quick), inset-block-start var(--animation-quick), font-size var(--animation-quick), color var(--animation-quick), background-color var(--animation-quick) var(--animation-slow);
}
.textarea__input:focus + .textarea__label[data-v-58be798d], .textarea__input:not(:placeholder-shown) + .textarea__label[data-v-58be798d] {
  inset-block-start: -10px;
  line-height: 1.5;
  font-size: 13px;
  font-weight: 500;
  color: var(--color-main-text);
  background-color: var(--color-main-background);
  padding-inline: 4px;
  margin-inline-start: 8px;
  transition: height var(--animation-quick), inset-block-start var(--animation-quick), font-size var(--animation-quick), color var(--animation-quick);
}
.textarea__helper-text-message[data-v-58be798d] {
  padding-block: 4px;
  display: flex;
  align-items: center;
}
.textarea__helper-text-message__icon[data-v-58be798d] {
  margin-inline-end: 8px;
}
.textarea__helper-text-message--error[data-v-58be798d] {
  color: var(--color-error-text);
}
.textarea__helper-text-message--success[data-v-58be798d] {
  color: var(--color-success-text);
}.input-div[data-v-014cf401] {
  --input-height: 44px;
  position: relative;
  margin-bottom: var(--default-grid-baseline);
  display: block !important;
}
.input-div label[data-v-014cf401] {
  display: block;
  margin-bottom: 2px;
}
.input-div input[data-v-014cf401] {
  margin: 0;
}
.input-div input.has-submit[data-v-014cf401], .input-div input.error[data-v-014cf401], .input-div input.success[data-v-014cf401], .input-div input.checking[data-v-014cf401] {
  padding-inline-end: var(--input-height);
}
.input-div input.has-modifier[data-v-014cf401] {
  padding: 0 var(--input-height);
}
.input-div input.error[data-v-014cf401] {
  border-color: var(--color-error);
}
.input-div input.success[data-v-014cf401] {
  border-color: var(--color-success);
}
.input-div .input-wrapper[data-v-014cf401] {
  position: relative;
  display: flex;
}
.input-div .input-wrapper > input[data-v-014cf401] {
  flex: 1;
}
.input-div .helper[data-v-014cf401] {
  min-height: 1.5rem;
  font-size: 0.8em;
  opacity: 0.8;
}
.input-div .helper.error[data-v-014cf401] {
  opacity: 1;
  color: var(--color-error);
}
.input-div.numeric .input-wrapper input[data-v-014cf401] {
  text-align: center;
  max-width: 4rem;
  padding: 0;
}
.input-div .signaling-icon[data-v-014cf401] {
  position: absolute;
  inset-inline-end: 0;
  width: var(--input-height);
  height: var(--input-height);
}
.input-div .modifier[data-v-014cf401] {
  position: absolute;
  height: 100%;
  width: var(--input-height);
  border-color: var(--color-border-dark);
  cursor: pointer;
}
.input-div .modifier[data-v-014cf401]:hover {
  background-color: var(--color-background-hover);
}
.input-div .modifier.add[data-v-014cf401] {
  inset-inline-end: 0;
  border-inline-start: solid 2px var(--color-border-maxcontrast);
  border-radius: 0 var(--border-radius) var(--border-radius) 0;
}
.input-div .modifier.subtract[data-v-014cf401] {
  border-inline-end: solid 2px var(--color-border-maxcontrast);
  border-radius: var(--border-radius) 0 0 var(--border-radius);
}.loading-overlay {
  position: absolute;
  inset-inline-start: 0;
  top: 0;
  width: 100vw;
  height: 100vh;
  background: var(--color-main-background);
  opacity: 0.9;
  z-index: 9999;
}
.loading-overlay .loading-overlay__inner {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
}
.loading-overlay .loading-overlay__name {
  margin-bottom: 10px;
  text-align: center;
  font-weight: bold;
  font-size: 20px;
  line-height: 30px;
}
.loading-overlay .loading-overlay__description {
  color: var(--color-text-maxcontrast);
  text-align: center;
  text-wrap-style: balance;
}
.loading-overlay .loading-overlay__spinner {
  inset-inline-start: 50%;
}.canvas {
  margin: auto;
  padding: 32px;
}
.qr-url {
  font-size: 0.6em;
  margin-top: 16px;
}
@media print {
.noprint {
    display: none;
}
}
.collapsible {
  position: relative;
  margin-bottom: 1.5rem;
}
.collapsible .collapsible_container {
  position: relative;
  overflow: auto;
  width: 100%;
  transition: height 0.3s ease;
  padding-right: 8px;
}
.collapsible .collapsible_container.no-transition {
  transition: none !important;
}
.collapsible .collapsible_wrapper {
  position: relative;
  overflow: hidden;
}
.collapsible .collapsible_wrapper::before, .collapsible .collapsible_wrapper::after {
  content: "";
  position: absolute;
  left: 0;
  right: 8px;
  height: 2.5rem;
  pointer-events: none;
  z-index: 1;
}
.collapsible .collapsible_wrapper::before {
  top: 0;
  background: linear-gradient(to bottom, var(--color-main-background), rgba(0, 0, 0, 0));
  opacity: 0;
  transition: opacity 0.2s;
}
.collapsible .collapsible_wrapper::after {
  bottom: 0;
  background: linear-gradient(to top, var(--color-main-background), rgba(0, 0, 0, 0));
  opacity: 0;
  transition: opacity 0.2s;
}
.collapsible .collapsible_wrapper.has-top-shadow::before {
  opacity: 1;
}
.collapsible .collapsible_wrapper.has-bottom-shadow::after {
  opacity: 1;
}
.resize-handle {
  position: absolute;
  left: 0;
  right: 0;
  height: 12px;
  cursor: ns-resize;
  background: transparent;
  z-index: 1;
}
.resize-handle::before {
  content: "";
  position: absolute;
  top: 50%;
  left: 0;
  right: 0;
  height: 1px;
  background: var(--color-border);
  transform: translateY(-0.5px);
}
.resize-handle::after {
  content: "• • •";
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  padding: 0.15rem 0.5rem;
  font-size: 1rem;
  line-height: 1;
  color: var(--color-main-text);
  background: var(--color-border, rgba(0, 0, 0, 0.05));
  border-radius: 0.5rem;
  pointer-events: none;
  user-select: none;
}
.resize-handle:hover::after {
  color: var(--color-loading-dark);
  background: var(--color-background-darker, rgba(0, 0, 0, 0.1));
}`));
      document.head.appendChild(elementStyle);
    }
  } catch (e) {
    console.error("vite-plugin-css-injected-by-js", e);
  }
})();
const Wu = "agora", Pv = "1.0.0rc4";
import { ba as Ln, i as nt, d as Ve, m as rn, j as An, bC as mn, $ as Er, aH as qu, k as Q, a2 as kn, P as se, e as De, x, o as p, w as he, a as j, z as Be, u as S, s as pr, v as Le, aa as Ku, I as ye, c as M, r as le, L as He, M as rt, bi as Ju, a3 as Xe, bD as Wn, l as Xu, bE as Lr, q as vt, b as gt, bw as ec, b3 as Dr, bF as $o, bG as Vo, b5 as Sr, bx as tc, f as Oe, be as Ct, a4 as ce, J as xt, bH as nc, bI as rc, U as $t, bJ as ac, at as $i, V as Pe, Q as Ot, T as Qo, ae as at, bK as ic, bL as sc, bM as oc, ab as Wo, b6 as qo, b7 as Ba, B as Mt, n as bt, g as Ht, _ as Cn, t as Vi, bb as lc, X as Qi, bN as Wi, aP as uc, aQ as cc, av as Za, a5 as wt, bO as Tc, bP as dc, bQ as Ko, bc as hc, bR as qi, y as Tt, bg as Ki, bS as En, bp as Jo, ar as Xo, aJ as Bt, bT as e0, S as Kt, bU as fc, bV as Ac, a6 as mc, bW as Ec, bX as pc, bY as t0, bZ as Dc, b_ as Sc, b$ as vc, ad as n0, bh as Ia, af as qn, c0 as gc, a8 as r0, c1 as Rc, c2 as Nc, c3 as a0, a0 as Fc, c4 as yc, c5 as Oc, A as Mc, c6 as bc, c7 as na, c8 as ra, c9 as i0, ca as s0, cb as Yc, Z as wc, cc as _c, cd as Bc, ce as Zc, cf as Ic, cg as Lc, ch as kc, ci as Cc, cj as xc, ck as Hc, aC as Pc, cl as o0, cm as Uc, cn as Gc, co as kr, cp as zc, cq as jc, cr as $c, cs as Vc, ct as Qc, cu as Wc, cv as qc } from "./NcEmptyContent-q-geAf0w-DsDiM4c8.chunk.mjs";
import { _ as Kc, t as Jc, L as Xc } from "./NcDashboardWidget-Wkx_9xKh-DfVZeYPI.chunk.mjs";
import { C as eT, a as l0, e as tT, f as Ji, l as u0, N as nT, b as Xi } from "./NcRichText-G8kzsdwx-DWCeYxXp.chunk.mjs";
function rT() {
  if (typeof globalThis.firstDay < "u") return globalThis.firstDay;
  const t = new Intl.Locale(Ln()), e = t.getWeekInfo?.() ?? t.weekInfo;
  return e ? e.firstDay % 7 : 1;
}
function aT() {
  if (typeof globalThis.dayNames < "u") return globalThis.dayNames;
  const t = Ln();
  return [(/* @__PURE__ */ new Date("1970-01-04T00:00:00.000Z")).toLocaleDateString(t, { weekday: "long" }), (/* @__PURE__ */ new Date("1970-01-05T00:00:00.000Z")).toLocaleDateString(t, { weekday: "long" }), (/* @__PURE__ */ new Date("1970-01-06T00:00:00.000Z")).toLocaleDateString(t, { weekday: "long" }), (/* @__PURE__ */ new Date("1970-01-07T00:00:00.000Z")).toLocaleDateString(t, { weekday: "long" }), (/* @__PURE__ */ new Date("1970-01-08T00:00:00.000Z")).toLocaleDateString(t, { weekday: "long" }), (/* @__PURE__ */ new Date("1970-01-09T00:00:00.000Z")).toLocaleDateString(t, { weekday: "long" }), (/* @__PURE__ */ new Date("1970-01-10T00:00:00.000Z")).toLocaleDateString(t, { weekday: "long" })];
}
function iT() {
  if (typeof globalThis.dayNamesMin < "u") return globalThis.dayNamesMin;
  const t = Ln();
  return [(/* @__PURE__ */ new Date("1970-01-04T00:00:00.000Z")).toLocaleDateString(t, { weekday: "narrow" }), (/* @__PURE__ */ new Date("1970-01-05T00:00:00.000Z")).toLocaleDateString(t, { weekday: "narrow" }), (/* @__PURE__ */ new Date("1970-01-06T00:00:00.000Z")).toLocaleDateString(t, { weekday: "narrow" }), (/* @__PURE__ */ new Date("1970-01-07T00:00:00.000Z")).toLocaleDateString(t, { weekday: "narrow" }), (/* @__PURE__ */ new Date("1970-01-08T00:00:00.000Z")).toLocaleDateString(t, { weekday: "narrow" }), (/* @__PURE__ */ new Date("1970-01-09T00:00:00.000Z")).toLocaleDateString(t, { weekday: "narrow" }), (/* @__PURE__ */ new Date("1970-01-10T00:00:00.000Z")).toLocaleDateString(t, { weekday: "narrow" })];
}
const sT = ["id", "textContent"], oT = ["aria-label", "aria-labelledby"], lT = { class: "dialog__text" }, uT = { class: "dialog__actions" }, cT = Ve({ __name: "NcDialog", props: rn({ name: {}, message: { default: "" }, additionalTrapElements: { default: () => [] }, container: { default: "body" }, size: { default: "small" }, buttons: { default: () => [] }, isForm: { type: Boolean }, noClose: { type: Boolean }, closeOnClickOutside: { type: Boolean }, outTransition: { type: Boolean }, navigationAriaLabel: { default: "" }, navigationAriaLabelledby: { default: "" }, contentClasses: { default: "" }, dialogClasses: { default: "" }, navigationClasses: { default: "" } }, { open: { type: Boolean, default: true }, openModifiers: {} }), emits: rn(["closing", "reset", "submit"], ["update:open"]), setup(t, { emit: e }) {
  const n = t, r = An(t, "open"), a = e, i = mn(), s = Er("wrapper-key"), { width: l } = qu(s, { width: 900, height: 0 }), o = Q(() => l.value < 876), c = Q(() => i?.navigation !== void 0), u = kn(), T = Q(() => n.navigationAriaLabel || void 0), f = Q(() => {
    if (!n.navigationAriaLabel) return n.navigationAriaLabelledby || u;
  }), m = Er("dialog-key"), v = Q(() => n.isForm && !c.value ? "form" : "div"), E = Q(() => v.value === "form" ? { submit(L) {
    L.preventDefault(), a("submit", L);
  }, reset(L) {
    L.preventDefault(), a("reset", L);
  } } : {}), A = se(true);
  function g(L, _) {
    L.type === "submit" && v.value === "form" && "reportValidity" in m.value && !m.value.reportValidity() || (O(_), window.setTimeout(() => D(), 300));
  }
  function O(L) {
    A.value = false, a("closing", L);
  }
  const D = () => {
    A.value = true, r.value = false;
  }, w = Q(() => ({ noClose: n.noClose, container: n.container === void 0 ? "body" : n.container, labelId: u, size: n.size, show: r.value && A.value, outTransition: n.outTransition, closeOnClickOutside: n.closeOnClickOutside, additionalTrapElements: n.additionalTrapElements }));
  return (L, _) => r.value ? (p(), De(S(Ju), Le({ key: 0, class: "dialog__modal", "enable-slideshow": false, "disable-swipe": "" }, w.value, { onClose: D, "onUpdate:show": _[0] || (_[0] = (I) => O()) }), { default: he(() => [j("h2", { id: S(u), class: "dialog__name", textContent: Be(L.name) }, null, 8, sT), (p(), De(pr(v.value), Le({ ref: "dialog-key", class: ["dialog", L.dialogClasses] }, Ku(E.value)), { default: he(() => [j("div", { ref: "wrapper-key", class: ye(["dialog__wrapper", { "dialog__wrapper--collapsed": o.value }]) }, [c.value ? (p(), M("nav", { key: 0, class: ye(["dialog__navigation", L.navigationClasses]), "aria-label": T.value, "aria-labelledby": f.value }, [le(L.$slots, "navigation", { isCollapsed: o.value }, void 0, true)], 10, oT)) : x("", true), j("div", { class: ye(["dialog__content", L.contentClasses]) }, [le(L.$slots, "default", {}, () => [j("p", lT, Be(L.message), 1)], true)], 2)], 2), j("div", uT, [le(L.$slots, "actions", {}, () => [(p(true), M(He, null, rt(L.buttons, (I, V) => (p(), De(S(Kc), Le({ key: V }, { ref_for: true }, I, { onClick: (H, Z) => g(I, Z) }), null, 16, ["onClick"]))), 128))], true)])]), _: 3 }, 16, ["class"]))]), _: 3 }, 16)) : x("", true);
} }), c0 = nt(cT, [["__scopeId", "data-v-5392f82b"]]), TT = { name: "NcAppNavigationList" }, dT = { class: "app-navigation-list" };
function hT(t, e, n, r, a, i) {
  return p(), M("ul", dT, [le(t.$slots, "default", {}, void 0, true)]);
}
const fT = nt(TT, [["render", hT], ["__scopeId", "data-v-57437e4a"]]);
Xe();
const AT = { class: "app-navigation-toggle-wrapper" }, mT = Ve({ __name: "NcAppNavigationToggle", props: { open: { type: Boolean, required: true }, openModifiers: {} }, emits: ["update:open"], setup(t) {
  const e = An(t, "open"), n = Q(() => e.value ? ce("Close navigation") : ce("Open navigation"));
  return (r, a) => (p(), M("div", AT, [Oe(S($t), { class: "app-navigation-toggle", "aria-controls": "app-navigation-vue", "aria-expanded": e.value ? "true" : "false", "aria-label": n.value, title: n.value, variant: "tertiary", onClick: a[0] || (a[0] = (i) => e.value = !e.value) }, { icon: he(() => [Oe(xt, { path: e.value ? S(nc) : S(rc) }, null, 8, ["path"])]), _: 1 }, 8, ["aria-expanded", "aria-label", "title"])]));
} }), ET = nt(mT, [["__scopeId", "data-v-e17a2190"]]), pT = ["aria-hidden", "aria-label", "aria-labelledby", "inert"], DT = { class: "app-navigation__search" }, ST = Ve({ __name: "NcAppNavigation", props: { ariaLabel: {}, ariaLabelledby: {} }, setup(t) {
  let e;
  const n = Wn("NcContent:setHasAppNavigation", () => Xu(), false), r = Er("app-navigation-container-key"), a = Lr(), i = se(!a.value);
  vt(a, () => {
    i.value = !a.value;
  }), vt(i, () => {
    o();
  }), gt(() => {
    n(true), ec("toggle-navigation", l), Dr("navigation-toggled", { open: i.value }), e = $o(r.value, { allowOutsideClick: true, fallbackFocus: r.value, trapStack: Vo(), escapeDeactivates: false }), o();
  }), Sr(() => {
    n(false), tc("toggle-navigation", l), e.deactivate();
  });
  function s(u) {
    if (i.value === u) {
      Dr("navigation-toggled", { open: i.value });
      return;
    }
    i.value = u === void 0 ? !i.value : u;
    const T = getComputedStyle(document.body), f = parseInt(T.getPropertyValue("--animation-quick")) || 100;
    setTimeout(() => {
      Dr("navigation-toggled", { open: i.value });
    }, 1.5 * f);
  }
  function l({ open: u }) {
    return s(u);
  }
  function o() {
    a.value && i.value ? e.activate() : e.deactivate();
  }
  function c() {
    a.value && s(false);
  }
  return (u, T) => (p(), M("div", { ref: "app-navigation-container-key", class: ye(["app-navigation", { "app-navigation--closed": !i.value }]) }, [j("nav", { id: "app-navigation-vue", "aria-hidden": i.value ? "false" : "true", "aria-label": u.ariaLabel || void 0, "aria-labelledby": u.ariaLabelledby || void 0, class: "app-navigation__content", inert: !i.value || void 0, onKeydown: Ct(c, ["esc"]) }, [j("div", DT, [le(u.$slots, "search", {}, void 0, true)]), j("div", { class: ye(["app-navigation__body", { "app-navigation__body--no-list": !u.$slots.list }]) }, [le(u.$slots, "default", {}, void 0, true)], 2), u.$slots.list ? (p(), De(S(fT), { key: 0, class: "app-navigation__list" }, { default: he(() => [le(u.$slots, "list", {}, void 0, true)]), _: 3 })) : x("", true), le(u.$slots, "footer", {}, void 0, true)], 40, pT), Oe(ET, { open: i.value, "onUpdate:open": s }, null, 8, ["open"])], 2));
} }), vT = nt(ST, [["__scopeId", "data-v-0d73a3a1"]]), gT = { name: "ChevronUpIcon", emits: ["click"], props: { title: { type: String }, fillColor: { type: String, default: "currentColor" }, size: { type: Number, default: 24 } } }, RT = ["aria-hidden", "aria-label"], NT = ["fill", "width", "height"], FT = { d: "M7.41,15.41L12,10.83L16.59,15.41L18,14L12,8L6,14L7.41,15.41Z" }, yT = { key: 0 };
function OT(t, e, n, r, a, i) {
  return p(), M("span", Le(t.$attrs, { "aria-hidden": n.title ? null : "true", "aria-label": n.title, class: "material-design-icon chevron-up-icon", role: "img", onClick: e[0] || (e[0] = (s) => t.$emit("click", s)) }), [(p(), M("svg", { fill: n.fillColor, class: "material-design-icon__svg", width: n.size, height: n.size, viewBox: "0 0 24 24" }, [j("path", FT, [n.title ? (p(), M("title", yT, Be(n.title), 1)) : x("", true)])], 8, NT))], 16, RT);
}
const MT = nt(gT, [["render", OT]]), bT = { name: "ArrowRightIcon", emits: ["click"], props: { title: { type: String }, fillColor: { type: String, default: "currentColor" }, size: { type: Number, default: 24 } } }, YT = ["aria-hidden", "aria-label"], wT = ["fill", "width", "height"], _T = { d: "M4,11V13H16L10.5,18.5L11.92,19.92L19.84,12L11.92,4.08L10.5,5.5L16,11H4Z" }, BT = { key: 0 };
function ZT(t, e, n, r, a, i) {
  return p(), M("span", Le(t.$attrs, { "aria-hidden": n.title ? null : "true", "aria-label": n.title, class: "material-design-icon arrow-right-icon", role: "img", onClick: e[0] || (e[0] = (s) => t.$emit("click", s)) }), [(p(), M("svg", { fill: n.fillColor, class: "material-design-icon__svg", width: n.size, height: n.size, viewBox: "0 0 24 24" }, [j("path", _T, [n.title ? (p(), M("title", BT, Be(n.title), 1)) : x("", true)])], 8, wT))], 16, YT);
}
const T0 = nt(bT, [["render", ZT]]);
Xe(ac);
const IT = { name: "NcInputConfirmCancel", components: { IconArrowRight: T0, IconClose: $i, NcButton: $t }, props: { primary: { default: false, type: Boolean }, placeholder: { default: "", type: String }, modelValue: { default: "", type: String } }, emits: ["cancel", "confirm", "update:modelValue"], data() {
  return { labelConfirm: ce("Confirm changes"), labelCancel: ce("Cancel changes") };
}, computed: { valueModel: { get() {
  return this.modelValue;
}, set(t) {
  this.$emit("update:modelValue", t);
} } }, methods: { confirm() {
  this.$emit("confirm");
}, cancel() {
  this.$emit("cancel");
}, focusInput() {
  this.$refs.input.focus();
} } }, LT = { class: "app-navigation-input-confirm" }, kT = ["placeholder"];
function CT(t, e, n, r, a, i) {
  const s = Pe("IconArrowRight"), l = Pe("NcButton"), o = Pe("IconClose");
  return p(), M("div", LT, [j("form", { onSubmit: e[1] || (e[1] = at((...c) => i.confirm && i.confirm(...c), ["prevent"])), onKeydown: e[2] || (e[2] = Ct(at((...c) => i.cancel && i.cancel(...c), ["exact", "stop", "prevent"]), ["esc"])), onClick: e[3] || (e[3] = at(() => {
  }, ["stop", "prevent"])) }, [Ot(j("input", { ref: "input", "onUpdate:modelValue": e[0] || (e[0] = (c) => i.valueModel = c), type: "text", class: "app-navigation-input-confirm__input", placeholder: n.placeholder }, null, 8, kT), [[Qo, i.valueModel]]), Oe(l, { "aria-label": a.labelConfirm, type: "submit", variant: "primary", onClick: at(i.confirm, ["stop", "prevent"]) }, { icon: he(() => [Oe(s, { size: 20 })]), _: 1 }, 8, ["aria-label", "onClick"]), Oe(l, { "aria-label": a.labelCancel, type: "reset", variant: n.primary ? "primary" : "tertiary", onClick: at(i.cancel, ["stop", "prevent"]) }, { icon: he(() => [Oe(o, { size: 20 })]), _: 1 }, 8, ["aria-label", "variant", "onClick"])], 32)]);
}
const xT = nt(IT, [["render", CT], ["__scopeId", "data-v-71f6ed5a"]]), es = Ve({ name: "NcVNodes", props: { vnodes: { type: [Array, Object], default: null } }, render() {
  return this.vnodes || this.$slots?.default?.({});
} });
Xe(sc, ic);
const HT = { name: "PencilIcon", emits: ["click"], props: { title: { type: String }, fillColor: { type: String, default: "currentColor" }, size: { type: Number, default: 24 } } }, PT = ["aria-hidden", "aria-label"], UT = ["fill", "width", "height"], GT = { d: "M20.71,7.04C21.1,6.65 21.1,6 20.71,5.63L18.37,3.29C18,2.9 17.35,2.9 16.96,3.29L15.12,5.12L18.87,8.87M3,17.25V21H6.75L17.81,9.93L14.06,6.18L3,17.25Z" }, zT = { key: 0 };
function jT(t, e, n, r, a, i) {
  return p(), M("span", Le(t.$attrs, { "aria-hidden": n.title ? null : "true", "aria-label": n.title, class: "material-design-icon pencil-icon", role: "img", onClick: e[0] || (e[0] = (s) => t.$emit("click", s)) }), [(p(), M("svg", { fill: n.fillColor, class: "material-design-icon__svg", width: n.size, height: n.size, viewBox: "0 0 24 24" }, [j("path", GT, [n.title ? (p(), M("title", zT, Be(n.title), 1)) : x("", true)])], 8, UT))], 16, PT);
}
const $T = nt(HT, [["render", jT]]), VT = { name: "UndoIcon", emits: ["click"], props: { title: { type: String }, fillColor: { type: String, default: "currentColor" }, size: { type: Number, default: 24 } } }, QT = ["aria-hidden", "aria-label"], WT = ["fill", "width", "height"], qT = { d: "M12.5,8C9.85,8 7.45,9 5.6,10.6L2,7V16H11L7.38,12.38C8.77,11.22 10.54,10.5 12.5,10.5C16.04,10.5 19.05,12.81 20.1,16L22.47,15.22C21.08,11.03 17.15,8 12.5,8Z" }, KT = { key: 0 };
function JT(t, e, n, r, a, i) {
  return p(), M("span", Le(t.$attrs, { "aria-hidden": n.title ? null : "true", "aria-label": n.title, class: "material-design-icon undo-icon", role: "img", onClick: e[0] || (e[0] = (s) => t.$emit("click", s)) }), [(p(), M("svg", { fill: n.fillColor, class: "material-design-icon__svg", width: n.size, height: n.size, viewBox: "0 0 24 24" }, [j("path", qT, [n.title ? (p(), M("title", KT, Be(n.title), 1)) : x("", true)])], 8, WT))], 16, QT);
}
const XT = nt(VT, [["render", JT]]);
Xe(oc);
const ed = { name: "NcAppNavigationIconCollapsible", components: { NcButton: $t, ChevronDown: eT, ChevronUp: MT }, props: { open: { type: Boolean, default: true } }, emits: ["click"], computed: { labelButton() {
  return this.open ? ce("Collapse menu") : ce("Open menu");
} }, methods: { onClick(t) {
  this.$emit("click", t);
} } };
function td(t, e, n, r, a, i) {
  const s = Pe("ChevronUp"), l = Pe("ChevronDown"), o = Pe("NcButton");
  return p(), De(o, { class: ye(["icon-collapse", { "icon-collapse--open": n.open }]), "aria-label": i.labelButton, variant: "tertiary", onClick: i.onClick }, { icon: he(() => [n.open ? (p(), De(s, { key: 0, size: 20 })) : (p(), De(l, { key: 1, size: 20 }))]), _: 1 }, 8, ["class", "aria-label", "onClick"]);
}
const nd = nt(ed, [["render", td], ["__scopeId", "data-v-a21d21e6"]]), rd = { name: "NcAppNavigationItem", components: { NcActions: Ba, NcActionButton: qo, NcAppNavigationIconCollapsible: nd, NcInputConfirmCancel: xT, NcLoadingIcon: Wo, NcVNodes: es, Pencil: $T, Undo: XT }, props: { active: { type: Boolean, default: false }, name: { type: String, required: true }, title: { type: String, default: null }, id: { type: String, default: () => kn(), validator: (t) => t.trim() !== "" }, icon: { type: String, default: "" }, loading: { type: Boolean, default: false }, to: { type: [String, Object], default: null }, href: { type: String, default: null }, allowCollapse: { type: Boolean, default: false }, editable: { type: Boolean, default: false }, editLabel: { type: String, default: "" }, editPlaceholder: { type: String, default: "" }, pinned: { type: Boolean, default: false }, undo: { type: Boolean, default: false }, open: { type: Boolean, default: false }, menuOpen: { type: Boolean, default: false }, forceMenu: { type: Boolean, default: false }, menuIcon: { type: String, default: void 0 }, menuPlacement: { type: String, default: "bottom" }, ariaDescription: { type: String, default: null }, forceDisplayActions: { type: Boolean, default: false }, inlineActions: { type: Number, default: 0 } }, emits: ["update:menuOpen", "update:open", "update:name", "click", "undo"], setup() {
  return { isMobile: Lr() };
}, data() {
  return { actionsBoundariesElement: void 0, editingValue: "", opened: this.open, editingActive: false, menuOpenLocalValue: false, focused: false };
}, computed: { isRouterLink() {
  return this.to && !this.href;
}, canHaveChildren() {
  return this.$parent.$options._componentTag !== "AppNavigationItem";
}, editButtonAriaLabel() {
  return this.editLabel ? this.editLabel : ce("Edit item");
}, undoButtonAriaLabel() {
  return ce("Undo changes");
} }, watch: { open(t) {
  this.opened = t;
} }, mounted() {
  this.actionsBoundariesElement = document.querySelector("#content-vue") || void 0;
}, methods: { onMenuToggle(t) {
  this.$emit("update:menuOpen", t), this.menuOpenLocalValue = t;
}, toggleCollapse() {
  this.opened = !this.opened, this.$emit("update:open", this.opened);
}, onClick(t, e, n) {
  this.$emit("click", t), !(t.metaKey || t.altKey || t.ctrlKey || t.shiftKey) && n && (e?.(t), t.preventDefault());
}, handleEdit() {
  this.editingValue = this.name, this.editingActive = true, this.onMenuToggle(false), this.$nextTick(() => {
    this.$refs.editingInput.focusInput();
  });
}, cancelEditing() {
  this.editingActive = false;
}, handleEditingDone() {
  this.$emit("update:name", this.editingValue), this.editingValue = "", this.editingActive = false;
}, handleUndo() {
  this.$emit("undo");
}, handleFocus() {
  this.focused = true;
}, handleBlur() {
  this.focused = false;
}, handleTab(t) {
  this.$refs.actions && (this.focused ? (t.preventDefault(), this.$refs.actions.$refs.triggerButton.$el.focus(), this.focused = false) : this.$refs.actions.$refs.triggerButton.$el.blur());
}, isExternal(t) {
  return t && t.match(/[a-z]+:\/\//i);
} } }, ad = ["id"], id = ["aria-current", "aria-description", "aria-expanded", "href", "target", "title", "onClick"], sd = { key: 0, class: "editingContainer" }, od = { key: 1, class: "app-navigation-entry__deleted" }, ld = { class: "app-navigation-entry__deleted-description" }, ud = { key: 0, class: "app-navigation-entry__counter-wrapper" }, cd = { key: 0, class: "app-navigation-entry__children" };
function Td(t, e, n, r, a, i) {
  const s = Pe("NcLoadingIcon"), l = Pe("NcInputConfirmCancel"), o = Pe("Pencil"), c = Pe("NcActionButton"), u = Pe("Undo"), T = Pe("NcActions"), f = Pe("NcAppNavigationIconCollapsible");
  return p(), M("li", { id: n.id, class: ye([{ "app-navigation-entry--opened": a.opened, "app-navigation-entry--pinned": n.pinned, "app-navigation-entry--collapsible": n.allowCollapse && !!t.$slots.default }, "app-navigation-entry-wrapper"]) }, [(p(), De(pr(i.isRouterLink ? "router-link" : "NcVNodes"), bt(Ht({ ...i.isRouterLink && { custom: true, to: n.to } })), { default: he(({ href: m, navigate: v, isActive: E }) => [j("div", { class: ye([{ "app-navigation-entry--editing": a.editingActive, "app-navigation-entry--deleted": n.undo, active: E && n.to || n.active }, "app-navigation-entry"]) }, [n.undo ? x("", true) : (p(), M("a", { key: 0, class: "app-navigation-entry-link", "aria-current": n.active || E && n.to ? "page" : void 0, "aria-description": n.ariaDescription, "aria-expanded": t.$slots.default ? a.opened.toString() : void 0, href: n.href || m || "#", target: i.isExternal(n.href) ? "_blank" : void 0, title: n.title || n.name, onBlur: e[1] || (e[1] = (...A) => i.handleBlur && i.handleBlur(...A)), onClick: (A) => i.onClick(A, v, m), onFocus: e[2] || (e[2] = (...A) => i.handleFocus && i.handleFocus(...A)), onKeydown: e[3] || (e[3] = Ct(at((...A) => i.handleTab && i.handleTab(...A), ["exact"]), ["tab"])) }, [j("div", { class: ye([{ [n.icon]: n.icon }, "app-navigation-entry-icon"]) }, [n.loading ? (p(), De(s, { key: 0 })) : le(t.$slots, "icon", { key: 1, active: n.active || n.to && E }, void 0, true)], 2), j("span", { class: ye(["app-navigation-entry__name", { "hidden-visually": a.editingActive }]) }, Be(n.name), 3), a.editingActive ? (p(), M("div", sd, [Oe(l, { ref: "editingInput", modelValue: a.editingValue, "onUpdate:modelValue": e[0] || (e[0] = (A) => a.editingValue = A), placeholder: n.editPlaceholder !== "" ? n.editPlaceholder : n.name, primary: E && n.to || n.active, onCancel: i.cancelEditing, onConfirm: i.handleEditingDone }, null, 8, ["modelValue", "placeholder", "primary", "onCancel", "onConfirm"])])) : x("", true)], 40, id)), n.undo ? (p(), M("div", od, [j("div", ld, Be(n.name), 1)])) : x("", true), (t.$slots.actions || t.$slots.counter || n.editable || n.undo) && !a.editingActive ? (p(), M("div", { key: 2, class: ye(["app-navigation-entry__utils", { "app-navigation-entry__utils--display-actions": n.forceDisplayActions || a.menuOpenLocalValue || n.menuOpen }]) }, [t.$slots.counter ? (p(), M("div", ud, [le(t.$slots, "counter", {}, void 0, true)])) : x("", true), t.$slots.actions || n.editable && !a.editingActive || n.undo ? (p(), De(T, { key: 1, ref: "actions", inline: n.inlineActions, class: "app-navigation-entry__actions", container: "#app-navigation-vue", "boundaries-element": a.actionsBoundariesElement, placement: n.menuPlacement, open: n.menuOpen, "force-menu": n.forceMenu, "default-icon": n.menuIcon, variant: E && n.to || n.active ? "primary" : null, "onUpdate:open": i.onMenuToggle }, { icon: he(() => [le(t.$slots, "menu-icon", {}, void 0, true)]), default: he(() => [n.editable && !a.editingActive ? (p(), De(c, { key: 0, "aria-label": i.editButtonAriaLabel, onClick: i.handleEdit }, { icon: he(() => [Oe(o, { size: 20 })]), default: he(() => [Mt(" " + Be(n.editLabel), 1)]), _: 1 }, 8, ["aria-label", "onClick"])) : x("", true), n.undo ? (p(), De(c, { key: 1, "aria-label": i.undoButtonAriaLabel, onClick: i.handleUndo }, { icon: he(() => [Oe(u, { size: 20 })]), _: 1 }, 8, ["aria-label", "onClick"])) : x("", true), le(t.$slots, "actions", {}, void 0, true)]), _: 2 }, 1032, ["inline", "boundaries-element", "placement", "open", "force-menu", "default-icon", "variant", "onUpdate:open"])) : x("", true)], 2)) : x("", true), n.allowCollapse && t.$slots.default ? (p(), De(f, { key: 3, open: a.opened, onClick: at(i.toggleCollapse, ["prevent", "stop"]) }, null, 8, ["open", "onClick"])) : x("", true), le(t.$slots, "extra", {}, void 0, true)], 2)]), _: 3 }, 16)), i.canHaveChildren && t.$slots.default ? (p(), M("ul", cd, [le(t.$slots, "default", {}, void 0, true)])) : x("", true)], 10, ad);
}
const dd = nt(rd, [["render", Td], ["__scopeId", "data-v-7c1c910e"]]), hd = { name: "CheckIcon", emits: ["click"], props: { title: { type: String }, fillColor: { type: String, default: "currentColor" }, size: { type: Number, default: 24 } } }, fd = ["aria-hidden", "aria-label"], Ad = ["fill", "width", "height"], md = { d: "M21,7L9,19L3.5,13.5L4.91,12.09L9,16.17L19.59,5.59L21,7Z" }, Ed = { key: 0 };
function pd(t, e, n, r, a, i) {
  return p(), M("span", Le(t.$attrs, { "aria-hidden": n.title ? null : "true", "aria-label": n.title, class: "material-design-icon check-icon", role: "img", onClick: e[0] || (e[0] = (s) => t.$emit("click", s)) }), [(p(), M("svg", { fill: n.fillColor, class: "material-design-icon__svg", width: n.size, height: n.size, viewBox: "0 0 24 24" }, [j("path", md, [n.title ? (p(), M("title", Ed, Be(n.title), 1)) : x("", true)])], 8, Ad))], 16, fd);
}
const d0 = Cn(hd, [["render", pd]]);
Xe();
const Dd = ["for"], Sd = ["id", "type", "value", "min", "max"], vd = Ve({ inheritAttrs: false, __name: "NcDateTimePickerNative", props: rn({ class: { default: void 0 }, id: { default: () => kn() }, inputClass: { default: "" }, type: { default: "date" }, label: { default: () => ce("Please choose a date") }, min: { default: null }, max: { default: null }, hideLabel: { type: Boolean } }, { modelValue: { default: null }, modelModifiers: {} }), emits: ["update:modelValue"], setup(t) {
  const e = t, n = An(t, "modelValue"), r = Q(() => n.value ? l(n.value) : ""), a = Q(() => e.max ? l(e.max) : void 0), i = Q(() => e.min ? l(e.min) : void 0);
  function s(c) {
    const u = c.getFullYear().toString().padStart(4, "0"), T = (c.getMonth() + 1).toString().padStart(2, "0"), f = c.getDate().toString().padStart(2, "0"), m = c.getHours().toString().padStart(2, "0"), v = c.getMinutes().toString().padStart(2, "0");
    return { yyyy: u, MM: T, dd: f, hh: m, mm: v };
  }
  function l(c) {
    const { yyyy: u, MM: T, dd: f, hh: m, mm: v } = s(c);
    if (e.type === "datetime-local") return `${u}-${T}-${f}T${m}:${v}`;
    if (e.type === "date") return `${u}-${T}-${f}`;
    if (e.type === "month") return `${u}-${T}`;
    if (e.type === "time") return `${m}:${v}`;
    if (e.type === "week") {
      const E = new Date(Number.parseInt(u), 0, 1), A = Math.floor((c.getTime() - E.getTime()) / (1440 * 60 * 1e3)), g = Math.ceil(A / 7);
      return `${u}-W${g}`;
    }
    return "";
  }
  function o(c) {
    const u = c.target;
    if (!u || isNaN(u.valueAsNumber)) n.value = null;
    else if (e.type === "time") {
      const T = u.value, { yyyy: f, MM: m, dd: v } = s(n.value || /* @__PURE__ */ new Date());
      n.value = /* @__PURE__ */ new Date(`${f}-${m}-${v}T${T}`);
    } else if (e.type === "month") {
      const T = (new Date(u.value).getMonth() + 1).toString().padStart(2, "0"), { yyyy: f, dd: m, hh: v, mm: E } = s(n.value || /* @__PURE__ */ new Date());
      n.value = /* @__PURE__ */ new Date(`${f}-${T}-${m}T${v}:${E}`);
    } else {
      const T = new Date(u.valueAsNumber).getTimezoneOffset() * 1e3 * 60, f = u.valueAsNumber + T;
      n.value = new Date(f);
    }
  }
  return (c, u) => (p(), M("div", { class: ye(["native-datetime-picker", c.$props.class]) }, [j("label", { class: ye(["native-datetime-picker__label", { "hidden-visually": c.hideLabel }]), for: c.id }, Be(c.label), 11, Dd), j("input", Le({ id: c.id, class: ["native-datetime-picker__input", c.inputClass], type: c.type, value: r.value, min: i.value, max: a.value }, c.$attrs, { onInput: o }), null, 16, Sd)], 2));
} }), gd = nt(vd, [["__scopeId", "data-v-f356c0a6"]]), Rd = { name: "ChevronLeftIcon", emits: ["click"], props: { title: { type: String }, fillColor: { type: String, default: "currentColor" }, size: { type: Number, default: 24 } } }, Nd = ["aria-hidden", "aria-label"], Fd = ["fill", "width", "height"], yd = { d: "M15.41,16.58L10.83,12L15.41,7.41L14,6L8,12L14,18L15.41,16.58Z" }, Od = { key: 0 };
function Md(t, e, n, r, a, i) {
  return p(), M("span", Le(t.$attrs, { "aria-hidden": n.title ? null : "true", "aria-label": n.title, class: "material-design-icon chevron-left-icon", role: "img", onClick: e[0] || (e[0] = (s) => t.$emit("click", s)) }), [(p(), M("svg", { fill: n.fillColor, class: "material-design-icon__svg", width: n.size, height: n.size, viewBox: "0 0 24 24" }, [j("path", yd, [n.title ? (p(), M("title", Od, Be(n.title), 1)) : x("", true)])], 8, Fd))], 16, Nd);
}
const bd = Cn(Rd, [["render", Md]]), Yd = { name: "ChevronRightIcon", emits: ["click"], props: { title: { type: String }, fillColor: { type: String, default: "currentColor" }, size: { type: Number, default: 24 } } }, wd = ["aria-hidden", "aria-label"], _d = ["fill", "width", "height"], Bd = { d: "M8.59,16.58L13.17,12L8.59,7.41L10,6L16,12L10,18L8.59,16.58Z" }, Zd = { key: 0 };
function Id(t, e, n, r, a, i) {
  return p(), M("span", Le(t.$attrs, { "aria-hidden": n.title ? null : "true", "aria-label": n.title, class: "material-design-icon chevron-right-icon", role: "img", onClick: e[0] || (e[0] = (s) => t.$emit("click", s)) }), [(p(), M("svg", { fill: n.fillColor, class: "material-design-icon__svg", width: n.size, height: n.size, viewBox: "0 0 24 24" }, [j("path", Bd, [n.title ? (p(), M("title", Zd, Be(n.title), 1)) : x("", true)])], 8, _d))], 16, wd);
}
const Ld = Cn(Yd, [["render", Id]]), kd = { name: "PlusIcon", emits: ["click"], props: { title: { type: String }, fillColor: { type: String, default: "currentColor" }, size: { type: Number, default: 24 } } }, Cd = ["aria-hidden", "aria-label"], xd = ["fill", "width", "height"], Hd = { d: "M19,13H13V19H11V13H5V11H11V5H13V11H19V13Z" }, Pd = { key: 0 };
function Ud(t, e, n, r, a, i) {
  return p(), M("span", Le(t.$attrs, { "aria-hidden": n.title ? null : "true", "aria-label": n.title, class: "material-design-icon plus-icon", role: "img", onClick: e[0] || (e[0] = (s) => t.$emit("click", s)) }), [(p(), M("svg", { fill: n.fillColor, class: "material-design-icon__svg", width: n.size, height: n.size, viewBox: "0 0 24 24" }, [j("path", Hd, [n.title ? (p(), M("title", Pd, Be(n.title), 1)) : x("", true)])], 8, xd))], 16, Cd);
}
const h0 = Cn(kd, [["render", Ud]]), Gd = { name: "MinusIcon", emits: ["click"], props: { title: { type: String }, fillColor: { type: String, default: "currentColor" }, size: { type: Number, default: 24 } } }, zd = ["aria-hidden", "aria-label"], jd = ["fill", "width", "height"], $d = { d: "M19,13H5V11H19V13Z" }, Vd = { key: 0 };
function Qd(t, e, n, r, a, i) {
  return p(), M("span", Le(t.$attrs, { "aria-hidden": n.title ? null : "true", "aria-label": n.title, class: "material-design-icon minus-icon", role: "img", onClick: e[0] || (e[0] = (s) => t.$emit("click", s)) }), [(p(), M("svg", { fill: n.fillColor, class: "material-design-icon__svg", width: n.size, height: n.size, viewBox: "0 0 24 24" }, [j("path", $d, [n.title ? (p(), M("title", Vd, Be(n.title), 1)) : x("", true)])], 8, jd))], 16, zd);
}
const Wd = Cn(Gd, [["render", Qd]]), qd = { name: "ArrowRightIcon", emits: ["click"], props: { title: { type: String }, fillColor: { type: String, default: "currentColor" }, size: { type: Number, default: 24 } } }, Kd = ["aria-hidden", "aria-label"], Jd = ["fill", "width", "height"], Xd = { d: "M4,11V13H16L10.5,18.5L11.92,19.92L19.84,12L11.92,4.08L10.5,5.5L16,11H4Z" }, eh = { key: 0 };
function th(t, e, n, r, a, i) {
  return p(), M("span", Le(t.$attrs, { "aria-hidden": n.title ? null : "true", "aria-label": n.title, class: "material-design-icon arrow-right-icon", role: "img", onClick: e[0] || (e[0] = (s) => t.$emit("click", s)) }), [(p(), M("svg", { fill: n.fillColor, class: "material-design-icon__svg", width: n.size, height: n.size, viewBox: "0 0 24 24" }, [j("path", Xd, [n.title ? (p(), M("title", eh, Be(n.title), 1)) : x("", true)])], 8, Jd))], 16, Kd);
}
const nh = Cn(qd, [["render", th]]), rh = { name: "AlertCircleOutlineIcon", emits: ["click"], props: { title: { type: String }, fillColor: { type: String, default: "currentColor" }, size: { type: Number, default: 24 } } }, ah = ["aria-hidden", "aria-label"], ih = ["fill", "width", "height"], sh = { d: "M11,15H13V17H11V15M11,7H13V13H11V7M12,2C6.47,2 2,6.5 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M12,20A8,8 0 0,1 4,12A8,8 0 0,1 12,4A8,8 0 0,1 20,12A8,8 0 0,1 12,20Z" }, oh = { key: 0 };
function lh(t, e, n, r, a, i) {
  return p(), M("span", Le(t.$attrs, { "aria-hidden": n.title ? null : "true", "aria-label": n.title, class: "material-design-icon alert-circle-outline-icon", role: "img", onClick: e[0] || (e[0] = (s) => t.$emit("click", s)) }), [(p(), M("svg", { fill: n.fillColor, class: "material-design-icon__svg", width: n.size, height: n.size, viewBox: "0 0 24 24" }, [j("path", sh, [n.title ? (p(), M("title", oh, Be(n.title), 1)) : x("", true)])], 8, ih))], 16, ah);
}
const uh = Cn(rh, [["render", lh]]), ch = ["aria-hidden", "aria-label"], Th = ["width", "height"], dh = ["stroke"], hh = Ve({ __name: "Spinner", props: { title: { default: () => Vi("agora", "Loading …") }, fillColor: { default: "currentColor" }, size: { default: 24 } }, setup(t) {
  return (e, n) => (p(), M("span", { "aria-hidden": !e.title, "aria-label": e.title, class: "material-design-icon spinner", role: "img" }, [(p(), M("svg", { viewBox: "0 0 100 100", width: e.size, height: e.size }, [j("circle", { cx: "50", cy: "50", r: "45", stroke: e.fillColor }, null, 8, dh)], 8, Th))], 8, ch));
} }), f0 = Cn(hh, [["__scopeId", "data-v-ea840893"]]);
Xe();
const fh = Ve({ name: "NcActionButtonGroup", inject: { isInSemanticMenu: { from: lc, default: false } }, props: { name: { required: false, default: void 0, type: String } }, setup() {
  return { labelId: kn() };
}, methods: { t: ce } }), Ah = ["role"], mh = ["id"], Eh = ["aria-labelledby"];
function ph(t, e, n, r, a, i) {
  return p(), M("li", { class: "nc-button-group-base", role: t.isInSemanticMenu && "presentation" }, [t.name ? (p(), M("div", { key: 0, id: t.labelId }, Be(t.name), 9, mh)) : x("", true), j("ul", { class: "nc-button-group-content", role: "group", "aria-labelledby": t.name ? t.labelId : void 0 }, [le(t.$slots, "default")], 8, Eh)], 8, Ah);
}
const Dh = nt(fh, [["render", ph]]);
var La = { exports: {} }, A0;
function Sh() {
  if (A0) return La.exports;
  A0 = 1;
  function t(e, n = 100, r = {}) {
    if (typeof e != "function") throw new TypeError(`Expected the first parameter to be a function, got \`${typeof e}\`.`);
    if (n < 0) throw new RangeError("`wait` must not be negative.");
    const { immediate: a } = typeof r == "boolean" ? { immediate: r } : r;
    let i, s, l, o, c;
    function u() {
      const m = i, v = s;
      return i = void 0, s = void 0, c = e.apply(m, v), c;
    }
    function T() {
      const m = Date.now() - o;
      m < n && m >= 0 ? l = setTimeout(T, n - m) : (l = void 0, a || (c = u()));
    }
    const f = function(...m) {
      if (i && this !== i && Object.getPrototypeOf(this) === Object.getPrototypeOf(i)) throw new Error("Debounced method called with different contexts of the same prototype.");
      i = this, s = m, o = Date.now();
      const v = a && !l;
      return l || (l = setTimeout(T, n)), v && (c = u()), c;
    };
    return Object.defineProperty(f, "isPending", { get() {
      return l !== void 0;
    } }), f.clear = () => {
      l && (clearTimeout(l), l = void 0);
    }, f.flush = () => {
      l && f.trigger();
    }, f.trigger = () => {
      c = u(), f.clear();
    }, f;
  }
  return La.exports.debounce = t, La.exports = t, La.exports;
}
var vh = Sh();
const ts = Qi(vh);
Xe();
const gh = Ve({ __name: "NcPasswordField", props: rn({ class: {}, inputClass: { default: "" }, id: {}, label: {}, labelOutside: { type: Boolean }, placeholder: {}, showTrailingButton: { type: Boolean, default: true }, success: { type: Boolean }, error: { type: Boolean }, helperText: {}, disabled: { type: Boolean }, pill: { type: Boolean }, checkPasswordStrength: { type: Boolean }, minlength: { default: void 0 }, asText: { type: Boolean } }, { modelValue: { default: "" }, modelModifiers: {}, visible: { type: Boolean, default: false }, visibleModifiers: {} }), emits: rn(["valid", "invalid"], ["update:modelValue", "update:visible"]), setup(t, { expose: e, emit: n }) {
  const r = t, a = An(t, "modelValue");
  vt(a, ts(f, 500));
  const i = An(t, "visible"), s = n;
  e({ focus: v, select: E });
  const { password_policy: l } = Wi(), o = Er("input-field-key"), c = se(""), u = se(), T = Q(() => {
    const A = { ...r };
    return delete A.checkPasswordStrength, delete A.minlength, delete A.asText, delete A.error, delete A.helperText, delete A.inputClass, delete A.success, A;
  });
  async function f() {
    if (r.checkPasswordStrength) try {
      const { data: A } = await uc.post(cc("apps/password_policy/api/v1/validate"), { password: a.value });
      if (u.value = A.ocs.data.passed, A.ocs.data.passed) {
        c.value = ce("Password is secure"), s("valid");
        return;
      }
      c.value = A.ocs.data.reason, s("invalid");
    } catch (A) {
      Za.error("Password policy returned an error", { error: A });
    }
  }
  function m() {
    i.value = !i.value;
  }
  function v(A) {
    o.value.focus(A);
  }
  function E() {
    o.value.select();
  }
  return (A, g) => (p(), De(l0, Le(T.value, { ref: "input-field-key", modelValue: a.value, "onUpdate:modelValue": g[0] || (g[0] = (O) => a.value = O), error: A.error || u.value === false, "helper-text": A.helperText || c.value, "input-class": [A.inputClass, { "password-field__input--secure-text": !i.value && A.asText }], minlength: A.minlength ?? S(l)?.minLength ?? 0, success: A.success || u.value === true, "trailing-button-label": i.value ? S(ce)("Hide password") : S(ce)("Show password"), type: i.value || A.asText ? "text" : "password", onTrailingButtonClick: m }), wt({ "trailing-button-icon": he(() => [Oe(xt, { path: i.value ? S(Tc) : S(dc) }, null, 8, ["path"])]), _: 2 }, [A.$slots.icon ? { name: "icon", fn: he(() => [le(A.$slots, "icon", {}, void 0, true)]), key: "0" } : void 0]), 1040, ["modelValue", "error", "helper-text", "input-class", "minlength", "success", "trailing-button-label", "type"]));
} }), Rh = nt(gh, [["__scopeId", "data-v-929be55a"]]);
Xe(Ko);
const Nh = { name: "NcActionInput", components: { NcDateTimePickerNative: gd, NcPasswordField: Rh, NcTextField: tT, NcColorPicker: qi(() => Ji(() => Promise.resolve().then(() => xv), true ? void 0 : void 0, import.meta.url)), NcDateTimePicker: qi(() => Ji(() => Promise.resolve().then(() => Hv), true ? void 0 : void 0, import.meta.url)), NcSelect: qi(() => Ji(() => Promise.resolve().then(() => Cv), true ? void 0 : void 0, import.meta.url)) }, mixins: [hc], inheritAttrs: false, props: { id: { type: String, default: () => "action-" + kn(), validator: (t) => t.trim() !== "" }, inputId: { type: String, default: () => "action-input-" + kn(), validator: (t) => t.trim() !== "" }, icon: { type: String, default: "" }, type: { type: String, default: "text", validator(t) {
  return ["date", "datetime-local", "month", "multiselect", "number", "password", "search", "tel", "text", "time", "url", "week", "color", "email"].indexOf(t) > -1;
} }, idNativeDateTimePicker: { type: String, default: "date-time-picker_id" }, isNativePicker: { type: Boolean, default: false }, label: { type: String, default: null }, labelOutside: { type: Boolean, default: true }, modelValue: { type: [String, Date, Number, Array], default: "" }, disabled: { type: Boolean, default: false }, ariaLabel: { type: String, default: "" }, showTrailingButton: { type: Boolean, default: true }, trailingButtonLabel: { type: String, default: ce("Submit") }, class: { type: [String, Array, Object], default: "" } }, emits: ["submit", "update:modelValue"], computed: { isIconUrl() {
  try {
    return new URL(this.icon);
  } catch {
    return false;
  }
}, isMultiselectType() {
  return this.type === "multiselect";
}, nativeDatePickerType() {
  switch (this.type) {
    case "date":
    case "month":
    case "time":
    case "week":
    case "datetime-local":
      return this.type;
  }
  return false;
}, datePickerType() {
  if (!this.isNativePicker) switch (this.type) {
    case "date":
    case "month":
    case "time":
      return this.type;
    case "datetime-local":
      return "datetime";
  }
  return false;
}, isFocusable() {
  return !this.disabled;
} }, methods: { onLeave() {
  this.$refs.datetimepicker && this.$refs.datetimepicker.$refs.datepicker && this.$refs.datetimepicker.$refs.datepicker.closePopup();
}, onSubmit(t) {
  if (t.preventDefault(), t.stopPropagation(), !this.disabled) this.$emit("submit", t);
  else return false;
}, onUpdateModelValue(t) {
  this.$emit("update:modelValue", t);
} } }, Fh = { class: "action-input__icon-wrapper" }, yh = ["disabled"], Oh = { class: "action-input__container" }, Mh = ["for"], bh = { class: "action-input__input-container" }, Yh = { key: 4, class: "action-input__container" }, wh = ["for"], _h = { class: "action-input__input-container" };
function Bh(t, e, n, r, a, i) {
  const s = Pe("NcDateTimePicker"), l = Pe("NcDateTimePickerNative"), o = Pe("NcSelect"), c = Pe("NcPasswordField"), u = Pe("NcColorPicker"), T = Pe("NcTextField");
  return p(), M("li", { class: ye(["action", [{ "action--disabled": n.disabled }, t.$props.class]]) }, [j("span", { class: ye([{ "action-input-picker--disabled": n.disabled, "action-input--visible-label": n.labelOutside && n.label }, "action-input"]), onMouseleave: e[3] || (e[3] = (...f) => i.onLeave && i.onLeave(...f)) }, [j("span", Fh, [le(t.$slots, "icon", {}, () => [j("span", { class: ye([[i.isIconUrl ? "action-input__icon--url" : n.icon], "action-input__icon"]), style: Tt({ backgroundImage: i.isIconUrl ? `url(${n.icon})` : null }), "aria-hidden": "true" }, null, 6)], true)]), j("form", { ref: "form", class: "action-input__form", disabled: n.disabled, onSubmit: e[2] || (e[2] = at((...f) => i.onSubmit && i.onSubmit(...f), ["prevent"])) }, [j("div", Oh, [n.label && n.labelOutside ? (p(), M("label", { key: 0, class: ye(["action-input__text-label", { "action-input__text-label--hidden": !n.labelOutside }]), for: n.inputId }, Be(n.label), 11, Mh)) : x("", true), j("div", bh, [i.datePickerType ? (p(), De(s, Le({ key: 0, ref: "datetimepicker", "model-value": n.modelValue, style: { "z-index": "99999999999" }, placeholder: t.text, disabled: n.disabled, type: i.datePickerType, "input-class": ["mx-input", { focusable: i.isFocusable }], class: "action-input__datetimepicker" }, t.$attrs, { "onUpdate:modelValue": i.onUpdateModelValue }), null, 16, ["model-value", "placeholder", "disabled", "type", "input-class", "onUpdate:modelValue"])) : n.isNativePicker ? (p(), De(l, Le({ key: 1, id: n.idNativeDateTimePicker, "model-value": n.modelValue, type: i.nativeDatePickerType, "input-class": { focusable: i.isFocusable }, class: "action-input__datetimepicker" }, t.$attrs, { "onUpdate:modelValue": i.onUpdateModelValue }), null, 16, ["id", "model-value", "type", "input-class", "onUpdate:modelValue"])) : i.isMultiselectType ? (p(), De(o, Le({ key: 2, "model-value": n.modelValue, placeholder: t.text, disabled: n.disabled, "append-to-body": false, "input-class": { focusable: i.isFocusable }, class: "action-input__multi" }, t.$attrs, { "onUpdate:modelValue": i.onUpdateModelValue }), null, 16, ["model-value", "placeholder", "disabled", "input-class", "onUpdate:modelValue"])) : n.type === "password" ? (p(), De(c, Le({ key: 3, id: n.inputId, "model-value": n.modelValue, label: n.label, "label-outside": !n.label || n.labelOutside, placeholder: t.text, disabled: n.disabled, "input-class": { focusable: i.isFocusable }, "show-trailing-button": n.showTrailingButton && !n.disabled }, t.$attrs, { "onUpdate:modelValue": i.onUpdateModelValue }), null, 16, ["id", "model-value", "label", "label-outside", "placeholder", "disabled", "input-class", "show-trailing-button", "onUpdate:modelValue"])) : n.type === "color" ? (p(), M("div", Yh, [n.label && n.type === "color" ? (p(), M("label", { key: 0, class: ye(["action-input__text-label", { "action-input__text-label--hidden": !n.labelOutside }]), for: n.inputId }, Be(n.label), 11, wh)) : x("", true), j("div", _h, [Oe(u, Le({ id: "inputId", "model-value": n.modelValue, class: "colorpicker__trigger" }, t.$attrs, { "onUpdate:modelValue": i.onUpdateModelValue, onSubmit: e[0] || (e[0] = (f) => t.$refs.form.requestSubmit()) }), { default: he(() => [j("button", { style: Tt({ "background-color": n.modelValue }), class: ye(["colorpicker__preview", { focusable: i.isFocusable }]) }, null, 6)]), _: 1 }, 16, ["model-value", "onUpdate:modelValue"])])])) : (p(), De(T, Le({ key: 5, id: n.inputId, "model-value": n.modelValue, label: n.label, "label-outside": !n.label || n.labelOutside, placeholder: t.text, disabled: n.disabled, "input-class": { focusable: i.isFocusable }, type: n.type, "trailing-button-icon": "arrowRight", "trailing-button-label": n.trailingButtonLabel, "show-trailing-button": n.showTrailingButton && !n.disabled }, t.$attrs, { onTrailingButtonClick: e[1] || (e[1] = (f) => t.$refs.form.requestSubmit()), "onUpdate:modelValue": i.onUpdateModelValue }), null, 16, ["id", "model-value", "label", "label-outside", "placeholder", "disabled", "input-class", "type", "trailing-button-label", "show-trailing-button", "onUpdate:modelValue"]))])])], 40, yh)], 34)], 2);
}
const Zh = nt(Nh, [["render", Bh], ["__scopeId", "data-v-7607f0e9"]]), Ih = { __name: "splitpanes", props: { horizontal: { type: Boolean, default: false }, pushOtherPanes: { type: Boolean, default: true }, maximizePanes: { type: Boolean, default: true }, rtl: { type: Boolean, default: false }, firstSplitter: { type: Boolean, default: false } }, emits: ["ready", "resize", "resized", "pane-click", "pane-maximize", "pane-add", "pane-remove", "splitter-click", "splitter-dblclick"], setup(t, { emit: e }) {
  const n = e, r = t, a = mn(), i = se([]), s = Q(() => i.value.reduce((h, F) => (h[~~F.id] = F) && h, {})), l = Q(() => i.value.length), o = se(null), c = se(false), u = se({ mouseDown: false, dragging: false, activeSplitter: null, cursorOffset: 0 }), T = se({ splitter: null, timeoutId: null }), f = Q(() => ({ [`splitpanes splitpanes--${r.horizontal ? "horizontal" : "vertical"}`]: true, "splitpanes--dragging": u.value.dragging })), m = () => {
    document.addEventListener("mousemove", A, { passive: false }), document.addEventListener("mouseup", g), "ontouchstart" in window && (document.addEventListener("touchmove", A, { passive: false }), document.addEventListener("touchend", g));
  }, v = () => {
    document.removeEventListener("mousemove", A, { passive: false }), document.removeEventListener("mouseup", g), "ontouchstart" in window && (document.removeEventListener("touchmove", A, { passive: false }), document.removeEventListener("touchend", g));
  }, E = (h, F) => {
    const U = h.target.closest(".splitpanes__splitter");
    if (U) {
      const { left: ne, top: Y } = U.getBoundingClientRect(), { clientX: pe, clientY: q } = "ontouchstart" in window && h.touches ? h.touches[0] : h;
      u.value.cursorOffset = r.horizontal ? q - Y : pe - ne;
    }
    m(), u.value.mouseDown = true, u.value.activeSplitter = F;
  }, A = (h) => {
    u.value.mouseDown && (h.preventDefault(), u.value.dragging = true, requestAnimationFrame(() => {
      I(L(h)), W("resize", { event: h }, true);
    }));
  }, g = (h) => {
    u.value.dragging && (window.getSelection().removeAllRanges(), W("resized", { event: h }, true)), u.value.mouseDown = false, u.value.activeSplitter = null, setTimeout(() => {
      u.value.dragging = false, v();
    }, 100);
  }, O = (h, F) => {
    "ontouchstart" in window && (h.preventDefault(), T.value.splitter === F ? (clearTimeout(T.value.timeoutId), T.value.timeoutId = null, D(h, F), T.value.splitter = null) : (T.value.splitter = F, T.value.timeoutId = setTimeout(() => T.value.splitter = null, 500))), u.value.dragging || W("splitter-click", { event: h, index: F }, true);
  }, D = (h, F) => {
    if (W("splitter-dblclick", { event: h, index: F }, true), r.maximizePanes) {
      let U = 0;
      i.value = i.value.map((ne, Y) => (ne.size = Y === F ? ne.max : ne.min, Y !== F && (U += ne.min), ne)), i.value[F].size -= U, W("pane-maximize", { event: h, index: F, pane: i.value[F] }), W("resized", { event: h, index: F }, true);
    }
  }, w = (h, F) => {
    W("pane-click", { event: h, index: s.value[F].index, pane: s.value[F] });
  }, L = (h) => {
    const F = o.value.getBoundingClientRect(), { clientX: U, clientY: ne } = "ontouchstart" in window && h.touches ? h.touches[0] : h;
    return { x: U - (r.horizontal ? 0 : u.value.cursorOffset) - F.left, y: ne - (r.horizontal ? u.value.cursorOffset : 0) - F.top };
  }, _ = (h) => {
    h = h[r.horizontal ? "y" : "x"];
    const F = o.value[r.horizontal ? "clientHeight" : "clientWidth"];
    return r.rtl && !r.horizontal && (h = F - h), h * 100 / F;
  }, I = (h) => {
    const F = u.value.activeSplitter;
    let U = { prevPanesSize: H(F), nextPanesSize: Z(F), prevReachedMinPanes: 0, nextReachedMinPanes: 0 };
    const ne = 0 + (r.pushOtherPanes ? 0 : U.prevPanesSize), Y = 100 - (r.pushOtherPanes ? 0 : U.nextPanesSize), pe = Math.max(Math.min(_(h), Y), ne);
    let q = [F, F + 1], Te = i.value[q[0]] || null, R = i.value[q[1]] || null;
    const me = Te.max < 100 && pe >= Te.max + U.prevPanesSize, Se = R.max < 100 && pe <= 100 - (R.max + Z(F + 1));
    if (me || Se) {
      me ? (Te.size = Te.max, R.size = Math.max(100 - Te.max - U.prevPanesSize - U.nextPanesSize, 0)) : (Te.size = Math.max(100 - R.max - U.prevPanesSize - Z(F + 1), 0), R.size = R.max);
      return;
    }
    if (r.pushOtherPanes) {
      const ve = V(U, pe);
      if (!ve) return;
      ({ sums: U, panesToResize: q } = ve), Te = i.value[q[0]] || null, R = i.value[q[1]] || null;
    }
    Te !== null && (Te.size = Math.min(Math.max(pe - U.prevPanesSize - U.prevReachedMinPanes, Te.min), Te.max)), R !== null && (R.size = Math.min(Math.max(100 - pe - U.nextPanesSize - U.nextReachedMinPanes, R.min), R.max));
  }, V = (h, F) => {
    const U = u.value.activeSplitter, ne = [U, U + 1];
    return F < h.prevPanesSize + i.value[ne[0]].min && (ne[0] = J(U).index, h.prevReachedMinPanes = 0, ne[0] < U && i.value.forEach((Y, pe) => {
      pe > ne[0] && pe <= U && (Y.size = Y.min, h.prevReachedMinPanes += Y.min);
    }), h.prevPanesSize = H(ne[0]), ne[0] === void 0) ? (h.prevReachedMinPanes = 0, i.value[0].size = i.value[0].min, i.value.forEach((Y, pe) => {
      pe > 0 && pe <= U && (Y.size = Y.min, h.prevReachedMinPanes += Y.min);
    }), i.value[ne[1]].size = 100 - h.prevReachedMinPanes - i.value[0].min - h.prevPanesSize - h.nextPanesSize, null) : F > 100 - h.nextPanesSize - i.value[ne[1]].min && (ne[1] = re(U).index, h.nextReachedMinPanes = 0, ne[1] > U + 1 && i.value.forEach((Y, pe) => {
      pe > U && pe < ne[1] && (Y.size = Y.min, h.nextReachedMinPanes += Y.min);
    }), h.nextPanesSize = Z(ne[1] - 1), ne[1] === void 0) ? (h.nextReachedMinPanes = 0, i.value.forEach((Y, pe) => {
      pe < l.value - 1 && pe >= U + 1 && (Y.size = Y.min, h.nextReachedMinPanes += Y.min);
    }), i.value[ne[0]].size = 100 - h.prevPanesSize - Z(ne[0] - 1), null) : { sums: h, panesToResize: ne };
  }, H = (h) => i.value.reduce((F, U, ne) => F + (ne < h ? U.size : 0), 0), Z = (h) => i.value.reduce((F, U, ne) => F + (ne > h + 1 ? U.size : 0), 0), J = (h) => [...i.value].reverse().find((F) => F.index < h && F.size > F.min) || {}, re = (h) => i.value.find((F) => F.index > h + 1 && F.size > F.min) || {}, oe = () => {
    var h;
    const F = Array.from(((h = o.value) == null ? void 0 : h.children) || []);
    for (const U of F) {
      const ne = U.classList.contains("splitpanes__pane"), Y = U.classList.contains("splitpanes__splitter");
      !ne && !Y && (U.remove(), console.warn("Splitpanes: Only <pane> elements are allowed at the root of <splitpanes>. One of your DOM nodes was removed."));
    }
  }, b = (h, F, U = false) => {
    const ne = h - 1, Y = document.createElement("div");
    Y.classList.add("splitpanes__splitter"), U || (Y.onmousedown = (pe) => E(pe, ne), typeof window < "u" && "ontouchstart" in window && (Y.ontouchstart = (pe) => E(pe, ne)), Y.onclick = (pe) => O(pe, ne + 1)), Y.ondblclick = (pe) => D(pe, ne + 1), F.parentNode.insertBefore(Y, F);
  }, P = (h) => {
    h.onmousedown = void 0, h.onclick = void 0, h.ondblclick = void 0, h.remove();
  }, k = () => {
    var h;
    const F = Array.from(((h = o.value) == null ? void 0 : h.children) || []);
    for (const ne of F) ne.className.includes("splitpanes__splitter") && P(ne);
    let U = 0;
    for (const ne of F) ne.className.includes("splitpanes__pane") && (!U && r.firstSplitter ? b(U, ne, true) : U && b(U, ne), U++);
  }, te = ({ uid: h, ...F }) => {
    const U = s.value[h];
    for (const [ne, Y] of Object.entries(F)) U[ne] = Y;
  }, Ee = (h) => {
    var F;
    let U = -1;
    Array.from(((F = o.value) == null ? void 0 : F.children) || []).some((ne) => (ne.className.includes("splitpanes__pane") && U++, ne.isSameNode(h.el))), i.value.splice(U, 0, { ...h, index: U }), i.value.forEach((ne, Y) => ne.index = Y), c.value && Bt(() => {
      k(), Ae({ addedPane: i.value[U] }), W("pane-add", { pane: i.value[U] });
    });
  }, ee = (h) => {
    const F = i.value.findIndex((ne) => ne.id === h);
    i.value[F].el = null;
    const U = i.value.splice(F, 1)[0];
    i.value.forEach((ne, Y) => ne.index = Y), Bt(() => {
      k(), W("pane-remove", { pane: U }), Ae({ removedPane: { ...U } });
    });
  }, Ae = (h = {}) => {
    !h.addedPane && !h.removedPane ? Me() : i.value.some((F) => F.givenSize !== null || F.min || F.max < 100) ? B(h) : $(), c.value && W("resized");
  }, $ = () => {
    const h = 100 / l.value;
    let F = 0;
    const U = [], ne = [];
    for (const Y of i.value) Y.size = Math.max(Math.min(h, Y.max), Y.min), F -= Y.size, Y.size >= Y.max && U.push(Y.id), Y.size <= Y.min && ne.push(Y.id);
    F > 0.1 && z(F, U, ne);
  }, Me = () => {
    let h = 100;
    const F = [], U = [];
    let ne = 0;
    for (const pe of i.value) h -= pe.size, pe.givenSize !== null && ne++, pe.size >= pe.max && F.push(pe.id), pe.size <= pe.min && U.push(pe.id);
    let Y = 100;
    if (h > 0.1) {
      for (const pe of i.value) pe.givenSize === null && (pe.size = Math.max(Math.min(h / (l.value - ne), pe.max), pe.min)), Y -= pe.size;
      Y > 0.1 && z(Y, F, U);
    }
  }, B = ({ addedPane: h, removedPane: F } = {}) => {
    let U = 100 / l.value, ne = 0;
    const Y = [], pe = [];
    (h?.givenSize ?? null) !== null && (U = (100 - h.givenSize) / (l.value - 1));
    for (const q of i.value) ne -= q.size, q.size >= q.max && Y.push(q.id), q.size <= q.min && pe.push(q.id);
    if (!(Math.abs(ne) < 0.1)) {
      for (const q of i.value) h?.givenSize !== null && h?.id === q.id || (q.size = Math.max(Math.min(U, q.max), q.min)), ne -= q.size, q.size >= q.max && Y.push(q.id), q.size <= q.min && pe.push(q.id);
      ne > 0.1 && z(ne, Y, pe);
    }
  }, z = (h, F, U) => {
    let ne;
    h > 0 ? ne = h / (l.value - F.length) : ne = h / (l.value - U.length), i.value.forEach((Y, pe) => {
      if (h > 0 && !F.includes(Y.id)) {
        const q = Math.max(Math.min(Y.size + ne, Y.max), Y.min), Te = q - Y.size;
        h -= Te, Y.size = q;
      } else if (!U.includes(Y.id)) {
        const q = Math.max(Math.min(Y.size + ne, Y.max), Y.min), Te = q - Y.size;
        h -= Te, Y.size = q;
      }
    }), Math.abs(h) > 0.1 && Bt(() => {
      c.value && console.warn("Splitpanes: Could not resize panes correctly due to their constraints.");
    });
  }, W = (h, F = void 0, U = false) => {
    const ne = F?.index ?? u.value.activeSplitter ?? null;
    n(h, { ...F, ...ne !== null && { index: ne }, ...U && ne !== null && { prevPane: i.value[ne - (r.firstSplitter ? 1 : 0)], nextPane: i.value[ne + (r.firstSplitter ? 0 : 1)] }, panes: i.value.map((Y) => ({ min: Y.min, max: Y.max, size: Y.size })) });
  };
  vt(() => r.firstSplitter, () => k()), gt(() => {
    oe(), k(), Ae(), W("ready"), c.value = true;
  }), Ki(() => c.value = false);
  const ie = () => {
    var h;
    return Xo("div", { ref: o, class: f.value }, (h = a.default) == null ? void 0 : h.call(a));
  };
  return En("panes", i), En("indexedPanes", s), En("horizontal", Q(() => r.horizontal)), En("requestUpdate", te), En("onPaneAdd", Ee), En("onPaneRemove", ee), En("onPaneClick", w), (h, F) => (p(), De(pr(ie)));
} }, Lh = { __name: "pane", props: { size: { type: [Number, String] }, minSize: { type: [Number, String], default: 0 }, maxSize: { type: [Number, String], default: 100 } }, setup(t) {
  var e;
  const n = t, r = Wn("requestUpdate"), a = Wn("onPaneAdd"), i = Wn("horizontal"), s = Wn("onPaneRemove"), l = Wn("onPaneClick"), o = (e = Jo()) == null ? void 0 : e.uid, c = Wn("indexedPanes"), u = Q(() => c.value[o]), T = se(null), f = Q(() => {
    const A = isNaN(n.size) || n.size === void 0 ? 0 : parseFloat(n.size);
    return Math.max(Math.min(A, v.value), m.value);
  }), m = Q(() => {
    const A = parseFloat(n.minSize);
    return isNaN(A) ? 0 : A;
  }), v = Q(() => {
    const A = parseFloat(n.maxSize);
    return isNaN(A) ? 100 : A;
  }), E = Q(() => {
    var A;
    return `${i.value ? "height" : "width"}: ${(A = u.value) == null ? void 0 : A.size}%`;
  });
  return vt(() => f.value, (A) => r({ uid: o, size: A })), vt(() => m.value, (A) => r({ uid: o, min: A })), vt(() => v.value, (A) => r({ uid: o, max: A })), gt(() => {
    a({ id: o, el: T.value, min: m.value, max: v.value, givenSize: n.size === void 0 ? null : f.value, size: f.value });
  }), Ki(() => s(o)), (A, g) => (p(), M("div", { ref_key: "paneEl", ref: T, class: "splitpanes__pane", onClick: g[0] || (g[0] = (O) => S(l)(O, A._.uid)), style: Tt(E.value) }, [le(A.$slots, "default")], 4));
} };
Xe();
const kh = Ve({ __name: "NcAppContentDetailsToggle", setup(t) {
  const e = Lr();
  vt(e, n, { immediate: true }), Ki(() => {
    e.value && n(false);
  });
  function n(r = true) {
    const a = document.querySelector(".app-navigation .app-navigation-toggle");
    a && (a.style.display = r ? "none" : "", r === true && Dr("toggle-navigation", { open: false }));
  }
  return (r, a) => (p(), De(S($t), { "aria-label": S(ce)("Go back to the list"), class: ye(["app-details-toggle", { "app-details-toggle--mobile": S(e) }]), title: S(ce)("Go back to the list"), variant: "tertiary" }, { icon: he(() => [Oe(S(xt), { directional: "", path: S(mc) }, null, 8, ["path"])]), _: 1 }, 8, ["aria-label", "class", "title"]));
} }), Ch = nt(kh, [["__scopeId", "data-v-a5fd2a54"]]);
let m0 = "missing-app-name";
try {
  m0 = Wu;
} catch {
  Za.error("The `@nextcloud/vue` library was used without setting / replacing the `appName`.");
}
const ns = m0, E0 = e0.getBuilder("nextcloud").persist().build(), xh = Wi().theming?.name ?? "Nextcloud", Hh = u0("core", "active-app", ns), Ph = u0("core", "apps", []).find(({ id: t }) => t === Hh)?.name ?? ns, Uh = { name: "NcAppContent", components: { NcAppContentDetailsToggle: Ch, Pane: Lh, Splitpanes: Ih }, props: { disableSwipe: { type: Boolean, default: false }, listSize: { type: Number, default: 20 }, listMinWidth: { type: Number, default: 15 }, listMaxWidth: { type: Number, default: 40 }, paneConfigKey: { type: String, default: "" }, showDetails: { type: Boolean, default: true }, layout: { type: String, default: "vertical-split", validator(t) {
  return ["no-split", "vertical-split", "horizontal-split"].includes(t);
} }, pageHeading: { type: String, default: null }, pageTitle: { type: String, default: null } }, emits: ["update:showDetails", "resizeList"], setup() {
  return { isMobile: Lr(), isRtl: Ac };
}, data() {
  return { contentHeight: 0, hasList: false, hasContent: false, swiping: {}, listPaneSize: this.restorePaneConfig() };
}, computed: { paneConfigID() {
  if (this.paneConfigKey !== "") return `pane-list-size-${this.paneConfigKey}`;
  try {
    return `pane-list-size-${ns}`;
  } catch {
    return Za.info("[NcAppContent]: falling back to global nextcloud pane config"), "pane-list-size-nextcloud";
  }
}, detailsPaneSize() {
  return this.listPaneSize ? 100 - this.listPaneSize : this.paneDefaults.details.size;
}, paneDefaults() {
  return { list: { size: this.listSize, min: this.listMinWidth, max: this.listMaxWidth }, details: { size: 100 - this.listSize, min: 100 - this.listMaxWidth, max: 100 - this.listMinWidth } };
}, realPageTitle() {
  const t = /* @__PURE__ */ new Set();
  if (this.pageTitle) for (const e of this.pageTitle.split(" - ")) t.add(e);
  else if (this.pageHeading) {
    for (const e of this.pageHeading.split(" - ")) t.add(e);
    t.size > 0 && t.add(Ph);
  } else return null;
  return t.add(xh), [...t.values()].join(" - ");
} }, watch: { realPageTitle: { immediate: true, handler() {
  this.realPageTitle !== null && (document.title = this.realPageTitle);
} } }, updated() {
  this.checkSlots();
}, mounted() {
  this.disableSwipe || (this.swiping = fc(this.$el, { onSwipeEnd: this.handleSwipe })), this.checkSlots(), this.restorePaneConfig();
}, methods: { handleSwipe(t, e) {
  Math.abs(this.swiping.lengthX) > 70 && (this.swiping.coordsStart.x < 300 / 2 && e === "right" ? Dr("toggle-navigation", { open: true }) : this.swiping.coordsStart.x < 300 * 1.5 && e === "left" && Dr("toggle-navigation", { open: false }));
}, handlePaneResize(t) {
  const e = parseInt(t.panes[0].size, 10);
  E0.setItem(this.paneConfigID, JSON.stringify(e)), this.listPaneSize = e, this.$emit("resizeList", { size: e }), console.debug("AppContent pane config", e);
}, checkSlots() {
  this.hasList = !!this.$slots.list, this.hasContent = !!this.$slots.default;
}, restorePaneConfig() {
  const t = parseInt(E0.getItem(this.paneConfigID), 10);
  if (!isNaN(t) && t !== this.listPaneSize) return console.debug("AppContent pane config", t), this.listPaneSize = t, t;
}, hideDetails() {
  this.$emit("update:showDetails", false);
} } }, Gh = { key: 0, class: "hidden-visually" }, zh = { key: 1, class: "app-content-wrapper" };
function jh(t, e, n, r, a, i) {
  const s = Pe("NcAppContentDetailsToggle"), l = Pe("Pane"), o = Pe("Splitpanes");
  return p(), M("main", { id: "app-content-vue", class: ye(["app-content no-snapper", { "app-content--has-list": a.hasList }]) }, [n.pageHeading ? (p(), M("h1", Gh, Be(n.pageHeading), 1)) : x("", true), a.hasList ? (p(), M(He, { key: 1 }, [r.isMobile || n.layout === "no-split" ? (p(), M("div", { key: 0, class: ye(["app-content-wrapper app-content-wrapper--no-split", { "app-content-wrapper--show-details": n.showDetails, "app-content-wrapper--show-list": !n.showDetails, "app-content-wrapper--mobile": r.isMobile }]) }, [n.showDetails ? (p(), De(s, { key: 0, onClick: at(i.hideDetails, ["stop", "prevent"]) }, null, 8, ["onClick"])) : x("", true), Ot(j("div", null, [le(t.$slots, "list", {}, void 0, true)], 512), [[Kt, !n.showDetails]]), n.showDetails ? le(t.$slots, "default", { key: 1 }, void 0, true) : x("", true)], 2)) : n.layout === "vertical-split" || n.layout === "horizontal-split" ? (p(), M("div", zh, [Oe(o, { horizontal: n.layout === "horizontal-split", class: ye(["default-theme", { "splitpanes--horizontal": n.layout === "horizontal-split", "splitpanes--vertical": n.layout === "vertical-split" }]), rtl: r.isRtl, onResized: i.handlePaneResize }, { default: he(() => [Oe(l, { class: "splitpanes__pane-list", size: a.listPaneSize || i.paneDefaults.list.size, "min-size": i.paneDefaults.list.min, "max-size": i.paneDefaults.list.max }, { default: he(() => [le(t.$slots, "list", {}, void 0, true)]), _: 3 }, 8, ["size", "min-size", "max-size"]), Oe(l, { class: "splitpanes__pane-details", size: i.detailsPaneSize, "min-size": i.paneDefaults.details.min, "max-size": i.paneDefaults.details.max }, { default: he(() => [le(t.$slots, "default", {}, void 0, true)]), _: 3 }, 8, ["size", "min-size", "max-size"])]), _: 3 }, 8, ["horizontal", "class", "rtl", "onResized"])])) : x("", true)], 64)) : x("", true), a.hasList ? x("", true) : le(t.$slots, "default", { key: 2 }, void 0, true)], 2);
}
const $h = nt(Uh, [["render", jh], ["__scopeId", "data-v-8d2eca70"]]);
({ ...Ba.props }, Xe()), ce("Search…"), Xe(), Xe(pc);
const Vh = { name: "NcAppSettingsDialog", components: { NcDialog: c0, NcVNodes: es }, provide() {
  return { registerSection: this.registerSection, unregisterSection: this.unregisterSection };
}, props: { open: { type: Boolean, required: true }, showNavigation: { type: Boolean, default: false }, container: { type: String, default: "body" }, name: { type: String, default: "" }, additionalTrapElements: { type: Array, default: () => [] } }, emits: ["update:open"], setup() {
  return { isMobile: Lr() };
}, data() {
  return { selectedSection: "", linkClicked: false, addedScrollListener: false, scroller: null, sections: [] };
}, computed: { dialogProperties() {
  return { additionalTrapElements: this.additionalTrapElements, closeOnClickOutside: true, class: "app-settings", container: this.container, contentClasses: "app-settings__content", size: "large", name: this.name, navigationClasses: "app-settings__navigation" };
}, hasNavigationIcons() {
  return this.sections.some(({ icon: t }) => !!t);
}, hasNavigation() {
  return !(this.isMobile || !this.showNavigation);
}, settingsNavigationAriaLabel() {
  return ce("Settings navigation");
} }, updated() {
  this.$refs.settingsScroller && (this.scroller = this.$refs.settingsScroller, this.addedScrollListener || (this.scroller.addEventListener("scroll", this.handleScroll), this.addedScrollListener = true));
}, methods: { registerSection(t, e, n) {
  if (this.sections.some(({ id: a }) => t === a)) throw new Error(`Duplicate section id found: ${t}. Settings navigation sections must have unique section ids.`);
  this.sections.some(({ name: a }) => e === a);
  const r = [...this.sections, { id: t, name: e, icon: n }];
  this.sections = r.sort(({ id: a }, { id: i }) => {
    const s = (l) => this.$slots.default?.().indexOf((o) => o?.props?.id === l) ?? -1;
    return s(a) - s(i);
  }), this.sections.length === 1 && (this.selectedSection = t);
}, unregisterSection(t) {
  this.sections = this.sections.filter(({ id: e }) => t !== e), this.selectedSection === t && (this.selectedSection = this.sections[0]?.id ?? "");
}, handleSettingsNavigationClick(t) {
  this.linkClicked = true, document.getElementById("settings-section_" + t).scrollIntoView({ behavior: "smooth", inline: "nearest" }), this.selectedSection = t, setTimeout(() => {
    this.linkClicked = false;
  }, 1e3);
}, handleCloseModal(t) {
  t || (this.$emit("update:open", false), this.scroller.removeEventListener("scroll", this.handleScroll), this.addedScrollListener = false, this.scroller.scrollTop = 0);
}, handleScroll() {
  this.linkClicked || this.unfocusNavigationItem();
}, unfocusNavigationItem: ts(function() {
  this.selectedSection = "", document.activeElement.className.includes("navigation-list__link") && document.activeElement.blur();
}, 300) } }, Qh = { key: 0, class: "navigation-list" }, Wh = ["aria-current", "href", "onClick", "onKeydown"], qh = { key: 0, class: "navigation-list__link-icon" }, Kh = { class: "navigation-list__link-text" }, Jh = { ref: "settingsScroller" };
function Xh(t, e, n, r, a, i) {
  const s = Pe("NcVNodes"), l = Pe("NcDialog");
  return n.open ? (p(), De(l, Le({ key: 0, "navigation-aria-label": i.settingsNavigationAriaLabel }, i.dialogProperties, { "onUpdate:open": i.handleCloseModal }), wt({ default: he(() => [j("div", Jh, [le(t.$slots, "default", {}, void 0, true)], 512)]), _: 2 }, [i.hasNavigation ? { name: "navigation", fn: he(({ isCollapsed: o }) => [o ? x("", true) : (p(), M("ul", Qh, [(p(true), M(He, null, rt(a.sections, (c) => (p(), M("li", { key: c.id }, [j("a", { "aria-current": `${c.id === a.selectedSection}`, class: ye({ "navigation-list__link": true, "navigation-list__link--active": c.id === a.selectedSection, "navigation-list__link--icon": i.hasNavigationIcons }), href: `#settings-section_${c.id}`, tabindex: "0", onClick: at((u) => i.handleSettingsNavigationClick(c.id), ["prevent"]), onKeydown: Ct((u) => i.handleSettingsNavigationClick(c.id), ["enter"]) }, [i.hasNavigationIcons ? (p(), M("div", qh, [c.icon ? (p(), De(s, { key: 0, vnodes: c.icon }, null, 8, ["vnodes"])) : x("", true)])) : x("", true), j("span", Kh, Be(c.name), 1)], 42, Wh)]))), 128))]))]), key: "0" } : void 0]), 1040, ["navigation-aria-label", "onUpdate:open"])) : x("", true);
}
const e1 = nt(Vh, [["render", Xh], ["__scopeId", "data-v-92616d32"]]), t1 = "aaa1rp3bb0ott3vie4c1le2ogado5udhabi7c0ademy5centure6ountant0s9o1tor4d0s1ult4e0g1ro2tna4f0l1rica5g0akhan5ency5i0g1rbus3force5tel5kdn3l0ibaba4pay4lfinanz6state5y2sace3tom5m0azon4ericanexpress7family11x2fam3ica3sterdam8nalytics7droid5quan4z2o0l2partments8p0le4q0uarelle8r0ab1mco4chi3my2pa2t0e3s0da2ia2sociates9t0hleta5torney7u0ction5di0ble3o3spost5thor3o0s4w0s2x0a2z0ure5ba0by2idu3namex4d1k2r0celona5laycard4s5efoot5gains6seball5ketball8uhaus5yern5b0c1t1va3cg1n2d1e0ats2uty4er2rlin4st0buy5t2f1g1h0arti5i0ble3d1ke2ng0o3o1z2j1lack0friday9ockbuster8g1omberg7ue3m0s1w2n0pparibas9o0ats3ehringer8fa2m1nd2o0k0ing5sch2tik2on4t1utique6x2r0adesco6idgestone9oadway5ker3ther5ussels7s1t1uild0ers6siness6y1zz3v1w1y1z0h3ca0b1fe2l0l1vinklein9m0era3p2non3petown5ital0one8r0avan4ds2e0er0s4s2sa1e1h1ino4t0ering5holic7ba1n1re3c1d1enter4o1rn3f0a1d2g1h0anel2nel4rity4se2t2eap3intai5ristmas6ome4urch5i0priani6rcle4sco3tadel4i0c2y3k1l0aims4eaning6ick2nic1que6othing5ud3ub0med6m1n1o0ach3des3ffee4llege4ogne5m0mbank4unity6pany2re3uter5sec4ndos3struction8ulting7tact3ractors9oking4l1p2rsica5untry4pon0s4rses6pa2r0edit0card4union9icket5own3s1uise0s6u0isinella9v1w1x1y0mru3ou3z2dad1nce3ta1e1ing3sun4y2clk3ds2e0al0er2s3gree4livery5l1oitte5ta3mocrat6ntal2ist5si0gn4v2hl2iamonds6et2gital5rect0ory7scount3ver5h2y2j1k1m1np2o0cs1tor4g1mains5t1wnload7rive4tv2ubai3nlop4pont4rban5vag2r2z2earth3t2c0o2deka3u0cation8e1g1mail3erck5nergy4gineer0ing9terprises10pson4quipment8r0icsson6ni3s0q1tate5t1u0rovision8s2vents5xchange6pert3osed4ress5traspace10fage2il1rwinds6th3mily4n0s2rm0ers5shion4t3edex3edback6rrari3ero6i0delity5o2lm2nal1nce1ial7re0stone6mdale6sh0ing5t0ness6j1k1lickr3ghts4r2orist4wers5y2m1o0o0d1tball6rd1ex2sale4um3undation8x2r0ee1senius7l1ogans4ntier7tr2ujitsu5n0d2rniture7tbol5yi3ga0l0lery3o1up4me0s3p1rden4y2b0iz3d0n2e0a1nt0ing5orge5f1g0ee3h1i0ft0s3ves2ing5l0ass3e1obal2o4m0ail3bh2o1x2n1odaddy5ld0point6f2o0dyear5g0le4p1t1v2p1q1r0ainger5phics5tis4een3ipe3ocery4up4s1t1u0cci3ge2ide2tars5ru3w1y2hair2mburg5ngout5us3bo2dfc0bank7ealth0care8lp1sinki6re1mes5iphop4samitsu7tachi5v2k0t2m1n1ockey4ldings5iday5medepot5goods5s0ense7nda3rse3spital5t0ing5t0els3mail5use3w2r1sbc3t1u0ghes5yatt3undai7ibm2cbc2e1u2d1e0ee3fm2kano4l1m0amat4db2mo0bilien9n0c1dustries8finiti5o2g1k1stitute6urance4e4t0ernational10uit4vestments10o1piranga7q1r0ish4s0maili5t0anbul7t0au2v3jaguar4va3cb2e0ep2tzt3welry6io2ll2m0p2nj2o0bs1urg4t1y2p0morgan6rs3uegos4niper7kaufen5ddi3e0rryhotels6properties14fh2g1h1i0a1ds2m1ndle4tchen5wi3m1n1oeln3matsu5sher5p0mg2n2r0d1ed3uokgroup8w1y0oto4z2la0caixa5mborghini8er3nd0rover6xess5salle5t0ino3robe5w0yer5b1c1ds2ease3clerc5frak4gal2o2xus4gbt3i0dl2fe0insurance9style7ghting6ke2lly3mited4o2ncoln4k2ve1ing5k1lc1p2oan0s3cker3us3l1ndon4tte1o3ve3pl0financial11r1s1t0d0a3u0ndbeck6xe1ury5v1y2ma0drid4if1son4keup4n0agement7go3p1rket0ing3s4riott5shalls7ttel5ba2c0kinsey7d1e0d0ia3et2lbourne7me1orial6n0u2rckmsd7g1h1iami3crosoft7l1ni1t2t0subishi9k1l0b1s2m0a2n1o0bi0le4da2e1i1m1nash3ey2ster5rmon3tgage6scow4to0rcycles9v0ie4p1q1r1s0d2t0n1r2u0seum3ic4v1w1x1y1z2na0b1goya4me2vy3ba2c1e0c1t0bank4flix4work5ustar5w0s2xt0direct7us4f0l2g0o2hk2i0co2ke1on3nja3ssan1y5l1o0kia3rton4w0ruz3tv4p1r0a1w2tt2u1yc2z2obi1server7ffice5kinawa6layan0group9lo3m0ega4ne1g1l0ine5oo2pen3racle3nge4g0anic5igins6saka4tsuka4t2vh3pa0ge2nasonic7ris2s1tners4s1y3y2ccw3e0t2f0izer5g1h0armacy6d1ilips5one2to0graphy6s4ysio5ics1tet2ures6d1n0g1k2oneer5zza4k1l0ace2y0station9umbing5s3m1n0c2ohl2ker3litie5rn2st3r0axi3ess3ime3o0d0uctions8f1gressive8mo2perties3y5tection8u0dential9s1t1ub2w0c2y2qa1pon3uebec3st5racing4dio4e0ad1lestate6tor2y4cipes5d0stone5umbrella9hab3ise0n3t2liance6n0t0als5pair3ort3ublican8st0aurant8view0s5xroth6ich0ardli6oh3l1o1p2o0cks3deo3gers4om3s0vp3u0gby3hr2n2w0e2yukyu6sa0arland6fe0ty4kura4le1on3msclub4ung5ndvik0coromant12ofi4p1rl2s1ve2xo3b0i1s2c0b1haeffler7midt4olarships8ol3ule3warz5ience5ot3d1e0arch3t2cure1ity6ek2lect4ner3rvices6ven3w1x0y3fr2g1h0angrila6rp3ell3ia1ksha5oes2p0ping5uji3w3i0lk2na1gles5te3j1k0i0n2y0pe4l0ing4m0art3ile4n0cf3o0ccer3ial4ftbank4ware6hu2lar2utions7ng1y2y2pa0ce3ort2t3r0l2s1t0ada2ples4r1tebank4farm7c0group6ockholm6rage3e3ream4udio2y3yle4u0cks3pplies3y2ort5rf1gery5zuki5v1watch4iss4x1y0dney4stems6z2tab1ipei4lk2obao4rget4tamotors6r2too4x0i3c0i2d0k2eam2ch0nology8l1masek5nnis4va3f1g1h0d1eater2re6iaa2ckets5enda4ps2res2ol4j0maxx4x2k0maxx5l1m0all4n1o0day3kyo3ols3p1ray3shiba5tal3urs3wn2yota3s3r0ade1ing4ining5vel0ers0insurance16ust3v2t1ube2i1nes3shu4v0s2w1z2ua1bank3s2g1k1nicom3versity8o2ol2ps2s1y1z2va0cations7na1guard7c1e0gas3ntures6risign5mögensberater2ung14sicherung10t2g1i0ajes4deo3g1king4llas4n1p1rgin4sa1ion4va1o3laanderen9n1odka3lvo3te1ing3o2yage5u2wales2mart4ter4ng0gou5tch0es6eather0channel12bcam3er2site5d0ding5ibo2r3f1hoswho6ien2ki2lliamhill9n0dows4e1ners6me2olterskluwer11odside6rk0s2ld3w2s1tc1f3xbox3erox4ihuan4n2xx2yz3yachts4hoo3maxun5ndex5e1odobashi7ga2kohama6u0tube6t1un3za0ppos4ra3ero3ip2m1one3uerich6w2", n1 = "ελ1υ2бг1ел3дети4ею2католик6ом3мкд2он1сква6онлайн5рг3рус2ф2сайт3рб3укр3қаз3հայ3ישראל5קום3ابوظبي5رامكو5لاردن4بحرين5جزائر5سعودية6عليان5مغرب5مارات5یران5بارت2زار4يتك3ھارت5تونس4سودان3رية5شبكة4عراق2ب2مان4فلسطين6قطر3كاثوليك6وم3مصر2ليسيا5وريتانيا7قع4همراه5پاکستان7ڀارت4कॉम3नेट3भारत0म्3ोत5संगठन5বাংলা5ভারত2ৰত4ਭਾਰਤ4ભારત4ଭାରତ4இந்தியா6லங்கை6சிங்கப்பூர்11భారత్5ಭಾರತ4ഭാരതം5ලංකා4คอม3ไทย3ລາວ3გე2みんな3アマゾン4クラウド4グーグル4コム2ストア3セール3ファッション6ポイント4世界2中信1国1國1文网3亚马逊3企业2佛山2信息2健康2八卦2公司1益2台湾1灣2商城1店1标2嘉里0大酒店5在线2大拿2天主教3娱乐2家電2广东2微博2慈善2我爱你3手机2招聘2政务1府2新加坡2闻2时尚2書籍2机构2淡马锡3游戏2澳門2点看2移动2组织机构4网址1店1站1络2联通2谷歌2购物2通販2集团2電訊盈科4飞利浦3食品2餐厅2香格里拉3港2닷넷1컴2삼성2한국2", rs = "numeric", as = "ascii", is = "alpha", aa = "asciinumeric", ia = "alphanumeric", ss = "domain", p0 = "emoji", r1 = "scheme", a1 = "slashscheme", os = "whitespace";
function i1(t, e) {
  return t in e || (e[t] = []), e[t];
}
function vr(t, e, n) {
  e[rs] && (e[aa] = true, e[ia] = true), e[as] && (e[aa] = true, e[is] = true), e[aa] && (e[ia] = true), e[is] && (e[ia] = true), e[ia] && (e[ss] = true), e[p0] && (e[ss] = true);
  for (const r in e) {
    const a = i1(r, n);
    a.indexOf(t) < 0 && a.push(t);
  }
}
function s1(t, e) {
  const n = {};
  for (const r in e) e[r].indexOf(t) >= 0 && (n[r] = true);
  return n;
}
function Jt(t = null) {
  this.j = {}, this.jr = [], this.jd = null, this.t = t;
}
Jt.groups = {}, Jt.prototype = { accepts() {
  return !!this.t;
}, go(t) {
  const e = this, n = e.j[t];
  if (n) return n;
  for (let r = 0; r < e.jr.length; r++) {
    const a = e.jr[r][0], i = e.jr[r][1];
    if (i && a.test(t)) return i;
  }
  return e.jd;
}, has(t, e = false) {
  return e ? t in this.j : !!this.go(t);
}, ta(t, e, n, r) {
  for (let a = 0; a < t.length; a++) this.tt(t[a], e, n, r);
}, tr(t, e, n, r) {
  r = r || Jt.groups;
  let a;
  return e && e.j ? a = e : (a = new Jt(e), n && r && vr(e, n, r)), this.jr.push([t, a]), a;
}, ts(t, e, n, r) {
  let a = this;
  const i = t.length;
  if (!i) return a;
  for (let s = 0; s < i - 1; s++) a = a.tt(t[s]);
  return a.tt(t[i - 1], e, n, r);
}, tt(t, e, n, r) {
  r = r || Jt.groups;
  const a = this;
  if (e && e.j) return a.j[t] = e, e;
  const i = e;
  let s, l = a.go(t);
  if (l ? (s = new Jt(), Object.assign(s.j, l.j), s.jr.push.apply(s.jr, l.jr), s.jd = l.jd, s.t = l.t) : s = new Jt(), i) {
    if (r) if (s.t && typeof s.t == "string") {
      const o = Object.assign(s1(s.t, r), n);
      vr(i, o, r);
    } else n && vr(i, n, r);
    s.t = i;
  }
  return a.j[t] = s, s;
} };
const Ge = (t, e, n, r, a) => t.ta(e, n, r, a), mt = (t, e, n, r, a) => t.tr(e, n, r, a), D0 = (t, e, n, r, a) => t.ts(e, n, r, a), fe = (t, e, n, r, a) => t.tt(e, n, r, a), xn = "WORD", ls = "UWORD", S0 = "ASCIINUMERICAL", v0 = "ALPHANUMERICAL", sa = "LOCALHOST", us = "TLD", cs = "UTLD", ka = "SCHEME", Cr = "SLASH_SCHEME", Ts = "NUM", ds = "WS", hs = "NL", oa = "OPENBRACE", la = "CLOSEBRACE", Ca = "OPENBRACKET", xa = "CLOSEBRACKET", Ha = "OPENPAREN", Pa = "CLOSEPAREN", Ua = "OPENANGLEBRACKET", Ga = "CLOSEANGLEBRACKET", za = "FULLWIDTHLEFTPAREN", ja = "FULLWIDTHRIGHTPAREN", $a = "LEFTCORNERBRACKET", Va = "RIGHTCORNERBRACKET", Qa = "LEFTWHITECORNERBRACKET", Wa = "RIGHTWHITECORNERBRACKET", qa = "FULLWIDTHLESSTHAN", Ka = "FULLWIDTHGREATERTHAN", Ja = "AMPERSAND", Xa = "APOSTROPHE", ei = "ASTERISK", Kn = "AT", ti = "BACKSLASH", ni = "BACKTICK", ri = "CARET", Jn = "COLON", fs = "COMMA", ai = "DOLLAR", On = "DOT", ii = "EQUALS", As = "EXCLAMATION", cn = "HYPHEN", ua = "PERCENT", si = "PIPE", oi = "PLUS", li = "POUND", ca = "QUERY", ms = "QUOTE", g0 = "FULLWIDTHMIDDLEDOT", Es = "SEMI", Mn = "SLASH", Ta = "TILDE", ui = "UNDERSCORE", R0 = "EMOJI", ci = "SYM";
var N0 = Object.freeze({ __proto__: null, ALPHANUMERICAL: v0, AMPERSAND: Ja, APOSTROPHE: Xa, ASCIINUMERICAL: S0, ASTERISK: ei, AT: Kn, BACKSLASH: ti, BACKTICK: ni, CARET: ri, CLOSEANGLEBRACKET: Ga, CLOSEBRACE: la, CLOSEBRACKET: xa, CLOSEPAREN: Pa, COLON: Jn, COMMA: fs, DOLLAR: ai, DOT: On, EMOJI: R0, EQUALS: ii, EXCLAMATION: As, FULLWIDTHGREATERTHAN: Ka, FULLWIDTHLEFTPAREN: za, FULLWIDTHLESSTHAN: qa, FULLWIDTHMIDDLEDOT: g0, FULLWIDTHRIGHTPAREN: ja, HYPHEN: cn, LEFTCORNERBRACKET: $a, LEFTWHITECORNERBRACKET: Qa, LOCALHOST: sa, NL: hs, NUM: Ts, OPENANGLEBRACKET: Ua, OPENBRACE: oa, OPENBRACKET: Ca, OPENPAREN: Ha, PERCENT: ua, PIPE: si, PLUS: oi, POUND: li, QUERY: ca, QUOTE: ms, RIGHTCORNERBRACKET: Va, RIGHTWHITECORNERBRACKET: Wa, SCHEME: ka, SEMI: Es, SLASH: Mn, SLASH_SCHEME: Cr, SYM: ci, TILDE: Ta, TLD: us, UNDERSCORE: ui, UTLD: cs, UWORD: ls, WORD: xn, WS: ds });
const Hn = /[a-z]/, da = new RegExp("\\p{L}", "u"), ps = new RegExp("\\p{Emoji}", "u"), Pn = /\d/, Ds = /\s/, F0 = "\r", Ss = `
`, o1 = "️", l1 = "‍", vs = "￼";
let Ti = null, di = null;
function u1(t = []) {
  const e = {};
  Jt.groups = e;
  const n = new Jt();
  Ti == null && (Ti = O0(t1)), di == null && (di = O0(n1)), fe(n, "'", Xa), fe(n, "{", oa), fe(n, "}", la), fe(n, "[", Ca), fe(n, "]", xa), fe(n, "(", Ha), fe(n, ")", Pa), fe(n, "<", Ua), fe(n, ">", Ga), fe(n, "（", za), fe(n, "）", ja), fe(n, "「", $a), fe(n, "」", Va), fe(n, "『", Qa), fe(n, "』", Wa), fe(n, "＜", qa), fe(n, "＞", Ka), fe(n, "&", Ja), fe(n, "*", ei), fe(n, "@", Kn), fe(n, "`", ni), fe(n, "^", ri), fe(n, ":", Jn), fe(n, ",", fs), fe(n, "$", ai), fe(n, ".", On), fe(n, "=", ii), fe(n, "!", As), fe(n, "-", cn), fe(n, "%", ua), fe(n, "|", si), fe(n, "+", oi), fe(n, "#", li), fe(n, "?", ca), fe(n, '"', ms), fe(n, "/", Mn), fe(n, ";", Es), fe(n, "~", Ta), fe(n, "_", ui), fe(n, "\\", ti), fe(n, "・", g0);
  const r = mt(n, Pn, Ts, { [rs]: true });
  mt(r, Pn, r);
  const a = mt(r, Hn, S0, { [aa]: true }), i = mt(r, da, v0, { [ia]: true }), s = mt(n, Hn, xn, { [as]: true });
  mt(s, Pn, a), mt(s, Hn, s), mt(a, Pn, a), mt(a, Hn, a);
  const l = mt(n, da, ls, { [is]: true });
  mt(l, Hn), mt(l, Pn, i), mt(l, da, l), mt(i, Pn, i), mt(i, Hn), mt(i, da, i);
  const o = fe(n, Ss, hs, { [os]: true }), c = fe(n, F0, ds, { [os]: true }), u = mt(n, Ds, ds, { [os]: true });
  fe(n, vs, u), fe(c, Ss, o), fe(c, vs, u), mt(c, Ds, u), fe(u, F0), fe(u, Ss), mt(u, Ds, u), fe(u, vs, u);
  const T = mt(n, ps, R0, { [p0]: true });
  fe(T, "#"), mt(T, ps, T), fe(T, o1, T);
  const f = fe(T, l1);
  fe(f, "#"), mt(f, ps, T);
  const m = [[Hn, s], [Pn, a]], v = [[Hn, null], [da, l], [Pn, i]];
  for (let E = 0; E < Ti.length; E++) Xn(n, Ti[E], us, xn, m);
  for (let E = 0; E < di.length; E++) Xn(n, di[E], cs, ls, v);
  vr(us, { tld: true, ascii: true }, e), vr(cs, { utld: true, alpha: true }, e), Xn(n, "file", ka, xn, m), Xn(n, "mailto", ka, xn, m), Xn(n, "http", Cr, xn, m), Xn(n, "https", Cr, xn, m), Xn(n, "ftp", Cr, xn, m), Xn(n, "ftps", Cr, xn, m), vr(ka, { scheme: true, ascii: true }, e), vr(Cr, { slashscheme: true, ascii: true }, e), t = t.sort((E, A) => E[0] > A[0] ? 1 : -1);
  for (let E = 0; E < t.length; E++) {
    const A = t[E][0], O = t[E][1] ? { [r1]: true } : { [a1]: true };
    A.indexOf("-") >= 0 ? O[ss] = true : Hn.test(A) ? Pn.test(A) ? O[aa] = true : O[as] = true : O[rs] = true, D0(n, A, A, O);
  }
  return D0(n, "localhost", sa, { ascii: true }), n.jd = new Jt(ci), { start: n, tokens: Object.assign({ groups: e }, N0) };
}
function y0(t, e) {
  const n = c1(e.replace(/[A-Z]/g, (l) => l.toLowerCase())), r = n.length, a = [];
  let i = 0, s = 0;
  for (; s < r; ) {
    let l = t, o = null, c = 0, u = null, T = -1, f = -1;
    for (; s < r && (o = l.go(n[s])); ) l = o, l.accepts() ? (T = 0, f = 0, u = l) : T >= 0 && (T += n[s].length, f++), c += n[s].length, i += n[s].length, s++;
    i -= T, s -= f, c -= T, a.push({ t: u.t, v: e.slice(i - c, i), s: i - c, e: i });
  }
  return a;
}
function c1(t) {
  const e = [], n = t.length;
  let r = 0;
  for (; r < n; ) {
    let a = t.charCodeAt(r), i, s = a < 55296 || a > 56319 || r + 1 === n || (i = t.charCodeAt(r + 1)) < 56320 || i > 57343 ? t[r] : t.slice(r, r + 2);
    e.push(s), r += s.length;
  }
  return e;
}
function Xn(t, e, n, r, a) {
  let i;
  const s = e.length;
  for (let l = 0; l < s - 1; l++) {
    const o = e[l];
    t.j[o] ? i = t.j[o] : (i = new Jt(r), i.jr = a.slice(), t.j[o] = i), t = i;
  }
  return i = new Jt(n), i.jr = a.slice(), t.j[e[s - 1]] = i, i;
}
function O0(t) {
  const e = [], n = [];
  let r = 0, a = "0123456789";
  for (; r < t.length; ) {
    let i = 0;
    for (; a.indexOf(t[r + i]) >= 0; ) i++;
    if (i > 0) {
      e.push(n.join(""));
      for (let s = parseInt(t.substring(r, r + i), 10); s > 0; s--) n.pop();
      r += i;
    } else n.push(t[r]), r++;
  }
  return e;
}
const ha = { defaultProtocol: "http", events: null, format: M0, formatHref: M0, nl2br: false, tagName: "a", target: null, rel: null, validate: true, truncate: 1 / 0, className: null, attributes: null, ignoreTags: [], render: null };
function fa(t, e = null) {
  let n = Object.assign({}, ha);
  t && (n = Object.assign(n, t instanceof fa ? t.o : t));
  const r = n.ignoreTags, a = [];
  for (let i = 0; i < r.length; i++) a.push(r[i].toUpperCase());
  this.o = n, e && (this.defaultRender = e), this.ignoreTags = a;
}
fa.prototype = { o: ha, ignoreTags: [], defaultRender(t) {
  return t;
}, check(t) {
  return this.get("validate", t.toString(), t);
}, get(t, e, n) {
  const r = e != null;
  let a = this.o[t];
  return a && (typeof a == "object" ? (a = n.t in a ? a[n.t] : ha[t], typeof a == "function" && r && (a = a(e, n))) : typeof a == "function" && r && (a = a(e, n.t, n)), a);
}, getObj(t, e, n) {
  let r = this.o[t];
  return typeof r == "function" && e != null && (r = r(e, n.t, n)), r;
}, render(t) {
  const e = t.render(this);
  return (this.get("render", null, t) || this.defaultRender)(e, t.t, t);
} };
function M0(t) {
  return t;
}
function b0(t, e) {
  this.t = "token", this.v = t, this.tk = e;
}
b0.prototype = { isLink: false, toString() {
  return this.v;
}, toHref(t) {
  return this.toString();
}, toFormattedString(t) {
  const e = this.toString(), n = t.get("truncate", e, this), r = t.get("format", e, this);
  return n && r.length > n ? r.substring(0, n) + "…" : r;
}, toFormattedHref(t) {
  return t.get("formatHref", this.toHref(t.get("defaultProtocol")), this);
}, startIndex() {
  return this.tk[0].s;
}, endIndex() {
  return this.tk[this.tk.length - 1].e;
}, toObject(t = ha.defaultProtocol) {
  return { type: this.t, value: this.toString(), isLink: this.isLink, href: this.toHref(t), start: this.startIndex(), end: this.endIndex() };
}, toFormattedObject(t) {
  return { type: this.t, value: this.toFormattedString(t), isLink: this.isLink, href: this.toFormattedHref(t), start: this.startIndex(), end: this.endIndex() };
}, validate(t) {
  return t.get("validate", this.toString(), this);
}, render(t) {
  const e = this, n = this.toHref(t.get("defaultProtocol")), r = t.get("formatHref", n, this), a = t.get("tagName", n, e), i = this.toFormattedString(t), s = {}, l = t.get("className", n, e), o = t.get("target", n, e), c = t.get("rel", n, e), u = t.getObj("attributes", n, e), T = t.getObj("events", n, e);
  return s.href = r, l && (s.class = l), o && (s.target = o), c && (s.rel = c), u && Object.assign(s, u), { tagName: a, attributes: s, content: i, eventListeners: T };
} };
function hi(t, e) {
  class n extends b0 {
    constructor(a, i) {
      super(a, i), this.t = t;
    }
  }
  for (const r in e) n.prototype[r] = e[r];
  return n.t = t, n;
}
const Y0 = hi("email", { isLink: true, toHref() {
  return "mailto:" + this.toString();
} }), w0 = hi("text"), T1 = hi("nl"), fi = hi("url", { isLink: true, toHref(t = ha.defaultProtocol) {
  return this.hasProtocol() ? this.v : `${t}://${this.v}`;
}, hasProtocol() {
  const t = this.tk;
  return t.length >= 2 && t[0].t !== sa && t[1].t === Jn;
} }), Tn = (t) => new Jt(t);
function d1({ groups: t }) {
  const e = t.domain.concat([Ja, ei, Kn, ti, ni, ri, ai, ii, cn, Ts, ua, si, oi, li, Mn, ci, Ta, ui]), n = [Xa, Jn, fs, On, As, ua, ca, ms, Es, Ua, Ga, oa, la, xa, Ca, Ha, Pa, za, ja, $a, Va, Qa, Wa, qa, Ka], r = [Ja, Xa, ei, ti, ni, ri, ai, ii, cn, oa, la, ua, si, oi, li, ca, Mn, ci, Ta, ui], a = Tn(), i = fe(a, Ta);
  Ge(i, r, i), Ge(i, t.domain, i);
  const s = Tn(), l = Tn(), o = Tn();
  Ge(a, t.domain, s), Ge(a, t.scheme, l), Ge(a, t.slashscheme, o), Ge(s, r, i), Ge(s, t.domain, s);
  const c = fe(s, Kn);
  fe(i, Kn, c), fe(l, Kn, c), fe(o, Kn, c);
  const u = fe(i, On);
  Ge(u, r, i), Ge(u, t.domain, i);
  const T = Tn();
  Ge(c, t.domain, T), Ge(T, t.domain, T);
  const f = fe(T, On);
  Ge(f, t.domain, T);
  const m = Tn(Y0);
  Ge(f, t.tld, m), Ge(f, t.utld, m), fe(c, sa, m);
  const v = fe(T, cn);
  fe(v, cn, v), Ge(v, t.domain, T), Ge(m, t.domain, T), fe(m, On, f), fe(m, cn, v);
  const E = fe(m, Jn);
  Ge(E, t.numeric, Y0);
  const A = fe(s, cn), g = fe(s, On);
  fe(A, cn, A), Ge(A, t.domain, s), Ge(g, r, i), Ge(g, t.domain, s);
  const O = Tn(fi);
  Ge(g, t.tld, O), Ge(g, t.utld, O), Ge(O, t.domain, s), Ge(O, r, i), fe(O, On, g), fe(O, cn, A), fe(O, Kn, c);
  const D = fe(O, Jn), w = Tn(fi);
  Ge(D, t.numeric, w);
  const L = Tn(fi), _ = Tn();
  Ge(L, e, L), Ge(L, n, _), Ge(_, e, L), Ge(_, n, _), fe(O, Mn, L), fe(w, Mn, L);
  const I = fe(l, Jn), V = fe(o, Jn), H = fe(V, Mn), Z = fe(H, Mn);
  Ge(l, t.domain, s), fe(l, On, g), fe(l, cn, A), Ge(o, t.domain, s), fe(o, On, g), fe(o, cn, A), Ge(I, t.domain, L), fe(I, Mn, L), fe(I, ca, L), Ge(Z, t.domain, L), Ge(Z, e, L), fe(Z, Mn, L);
  const J = [[oa, la], [Ca, xa], [Ha, Pa], [Ua, Ga], [za, ja], [$a, Va], [Qa, Wa], [qa, Ka]];
  for (let re = 0; re < J.length; re++) {
    const [oe, b] = J[re], P = fe(L, oe);
    fe(_, oe, P), fe(P, b, L);
    const k = Tn(fi);
    Ge(P, e, k);
    const te = Tn();
    Ge(P, n), Ge(k, e, k), Ge(k, n, te), Ge(te, e, k), Ge(te, n, te), fe(k, b, L), fe(te, b, L);
  }
  return fe(a, sa, O), fe(a, hs, T1), { start: a, tokens: N0 };
}
function h1(t, e, n) {
  let r = n.length, a = 0, i = [], s = [];
  for (; a < r; ) {
    let l = t, o = null, c = null, u = 0, T = null, f = -1;
    for (; a < r && !(o = l.go(n[a].t)); ) s.push(n[a++]);
    for (; a < r && (c = o || l.go(n[a].t)); ) o = null, l = c, l.accepts() ? (f = 0, T = l) : f >= 0 && f++, a++, u++;
    if (f < 0) a -= u, a < r && (s.push(n[a]), a++);
    else {
      s.length > 0 && (i.push(gs(w0, e, s)), s = []), a -= f, u -= f;
      const m = T.t, v = n.slice(a - u, a);
      i.push(gs(m, e, v));
    }
  }
  return s.length > 0 && i.push(gs(w0, e, s)), i;
}
function gs(t, e, n) {
  const r = n[0].s, a = n[n.length - 1].e, i = e.slice(r, a);
  return new t(i, n);
}
const f1 = typeof console < "u" && console && console.warn || (() => {
}), A1 = "until manual call of linkify.init(). Register all schemes and plugins before invoking linkify the first time.", lt = { scanner: null, parser: null, tokenQueue: [], pluginQueue: [], customSchemes: [], initialized: false };
function m1() {
  return Jt.groups = {}, lt.scanner = null, lt.parser = null, lt.tokenQueue = [], lt.pluginQueue = [], lt.customSchemes = [], lt.initialized = false, lt;
}
function E1(t, e = false) {
  if (lt.initialized && f1(`linkifyjs: already initialized - will not register custom scheme "${t}" ${A1}`), !/^[0-9a-z]+(-[0-9a-z]+)*$/.test(t)) throw new Error(`linkifyjs: incorrect scheme format.
1. Must only contain digits, lowercase ASCII letters or "-"
2. Cannot start or end with "-"
3. "-" cannot repeat`);
  lt.customSchemes.push([t, e]);
}
function p1() {
  lt.scanner = u1(lt.customSchemes);
  for (let t = 0; t < lt.tokenQueue.length; t++) lt.tokenQueue[t][1]({ scanner: lt.scanner });
  lt.parser = d1(lt.scanner.tokens);
  for (let t = 0; t < lt.pluginQueue.length; t++) lt.pluginQueue[t][1]({ scanner: lt.scanner, parser: lt.parser });
  return lt.initialized = true, lt;
}
function Ai(t) {
  return lt.initialized || p1(), h1(lt.parser.start, t, y0(lt.scanner.start, t));
}
Ai.scan = y0;
function D1(t, e = null, n = null) {
  if (e && typeof e == "object") {
    if (n) throw Error(`linkifyjs: Invalid link type ${e}; must be a string`);
    n = e, e = null;
  }
  const r = new fa(n), a = Ai(t), i = [];
  for (let s = 0; s < a.length; s++) {
    const l = a[s];
    l.isLink && (!e || l.t === e) && r.check(l) && i.push(l.toFormattedObject(r));
  }
  return i;
}
function S1(t) {
  const e = new fa({ defaultProtocol: "https", target: "_blank", className: "external linkified", attributes: { rel: "nofollow noopener noreferrer" } }, R1), n = Ai(t), r = [];
  for (const a of n) a.t === "nl" && e.get("nl2br") ? r.push(`<br>
`) : !a.isLink || !e.check(a) ? r.push(t0(a.toString())) : r.push(e.render(a));
  return r.join("");
}
function v1(t) {
  return t.replace(/"/g, "&quot;");
}
function g1(t) {
  const e = [];
  for (const n in t) {
    const r = t[n] + "";
    e.push(`${n}="${v1(r)}"`);
  }
  return e.join(" ");
}
function R1({ tagName: t, attributes: e, content: n }) {
  return `<${t} ${g1(e)}>${t0(n)}</${t}>`;
}
const N1 = function(t, { value: e }) {
  e?.linkify === true && (t.innerHTML = S1(e.text));
}, F1 = ["title"], y1 = Ve({ __name: "NcAppSidebarHeader", props: { name: {}, title: {}, linkify: { type: Boolean } }, setup(t) {
  const e = Wn("NcAppSidebar:header:ref");
  return (n, r) => Ot((p(), M("h2", { ref_key: "headerRef", ref: e, tabindex: "-1", title: n.title }, [Mt(Be(n.name), 1)], 8, F1)), [[S(N1), { text: n.name, linkify: n.linkify }]]);
} }), O1 = { mounted(t) {
  t.focus();
} };
Xe(Dc);
const M1 = { name: "DockRightIcon", emits: ["click"], props: { title: { type: String }, fillColor: { type: String, default: "currentColor" }, size: { type: Number, default: 24 } } }, b1 = ["aria-hidden", "aria-label"], Y1 = ["fill", "width", "height"], w1 = { d: "M20 4H4A2 2 0 0 0 2 6V18A2 2 0 0 0 4 20H20A2 2 0 0 0 22 18V6A2 2 0 0 0 20 4M15 18H4V6H15Z" }, _1 = { key: 0 };
function B1(t, e, n, r, a, i) {
  return p(), M("span", Le(t.$attrs, { "aria-hidden": n.title ? null : "true", "aria-label": n.title, class: "material-design-icon dock-right-icon", role: "img", onClick: e[0] || (e[0] = (s) => t.$emit("click", s)) }), [(p(), M("svg", { fill: n.fillColor, class: "material-design-icon__svg", width: n.size, height: n.size, viewBox: "0 0 24 24" }, [j("path", w1, [n.title ? (p(), M("title", _1, Be(n.title), 1)) : x("", true)])], 8, Y1))], 16, b1);
}
const Z1 = nt(M1, [["render", B1]]), I1 = { name: "StarIcon", emits: ["click"], props: { title: { type: String }, fillColor: { type: String, default: "currentColor" }, size: { type: Number, default: 24 } } }, L1 = ["aria-hidden", "aria-label"], k1 = ["fill", "width", "height"], C1 = { d: "M12,17.27L18.18,21L16.54,13.97L22,9.24L14.81,8.62L12,2L9.19,8.62L2,9.24L7.45,13.97L5.82,21L12,17.27Z" }, x1 = { key: 0 };
function H1(t, e, n, r, a, i) {
  return p(), M("span", Le(t.$attrs, { "aria-hidden": n.title ? null : "true", "aria-label": n.title, class: "material-design-icon star-icon", role: "img", onClick: e[0] || (e[0] = (s) => t.$emit("click", s)) }), [(p(), M("svg", { fill: n.fillColor, class: "material-design-icon__svg", width: n.size, height: n.size, viewBox: "0 0 24 24" }, [j("path", C1, [n.title ? (p(), M("title", x1, Be(n.title), 1)) : x("", true)])], 8, k1))], 16, L1);
}
const P1 = nt(I1, [["render", H1]]), U1 = { name: "StarOutlineIcon", emits: ["click"], props: { title: { type: String }, fillColor: { type: String, default: "currentColor" }, size: { type: Number, default: 24 } } }, G1 = ["aria-hidden", "aria-label"], z1 = ["fill", "width", "height"], j1 = { d: "M12,15.39L8.24,17.66L9.23,13.38L5.91,10.5L10.29,10.13L12,6.09L13.71,10.13L18.09,10.5L14.77,13.38L15.76,17.66M22,9.24L14.81,8.63L12,2L9.19,8.63L2,9.24L7.45,13.97L5.82,21L12,17.27L18.18,21L16.54,13.97L22,9.24Z" }, $1 = { key: 0 };
function V1(t, e, n, r, a, i) {
  return p(), M("span", Le(t.$attrs, { "aria-hidden": n.title ? null : "true", "aria-label": n.title, class: "material-design-icon star-outline-icon", role: "img", onClick: e[0] || (e[0] = (s) => t.$emit("click", s)) }), [(p(), M("svg", { fill: n.fillColor, class: "material-design-icon__svg", width: n.size, height: n.size, viewBox: "0 0 24 24" }, [j("path", j1, [n.title ? (p(), M("title", $1, Be(n.title), 1)) : x("", true)])], 8, z1))], 16, G1);
}
const Q1 = nt(U1, [["render", V1]]), W1 = { name: "NcAppSidebarTabs", components: { NcCheckboxRadioSwitch: nT, NcVNodes: es }, provide() {
  return { registerTab: this.registerTab, unregisterTab: this.unregisterTab, getActiveTab: () => this.activeTab, isTablistShown: () => this.hasMultipleTabs };
}, props: { active: { type: String, default: "" }, forceTabs: { type: Boolean, default: false } }, emits: ["update:active"], data() {
  return { tabs: [], activeTab: "" };
}, computed: { hasMultipleTabs() {
  return this.tabs.length > 1;
}, showForSingleTab() {
  return this.forceTabs && this.tabs.length === 1;
}, currentTabIndex() {
  return this.tabs.findIndex((t) => t.id === this.activeTab);
} }, watch: { active(t) {
  t !== this.activeTab && this.updateActive();
} }, methods: { setActive(t) {
  this.activeTab = t, this.$emit("update:active", this.activeTab);
}, focusPreviousTab() {
  this.currentTabIndex > 0 && this.setActive(this.tabs[this.currentTabIndex - 1].id), this.focusActiveTab();
}, focusNextTab() {
  this.currentTabIndex < this.tabs.length - 1 && this.setActive(this.tabs[this.currentTabIndex + 1].id), this.focusActiveTab();
}, focusFirstTab() {
  this.setActive(this.tabs[0].id), this.focusActiveTab();
}, focusLastTab() {
  this.setActive(this.tabs[this.tabs.length - 1].id), this.focusActiveTab();
}, focusActiveTab() {
  this.$el.querySelector(`#tab-button-${this.activeTab}`).focus();
}, focusActiveTabContent() {
  this.$el.querySelector("#tab-" + this.activeTab).focus();
}, updateActive() {
  this.activeTab = this.active && this.tabs.some((t) => t.id === this.active) ? this.active : this.tabs.length > 0 ? this.tabs[0].id : "";
}, registerTab(t) {
  this.tabs.push(t), this.tabs.sort((e, n) => e.order === n.order ? OC.Util.naturalSortCompare(e.name, n.name) : e.order - n.order), this.updateActive();
}, unregisterTab(t) {
  const e = this.tabs.findIndex((n) => n.id === t);
  e !== -1 && this.tabs.splice(e, 1), this.activeTab === t && this.updateActive();
} } }, q1 = { class: "app-sidebar-tabs" }, K1 = { class: "app-sidebar-tabs__tab-caption" };
function J1(t, e, n, r, a, i) {
  const s = Pe("NcVNodes"), l = Pe("NcCheckboxRadioSwitch");
  return p(), M("div", q1, [i.hasMultipleTabs || i.showForSingleTab ? (p(), M("div", { key: 0, role: "tablist", class: "app-sidebar-tabs__nav", onKeydown: [e[0] || (e[0] = Ct(at((...o) => i.focusPreviousTab && i.focusPreviousTab(...o), ["exact", "prevent", "stop"]), ["left"])), e[1] || (e[1] = Ct(at((...o) => i.focusNextTab && i.focusNextTab(...o), ["exact", "prevent", "stop"]), ["right"])), e[2] || (e[2] = Ct(at((...o) => i.focusActiveTabContent && i.focusActiveTabContent(...o), ["exact", "prevent", "stop"]), ["tab"])), e[3] || (e[3] = Ct(at((...o) => i.focusFirstTab && i.focusFirstTab(...o), ["exact", "prevent", "stop"]), ["home"])), e[4] || (e[4] = Ct(at((...o) => i.focusLastTab && i.focusLastTab(...o), ["exact", "prevent", "stop"]), ["end"])), e[5] || (e[5] = Ct(at((...o) => i.focusFirstTab && i.focusFirstTab(...o), ["exact", "prevent", "stop"]), ["page-up"])), e[6] || (e[6] = Ct(at((...o) => i.focusLastTab && i.focusLastTab(...o), ["exact", "prevent", "stop"]), ["page-down"]))] }, [(p(true), M(He, null, rt(a.tabs, (o) => (p(), De(l, { key: o.id, "aria-controls": `tab-${o.id}`, "aria-selected": String(a.activeTab === o.id), "button-variant": true, "model-value": a.activeTab === o.id, "wrapper-id": `tab-button-${o.id}`, tabindex: a.activeTab === o.id ? 0 : -1, "button-variant-grouped": "horizontal", class: ye(["app-sidebar-tabs__tab", { active: o.id === a.activeTab }]), role: "tab", type: "button", "onUpdate:modelValue": (c) => i.setActive(o.id) }, { icon: he(() => [Oe(s, { vnodes: o.renderIcon() }, { default: he(() => [j("span", { class: ye(["app-sidebar-tabs__tab-icon", o.icon]) }, null, 2)]), _: 2 }, 1032, ["vnodes"])]), default: he(() => [j("span", K1, Be(o.name), 1)]), _: 2 }, 1032, ["aria-controls", "aria-selected", "model-value", "wrapper-id", "tabindex", "class", "onUpdate:modelValue"]))), 128))], 32)) : x("", true), j("div", { class: ye([{ "app-sidebar-tabs__content--multiple": i.hasMultipleTabs }, "app-sidebar-tabs__content"]) }, [le(t.$slots, "default", {}, void 0, true)], 2)]);
}
const X1 = nt(W1, [["render", J1], ["__scopeId", "data-v-9a713930"]]), ef = { name: "NcAppSidebar", components: { NcActions: Ba, NcAppSidebarHeader: y1, NcAppSidebarTabs: X1, NcButton: $t, NcLoadingIcon: Wo, NcEmptyContent: Jc, IconArrowRight: T0, IconClose: $i, IconDockRight: Z1, IconStar: P1, IconStarOutline: Q1 }, directives: { Focus: O1, ClickOutside: vc }, inject: { ncContentSelector: { from: "NcContent:selector", default: void 0 } }, props: { active: { type: String, default: "" }, name: { type: String, default: "", required: true }, nameEditable: { type: Boolean, default: false }, namePlaceholder: { type: String, default: "" }, subname: { type: String, default: "" }, subtitle: { type: String, default: "" }, background: { type: String, default: "" }, starred: { type: Boolean, default: null }, starLoading: { type: Boolean, default: false }, loading: { type: Boolean, default: false }, compact: { type: Boolean, default: false }, empty: { type: Boolean, default: false }, forceMenu: { type: Boolean, default: false }, forceTabs: { type: Boolean, default: false }, linkifyName: { type: Boolean, default: false }, title: { type: String, default: "" }, open: { type: Boolean, default: true }, toggleClasses: { type: [String, Array, Object], default: "" }, toggleAttrs: { type: Object, default: void 0 }, noToggle: { type: Boolean, default: false } }, emits: ["close", "closed", "opened", "update:active", "update:name", "update:nameEditable", "update:open", "update:starred", "submitName", "dismissEditing"], setup() {
  const t = se(null);
  return En("NcAppSidebar:header:ref", t), { uid: kn(), isMobile: gc(), headerRef: t };
}, data() {
  return { changeNameTranslated: ce("Change name"), closeTranslated: ce("Close sidebar"), favoriteTranslated: ce("Favorite"), isStarred: this.starred, focusTrap: null, elementToReturnFocus: null };
}, computed: { canStar() {
  return this.isStarred !== null;
}, hasFigureClickListener() {
  return !!this.$attrs.onFigureClick;
} }, watch: { starred() {
  this.isStarred = this.starred;
}, isMobile() {
  this.toggleFocusTrap();
}, open() {
  this.checkToggleButtonContainerAvailability();
} }, created() {
  this.preserveElementToReturnFocus(), this.checkToggleButtonContainerAvailability();
}, beforeUnmount() {
  this.$emit("closed"), this.focusTrap?.deactivate();
}, methods: { isSlotPopulated: Sc, t: ce, preserveElementToReturnFocus() {
  if (document.activeElement && document.activeElement !== document.body && (this.elementToReturnFocus = document.activeElement, this.elementToReturnFocus.getAttribute("role") === "menuitem")) {
    const t = this.elementToReturnFocus.closest('[role="menu"]');
    if (t) {
      const e = document.querySelector(`[aria-controls="${t.id}"]`);
      this.elementToReturnFocus = e;
    }
  }
}, initFocusTrap() {
  this.focusTrap || (this.focusTrap = $o([this.$refs.sidebar, document.querySelector("#header")], { allowOutsideClick: true, fallbackFocus: this.$refs.closeButton.$el, trapStack: Vo(), escapeDeactivates: false }));
}, toggleFocusTrap() {
  this.open && this.isMobile ? (this.initFocusTrap(), this.focusTrap.activate()) : this.focusTrap?.deactivate();
}, onKeydownEsc(t) {
  this.isMobile && (t.stopPropagation(), this.closeSidebar());
}, onAfterEnter(t) {
  this.elementToReturnFocus && this.focus(), this.toggleFocusTrap(), this.$emit("opened", t);
}, onAfterLeave(t) {
  this.$emit("closed", t), this.toggleFocusTrap(), this.elementToReturnFocus?.focus({ focusVisible: true }), this.elementToReturnFocus = null;
}, closeSidebar(t) {
  this.$emit("close", t), this.$emit("update:open", false);
}, onFigureClick(t) {
  this.$emit("figureClick", t);
}, toggleStarred() {
  this.isStarred = !this.isStarred, this.$emit("update:starred", this.isStarred);
}, async editName() {
  this.$emit("update:nameEditable", true), this.nameEditable && (await this.$nextTick(), this.$refs.nameInput.focus());
}, focus() {
  if (!this.open && !this.noToggle) {
    this.$refs.toggle.$el.focus();
    return;
  }
  try {
    this.headerRef.focus();
  } catch {
  }
}, focusActiveTabContent() {
  this.preserveElementToReturnFocus(), this.$refs.tabs.focusActiveTabContent();
}, checkToggleButtonContainerAvailability() {
  this.open === false && !this.noToggle && !this.ncContentSelector && console.warn("[NcAppSidebar] It looks like you want to use NcAppSidebar with the built-in toggle button. This feature is only available when NcAppSidebar is used in NcContent.");
}, onNameInput(t) {
  this.$emit("update:name", t.target.value);
}, onSubmitName(t) {
  this.$emit("update:nameEditable", false), this.$emit("submitName", t);
}, onDismissEditing() {
  this.$emit("update:nameEditable", false), this.$emit("dismissEditing");
}, onUpdateActive(t) {
  this.$emit("update:active", t);
} } }, tf = ["aria-labelledby"], nf = { class: "app-sidebar-header__info" }, rf = { key: 0, class: "app-sidebar-header__tertiary-actions" }, af = { class: "app-sidebar-header__name-container" }, sf = { class: "app-sidebar-header__mainname-container" }, of = ["placeholder", "value"], lf = ["title"], uf = { key: 2, class: "app-sidebar-header__description" };
function cf(t, e, n, r, a, i) {
  const s = Pe("IconDockRight"), l = Pe("NcButton"), o = Pe("NcLoadingIcon"), c = Pe("IconStar"), u = Pe("IconStarOutline"), T = Pe("NcAppSidebarHeader"), f = Pe("IconArrowRight"), m = Pe("NcActions"), v = Pe("IconClose"), E = Pe("NcAppSidebarTabs"), A = Pe("NcEmptyContent"), g = n0("focus"), O = n0("click-outside");
  return p(), De(qn, { appear: "", name: "slide-right", onAfterEnter: i.onAfterEnter, onAfterLeave: i.onAfterLeave }, { default: he(() => [Ot(j("aside", { id: "app-sidebar-vue", ref: "sidebar", class: "app-sidebar", "aria-labelledby": `app-sidebar-vue-${r.uid}__header`, onKeydown: e[6] || (e[6] = Ct((...D) => i.onKeydownEsc && i.onKeydownEsc(...D), ["esc"])) }, [i.ncContentSelector && !n.open && !n.noToggle ? (p(), De(Ia, { key: 0, to: i.ncContentSelector }, [Oe(l, Le({ ref: "toggle", "aria-label": i.t("Open sidebar"), class: ["app-sidebar__toggle", n.toggleClasses], variant: "tertiary" }, n.toggleAttrs, { onClick: e[0] || (e[0] = (D) => t.$emit("update:open", true)) }), { icon: he(() => [le(t.$slots, "toggle-icon", {}, () => [Oe(s, { size: 20 })], true)]), _: 3 }, 16, ["aria-label", "class"])], 8, ["to"])) : x("", true), j("header", { class: ye([{ "app-sidebar-header--with-figure": i.isSlotPopulated(t.$slots.header?.()) || n.background, "app-sidebar-header--compact": n.compact }, "app-sidebar-header"]) }, [n.empty ? (p(), De(T, { key: 1, class: "app-sidebar-header__mainname--hidden", name: n.name, tabindex: "-1" }, null, 8, ["name"])) : le(t.$slots, "info", { key: 0 }, () => [j("div", nf, [i.isSlotPopulated(t.$slots.header?.()) || n.background ? (p(), M("div", { key: 0, class: ye([{ "app-sidebar-header__figure--with-action": i.hasFigureClickListener }, "app-sidebar-header__figure"]), style: Tt({ backgroundImage: `url(${n.background})` }), tabindex: "0", onClick: e[1] || (e[1] = (...D) => i.onFigureClick && i.onFigureClick(...D)), onKeydown: e[2] || (e[2] = Ct((...D) => i.onFigureClick && i.onFigureClick(...D), ["enter"])) }, [le(t.$slots, "header", { class: "app-sidebar-header__background" }, void 0, true)], 38)) : x("", true), j("div", { class: ye([{ "app-sidebar-header__desc--with-tertiary-action": i.canStar || i.isSlotPopulated(t.$slots["tertiary-actions"]?.()), "app-sidebar-header__desc--editable": n.nameEditable && !n.subname, "app-sidebar-header__desc--with-subname--editable": n.nameEditable && n.subname, "app-sidebar-header__desc--without-actions": !i.isSlotPopulated(t.$slots["secondary-actions"]?.()) }, "app-sidebar-header__desc"]) }, [i.canStar || i.isSlotPopulated(t.$slots["tertiary-actions"]?.()) ? (p(), M("div", rf, [le(t.$slots, "tertiary-actions", {}, () => [i.canStar ? (p(), De(l, { key: 0, "aria-label": a.favoriteTranslated, pressed: a.isStarred, class: "app-sidebar-header__star", variant: "secondary", onClick: at(i.toggleStarred, ["prevent"]) }, { icon: he(() => [n.starLoading ? (p(), De(o, { key: 0 })) : a.isStarred ? (p(), De(c, { key: 1, size: 20 })) : (p(), De(u, { key: 2, size: 20 }))]), _: 1 }, 8, ["aria-label", "pressed", "onClick"])) : x("", true)], true)])) : x("", true), j("div", af, [j("div", sf, [Ot(Oe(T, { class: "app-sidebar-header__mainname", name: n.name, linkify: n.linkifyName, title: n.title, tabindex: n.nameEditable ? 0 : -1, onClick: at(i.editName, ["self"]) }, null, 8, ["name", "linkify", "title", "tabindex", "onClick"]), [[Kt, !n.nameEditable]]), n.nameEditable ? Ot((p(), M("form", { key: 0, class: "app-sidebar-header__mainname-form", onSubmit: e[5] || (e[5] = at((...D) => i.onSubmitName && i.onSubmitName(...D), ["prevent"])) }, [Ot(j("input", { ref: "nameInput", class: "app-sidebar-header__mainname-input", type: "text", placeholder: n.namePlaceholder, value: n.name, onKeydown: e[3] || (e[3] = Ct(at((...D) => i.onDismissEditing && i.onDismissEditing(...D), ["stop"]), ["esc"])), onInput: e[4] || (e[4] = (...D) => i.onNameInput && i.onNameInput(...D)) }, null, 40, of), [[g]]), Oe(l, { "aria-label": a.changeNameTranslated, type: "submit", variant: "tertiary-no-background" }, { icon: he(() => [Oe(f, { size: 20 })]), _: 1 }, 8, ["aria-label"])], 32)), [[O, () => i.onSubmitName()]]) : x("", true), i.isSlotPopulated(t.$slots["secondary-actions"]?.()) ? (p(), De(m, { key: 1, class: "app-sidebar-header__menu", "force-menu": n.forceMenu }, { default: he(() => [le(t.$slots, "secondary-actions", {}, void 0, true)]), _: 3 }, 8, ["force-menu"])) : x("", true)]), n.subname.trim() !== "" || t.$slots.subname ? (p(), M("p", { key: 0, title: n.subtitle || void 0, class: "app-sidebar-header__subname" }, [le(t.$slots, "subname", {}, () => [Mt(Be(n.subname), 1)], true)], 8, lf)) : x("", true)])], 2)])], true), Oe(l, { ref: "closeButton", "aria-label": a.closeTranslated, title: a.closeTranslated, class: "app-sidebar__close", variant: "tertiary", onClick: at(i.closeSidebar, ["prevent"]) }, { icon: he(() => [Oe(v, { size: 20 })]), _: 1 }, 8, ["aria-label", "title", "onClick"]), i.isSlotPopulated(t.$slots.description?.()) && !n.empty ? (p(), M("div", uf, [le(t.$slots, "description", {}, void 0, true)])) : x("", true)], 2), Ot(Oe(E, { ref: "tabs", active: n.active, "force-tabs": n.forceTabs, "onUpdate:active": i.onUpdateActive }, { default: he(() => [le(t.$slots, "default", {}, void 0, true)]), _: 3 }, 8, ["active", "force-tabs", "onUpdate:active"]), [[Kt, !n.loading]]), n.loading ? (p(), De(A, { key: 1 }, { icon: he(() => [Oe(o, { size: 64 })]), _: 1 })) : x("", true)], 40, tf), [[Kt, n.open]])]), _: 3 }, 8, ["onAfterEnter", "onAfterLeave"]);
}
const Tf = nt(ef, [["render", cf], ["__scopeId", "data-v-75d9d903"]]);
var Rs = { exports: {} }, _0;
function df() {
  return _0 || (_0 = 1, (function(t) {
    var e = Object.prototype.hasOwnProperty, n = "~";
    function r() {
    }
    Object.create && (r.prototype = /* @__PURE__ */ Object.create(null), new r().__proto__ || (n = false));
    function a(o, c, u) {
      this.fn = o, this.context = c, this.once = u || false;
    }
    function i(o, c, u, T, f) {
      if (typeof u != "function") throw new TypeError("The listener must be a function");
      var m = new a(u, T || o, f), v = n ? n + c : c;
      return o._events[v] ? o._events[v].fn ? o._events[v] = [o._events[v], m] : o._events[v].push(m) : (o._events[v] = m, o._eventsCount++), o;
    }
    function s(o, c) {
      --o._eventsCount === 0 ? o._events = new r() : delete o._events[c];
    }
    function l() {
      this._events = new r(), this._eventsCount = 0;
    }
    l.prototype.eventNames = function() {
      var c = [], u, T;
      if (this._eventsCount === 0) return c;
      for (T in u = this._events) e.call(u, T) && c.push(n ? T.slice(1) : T);
      return Object.getOwnPropertySymbols ? c.concat(Object.getOwnPropertySymbols(u)) : c;
    }, l.prototype.listeners = function(c) {
      var u = n ? n + c : c, T = this._events[u];
      if (!T) return [];
      if (T.fn) return [T.fn];
      for (var f = 0, m = T.length, v = new Array(m); f < m; f++) v[f] = T[f].fn;
      return v;
    }, l.prototype.listenerCount = function(c) {
      var u = n ? n + c : c, T = this._events[u];
      return T ? T.fn ? 1 : T.length : 0;
    }, l.prototype.emit = function(c, u, T, f, m, v) {
      var E = n ? n + c : c;
      if (!this._events[E]) return false;
      var A = this._events[E], g = arguments.length, O, D;
      if (A.fn) {
        switch (A.once && this.removeListener(c, A.fn, void 0, true), g) {
          case 1:
            return A.fn.call(A.context), true;
          case 2:
            return A.fn.call(A.context, u), true;
          case 3:
            return A.fn.call(A.context, u, T), true;
          case 4:
            return A.fn.call(A.context, u, T, f), true;
          case 5:
            return A.fn.call(A.context, u, T, f, m), true;
          case 6:
            return A.fn.call(A.context, u, T, f, m, v), true;
        }
        for (D = 1, O = new Array(g - 1); D < g; D++) O[D - 1] = arguments[D];
        A.fn.apply(A.context, O);
      } else {
        var w = A.length, L;
        for (D = 0; D < w; D++) switch (A[D].once && this.removeListener(c, A[D].fn, void 0, true), g) {
          case 1:
            A[D].fn.call(A[D].context);
            break;
          case 2:
            A[D].fn.call(A[D].context, u);
            break;
          case 3:
            A[D].fn.call(A[D].context, u, T);
            break;
          case 4:
            A[D].fn.call(A[D].context, u, T, f);
            break;
          default:
            if (!O) for (L = 1, O = new Array(g - 1); L < g; L++) O[L - 1] = arguments[L];
            A[D].fn.apply(A[D].context, O);
        }
      }
      return true;
    }, l.prototype.on = function(c, u, T) {
      return i(this, c, u, T, false);
    }, l.prototype.once = function(c, u, T) {
      return i(this, c, u, T, true);
    }, l.prototype.removeListener = function(c, u, T, f) {
      var m = n ? n + c : c;
      if (!this._events[m]) return this;
      if (!u) return s(this, m), this;
      var v = this._events[m];
      if (v.fn) v.fn === u && (!f || v.once) && (!T || v.context === T) && s(this, m);
      else {
        for (var E = 0, A = [], g = v.length; E < g; E++) (v[E].fn !== u || f && !v[E].once || T && v[E].context !== T) && A.push(v[E]);
        A.length ? this._events[m] = A.length === 1 ? A[0] : A : s(this, m);
      }
      return this;
    }, l.prototype.removeAllListeners = function(c) {
      var u;
      return c ? (u = n ? n + c : c, this._events[u] && s(this, u)) : (this._events = new r(), this._eventsCount = 0), this;
    }, l.prototype.off = l.prototype.removeListener, l.prototype.addListener = l.prototype.on, l.prefixed = n, l.EventEmitter = l, t.exports = l;
  })(Rs)), Rs.exports;
}
var hf = df();
const ff = Qi(hf);
class B0 extends Error {
  constructor(e) {
    super(e), this.name = "TimeoutError";
  }
}
class Af extends Error {
  constructor(e) {
    super(), this.name = "AbortError", this.message = e;
  }
}
const Z0 = (t) => globalThis.DOMException === void 0 ? new Af(t) : new DOMException(t), I0 = (t) => {
  const e = t.reason === void 0 ? Z0("This operation was aborted.") : t.reason;
  return e instanceof Error ? e : Z0(e);
};
function mf(t, e) {
  const { milliseconds: n, fallback: r, message: a, customTimers: i = { setTimeout, clearTimeout } } = e;
  let s, l;
  const c = new Promise((u, T) => {
    if (typeof n != "number" || Math.sign(n) !== 1) throw new TypeError(`Expected \`milliseconds\` to be a positive number, got \`${n}\``);
    if (e.signal) {
      const { signal: m } = e;
      m.aborted && T(I0(m)), l = () => {
        T(I0(m));
      }, m.addEventListener("abort", l, { once: true });
    }
    if (n === Number.POSITIVE_INFINITY) {
      t.then(u, T);
      return;
    }
    const f = new B0();
    s = i.setTimeout.call(void 0, () => {
      if (r) {
        try {
          u(r());
        } catch (m) {
          T(m);
        }
        return;
      }
      typeof t.cancel == "function" && t.cancel(), a === false ? u() : a instanceof Error ? T(a) : (f.message = a ?? `Promise timed out after ${n} milliseconds`, T(f));
    }, n), (async () => {
      try {
        u(await t);
      } catch (m) {
        T(m);
      }
    })();
  }).finally(() => {
    c.clear(), l && e.signal && e.signal.removeEventListener("abort", l);
  });
  return c.clear = () => {
    i.clearTimeout.call(void 0, s), s = void 0;
  }, c;
}
function Ef(t, e, n) {
  let r = 0, a = t.length;
  for (; a > 0; ) {
    const i = Math.trunc(a / 2);
    let s = r + i;
    n(t[s], e) <= 0 ? (r = ++s, a -= i + 1) : a = i;
  }
  return r;
}
class pf {
  #e = [];
  enqueue(e, n) {
    n = { priority: 0, ...n };
    const r = { priority: n.priority, id: n.id, run: e };
    if (this.size === 0 || this.#e[this.size - 1].priority >= n.priority) {
      this.#e.push(r);
      return;
    }
    const a = Ef(this.#e, r, (i, s) => s.priority - i.priority);
    this.#e.splice(a, 0, r);
  }
  setPriority(e, n) {
    const r = this.#e.findIndex((i) => i.id === e);
    if (r === -1) throw new ReferenceError(`No promise function with the id "${e}" exists in the queue.`);
    const [a] = this.#e.splice(r, 1);
    this.enqueue(a.run, { priority: n, id: e });
  }
  dequeue() {
    return this.#e.shift()?.run;
  }
  filter(e) {
    return this.#e.filter((n) => n.priority === e.priority).map((n) => n.run);
  }
  get size() {
    return this.#e.length;
  }
}
class Df extends ff {
  #e;
  #a;
  #s = 0;
  #h;
  #o;
  #f = 0;
  #n;
  #l;
  #t;
  #A;
  #r = 0;
  #u;
  #i;
  #m;
  #D = 1n;
  timeout;
  constructor(e) {
    if (super(), e = { carryoverConcurrencyCount: false, intervalCap: Number.POSITIVE_INFINITY, interval: 0, concurrency: Number.POSITIVE_INFINITY, autoStart: true, queueClass: pf, ...e }, !(typeof e.intervalCap == "number" && e.intervalCap >= 1)) throw new TypeError(`Expected \`intervalCap\` to be a number from 1 and up, got \`${e.intervalCap?.toString() ?? ""}\` (${typeof e.intervalCap})`);
    if (e.interval === void 0 || !(Number.isFinite(e.interval) && e.interval >= 0)) throw new TypeError(`Expected \`interval\` to be a finite number >= 0, got \`${e.interval?.toString() ?? ""}\` (${typeof e.interval})`);
    this.#e = e.carryoverConcurrencyCount, this.#a = e.intervalCap === Number.POSITIVE_INFINITY || e.interval === 0, this.#h = e.intervalCap, this.#o = e.interval, this.#t = new e.queueClass(), this.#A = e.queueClass, this.concurrency = e.concurrency, this.timeout = e.timeout, this.#m = e.throwOnTimeout === true, this.#i = e.autoStart === false;
  }
  get #S() {
    return this.#a || this.#s < this.#h;
  }
  get #v() {
    return this.#r < this.#u;
  }
  #g() {
    this.#r--, this.#c(), this.emit("next");
  }
  #R() {
    this.#p(), this.#E(), this.#l = void 0;
  }
  get #N() {
    const e = Date.now();
    if (this.#n === void 0) {
      const n = this.#f - e;
      if (n < 0) this.#s = this.#e ? this.#r : 0;
      else return this.#l === void 0 && (this.#l = setTimeout(() => {
        this.#R();
      }, n)), true;
    }
    return false;
  }
  #c() {
    if (this.#t.size === 0) return this.#n && clearInterval(this.#n), this.#n = void 0, this.emit("empty"), this.#r === 0 && this.emit("idle"), false;
    if (!this.#i) {
      const e = !this.#N;
      if (this.#S && this.#v) {
        const n = this.#t.dequeue();
        return n ? (this.emit("active"), n(), e && this.#E(), true) : false;
      }
    }
    return false;
  }
  #E() {
    this.#a || this.#n !== void 0 || (this.#n = setInterval(() => {
      this.#p();
    }, this.#o), this.#f = Date.now() + this.#o);
  }
  #p() {
    this.#s === 0 && this.#r === 0 && this.#n && (clearInterval(this.#n), this.#n = void 0), this.#s = this.#e ? this.#r : 0, this.#T();
  }
  #T() {
    for (; this.#c(); ) ;
  }
  get concurrency() {
    return this.#u;
  }
  set concurrency(e) {
    if (!(typeof e == "number" && e >= 1)) throw new TypeError(`Expected \`concurrency\` to be a number from 1 and up, got \`${e}\` (${typeof e})`);
    this.#u = e, this.#T();
  }
  async #F(e) {
    return new Promise((n, r) => {
      e.addEventListener("abort", () => {
        r(e.reason);
      }, { once: true });
    });
  }
  setPriority(e, n) {
    this.#t.setPriority(e, n);
  }
  async add(e, n = {}) {
    return n.id ??= (this.#D++).toString(), n = { timeout: this.timeout, throwOnTimeout: this.#m, ...n }, new Promise((r, a) => {
      this.#t.enqueue(async () => {
        this.#r++, this.#s++;
        try {
          n.signal?.throwIfAborted();
          let i = e({ signal: n.signal });
          n.timeout && (i = mf(Promise.resolve(i), { milliseconds: n.timeout })), n.signal && (i = Promise.race([i, this.#F(n.signal)]));
          const s = await i;
          r(s), this.emit("completed", s);
        } catch (i) {
          if (i instanceof B0 && !n.throwOnTimeout) {
            r();
            return;
          }
          a(i), this.emit("error", i);
        } finally {
          this.#g();
        }
      }, n), this.emit("add"), this.#c();
    });
  }
  async addAll(e, n) {
    return Promise.all(e.map(async (r) => this.add(r, n)));
  }
  start() {
    return this.#i ? (this.#i = false, this.#T(), this) : this;
  }
  pause() {
    this.#i = true;
  }
  clear() {
    this.#t = new this.#A();
  }
  async onEmpty() {
    this.#t.size !== 0 && await this.#d("empty");
  }
  async onSizeLessThan(e) {
    this.#t.size < e || await this.#d("next", () => this.#t.size < e);
  }
  async onIdle() {
    this.#r === 0 && this.#t.size === 0 || await this.#d("idle");
  }
  async #d(e, n) {
    return new Promise((r) => {
      const a = () => {
        n && !n() || (this.off(e, a), r());
      };
      this.on(e, a);
    });
  }
  get size() {
    return this.#t.size;
  }
  sizeBy(e) {
    return this.#t.filter(e).length;
  }
  get pending() {
    return this.#r;
  }
  get isPaused() {
    return this.#i;
  }
}
new Df({ concurrency: 5 }), Xe();
const Sf = { key: 0, class: "nc-chip__icon" }, vf = { class: "nc-chip__text" };
ce("Close"), Xe(Rc), Xe(Nc);
const gf = "";
function xr(t, e) {
  e === void 0 && (e = {});
  var n = e.insertAt;
  if (!(!t || typeof document > "u")) {
    var r = document.head || document.getElementsByTagName("head")[0], a = document.createElement("style");
    a.type = "text/css", n === "top" && r.firstChild ? r.insertBefore(a, r.firstChild) : r.appendChild(a), a.styleSheet ? a.styleSheet.cssText = t : a.appendChild(document.createTextNode(t));
  }
}
const Hr = function(t, e) {
  const { componentPrefix: n = gf } = e || {};
  t.component(`${n}${this.name}`, this);
}, Ns = {};
var Aa = { name: "Checkboard", props: { size: { type: [Number, String], default: 8 }, white: { type: String, default: "#fff" }, grey: { type: String, default: "#e6e6e6" } }, computed: { bgStyle() {
  return { "background-image": `url(${Nf(this.white, this.grey, this.size)})` };
} } };
function Rf(t, e, n) {
  if (typeof document > "u") return null;
  const r = document.createElement("canvas");
  r.width = r.height = n * 2;
  const a = r.getContext("2d");
  return a ? (a.fillStyle = t, a.fillRect(0, 0, r.width, r.height), a.fillStyle = e, a.fillRect(0, 0, n, n), a.translate(n, n), a.fillRect(0, 0, n, n), r.toDataURL()) : null;
}
function Nf(t, e, n) {
  const r = `${t},${e},${n}`;
  if (Ns[r]) return Ns[r];
  const a = Rf(t, e, n);
  return Ns[r] = a, a;
}
function Ff(t, e, n, r, a, i) {
  return p(), M("div", { class: "vc-checkerboard", style: Tt(i.bgStyle) }, null, 4);
}
var yf = ".vc-checkerboard{background-size:contain;bottom:0;left:0;position:absolute;right:0;top:0}";
xr(yf), Aa.render = Ff, Aa.__file = "src/components/checkboard/checkboard.vue", Aa.install = Hr;
var mi = { name: "Alpha", components: { Checkboard: Aa }, props: { value: Object, onChange: Function }, computed: { colors() {
  return this.value;
}, gradientColor() {
  const { rgba: t } = this.colors, e = [t.r, t.g, t.b].join(",");
  return `linear-gradient(to right, rgba(${e}, 0) 0%, rgba(${e}, 1) 100%)`;
} }, methods: { handleChange(t, e) {
  !e && t.preventDefault();
  const { container: n } = this.$refs;
  if (!n) return;
  const r = n.clientWidth, a = n.getBoundingClientRect().left + window.pageXOffset, s = (t.pageX || (t.touches ? t.touches[0].pageX : 0)) - a;
  let l;
  s < 0 ? l = 0 : s > r ? l = 1 : l = Math.round(s * 100 / r) / 100, this.colors.a !== l && this.$emit("change", { h: this.colors.hsl.h, s: this.colors.hsl.s, l: this.colors.hsl.l, a: l, source: "rgba" });
}, handleMouseDown(t) {
  this.handleChange(t, true), window.addEventListener("mousemove", this.handleChange), window.addEventListener("mouseup", this.handleMouseUp);
}, handleMouseUp() {
  this.unbindEventListeners();
}, unbindEventListeners() {
  window.removeEventListener("mousemove", this.handleChange), window.removeEventListener("mouseup", this.handleMouseUp);
} } };
const Of = { class: "vc-alpha" }, Mf = { class: "vc-alpha-checkboard-wrap" }, bf = j("div", { class: "vc-alpha-picker" }, null, -1), Yf = [bf];
function wf(t, e, n, r, a, i) {
  const s = Pe("Checkboard");
  return p(), M("div", Of, [j("div", Mf, [Oe(s)]), j("div", { class: "vc-alpha-gradient", style: Tt({ background: i.gradientColor }) }, null, 4), j("div", { ref: "container", class: "vc-alpha-container", onMousedown: e[0] || (e[0] = (...l) => i.handleMouseDown && i.handleMouseDown(...l)), onTouchmove: e[1] || (e[1] = (...l) => i.handleChange && i.handleChange(...l)), onTouchstart: e[2] || (e[2] = (...l) => i.handleChange && i.handleChange(...l)) }, [j("div", { class: "vc-alpha-pointer", style: Tt({ left: `${i.colors.a * 100}%` }) }, Yf, 4)], 544)]);
}
var _f = ".vc-alpha,.vc-alpha-checkboard-wrap{bottom:0;left:0;position:absolute;right:0;top:0}.vc-alpha-checkboard-wrap{overflow:hidden}.vc-alpha-gradient{bottom:0;left:0;position:absolute;right:0;top:0}.vc-alpha-container{cursor:pointer;height:100%;margin:0 3px;position:relative;z-index:2}.vc-alpha-pointer{position:absolute;z-index:2}.vc-alpha-picker{background:#fff;border-radius:1px;box-shadow:0 0 2px rgba(0,0,0,.6);cursor:pointer;height:8px;margin-top:1px;transform:translateX(-2px);width:4px}";
xr(_f), mi.render = wf, mi.__file = "src/components/alpha/alpha.vue", mi.install = Hr;
function kt(t, e) {
  Bf(t) && (t = "100%");
  var n = Zf(t);
  return t = e === 360 ? t : Math.min(e, Math.max(0, parseFloat(t))), n && (t = parseInt(String(t * e), 10) / 100), Math.abs(t - e) < 1e-6 ? 1 : (e === 360 ? t = (t < 0 ? t % e + e : t % e) / parseFloat(String(e)) : t = t % e / parseFloat(String(e)), t);
}
function Ei(t) {
  return Math.min(1, Math.max(0, t));
}
function Bf(t) {
  return typeof t == "string" && t.indexOf(".") !== -1 && parseFloat(t) === 1;
}
function Zf(t) {
  return typeof t == "string" && t.indexOf("%") !== -1;
}
function L0(t) {
  return t = parseFloat(t), (isNaN(t) || t < 0 || t > 1) && (t = 1), t;
}
function pi(t) {
  return t <= 1 ? "".concat(Number(t) * 100, "%") : t;
}
function gr(t) {
  return t.length === 1 ? "0" + t : String(t);
}
function If(t, e, n) {
  return { r: kt(t, 255) * 255, g: kt(e, 255) * 255, b: kt(n, 255) * 255 };
}
function k0(t, e, n) {
  t = kt(t, 255), e = kt(e, 255), n = kt(n, 255);
  var r = Math.max(t, e, n), a = Math.min(t, e, n), i = 0, s = 0, l = (r + a) / 2;
  if (r === a) s = 0, i = 0;
  else {
    var o = r - a;
    switch (s = l > 0.5 ? o / (2 - r - a) : o / (r + a), r) {
      case t:
        i = (e - n) / o + (e < n ? 6 : 0);
        break;
      case e:
        i = (n - t) / o + 2;
        break;
      case n:
        i = (t - e) / o + 4;
        break;
    }
    i /= 6;
  }
  return { h: i, s, l };
}
function Fs(t, e, n) {
  return n < 0 && (n += 1), n > 1 && (n -= 1), n < 1 / 6 ? t + (e - t) * (6 * n) : n < 1 / 2 ? e : n < 2 / 3 ? t + (e - t) * (2 / 3 - n) * 6 : t;
}
function Lf(t, e, n) {
  var r, a, i;
  if (t = kt(t, 360), e = kt(e, 100), n = kt(n, 100), e === 0) a = n, i = n, r = n;
  else {
    var s = n < 0.5 ? n * (1 + e) : n + e - n * e, l = 2 * n - s;
    r = Fs(l, s, t + 1 / 3), a = Fs(l, s, t), i = Fs(l, s, t - 1 / 3);
  }
  return { r: r * 255, g: a * 255, b: i * 255 };
}
function C0(t, e, n) {
  t = kt(t, 255), e = kt(e, 255), n = kt(n, 255);
  var r = Math.max(t, e, n), a = Math.min(t, e, n), i = 0, s = r, l = r - a, o = r === 0 ? 0 : l / r;
  if (r === a) i = 0;
  else {
    switch (r) {
      case t:
        i = (e - n) / l + (e < n ? 6 : 0);
        break;
      case e:
        i = (n - t) / l + 2;
        break;
      case n:
        i = (t - e) / l + 4;
        break;
    }
    i /= 6;
  }
  return { h: i, s: o, v: s };
}
function kf(t, e, n) {
  t = kt(t, 360) * 6, e = kt(e, 100), n = kt(n, 100);
  var r = Math.floor(t), a = t - r, i = n * (1 - e), s = n * (1 - a * e), l = n * (1 - (1 - a) * e), o = r % 6, c = [n, s, i, i, l, n][o], u = [l, n, n, s, i, i][o], T = [i, i, l, n, n, s][o];
  return { r: c * 255, g: u * 255, b: T * 255 };
}
function x0(t, e, n, r) {
  var a = [gr(Math.round(t).toString(16)), gr(Math.round(e).toString(16)), gr(Math.round(n).toString(16))];
  return r && a[0].startsWith(a[0].charAt(1)) && a[1].startsWith(a[1].charAt(1)) && a[2].startsWith(a[2].charAt(1)) ? a[0].charAt(0) + a[1].charAt(0) + a[2].charAt(0) : a.join("");
}
function Cf(t, e, n, r, a) {
  var i = [gr(Math.round(t).toString(16)), gr(Math.round(e).toString(16)), gr(Math.round(n).toString(16)), gr(xf(r))];
  return a && i[0].startsWith(i[0].charAt(1)) && i[1].startsWith(i[1].charAt(1)) && i[2].startsWith(i[2].charAt(1)) && i[3].startsWith(i[3].charAt(1)) ? i[0].charAt(0) + i[1].charAt(0) + i[2].charAt(0) + i[3].charAt(0) : i.join("");
}
function xf(t) {
  return Math.round(parseFloat(t) * 255).toString(16);
}
function H0(t) {
  return an(t) / 255;
}
function an(t) {
  return parseInt(t, 16);
}
function Hf(t) {
  return { r: t >> 16, g: (t & 65280) >> 8, b: t & 255 };
}
var ys = { aliceblue: "#f0f8ff", antiquewhite: "#faebd7", aqua: "#00ffff", aquamarine: "#7fffd4", azure: "#f0ffff", beige: "#f5f5dc", bisque: "#ffe4c4", black: "#000000", blanchedalmond: "#ffebcd", blue: "#0000ff", blueviolet: "#8a2be2", brown: "#a52a2a", burlywood: "#deb887", cadetblue: "#5f9ea0", chartreuse: "#7fff00", chocolate: "#d2691e", coral: "#ff7f50", cornflowerblue: "#6495ed", cornsilk: "#fff8dc", crimson: "#dc143c", cyan: "#00ffff", darkblue: "#00008b", darkcyan: "#008b8b", darkgoldenrod: "#b8860b", darkgray: "#a9a9a9", darkgreen: "#006400", darkgrey: "#a9a9a9", darkkhaki: "#bdb76b", darkmagenta: "#8b008b", darkolivegreen: "#556b2f", darkorange: "#ff8c00", darkorchid: "#9932cc", darkred: "#8b0000", darksalmon: "#e9967a", darkseagreen: "#8fbc8f", darkslateblue: "#483d8b", darkslategray: "#2f4f4f", darkslategrey: "#2f4f4f", darkturquoise: "#00ced1", darkviolet: "#9400d3", deeppink: "#ff1493", deepskyblue: "#00bfff", dimgray: "#696969", dimgrey: "#696969", dodgerblue: "#1e90ff", firebrick: "#b22222", floralwhite: "#fffaf0", forestgreen: "#228b22", fuchsia: "#ff00ff", gainsboro: "#dcdcdc", ghostwhite: "#f8f8ff", goldenrod: "#daa520", gold: "#ffd700", gray: "#808080", green: "#008000", greenyellow: "#adff2f", grey: "#808080", honeydew: "#f0fff0", hotpink: "#ff69b4", indianred: "#cd5c5c", indigo: "#4b0082", ivory: "#fffff0", khaki: "#f0e68c", lavenderblush: "#fff0f5", lavender: "#e6e6fa", lawngreen: "#7cfc00", lemonchiffon: "#fffacd", lightblue: "#add8e6", lightcoral: "#f08080", lightcyan: "#e0ffff", lightgoldenrodyellow: "#fafad2", lightgray: "#d3d3d3", lightgreen: "#90ee90", lightgrey: "#d3d3d3", lightpink: "#ffb6c1", lightsalmon: "#ffa07a", lightseagreen: "#20b2aa", lightskyblue: "#87cefa", lightslategray: "#778899", lightslategrey: "#778899", lightsteelblue: "#b0c4de", lightyellow: "#ffffe0", lime: "#00ff00", limegreen: "#32cd32", linen: "#faf0e6", magenta: "#ff00ff", maroon: "#800000", mediumaquamarine: "#66cdaa", mediumblue: "#0000cd", mediumorchid: "#ba55d3", mediumpurple: "#9370db", mediumseagreen: "#3cb371", mediumslateblue: "#7b68ee", mediumspringgreen: "#00fa9a", mediumturquoise: "#48d1cc", mediumvioletred: "#c71585", midnightblue: "#191970", mintcream: "#f5fffa", mistyrose: "#ffe4e1", moccasin: "#ffe4b5", navajowhite: "#ffdead", navy: "#000080", oldlace: "#fdf5e6", olive: "#808000", olivedrab: "#6b8e23", orange: "#ffa500", orangered: "#ff4500", orchid: "#da70d6", palegoldenrod: "#eee8aa", palegreen: "#98fb98", paleturquoise: "#afeeee", palevioletred: "#db7093", papayawhip: "#ffefd5", peachpuff: "#ffdab9", peru: "#cd853f", pink: "#ffc0cb", plum: "#dda0dd", powderblue: "#b0e0e6", purple: "#800080", rebeccapurple: "#663399", red: "#ff0000", rosybrown: "#bc8f8f", royalblue: "#4169e1", saddlebrown: "#8b4513", salmon: "#fa8072", sandybrown: "#f4a460", seagreen: "#2e8b57", seashell: "#fff5ee", sienna: "#a0522d", silver: "#c0c0c0", skyblue: "#87ceeb", slateblue: "#6a5acd", slategray: "#708090", slategrey: "#708090", snow: "#fffafa", springgreen: "#00ff7f", steelblue: "#4682b4", tan: "#d2b48c", teal: "#008080", thistle: "#d8bfd8", tomato: "#ff6347", turquoise: "#40e0d0", violet: "#ee82ee", wheat: "#f5deb3", white: "#ffffff", whitesmoke: "#f5f5f5", yellow: "#ffff00", yellowgreen: "#9acd32" };
function Pf(t) {
  var e = { r: 0, g: 0, b: 0 }, n = 1, r = null, a = null, i = null, s = false, l = false;
  return typeof t == "string" && (t = zf(t)), typeof t == "object" && (Un(t.r) && Un(t.g) && Un(t.b) ? (e = If(t.r, t.g, t.b), s = true, l = String(t.r).substr(-1) === "%" ? "prgb" : "rgb") : Un(t.h) && Un(t.s) && Un(t.v) ? (r = pi(t.s), a = pi(t.v), e = kf(t.h, r, a), s = true, l = "hsv") : Un(t.h) && Un(t.s) && Un(t.l) && (r = pi(t.s), i = pi(t.l), e = Lf(t.h, r, i), s = true, l = "hsl"), Object.prototype.hasOwnProperty.call(t, "a") && (n = t.a)), n = L0(n), { ok: s, format: t.format || l, r: Math.min(255, Math.max(e.r, 0)), g: Math.min(255, Math.max(e.g, 0)), b: Math.min(255, Math.max(e.b, 0)), a: n };
}
var Uf = "[-\\+]?\\d+%?", Gf = "[-\\+]?\\d*\\.\\d+%?", er = "(?:".concat(Gf, ")|(?:").concat(Uf, ")"), Os = "[\\s|\\(]+(".concat(er, ")[,|\\s]+(").concat(er, ")[,|\\s]+(").concat(er, ")\\s*\\)?"), Ms = "[\\s|\\(]+(".concat(er, ")[,|\\s]+(").concat(er, ")[,|\\s]+(").concat(er, ")[,|\\s]+(").concat(er, ")\\s*\\)?"), pn = { CSS_UNIT: new RegExp(er), rgb: new RegExp("rgb" + Os), rgba: new RegExp("rgba" + Ms), hsl: new RegExp("hsl" + Os), hsla: new RegExp("hsla" + Ms), hsv: new RegExp("hsv" + Os), hsva: new RegExp("hsva" + Ms), hex3: /^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/, hex6: /^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/, hex4: /^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/, hex8: /^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/ };
function zf(t) {
  if (t = t.trim().toLowerCase(), t.length === 0) return false;
  var e = false;
  if (ys[t]) t = ys[t], e = true;
  else if (t === "transparent") return { r: 0, g: 0, b: 0, a: 0, format: "name" };
  var n = pn.rgb.exec(t);
  return n ? { r: n[1], g: n[2], b: n[3] } : (n = pn.rgba.exec(t), n ? { r: n[1], g: n[2], b: n[3], a: n[4] } : (n = pn.hsl.exec(t), n ? { h: n[1], s: n[2], l: n[3] } : (n = pn.hsla.exec(t), n ? { h: n[1], s: n[2], l: n[3], a: n[4] } : (n = pn.hsv.exec(t), n ? { h: n[1], s: n[2], v: n[3] } : (n = pn.hsva.exec(t), n ? { h: n[1], s: n[2], v: n[3], a: n[4] } : (n = pn.hex8.exec(t), n ? { r: an(n[1]), g: an(n[2]), b: an(n[3]), a: H0(n[4]), format: e ? "name" : "hex8" } : (n = pn.hex6.exec(t), n ? { r: an(n[1]), g: an(n[2]), b: an(n[3]), format: e ? "name" : "hex" } : (n = pn.hex4.exec(t), n ? { r: an(n[1] + n[1]), g: an(n[2] + n[2]), b: an(n[3] + n[3]), a: H0(n[4] + n[4]), format: e ? "name" : "hex8" } : (n = pn.hex3.exec(t), n ? { r: an(n[1] + n[1]), g: an(n[2] + n[2]), b: an(n[3] + n[3]), format: e ? "name" : "hex" } : false)))))))));
}
function Un(t) {
  return !!pn.CSS_UNIT.exec(String(t));
}
var jf = (function() {
  function t(e, n) {
    e === void 0 && (e = ""), n === void 0 && (n = {});
    var r;
    if (e instanceof t) return e;
    typeof e == "number" && (e = Hf(e)), this.originalInput = e;
    var a = Pf(e);
    this.originalInput = e, this.r = a.r, this.g = a.g, this.b = a.b, this.a = a.a, this.roundA = Math.round(100 * this.a) / 100, this.format = (r = n.format) !== null && r !== void 0 ? r : a.format, this.gradientType = n.gradientType, this.r < 1 && (this.r = Math.round(this.r)), this.g < 1 && (this.g = Math.round(this.g)), this.b < 1 && (this.b = Math.round(this.b)), this.isValid = a.ok;
  }
  return t.prototype.isDark = function() {
    return this.getBrightness() < 128;
  }, t.prototype.isLight = function() {
    return !this.isDark();
  }, t.prototype.getBrightness = function() {
    var e = this.toRgb();
    return (e.r * 299 + e.g * 587 + e.b * 114) / 1e3;
  }, t.prototype.getLuminance = function() {
    var e = this.toRgb(), n, r, a, i = e.r / 255, s = e.g / 255, l = e.b / 255;
    return i <= 0.03928 ? n = i / 12.92 : n = Math.pow((i + 0.055) / 1.055, 2.4), s <= 0.03928 ? r = s / 12.92 : r = Math.pow((s + 0.055) / 1.055, 2.4), l <= 0.03928 ? a = l / 12.92 : a = Math.pow((l + 0.055) / 1.055, 2.4), 0.2126 * n + 0.7152 * r + 0.0722 * a;
  }, t.prototype.getAlpha = function() {
    return this.a;
  }, t.prototype.setAlpha = function(e) {
    return this.a = L0(e), this.roundA = Math.round(100 * this.a) / 100, this;
  }, t.prototype.isMonochrome = function() {
    var e = this.toHsl().s;
    return e === 0;
  }, t.prototype.toHsv = function() {
    var e = C0(this.r, this.g, this.b);
    return { h: e.h * 360, s: e.s, v: e.v, a: this.a };
  }, t.prototype.toHsvString = function() {
    var e = C0(this.r, this.g, this.b), n = Math.round(e.h * 360), r = Math.round(e.s * 100), a = Math.round(e.v * 100);
    return this.a === 1 ? "hsv(".concat(n, ", ").concat(r, "%, ").concat(a, "%)") : "hsva(".concat(n, ", ").concat(r, "%, ").concat(a, "%, ").concat(this.roundA, ")");
  }, t.prototype.toHsl = function() {
    var e = k0(this.r, this.g, this.b);
    return { h: e.h * 360, s: e.s, l: e.l, a: this.a };
  }, t.prototype.toHslString = function() {
    var e = k0(this.r, this.g, this.b), n = Math.round(e.h * 360), r = Math.round(e.s * 100), a = Math.round(e.l * 100);
    return this.a === 1 ? "hsl(".concat(n, ", ").concat(r, "%, ").concat(a, "%)") : "hsla(".concat(n, ", ").concat(r, "%, ").concat(a, "%, ").concat(this.roundA, ")");
  }, t.prototype.toHex = function(e) {
    return e === void 0 && (e = false), x0(this.r, this.g, this.b, e);
  }, t.prototype.toHexString = function(e) {
    return e === void 0 && (e = false), "#" + this.toHex(e);
  }, t.prototype.toHex8 = function(e) {
    return e === void 0 && (e = false), Cf(this.r, this.g, this.b, this.a, e);
  }, t.prototype.toHex8String = function(e) {
    return e === void 0 && (e = false), "#" + this.toHex8(e);
  }, t.prototype.toHexShortString = function(e) {
    return e === void 0 && (e = false), this.a === 1 ? this.toHexString(e) : this.toHex8String(e);
  }, t.prototype.toRgb = function() {
    return { r: Math.round(this.r), g: Math.round(this.g), b: Math.round(this.b), a: this.a };
  }, t.prototype.toRgbString = function() {
    var e = Math.round(this.r), n = Math.round(this.g), r = Math.round(this.b);
    return this.a === 1 ? "rgb(".concat(e, ", ").concat(n, ", ").concat(r, ")") : "rgba(".concat(e, ", ").concat(n, ", ").concat(r, ", ").concat(this.roundA, ")");
  }, t.prototype.toPercentageRgb = function() {
    var e = function(n) {
      return "".concat(Math.round(kt(n, 255) * 100), "%");
    };
    return { r: e(this.r), g: e(this.g), b: e(this.b), a: this.a };
  }, t.prototype.toPercentageRgbString = function() {
    var e = function(n) {
      return Math.round(kt(n, 255) * 100);
    };
    return this.a === 1 ? "rgb(".concat(e(this.r), "%, ").concat(e(this.g), "%, ").concat(e(this.b), "%)") : "rgba(".concat(e(this.r), "%, ").concat(e(this.g), "%, ").concat(e(this.b), "%, ").concat(this.roundA, ")");
  }, t.prototype.toName = function() {
    if (this.a === 0) return "transparent";
    if (this.a < 1) return false;
    for (var e = "#" + x0(this.r, this.g, this.b, false), n = 0, r = Object.entries(ys); n < r.length; n++) {
      var a = r[n], i = a[0], s = a[1];
      if (e === s) return i;
    }
    return false;
  }, t.prototype.toString = function(e) {
    var n = !!e;
    e = e ?? this.format;
    var r = false, a = this.a < 1 && this.a >= 0, i = !n && a && (e.startsWith("hex") || e === "name");
    return i ? e === "name" && this.a === 0 ? this.toName() : this.toRgbString() : (e === "rgb" && (r = this.toRgbString()), e === "prgb" && (r = this.toPercentageRgbString()), (e === "hex" || e === "hex6") && (r = this.toHexString()), e === "hex3" && (r = this.toHexString(true)), e === "hex4" && (r = this.toHex8String(true)), e === "hex8" && (r = this.toHex8String()), e === "name" && (r = this.toName()), e === "hsl" && (r = this.toHslString()), e === "hsv" && (r = this.toHsvString()), r || this.toHexString());
  }, t.prototype.toNumber = function() {
    return (Math.round(this.r) << 16) + (Math.round(this.g) << 8) + Math.round(this.b);
  }, t.prototype.clone = function() {
    return new t(this.toString());
  }, t.prototype.lighten = function(e) {
    e === void 0 && (e = 10);
    var n = this.toHsl();
    return n.l += e / 100, n.l = Ei(n.l), new t(n);
  }, t.prototype.brighten = function(e) {
    e === void 0 && (e = 10);
    var n = this.toRgb();
    return n.r = Math.max(0, Math.min(255, n.r - Math.round(255 * -(e / 100)))), n.g = Math.max(0, Math.min(255, n.g - Math.round(255 * -(e / 100)))), n.b = Math.max(0, Math.min(255, n.b - Math.round(255 * -(e / 100)))), new t(n);
  }, t.prototype.darken = function(e) {
    e === void 0 && (e = 10);
    var n = this.toHsl();
    return n.l -= e / 100, n.l = Ei(n.l), new t(n);
  }, t.prototype.tint = function(e) {
    return e === void 0 && (e = 10), this.mix("white", e);
  }, t.prototype.shade = function(e) {
    return e === void 0 && (e = 10), this.mix("black", e);
  }, t.prototype.desaturate = function(e) {
    e === void 0 && (e = 10);
    var n = this.toHsl();
    return n.s -= e / 100, n.s = Ei(n.s), new t(n);
  }, t.prototype.saturate = function(e) {
    e === void 0 && (e = 10);
    var n = this.toHsl();
    return n.s += e / 100, n.s = Ei(n.s), new t(n);
  }, t.prototype.greyscale = function() {
    return this.desaturate(100);
  }, t.prototype.spin = function(e) {
    var n = this.toHsl(), r = (n.h + e) % 360;
    return n.h = r < 0 ? 360 + r : r, new t(n);
  }, t.prototype.mix = function(e, n) {
    n === void 0 && (n = 50);
    var r = this.toRgb(), a = new t(e).toRgb(), i = n / 100, s = { r: (a.r - r.r) * i + r.r, g: (a.g - r.g) * i + r.g, b: (a.b - r.b) * i + r.b, a: (a.a - r.a) * i + r.a };
    return new t(s);
  }, t.prototype.analogous = function(e, n) {
    e === void 0 && (e = 6), n === void 0 && (n = 30);
    var r = this.toHsl(), a = 360 / n, i = [this];
    for (r.h = (r.h - (a * e >> 1) + 720) % 360; --e; ) r.h = (r.h + a) % 360, i.push(new t(r));
    return i;
  }, t.prototype.complement = function() {
    var e = this.toHsl();
    return e.h = (e.h + 180) % 360, new t(e);
  }, t.prototype.monochromatic = function(e) {
    e === void 0 && (e = 6);
    for (var n = this.toHsv(), r = n.h, a = n.s, i = n.v, s = [], l = 1 / e; e--; ) s.push(new t({ h: r, s: a, v: i })), i = (i + l) % 1;
    return s;
  }, t.prototype.splitcomplement = function() {
    var e = this.toHsl(), n = e.h;
    return [this, new t({ h: (n + 72) % 360, s: e.s, l: e.l }), new t({ h: (n + 216) % 360, s: e.s, l: e.l })];
  }, t.prototype.onBackground = function(e) {
    var n = this.toRgb(), r = new t(e).toRgb(), a = n.a + r.a * (1 - n.a);
    return new t({ r: (n.r * n.a + r.r * r.a * (1 - n.a)) / a, g: (n.g * n.a + r.g * r.a * (1 - n.a)) / a, b: (n.b * n.a + r.b * r.a * (1 - n.a)) / a, a });
  }, t.prototype.triad = function() {
    return this.polyad(3);
  }, t.prototype.tetrad = function() {
    return this.polyad(4);
  }, t.prototype.polyad = function(e) {
    for (var n = this.toHsl(), r = n.h, a = [this], i = 360 / e, s = 1; s < e; s++) a.push(new t({ h: (r + s * i) % 360, s: n.s, l: n.l }));
    return a;
  }, t.prototype.equals = function(e) {
    return this.toRgbString() === new t(e).toRgbString();
  }, t;
})();
function tr(...t) {
  return new jf(...t);
}
function bs(t, e) {
  const n = t && t.a;
  let r;
  t && t.hsl ? r = tr(t.hsl) : t && t.hex && t.hex.length > 0 ? r = tr(t.hex) : t && t.hsv ? r = tr(t.hsv) : t && t.rgba ? r = tr(t.rgba) : t && t.rgb ? r = tr(t.rgb) : r = tr(t), r && (r._a === void 0 || r._a === null) && r.setAlpha(n || r.getAlpha());
  const a = r.toHsl(), i = r.toHsv();
  return a.s === 0 && (i.h = a.h = t.h || t.hsl && t.hsl.h || e || 0), i.v < 0.0164 && (i.h = t.h || t.hsv && t.hsv.h || 0, i.s = t.s || t.hsv && t.hsv.s || 0), a.l < 0.01 && (a.h = t.h || t.hsl && t.hsl.h || 0, a.s = t.s || t.hsl && t.hsl.s || 0), { hsl: a, hex: r.toHexString().toUpperCase(), hex8: r.toHex8String().toUpperCase(), rgba: r.toRgb(), hsv: i, oldHue: t.h || e || a.h, source: t.source, a: r.getAlpha() };
}
var $f = { model: { prop: "modelValue", event: "update:modelValue" }, props: ["modelValue"], data() {
  return { val: bs(this.modelValue) };
}, computed: { colors: { get() {
  return this.val;
}, set(t) {
  this.val = t, this.$emit("update:modelValue", t);
} } }, watch: { modelValue(t) {
  this.val = bs(t);
} }, methods: { colorChange(t, e) {
  this.oldHue = this.colors.hsl.h, this.colors = bs(t, e || this.oldHue);
}, isValidHex(t) {
  return tr(t).isValid;
}, simpleCheckForValidColor(t) {
  const e = ["r", "g", "b", "a", "h", "s", "l", "v"];
  let n = 0, r = 0;
  for (let a = 0; a < e.length; a++) {
    const i = e[a];
    t[i] && (n++, isNaN(t[i]) || r++);
  }
  if (n === r) return t;
}, paletteUpperCase(t) {
  return t.map((e) => e.toUpperCase());
}, isTransparent(t) {
  return tr(t).getAlpha() === 0;
} } }, Di = { name: "EditableInput", props: { label: String, labelText: String, desc: String, value: [String, Number], max: Number, min: Number, arrowOffset: { type: Number, default: 1 } }, computed: { val: { get() {
  return this.value;
}, set(t) {
  if (this.max !== void 0 && +t > this.max) this.$refs.input.value = this.max;
  else return t;
} }, labelId() {
  return `input__label__${this.label}__${Math.random().toString().slice(2, 5)}`;
}, labelSpanText() {
  return this.labelText || this.label;
} }, methods: { update(t) {
  this.handleChange(t.target.value);
}, handleChange(t) {
  const e = {};
  e[this.label] = t, e.hex === void 0 && e["#"] === void 0 ? this.$emit("change", e) : t.length > 5 && this.$emit("change", e);
}, handleKeyDown(t) {
  let { val: e } = this;
  const n = Number(e);
  if (n) {
    const r = this.arrowOffset || 1;
    t.keyCode === 38 && (e = n + r, this.handleChange(e), t.preventDefault()), t.keyCode === 40 && (e = n - r, this.handleChange(e), t.preventDefault());
  }
} } };
const Vf = { class: "vc-editable-input" }, Qf = ["aria-labelledby"], Wf = ["id", "for"], qf = { class: "vc-input__desc" };
function Kf(t, e, n, r, a, i) {
  return p(), M("div", Vf, [Ot(j("input", { ref: "input", "onUpdate:modelValue": e[0] || (e[0] = (s) => i.val = s), "aria-labelledby": i.labelId, class: "vc-input__input", onKeydown: e[1] || (e[1] = (...s) => i.handleKeyDown && i.handleKeyDown(...s)), onInput: e[2] || (e[2] = (...s) => i.update && i.update(...s)) }, null, 40, Qf), [[Qo, i.val]]), j("span", { id: i.labelId, for: n.label, class: "vc-input__label" }, Be(i.labelSpanText), 9, Wf), j("span", qf, Be(n.desc), 1)]);
}
var Jf = ".vc-editable-input{position:relative}.vc-input__input{border:0;outline:none;padding:0}.vc-input__label{text-transform:capitalize}";
xr(Jf), Di.render = Kf, Di.__file = "src/components/editable-input/editable-input.vue", Di.install = Hr;
function Ys(t, e, n) {
  return e < n ? t < e ? e : t > n ? n : t : t < n ? n : t > e ? e : t;
}
var Si = { name: "Saturation", props: { value: Object }, computed: { colors() {
  return this.value;
}, bgColor() {
  return `hsl(${this.colors.hsv.h}, 100%, 50%)`;
}, pointerTop() {
  return `${-(this.colors.hsv.v * 100) + 1 + 100}%`;
}, pointerLeft() {
  return `${this.colors.hsv.s * 100}%`;
} }, methods: { handleChange(t, e) {
  !e && t.preventDefault();
  const { container: n } = this.$refs;
  if (!n) return;
  const r = n.clientWidth, a = n.clientHeight, i = n.getBoundingClientRect().left + window.pageXOffset, s = n.getBoundingClientRect().top + window.pageYOffset, l = t.pageX || (t.touches ? t.touches[0].pageX : 0), o = t.pageY || (t.touches ? t.touches[0].pageY : 0), c = Ys(l - i, 0, r), u = Ys(o - s, 0, a), T = c / r, f = Ys(-(u / a) + 1, 0, 1);
  this.onChange({ h: this.colors.hsv.h, s: T, v: f, a: this.colors.hsv.a, source: "hsva" });
}, onChange(t) {
  this.$emit("change", t);
}, handleMouseDown(t) {
  window.addEventListener("mousemove", this.handleChange), window.addEventListener("mouseup", this.handleChange), window.addEventListener("mouseup", this.handleMouseUp);
}, handleMouseUp(t) {
  this.unbindEventListeners();
}, unbindEventListeners() {
  window.removeEventListener("mousemove", this.handleChange), window.removeEventListener("mouseup", this.handleChange), window.removeEventListener("mouseup", this.handleMouseUp);
} } };
const Xf = j("div", { class: "vc-saturation--white" }, null, -1), eA = j("div", { class: "vc-saturation--black" }, null, -1), tA = j("div", { class: "vc-saturation-circle" }, null, -1), nA = [tA];
function rA(t, e, n, r, a, i) {
  return p(), M("div", { ref: "container", class: "vc-saturation", style: Tt({ background: i.bgColor }), onMousedown: e[0] || (e[0] = (...s) => i.handleMouseDown && i.handleMouseDown(...s)), onTouchmove: e[1] || (e[1] = (...s) => i.handleChange && i.handleChange(...s)), onTouchstart: e[2] || (e[2] = (...s) => i.handleChange && i.handleChange(...s)) }, [Xf, eA, j("div", { class: "vc-saturation-pointer", style: Tt({ top: i.pointerTop, left: i.pointerLeft }) }, nA, 4)], 36);
}
var aA = ".vc-saturation,.vc-saturation--black,.vc-saturation--white{bottom:0;cursor:pointer;left:0;position:absolute;right:0;top:0}.vc-saturation--white{background:linear-gradient(90deg,#fff,hsla(0,0%,100%,0))}.vc-saturation--black{background:linear-gradient(0deg,#000,transparent)}.vc-saturation-pointer{cursor:pointer;position:absolute}.vc-saturation-circle{border-radius:50%;box-shadow:0 0 0 1.5px #fff,inset 0 0 1px 1px rgba(0,0,0,.3),0 0 1px 2px rgba(0,0,0,.4);cursor:head;height:4px;transform:translate(-2px,-2px);width:4px}";
xr(aA), Si.render = rA, Si.__file = "src/components/saturation/saturation.vue", Si.install = Hr;
var vi = { name: "Hue", props: { value: Object, direction: { type: String, default: "horizontal" } }, data() {
  return { oldHue: 0, pullDirection: "" };
}, computed: { colors() {
  return this.value;
}, directionClass() {
  return { "vc-hue--horizontal": this.direction === "horizontal", "vc-hue--vertical": this.direction === "vertical" };
}, pointerTop() {
  return this.direction === "vertical" ? this.colors.hsl.h === 0 && this.pullDirection === "right" ? 0 : `${-(this.colors.hsl.h * 100 / 360) + 100}%` : 0;
}, pointerLeft() {
  return this.direction === "vertical" ? 0 : this.colors.hsl.h === 0 && this.pullDirection === "right" ? "100%" : `${this.colors.hsl.h * 100 / 360}%`;
} }, watch: { value: { handler(t, e) {
  const { h: n } = t.hsl;
  n !== 0 && n - this.oldHue > 0 && (this.pullDirection = "right"), n !== 0 && n - this.oldHue < 0 && (this.pullDirection = "left"), this.oldHue = n;
}, deep: true, immediate: true } }, methods: { handleChange(t, e) {
  !e && t.preventDefault();
  const { container: n } = this.$refs;
  if (!n) return;
  const r = n.clientWidth, a = n.clientHeight, i = n.getBoundingClientRect().left + window.pageXOffset, s = n.getBoundingClientRect().top + window.pageYOffset, l = t.pageX || (t.touches ? t.touches[0].pageX : 0), o = t.pageY || (t.touches ? t.touches[0].pageY : 0), c = l - i, u = o - s;
  let T, f;
  this.direction === "vertical" ? (u < 0 ? T = 360 : u > a ? T = 0 : (f = -(u * 100 / a) + 100, T = 360 * f / 100), this.colors.hsl.h !== T && this.$emit("change", { h: T, s: this.colors.hsl.s, l: this.colors.hsl.l, a: this.colors.hsl.a, source: "hsl" })) : (c < 0 ? T = 0 : c > r ? T = 360 : (f = c * 100 / r, T = 360 * f / 100), this.colors.hsl.h !== T && this.$emit("change", { h: T, s: this.colors.hsl.s, l: this.colors.hsl.l, a: this.colors.hsl.a, source: "hsl" }));
}, handleMouseDown(t) {
  this.handleChange(t, true), window.addEventListener("mousemove", this.handleChange), window.addEventListener("mouseup", this.handleChange), window.addEventListener("mouseup", this.handleMouseUp);
}, handleMouseUp(t) {
  this.unbindEventListeners();
}, unbindEventListeners() {
  window.removeEventListener("mousemove", this.handleChange), window.removeEventListener("mouseup", this.handleChange), window.removeEventListener("mouseup", this.handleMouseUp);
} } };
const iA = ["aria-valuenow"], sA = j("div", { class: "vc-hue-picker" }, null, -1), oA = [sA];
function lA(t, e, n, r, a, i) {
  return p(), M("div", { class: ye(["vc-hue", [i.directionClass]]) }, [j("div", { ref: "container", class: "vc-hue-container", role: "slider", "aria-valuenow": i.colors.hsl.h, "aria-valuemin": "0", "aria-valuemax": "360", onMousedown: e[0] || (e[0] = (...s) => i.handleMouseDown && i.handleMouseDown(...s)), onTouchmove: e[1] || (e[1] = (...s) => i.handleChange && i.handleChange(...s)), onTouchstart: e[2] || (e[2] = (...s) => i.handleChange && i.handleChange(...s)) }, [j("div", { class: "vc-hue-pointer", style: Tt({ top: i.pointerTop, left: i.pointerLeft }), role: "presentation" }, oA, 4)], 40, iA)], 2);
}
var uA = ".vc-hue{border-radius:2px;bottom:0;left:0;position:absolute;right:0;top:0}.vc-hue--horizontal{background:linear-gradient(90deg,red 0,#ff0 17%,#0f0 33%,#0ff 50%,#00f 67%,#f0f 83%,red)}.vc-hue--vertical{background:linear-gradient(0deg,red 0,#ff0 17%,#0f0 33%,#0ff 50%,#00f 67%,#f0f 83%,red)}.vc-hue-container{cursor:pointer;height:100%;margin:0 2px;position:relative}.vc-hue-pointer{position:absolute;z-index:2}.vc-hue-picker{background:#fff;border-radius:1px;box-shadow:0 0 2px rgba(0,0,0,.6);cursor:pointer;height:8px;margin-top:1px;transform:translateX(-2px);width:4px}";
xr(uA), vi.render = lA, vi.__file = "src/components/hue/hue.vue", vi.install = Hr;
var gi = { name: "Chrome", components: { Saturation: Si, Hue: vi, Alpha: mi, EdIn: Di, Checkboard: Aa }, mixins: [$f], props: { disableAlpha: { type: Boolean, default: false }, disableFields: { type: Boolean, default: false }, format: { type: String, default: "hex" } }, data() {
  return { fieldsIndex: "hex", highlight: false };
}, computed: { hsl() {
  const { h: t, s: e, l: n } = this.colors.hsl;
  return { h: t.toFixed(), s: `${(e * 100).toFixed()}%`, l: `${(n * 100).toFixed()}%` };
}, activeColor() {
  const { rgba: t } = this.colors;
  return `rgba(${[t.r, t.g, t.b, t.a].join(",")})`;
}, hasAlpha() {
  return this.colors.a < 1;
} }, watch: { format: { handler(t) {
  this.fieldsIndex = t;
}, immediate: true } }, methods: { childChange(t) {
  this.colorChange(t);
}, inputChange(t) {
  if (t) {
    if (t.hex) this.isValidHex(t.hex) && this.colorChange({ hex: t.hex, source: "hex" });
    else if (t.r || t.g || t.b || t.a) this.colorChange({ r: t.r || this.colors.rgba.r, g: t.g || this.colors.rgba.g, b: t.b || this.colors.rgba.b, a: t.a || this.colors.rgba.a, source: "rgba" });
    else if (t.h || t.s || t.l) {
      const e = t.s ? t.s.replace("%", "") / 100 : this.colors.hsl.s, n = t.l ? t.l.replace("%", "") / 100 : this.colors.hsl.l;
      this.colorChange({ h: t.h || this.colors.hsl.h, s: e, l: n, source: "hsl" });
    }
  }
}, toggleViews() {
  switch (this.fieldsIndex) {
    case "hex":
      this.fieldsIndex = `rgb${this.disableAlpha ? "" : "a"}`;
      break;
    case "rgb":
    case "rgba":
      this.fieldsIndex = `hsl${this.disableAlpha ? "" : "a"}`;
      break;
    default:
      this.fieldsIndex = "hex";
      break;
  }
  this.$emit("update:format", this.fieldsIndex);
}, showHighlight() {
  this.highlight = true;
}, hideHighlight() {
  this.highlight = false;
} } };
const cA = { class: "vc-chrome-saturation-wrap" }, TA = { class: "vc-chrome-body" }, dA = { class: "vc-chrome-controls" }, hA = { class: "vc-chrome-color-wrap" }, fA = ["aria-label"], AA = { class: "vc-chrome-sliders" }, mA = { class: "vc-chrome-hue-wrap" }, EA = { key: 0, class: "vc-chrome-alpha-wrap" }, pA = { key: 0, class: "vc-chrome-fields-wrap" }, DA = { class: "vc-chrome-fields" }, SA = { class: "vc-chrome-field" }, vA = { class: "vc-chrome-fields" }, gA = { class: "vc-chrome-field" }, RA = { class: "vc-chrome-field" }, NA = { class: "vc-chrome-field" }, FA = { key: 0, class: "vc-chrome-field" }, yA = { class: "vc-chrome-fields" }, OA = { class: "vc-chrome-field" }, MA = { class: "vc-chrome-field" }, bA = { class: "vc-chrome-field" }, YA = { key: 0, class: "vc-chrome-field" }, wA = { class: "vc-chrome-toggle-icon" }, _A = j("path", { fill: "#333", d: "M12,18.17L8.83,15L7.42,16.41L12,21L16.59,16.41L15.17,15M12,5.83L15.17,9L16.58,7.59L12,3L7.41,7.59L8.83,9L12,5.83Z" }, null, -1), BA = [_A], ZA = { class: "vc-chrome-toggle-icon-highlight" };
function IA(t, e, n, r, a, i) {
  const s = Pe("Saturation"), l = Pe("Checkboard"), o = Pe("Hue"), c = Pe("Alpha"), u = Pe("EdIn");
  return p(), M("div", { role: "application", "aria-label": "Chrome color picker", class: ye(["vc-chrome", [n.disableAlpha ? "vc-chrome__disable-alpha" : ""]]) }, [j("div", cA, [Oe(s, { value: t.colors, onChange: i.childChange }, null, 8, ["value", "onChange"])]), j("div", TA, [j("div", dA, [j("div", hA, [j("div", { "aria-label": `current color is ${t.colors.hex}`, class: "vc-chrome-active-color", style: Tt({ background: i.activeColor }) }, null, 12, fA), n.disableAlpha ? x("v-if", true) : (p(), De(l, { key: 0 }))]), j("div", AA, [j("div", mA, [Oe(o, { value: t.colors, onChange: i.childChange }, null, 8, ["value", "onChange"])]), n.disableAlpha ? x("v-if", true) : (p(), M("div", EA, [Oe(c, { value: t.colors, onChange: i.childChange }, null, 8, ["value", "onChange"])]))])]), n.disableFields ? x("v-if", true) : (p(), M("div", pA, [Ot(j("div", DA, [x(" hex "), j("div", SA, [i.hasAlpha ? x("v-if", true) : (p(), De(u, { key: 0, label: "hex", value: t.colors.hex, onChange: i.inputChange }, null, 8, ["value", "onChange"])), i.hasAlpha ? (p(), De(u, { key: 1, label: "hex", value: t.colors.hex8, onChange: i.inputChange }, null, 8, ["value", "onChange"])) : x("v-if", true)])], 512), [[Kt, a.fieldsIndex === "hex"]]), Ot(j("div", vA, [x(" rgba "), j("div", gA, [Oe(u, { label: "r", value: t.colors.rgba.r, onChange: i.inputChange }, null, 8, ["value", "onChange"])]), j("div", RA, [Oe(u, { label: "g", value: t.colors.rgba.g, onChange: i.inputChange }, null, 8, ["value", "onChange"])]), j("div", NA, [Oe(u, { label: "b", value: t.colors.rgba.b, onChange: i.inputChange }, null, 8, ["value", "onChange"])]), n.disableAlpha ? x("v-if", true) : (p(), M("div", FA, [Oe(u, { label: "a", value: t.colors.a, "arrow-offset": 0.01, max: 1, onChange: i.inputChange }, null, 8, ["value", "arrow-offset", "onChange"])]))], 512), [[Kt, ["rgb", "rgba"].includes(a.fieldsIndex)]]), Ot(j("div", yA, [x(" hsla "), j("div", OA, [Oe(u, { label: "h", value: i.hsl.h, onChange: i.inputChange }, null, 8, ["value", "onChange"])]), j("div", MA, [Oe(u, { label: "s", value: i.hsl.s, onChange: i.inputChange }, null, 8, ["value", "onChange"])]), j("div", bA, [Oe(u, { label: "l", value: i.hsl.l, onChange: i.inputChange }, null, 8, ["value", "onChange"])]), n.disableAlpha ? x("v-if", true) : (p(), M("div", YA, [Oe(u, { label: "a", value: t.colors.a, "arrow-offset": 0.01, max: 1, onChange: i.inputChange }, null, 8, ["value", "arrow-offset", "onChange"])]))], 512), [[Kt, ["hsl", "hsla"].includes(a.fieldsIndex)]]), x(" btn "), j("div", { class: "vc-chrome-toggle-btn", role: "button", "aria-label": "Change another color definition", onClick: e[3] || (e[3] = (...T) => i.toggleViews && i.toggleViews(...T)) }, [j("div", wA, [(p(), M("svg", { style: { width: "24px", height: "24px" }, viewBox: "0 0 24 24", onMouseover: e[0] || (e[0] = (...T) => i.showHighlight && i.showHighlight(...T)), onMouseenter: e[1] || (e[1] = (...T) => i.showHighlight && i.showHighlight(...T)), onMouseout: e[2] || (e[2] = (...T) => i.hideHighlight && i.hideHighlight(...T)) }, BA, 32))]), Ot(j("div", ZA, null, 512), [[Kt, a.highlight]])]), x(" btn ")]))])], 2);
}
var LA = ".vc-chrome{background:#fff;background-color:#fff;border-radius:2px;box-shadow:0 0 2px rgba(0,0,0,.3),0 4px 8px rgba(0,0,0,.3);box-sizing:initial;font-family:Menlo;width:225px}.vc-chrome-controls{display:flex}.vc-chrome-color-wrap{position:relative;width:36px}.vc-chrome-active-color{border-radius:15px;height:30px;overflow:hidden;position:relative;width:30px;z-index:1}.vc-chrome-color-wrap .vc-checkerboard{background-size:auto;border-radius:15px;height:30px;width:30px}.vc-chrome-sliders{flex:1}.vc-chrome-fields-wrap{display:flex;padding-top:16px}.vc-chrome-fields{display:flex;flex:1;margin-left:-6px}.vc-chrome-field{padding-left:6px;width:100%}.vc-chrome-toggle-btn{position:relative;text-align:right;width:32px}.vc-chrome-toggle-icon{cursor:pointer;margin-right:-4px;margin-top:12px;position:relative;z-index:2}.vc-chrome-toggle-icon-highlight{background:#eee;border-radius:4px;height:28px;left:12px;position:absolute;top:10px;width:24px}.vc-chrome-hue-wrap{margin-bottom:8px}.vc-chrome-alpha-wrap,.vc-chrome-hue-wrap{height:10px;position:relative}.vc-chrome-alpha-wrap .vc-alpha-gradient,.vc-chrome-hue-wrap .vc-hue{border-radius:2px}.vc-chrome-alpha-wrap .vc-alpha-picker,.vc-chrome-hue-wrap .vc-hue-picker{background-color:#f8f8f8;border-radius:6px;box-shadow:0 1px 4px 0 rgba(0,0,0,.37);height:12px;transform:translate(-6px,-2px);width:12px}.vc-chrome-body{background-color:#fff;padding:16px 16px 12px}.vc-chrome-saturation-wrap{border-radius:2px 2px 0 0;overflow:hidden;padding-bottom:55%;position:relative;width:100%}.vc-chrome-saturation-wrap .vc-saturation-circle{height:12px;width:12px}.vc-chrome-fields .vc-input__input{border:none;border-radius:2px;box-shadow:inset 0 0 0 1px #dadada;color:#333;font-size:11px;height:21px;text-align:center;width:100%}.vc-chrome-fields .vc-input__label{color:#969696;display:block;font-size:11px;line-height:11px;margin-top:12px;text-align:center;text-transform:uppercase}.vc-chrome__disable-alpha .vc-chrome-active-color{height:18px;width:18px}.vc-chrome__disable-alpha .vc-chrome-color-wrap{width:30px}.vc-chrome__disable-alpha .vc-chrome-hue-wrap{margin-bottom:4px;margin-top:4px}";
xr(LA), gi.render = IA, gi.__file = "src/components/chrome/chrome.vue", gi.install = Hr, Xe();
const kA = ["aria-label"], CA = { key: 0, class: "color-picker__simple" }, xA = ["aria-label", "name", "checked", "onClick"], HA = { key: 0, class: "color-picker__navigation" }, PA = Ve({ __name: "NcColorPicker", props: rn({ advancedFields: { type: Boolean }, container: { default: "body" }, palette: { default: () => [...a0] }, paletteOnly: { type: Boolean } }, { modelValue: { required: true }, modelModifiers: {}, open: { type: Boolean }, openModifiers: {} }), emits: rn(["submit", "closed"], ["update:modelValue", "update:open"]), setup(t, { emit: e }) {
  const n = /^#([a-f0-9]{3}|[a-f0-9]{6})$/i, r = t, a = An(t, "modelValue"), i = An(t, "open"), s = e, l = kn(), o = se(false), c = Q(() => {
    let E = r.palette;
    for (const A of E) if (typeof A == "string" && !A.match(n) || typeof A == "object" && !A.color?.match(n)) {
      Za.error("[NcColorPicker] Invalid palette passed", { color: A }), E = [...a0];
      break;
    }
    return E.map((A) => ({ color: typeof A == "object" ? A.color : A, name: typeof A == "object" && A.name ? A.name : ce("A color with a HEX value {hex}", { hex: A.color }) }));
  }), u = Q(() => m(a.value) > 0.5 ? "#000000" : "#FFFFFF");
  function T(E) {
    s("submit", a.value), E(), o.value = false;
  }
  function f(E) {
    typeof E != "string" && (E = "hex" in E ? E.hex : E.color), a.value = E;
  }
  function m(E) {
    const [A, g, O] = v(E);
    return (0.2126 * A + 0.7152 * g + 0.0722 * O) / 255;
  }
  function v(E) {
    const A = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(E);
    return A ? [parseInt(A[1], 16), parseInt(A[2], 16), parseInt(A[3], 16)] : [0, 0, 0];
  }
  return (E, A) => (p(), De(S(Mc), { shown: i.value, "onUpdate:shown": A[3] || (A[3] = (g) => i.value = g), container: E.container, "popup-role": "dialog", onApplyHide: A[4] || (A[4] = (g) => s("closed")) }, { trigger: he((g) => [le(E.$slots, "default", bt(Ht(g)), void 0, true)]), default: he((g) => [j("div", { role: "dialog", class: ye(["color-picker", { "color-picker--advanced-fields": o.value && E.advancedFields }]), "aria-modal": "true", "aria-label": S(ce)("Color picker") }, [Oe(qn, { name: "slide", mode: "out-in" }, { default: he(() => [o.value ? (p(), De(S(gi), { key: 1, modelValue: a.value, "onUpdate:modelValue": [A[0] || (A[0] = (O) => a.value = O), f], class: "color-picker__advanced", "disable-alpha": true, "disable-fields": !E.advancedFields }, null, 8, ["modelValue", "disable-fields"])) : (p(), M("div", CA, [(p(true), M(He, null, rt(c.value, ({ color: O, name: D }, w) => (p(), M("label", { key: w, class: ye(["color-picker__simple-color-circle", { "color-picker__simple-color-circle--active": O === a.value }]), style: Tt({ backgroundColor: O, color: u.value }) }, [O === a.value ? (p(), De(S(xt), { key: 0, path: S(Fc) }, null, 8, ["path"])) : x("", true), j("input", { type: "radio", class: "hidden-visually", "aria-label": D, name: `color-picker-${S(l)}`, checked: O === a.value, onClick: (L) => f(O) }, null, 8, xA)], 6))), 128))]))]), _: 1 }), E.paletteOnly ? x("", true) : (p(), M("div", HA, [o.value ? (p(), De(S($t), { key: 0, "aria-label": S(ce)("Back"), variant: "tertiary", onClick: A[1] || (A[1] = (O) => o.value = false) }, { icon: he(() => [Oe(S(xt), { directional: "", path: S(yc) }, null, 8, ["path"])]), _: 1 }, 8, ["aria-label"])) : (p(), De(S($t), { key: 1, "aria-label": S(ce)("More options"), variant: "tertiary", onClick: A[2] || (A[2] = (O) => o.value = true) }, { icon: he(() => [Oe(S(xt), { path: S(Oc) }, null, 8, ["path"])]), _: 1 }, 8, ["aria-label"])), Oe(S($t), { variant: "primary", onClick: (O) => T(g.hide) }, { default: he(() => [Mt(Be(S(ce)("Choose")), 1)]), _: 2 }, 1032, ["onClick"])]))], 10, kA)]), _: 3 }, 8, ["shown", "container"]));
} }), UA = nt(PA, [["__scopeId", "data-v-3ec4b698"]]);
Xe();
const GA = `<!--
  - SPDX-FileCopyrightText: 2023 Nextcloud GmbH and Nextcloud contributors
  - SPDX-License-Identifier: AGPL-3.0-or-later
-->
<svg width="395" height="314" viewBox="0 0 395 314" fill="none" xmlns="http://www.w3.org/2000/svg">
<rect width="395" height="314" rx="11" fill="#439DCD"/>
<rect x="13" y="51" width="366" height="248" rx="8" fill="white"/>
<rect x="22" y="111" width="92" height="12" rx="6" fill="#DEDEDE"/>
<rect x="22" y="127" width="92" height="12" rx="6" fill="#DEDEDE"/>
<rect x="22" y="63" width="92" height="12" rx="6" fill="#DEDEDE"/>
<rect x="22" y="191" width="92" height="12" rx="6" fill="#DEDEDE"/>
<rect x="22" y="143" width="92" height="12" rx="6" fill="#DEDEDE"/>
<rect x="22" y="79" width="92" height="12" rx="6" fill="#DEDEDE"/>
<rect x="22" y="159" width="92" height="12" rx="6" fill="#DEDEDE"/>
<rect x="22" y="95" width="92" height="12" rx="6" fill="#DEDEDE"/>
<rect x="22" y="175" width="92" height="12" rx="6" fill="#DEDEDE"/>
<path d="M288 145C277.56 147.8 265.32 149 254 149C242.68 149 230.44 147.8 220 145L218 153C225.44 155 234 156.32 242 157V209H250V185H258V209H266V157C274 156.32 282.56 155 290 153L288 145ZM254 145C258.4 145 262 141.4 262 137C262 132.6 258.4 129 254 129C249.6 129 246 132.6 246 137C246 141.4 249.6 145 254 145Z" fill="#DEDEDE"/>
<path d="M43.5358 13C38.6641 13 34.535 16.2415 33.2552 20.6333C32.143 18.3038 29.7327 16.6718 26.9564 16.6718C23.1385 16.6718 20 19.7521 20 23.4993C20 27.2465 23.1385 30.3282 26.9564 30.3282C29.7327 30.3282 32.1429 28.6952 33.2552 26.3653C34.535 30.7575 38.6641 34 43.5358 34C48.3715 34 52.4796 30.8064 53.7921 26.4637C54.9249 28.7407 57.3053 30.3282 60.0421 30.3282C63.8601 30.3282 67 27.2465 67 23.4993C67 19.7521 63.8601 16.6718 60.0421 16.6718C57.3053 16.6718 54.9249 18.2583 53.7921 20.5349C52.4796 16.1926 48.3715 13 43.5358 13ZM43.5358 17.0079C47.2134 17.0079 50.1512 19.8899 50.1512 23.4993C50.1512 27.1087 47.2134 29.9921 43.5358 29.9921C39.8583 29.9921 36.9218 27.1087 36.9218 23.4993C36.9218 19.8899 39.8583 17.0079 43.5358 17.0079ZM26.9564 20.6797C28.5677 20.6797 29.8307 21.9179 29.8307 23.4993C29.8307 25.0807 28.5677 26.3203 26.9564 26.3203C25.3452 26.3203 24.0836 25.0807 24.0836 23.4993C24.0836 21.9179 25.3452 20.6797 26.9564 20.6797ZM60.0421 20.6797C61.6534 20.6797 62.9164 21.9179 62.9164 23.4993C62.9164 25.0807 61.6534 26.3203 60.0421 26.3203C58.4309 26.3203 57.1693 25.0807 57.1693 23.4993C57.1693 21.9179 58.4309 20.6797 60.0421 20.6797Z" fill="white"/>
<rect x="79" y="20" width="8" height="8" rx="4" fill="white"/>
<rect x="99" y="20" width="8" height="8" rx="4" fill="white"/>
<rect x="119" y="20" width="8" height="8" rx="4" fill="white"/>
<rect x="139" y="20" width="8" height="8" rx="4" fill="white"/>
<rect x="159" y="20" width="8" height="8" rx="4" fill="white"/>
<rect x="179" y="20" width="8" height="8" rx="4" fill="white"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M12 0C5.37258 0 0 5.37259 0 12V302C0 308.627 5.37259 314 12 314H383C389.627 314 395 308.627 395 302V12C395 5.37258 389.627 0 383 0H12ZM140 44C132.268 44 126 50.268 126 58V292C126 299.732 132.268 306 140 306H372C379.732 306 386 299.732 386 292V58C386 50.268 379.732 44 372 44H140Z" fill="black" fill-opacity="0.35"/>
</svg>
`, zA = `<!--
  - SPDX-FileCopyrightText: 2023 Nextcloud GmbH and Nextcloud contributors
  - SPDX-License-Identifier: AGPL-3.0-or-later
-->
<svg width="395" height="314" viewBox="0 0 395 314" fill="none" xmlns="http://www.w3.org/2000/svg">
<rect width="395" height="314" rx="11" fill="#439DCD"/>
<rect x="13" y="51" width="366" height="248" rx="8" fill="white"/>
<rect x="22" y="111" width="92" height="12" rx="6" fill="#DEDEDE"/>
<rect x="22" y="127" width="92" height="12" rx="6" fill="#DEDEDE"/>
<rect x="22" y="63" width="92" height="12" rx="6" fill="#DEDEDE"/>
<rect x="22" y="191" width="92" height="12" rx="6" fill="#DEDEDE"/>
<rect x="22" y="143" width="92" height="12" rx="6" fill="#DEDEDE"/>
<rect x="22" y="79" width="92" height="12" rx="6" fill="#DEDEDE"/>
<rect x="22" y="159" width="92" height="12" rx="6" fill="#DEDEDE"/>
<rect x="22" y="95" width="92" height="12" rx="6" fill="#DEDEDE"/>
<rect x="22" y="175" width="92" height="12" rx="6" fill="#DEDEDE"/>
<path d="M288 145C277.56 147.8 265.32 149 254 149C242.68 149 230.44 147.8 220 145L218 153C225.44 155 234 156.32 242 157V209H250V185H258V209H266V157C274 156.32 282.56 155 290 153L288 145ZM254 145C258.4 145 262 141.4 262 137C262 132.6 258.4 129 254 129C249.6 129 246 132.6 246 137C246 141.4 249.6 145 254 145Z" fill="#DEDEDE"/>
<path d="M43.5358 13C38.6641 13 34.535 16.2415 33.2552 20.6333C32.143 18.3038 29.7327 16.6718 26.9564 16.6718C23.1385 16.6718 20 19.7521 20 23.4993C20 27.2465 23.1385 30.3282 26.9564 30.3282C29.7327 30.3282 32.1429 28.6952 33.2552 26.3653C34.535 30.7575 38.6641 34 43.5358 34C48.3715 34 52.4796 30.8064 53.7921 26.4637C54.9249 28.7407 57.3053 30.3282 60.0421 30.3282C63.8601 30.3282 67 27.2465 67 23.4993C67 19.7521 63.8601 16.6718 60.0421 16.6718C57.3053 16.6718 54.9249 18.2583 53.7921 20.5349C52.4796 16.1926 48.3715 13 43.5358 13ZM43.5358 17.0079C47.2134 17.0079 50.1512 19.8899 50.1512 23.4993C50.1512 27.1087 47.2134 29.9921 43.5358 29.9921C39.8583 29.9921 36.9218 27.1087 36.9218 23.4993C36.9218 19.8899 39.8583 17.0079 43.5358 17.0079ZM26.9564 20.6797C28.5677 20.6797 29.8307 21.9179 29.8307 23.4993C29.8307 25.0807 28.5677 26.3203 26.9564 26.3203C25.3452 26.3203 24.0836 25.0807 24.0836 23.4993C24.0836 21.9179 25.3452 20.6797 26.9564 20.6797ZM60.0421 20.6797C61.6534 20.6797 62.9164 21.9179 62.9164 23.4993C62.9164 25.0807 61.6534 26.3203 60.0421 26.3203C58.4309 26.3203 57.1693 25.0807 57.1693 23.4993C57.1693 21.9179 58.4309 20.6797 60.0421 20.6797Z" fill="white"/>
<rect x="79" y="20" width="8" height="8" rx="4" fill="white"/>
<rect x="99" y="20" width="8" height="8" rx="4" fill="white"/>
<rect x="119" y="20" width="8" height="8" rx="4" fill="white"/>
<rect x="139" y="20" width="8" height="8" rx="4" fill="white"/>
<rect x="159" y="20" width="8" height="8" rx="4" fill="white"/>
<rect x="179" y="20" width="8" height="8" rx="4" fill="white"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M12 0C5.37258 0 0 5.37259 0 12V302C0 308.627 5.37259 314 12 314H383C389.627 314 395 308.627 395 302V12C395 5.37258 389.627 0 383 0H12ZM112 44C119.732 44 126 50.268 126 58V292C126 299.732 119.732 306 112 306H20C12.268 306 6 299.732 6 292V58C6 50.268 12.268 44 20 44H112Z" fill="black" fill-opacity="0.35"/>
</svg>
`, jA = { class: "vue-skip-actions__container" }, $A = { class: "vue-skip-actions__headline" }, VA = { class: "vue-skip-actions__buttons" }, QA = Ve({ __name: "NcContent", props: { appName: {} }, setup(t) {
  const e = t;
  En("NcContent:setHasAppNavigation", l), En("NcContent:selector", "#content-vue"), En("appName", Q(() => e.appName));
  const n = Lr(), r = se(false), a = se(), i = Q(() => a.value === "navigation" ? zA : GA);
  bc(() => {
    const o = document.getElementById("skip-actions");
    o && (o.innerHTML = "", o.classList.add("vue-skip-actions"));
  });
  function s() {
    Dr("toggle-navigation", { open: true }), Bt(() => {
      window.location.hash = "app-navigation-vue", document.getElementById("app-navigation-vue").focus();
    });
  }
  function l(o) {
    r.value = o, a.value || (a.value = "navigation");
  }
  return (o, c) => (p(), M("div", { id: "content-vue", class: ye(["content", `app-${o.appName.toLowerCase()}`]) }, [(p(), De(Ia, { to: "#skip-actions" }, [j("div", jA, [j("div", $A, Be(S(ce)("Keyboard navigation help")), 1), j("div", VA, [Ot(Oe($t, { href: "#app-navigation-vue", variant: "tertiary", onClick: at(s, ["prevent"]), onFocusin: c[0] || (c[0] = (u) => a.value = "navigation"), onMouseover: c[1] || (c[1] = (u) => a.value = "navigation") }, { default: he(() => [Mt(Be(S(ce)("Skip to app navigation")), 1)]), _: 1 }, 512), [[Kt, r.value]]), Oe($t, { href: "#app-content-vue", variant: "tertiary", onFocusin: c[2] || (c[2] = (u) => a.value = "content"), onMouseover: c[3] || (c[3] = (u) => a.value = "content") }, { default: he(() => [Mt(Be(S(ce)("Skip to main content")), 1)]), _: 1 })]), Ot(Oe(xt, { class: "vue-skip-actions__image", svg: i.value, size: "auto" }, null, 8, ["svg"]), [[Kt, !S(n)]])])])), le(o.$slots, "default", {}, void 0, true)], 2));
} }), WA = nt(QA, [["__scopeId", "data-v-225e6d1b"]]), P0 = 6048e5, qA = 864e5, KA = 6e4, U0 = 36e5, JA = 1e3, G0 = Symbol.for("constructDateFrom");
function et(t, e) {
  return typeof t == "function" ? t(e) : t && typeof t == "object" && G0 in t ? t[G0](e) : t instanceof Date ? new t.constructor(e) : new Date(e);
}
function Ie(t, e) {
  return et(e || t, t);
}
function dn(t, e, n) {
  const r = Ie(t, n?.in);
  return isNaN(e) ? et(n?.in || t, NaN) : (e && r.setDate(r.getDate() + e), r);
}
function Dn(t, e, n) {
  const r = Ie(t, n?.in);
  if (isNaN(e)) return et(t, NaN);
  if (!e) return r;
  const a = r.getDate(), i = et(t, r.getTime());
  i.setMonth(r.getMonth() + e + 1, 0);
  const s = i.getDate();
  return a >= s ? i : (r.setFullYear(i.getFullYear(), i.getMonth(), a), r);
}
function z0(t, e, n) {
  const { years: r = 0, months: a = 0, weeks: i = 0, days: s = 0, hours: l = 0, minutes: o = 0, seconds: c = 0 } = e, u = Ie(t, n?.in), T = a || r ? Dn(u, a + r * 12) : u, f = s || i ? dn(T, s + i * 7) : T, m = o + l * 60, E = (c + m * 60) * 1e3;
  return et(t, +f + E);
}
function XA(t, e, n) {
  return et(t, +Ie(t) + e);
}
function em(t, e, n) {
  return XA(t, e * U0);
}
let tm = {};
function Rr() {
  return tm;
}
function Sn(t, e) {
  const n = Rr(), r = e?.weekStartsOn ?? e?.locale?.options?.weekStartsOn ?? n.weekStartsOn ?? n.locale?.options?.weekStartsOn ?? 0, a = Ie(t, e?.in), i = a.getDay(), s = (i < r ? 7 : 0) + i - r;
  return a.setDate(a.getDate() - s), a.setHours(0, 0, 0, 0), a;
}
function Pr(t, e) {
  return Sn(t, { ...e, weekStartsOn: 1 });
}
function j0(t, e) {
  const n = Ie(t, e?.in), r = n.getFullYear(), a = et(n, 0);
  a.setFullYear(r + 1, 0, 4), a.setHours(0, 0, 0, 0);
  const i = Pr(a), s = et(n, 0);
  s.setFullYear(r, 0, 4), s.setHours(0, 0, 0, 0);
  const l = Pr(s);
  return n.getTime() >= i.getTime() ? r + 1 : n.getTime() >= l.getTime() ? r : r - 1;
}
function Ri(t) {
  const e = Ie(t), n = new Date(Date.UTC(e.getFullYear(), e.getMonth(), e.getDate(), e.getHours(), e.getMinutes(), e.getSeconds(), e.getMilliseconds()));
  return n.setUTCFullYear(e.getFullYear()), +t - +n;
}
function ma(t, ...e) {
  const n = et.bind(null, e.find((r) => typeof r == "object"));
  return e.map(n);
}
function $0(t, e) {
  const n = Ie(t, e?.in);
  return n.setHours(0, 0, 0, 0), n;
}
function V0(t, e, n) {
  const [r, a] = ma(n?.in, t, e), i = $0(r), s = $0(a), l = +i - Ri(i), o = +s - Ri(s);
  return Math.round((l - o) / qA);
}
function nm(t, e) {
  const n = j0(t, e), r = et(t, 0);
  return r.setFullYear(n, 0, 4), r.setHours(0, 0, 0, 0), Pr(r);
}
function rm(t, e, n) {
  return Dn(t, e * 3, n);
}
function ws(t, e, n) {
  return Dn(t, e * 12, n);
}
function Q0(t, e) {
  const n = +Ie(t) - +Ie(e);
  return n < 0 ? -1 : n > 0 ? 1 : n;
}
function W0(t) {
  return t instanceof Date || typeof t == "object" && Object.prototype.toString.call(t) === "[object Date]";
}
function Ea(t) {
  return !(!W0(t) && typeof t != "number" || isNaN(+Ie(t)));
}
function q0(t, e) {
  const n = Ie(t, e?.in);
  return Math.trunc(n.getMonth() / 3) + 1;
}
function am(t, e, n) {
  const [r, a] = ma(n?.in, t, e);
  return r.getFullYear() - a.getFullYear();
}
function im(t, e, n) {
  const [r, a] = ma(n?.in, t, e), i = Q0(r, a), s = Math.abs(am(r, a));
  r.setFullYear(1584), a.setFullYear(1584);
  const l = Q0(r, a) === -i, o = i * (s - +l);
  return o === 0 ? 0 : o;
}
function K0(t, e) {
  const [n, r] = ma(t, e.start, e.end);
  return { start: n, end: r };
}
function J0(t, e) {
  const { start: n, end: r } = K0(e?.in, t);
  let a = +n > +r;
  const i = a ? +n : +r, s = a ? r : n;
  s.setHours(0, 0, 0, 0);
  let l = 1;
  const o = [];
  for (; +s <= i; ) o.push(et(n, s)), s.setDate(s.getDate() + l), s.setHours(0, 0, 0, 0);
  return a ? o.reverse() : o;
}
function Nr(t, e) {
  const n = Ie(t, e?.in), r = n.getMonth(), a = r - r % 3;
  return n.setMonth(a, 1), n.setHours(0, 0, 0, 0), n;
}
function sm(t, e) {
  const { start: n, end: r } = K0(e?.in, t);
  let a = +n > +r;
  const i = a ? +Nr(n) : +Nr(r);
  let s = Nr(a ? r : n), l = 1;
  const o = [];
  for (; +s <= i; ) o.push(et(n, s)), s = rm(s, l);
  return a ? o.reverse() : o;
}
function om(t, e) {
  const n = Ie(t, e?.in);
  return n.setDate(1), n.setHours(0, 0, 0, 0), n;
}
function X0(t, e) {
  const n = Ie(t, e?.in), r = n.getFullYear();
  return n.setFullYear(r + 1, 0, 0), n.setHours(23, 59, 59, 999), n;
}
function pa(t, e) {
  const n = Ie(t, e?.in);
  return n.setFullYear(n.getFullYear(), 0, 1), n.setHours(0, 0, 0, 0), n;
}
function el(t, e) {
  const n = Rr(), r = e?.weekStartsOn ?? e?.locale?.options?.weekStartsOn ?? n.weekStartsOn ?? n.locale?.options?.weekStartsOn ?? 0, a = Ie(t, e?.in), i = a.getDay(), s = (i < r ? -7 : 0) + 6 - (i - r);
  return a.setDate(a.getDate() + s), a.setHours(23, 59, 59, 999), a;
}
function tl(t, e) {
  const n = Ie(t, e?.in), r = n.getMonth(), a = r - r % 3 + 3;
  return n.setMonth(a, 0), n.setHours(23, 59, 59, 999), n;
}
const lm = { lessThanXSeconds: { one: "less than a second", other: "less than {{count}} seconds" }, xSeconds: { one: "1 second", other: "{{count}} seconds" }, halfAMinute: "half a minute", lessThanXMinutes: { one: "less than a minute", other: "less than {{count}} minutes" }, xMinutes: { one: "1 minute", other: "{{count}} minutes" }, aboutXHours: { one: "about 1 hour", other: "about {{count}} hours" }, xHours: { one: "1 hour", other: "{{count}} hours" }, xDays: { one: "1 day", other: "{{count}} days" }, aboutXWeeks: { one: "about 1 week", other: "about {{count}} weeks" }, xWeeks: { one: "1 week", other: "{{count}} weeks" }, aboutXMonths: { one: "about 1 month", other: "about {{count}} months" }, xMonths: { one: "1 month", other: "{{count}} months" }, aboutXYears: { one: "about 1 year", other: "about {{count}} years" }, xYears: { one: "1 year", other: "{{count}} years" }, overXYears: { one: "over 1 year", other: "over {{count}} years" }, almostXYears: { one: "almost 1 year", other: "almost {{count}} years" } }, um = (t, e, n) => {
  let r;
  const a = lm[t];
  return typeof a == "string" ? r = a : e === 1 ? r = a.one : r = a.other.replace("{{count}}", e.toString()), n?.addSuffix ? n.comparison && n.comparison > 0 ? "in " + r : r + " ago" : r;
};
function _s(t) {
  return (e = {}) => {
    const n = e.width ? String(e.width) : t.defaultWidth;
    return t.formats[n] || t.formats[t.defaultWidth];
  };
}
const cm = { full: "EEEE, MMMM do, y", long: "MMMM do, y", medium: "MMM d, y", short: "MM/dd/yyyy" }, Tm = { full: "h:mm:ss a zzzz", long: "h:mm:ss a z", medium: "h:mm:ss a", short: "h:mm a" }, dm = { full: "{{date}} 'at' {{time}}", long: "{{date}} 'at' {{time}}", medium: "{{date}}, {{time}}", short: "{{date}}, {{time}}" }, hm = { date: _s({ formats: cm, defaultWidth: "full" }), time: _s({ formats: Tm, defaultWidth: "full" }), dateTime: _s({ formats: dm, defaultWidth: "full" }) }, fm = { lastWeek: "'last' eeee 'at' p", yesterday: "'yesterday at' p", today: "'today at' p", tomorrow: "'tomorrow at' p", nextWeek: "eeee 'at' p", other: "P" }, Am = (t, e, n, r) => fm[t];
function Da(t) {
  return (e, n) => {
    const r = n?.context ? String(n.context) : "standalone";
    let a;
    if (r === "formatting" && t.formattingValues) {
      const s = t.defaultFormattingWidth || t.defaultWidth, l = n?.width ? String(n.width) : s;
      a = t.formattingValues[l] || t.formattingValues[s];
    } else {
      const s = t.defaultWidth, l = n?.width ? String(n.width) : t.defaultWidth;
      a = t.values[l] || t.values[s];
    }
    const i = t.argumentCallback ? t.argumentCallback(e) : e;
    return a[i];
  };
}
const mm = { narrow: ["B", "A"], abbreviated: ["BC", "AD"], wide: ["Before Christ", "Anno Domini"] }, Em = { narrow: ["1", "2", "3", "4"], abbreviated: ["Q1", "Q2", "Q3", "Q4"], wide: ["1st quarter", "2nd quarter", "3rd quarter", "4th quarter"] }, pm = { narrow: ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"], abbreviated: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], wide: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"] }, Dm = { narrow: ["S", "M", "T", "W", "T", "F", "S"], short: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"], abbreviated: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"], wide: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"] }, Sm = { narrow: { am: "a", pm: "p", midnight: "mi", noon: "n", morning: "morning", afternoon: "afternoon", evening: "evening", night: "night" }, abbreviated: { am: "AM", pm: "PM", midnight: "midnight", noon: "noon", morning: "morning", afternoon: "afternoon", evening: "evening", night: "night" }, wide: { am: "a.m.", pm: "p.m.", midnight: "midnight", noon: "noon", morning: "morning", afternoon: "afternoon", evening: "evening", night: "night" } }, vm = { narrow: { am: "a", pm: "p", midnight: "mi", noon: "n", morning: "in the morning", afternoon: "in the afternoon", evening: "in the evening", night: "at night" }, abbreviated: { am: "AM", pm: "PM", midnight: "midnight", noon: "noon", morning: "in the morning", afternoon: "in the afternoon", evening: "in the evening", night: "at night" }, wide: { am: "a.m.", pm: "p.m.", midnight: "midnight", noon: "noon", morning: "in the morning", afternoon: "in the afternoon", evening: "in the evening", night: "at night" } }, gm = (t, e) => {
  const n = Number(t), r = n % 100;
  if (r > 20 || r < 10) switch (r % 10) {
    case 1:
      return n + "st";
    case 2:
      return n + "nd";
    case 3:
      return n + "rd";
  }
  return n + "th";
}, Rm = { ordinalNumber: gm, era: Da({ values: mm, defaultWidth: "wide" }), quarter: Da({ values: Em, defaultWidth: "wide", argumentCallback: (t) => t - 1 }), month: Da({ values: pm, defaultWidth: "wide" }), day: Da({ values: Dm, defaultWidth: "wide" }), dayPeriod: Da({ values: Sm, defaultWidth: "wide", formattingValues: vm, defaultFormattingWidth: "wide" }) };
function Sa(t) {
  return (e, n = {}) => {
    const r = n.width, a = r && t.matchPatterns[r] || t.matchPatterns[t.defaultMatchWidth], i = e.match(a);
    if (!i) return null;
    const s = i[0], l = r && t.parsePatterns[r] || t.parsePatterns[t.defaultParseWidth], o = Array.isArray(l) ? Fm(l, (T) => T.test(s)) : Nm(l, (T) => T.test(s));
    let c;
    c = t.valueCallback ? t.valueCallback(o) : o, c = n.valueCallback ? n.valueCallback(c) : c;
    const u = e.slice(s.length);
    return { value: c, rest: u };
  };
}
function Nm(t, e) {
  for (const n in t) if (Object.prototype.hasOwnProperty.call(t, n) && e(t[n])) return n;
}
function Fm(t, e) {
  for (let n = 0; n < t.length; n++) if (e(t[n])) return n;
}
function ym(t) {
  return (e, n = {}) => {
    const r = e.match(t.matchPattern);
    if (!r) return null;
    const a = r[0], i = e.match(t.parsePattern);
    if (!i) return null;
    let s = t.valueCallback ? t.valueCallback(i[0]) : i[0];
    s = n.valueCallback ? n.valueCallback(s) : s;
    const l = e.slice(a.length);
    return { value: s, rest: l };
  };
}
const Om = /^(\d+)(th|st|nd|rd)?/i, Mm = /\d+/i, bm = { narrow: /^(b|a)/i, abbreviated: /^(b\.?\s?c\.?|b\.?\s?c\.?\s?e\.?|a\.?\s?d\.?|c\.?\s?e\.?)/i, wide: /^(before christ|before common era|anno domini|common era)/i }, Ym = { any: [/^b/i, /^(a|c)/i] }, wm = { narrow: /^[1234]/i, abbreviated: /^q[1234]/i, wide: /^[1234](th|st|nd|rd)? quarter/i }, _m = { any: [/1/i, /2/i, /3/i, /4/i] }, Bm = { narrow: /^[jfmasond]/i, abbreviated: /^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i, wide: /^(january|february|march|april|may|june|july|august|september|october|november|december)/i }, Zm = { narrow: [/^j/i, /^f/i, /^m/i, /^a/i, /^m/i, /^j/i, /^j/i, /^a/i, /^s/i, /^o/i, /^n/i, /^d/i], any: [/^ja/i, /^f/i, /^mar/i, /^ap/i, /^may/i, /^jun/i, /^jul/i, /^au/i, /^s/i, /^o/i, /^n/i, /^d/i] }, Im = { narrow: /^[smtwf]/i, short: /^(su|mo|tu|we|th|fr|sa)/i, abbreviated: /^(sun|mon|tue|wed|thu|fri|sat)/i, wide: /^(sunday|monday|tuesday|wednesday|thursday|friday|saturday)/i }, Lm = { narrow: [/^s/i, /^m/i, /^t/i, /^w/i, /^t/i, /^f/i, /^s/i], any: [/^su/i, /^m/i, /^tu/i, /^w/i, /^th/i, /^f/i, /^sa/i] }, km = { narrow: /^(a|p|mi|n|(in the|at) (morning|afternoon|evening|night))/i, any: /^([ap]\.?\s?m\.?|midnight|noon|(in the|at) (morning|afternoon|evening|night))/i }, Cm = { any: { am: /^a/i, pm: /^p/i, midnight: /^mi/i, noon: /^no/i, morning: /morning/i, afternoon: /afternoon/i, evening: /evening/i, night: /night/i } }, xm = { ordinalNumber: ym({ matchPattern: Om, parsePattern: Mm, valueCallback: (t) => parseInt(t, 10) }), era: Sa({ matchPatterns: bm, defaultMatchWidth: "wide", parsePatterns: Ym, defaultParseWidth: "any" }), quarter: Sa({ matchPatterns: wm, defaultMatchWidth: "wide", parsePatterns: _m, defaultParseWidth: "any", valueCallback: (t) => t + 1 }), month: Sa({ matchPatterns: Bm, defaultMatchWidth: "wide", parsePatterns: Zm, defaultParseWidth: "any" }), day: Sa({ matchPatterns: Im, defaultMatchWidth: "wide", parsePatterns: Lm, defaultParseWidth: "any" }), dayPeriod: Sa({ matchPatterns: km, defaultMatchWidth: "any", parsePatterns: Cm, defaultParseWidth: "any" }) }, nl = { code: "en-US", formatDistance: um, formatLong: hm, formatRelative: Am, localize: Rm, match: xm, options: { weekStartsOn: 0, firstWeekContainsDate: 1 } };
function Hm(t, e) {
  const n = Ie(t, e?.in);
  return V0(n, pa(n)) + 1;
}
function Bs(t, e) {
  const n = Ie(t, e?.in), r = +Pr(n) - +nm(n);
  return Math.round(r / P0) + 1;
}
function Zs(t, e) {
  const n = Ie(t, e?.in), r = n.getFullYear(), a = Rr(), i = e?.firstWeekContainsDate ?? e?.locale?.options?.firstWeekContainsDate ?? a.firstWeekContainsDate ?? a.locale?.options?.firstWeekContainsDate ?? 1, s = et(e?.in || t, 0);
  s.setFullYear(r + 1, 0, i), s.setHours(0, 0, 0, 0);
  const l = Sn(s, e), o = et(e?.in || t, 0);
  o.setFullYear(r, 0, i), o.setHours(0, 0, 0, 0);
  const c = Sn(o, e);
  return +n >= +l ? r + 1 : +n >= +c ? r : r - 1;
}
function Pm(t, e) {
  const n = Rr(), r = e?.firstWeekContainsDate ?? e?.locale?.options?.firstWeekContainsDate ?? n.firstWeekContainsDate ?? n.locale?.options?.firstWeekContainsDate ?? 1, a = Zs(t, e), i = et(e?.in || t, 0);
  return i.setFullYear(a, 0, r), i.setHours(0, 0, 0, 0), Sn(i, e);
}
function Is(t, e) {
  const n = Ie(t, e?.in), r = +Sn(n, e) - +Pm(n, e);
  return Math.round(r / P0) + 1;
}
function tt(t, e) {
  const n = t < 0 ? "-" : "", r = Math.abs(t).toString().padStart(e, "0");
  return n + r;
}
const nr = { y(t, e) {
  const n = t.getFullYear(), r = n > 0 ? n : 1 - n;
  return tt(e === "yy" ? r % 100 : r, e.length);
}, M(t, e) {
  const n = t.getMonth();
  return e === "M" ? String(n + 1) : tt(n + 1, 2);
}, d(t, e) {
  return tt(t.getDate(), e.length);
}, a(t, e) {
  const n = t.getHours() / 12 >= 1 ? "pm" : "am";
  switch (e) {
    case "a":
    case "aa":
      return n.toUpperCase();
    case "aaa":
      return n;
    case "aaaaa":
      return n[0];
    case "aaaa":
    default:
      return n === "am" ? "a.m." : "p.m.";
  }
}, h(t, e) {
  return tt(t.getHours() % 12 || 12, e.length);
}, H(t, e) {
  return tt(t.getHours(), e.length);
}, m(t, e) {
  return tt(t.getMinutes(), e.length);
}, s(t, e) {
  return tt(t.getSeconds(), e.length);
}, S(t, e) {
  const n = e.length, r = t.getMilliseconds(), a = Math.trunc(r * Math.pow(10, n - 3));
  return tt(a, e.length);
} }, Ur = { midnight: "midnight", noon: "noon", morning: "morning", afternoon: "afternoon", evening: "evening", night: "night" }, rl = { G: function(t, e, n) {
  const r = t.getFullYear() > 0 ? 1 : 0;
  switch (e) {
    case "G":
    case "GG":
    case "GGG":
      return n.era(r, { width: "abbreviated" });
    case "GGGGG":
      return n.era(r, { width: "narrow" });
    case "GGGG":
    default:
      return n.era(r, { width: "wide" });
  }
}, y: function(t, e, n) {
  if (e === "yo") {
    const r = t.getFullYear(), a = r > 0 ? r : 1 - r;
    return n.ordinalNumber(a, { unit: "year" });
  }
  return nr.y(t, e);
}, Y: function(t, e, n, r) {
  const a = Zs(t, r), i = a > 0 ? a : 1 - a;
  if (e === "YY") {
    const s = i % 100;
    return tt(s, 2);
  }
  return e === "Yo" ? n.ordinalNumber(i, { unit: "year" }) : tt(i, e.length);
}, R: function(t, e) {
  const n = j0(t);
  return tt(n, e.length);
}, u: function(t, e) {
  const n = t.getFullYear();
  return tt(n, e.length);
}, Q: function(t, e, n) {
  const r = Math.ceil((t.getMonth() + 1) / 3);
  switch (e) {
    case "Q":
      return String(r);
    case "QQ":
      return tt(r, 2);
    case "Qo":
      return n.ordinalNumber(r, { unit: "quarter" });
    case "QQQ":
      return n.quarter(r, { width: "abbreviated", context: "formatting" });
    case "QQQQQ":
      return n.quarter(r, { width: "narrow", context: "formatting" });
    case "QQQQ":
    default:
      return n.quarter(r, { width: "wide", context: "formatting" });
  }
}, q: function(t, e, n) {
  const r = Math.ceil((t.getMonth() + 1) / 3);
  switch (e) {
    case "q":
      return String(r);
    case "qq":
      return tt(r, 2);
    case "qo":
      return n.ordinalNumber(r, { unit: "quarter" });
    case "qqq":
      return n.quarter(r, { width: "abbreviated", context: "standalone" });
    case "qqqqq":
      return n.quarter(r, { width: "narrow", context: "standalone" });
    case "qqqq":
    default:
      return n.quarter(r, { width: "wide", context: "standalone" });
  }
}, M: function(t, e, n) {
  const r = t.getMonth();
  switch (e) {
    case "M":
    case "MM":
      return nr.M(t, e);
    case "Mo":
      return n.ordinalNumber(r + 1, { unit: "month" });
    case "MMM":
      return n.month(r, { width: "abbreviated", context: "formatting" });
    case "MMMMM":
      return n.month(r, { width: "narrow", context: "formatting" });
    case "MMMM":
    default:
      return n.month(r, { width: "wide", context: "formatting" });
  }
}, L: function(t, e, n) {
  const r = t.getMonth();
  switch (e) {
    case "L":
      return String(r + 1);
    case "LL":
      return tt(r + 1, 2);
    case "Lo":
      return n.ordinalNumber(r + 1, { unit: "month" });
    case "LLL":
      return n.month(r, { width: "abbreviated", context: "standalone" });
    case "LLLLL":
      return n.month(r, { width: "narrow", context: "standalone" });
    case "LLLL":
    default:
      return n.month(r, { width: "wide", context: "standalone" });
  }
}, w: function(t, e, n, r) {
  const a = Is(t, r);
  return e === "wo" ? n.ordinalNumber(a, { unit: "week" }) : tt(a, e.length);
}, I: function(t, e, n) {
  const r = Bs(t);
  return e === "Io" ? n.ordinalNumber(r, { unit: "week" }) : tt(r, e.length);
}, d: function(t, e, n) {
  return e === "do" ? n.ordinalNumber(t.getDate(), { unit: "date" }) : nr.d(t, e);
}, D: function(t, e, n) {
  const r = Hm(t);
  return e === "Do" ? n.ordinalNumber(r, { unit: "dayOfYear" }) : tt(r, e.length);
}, E: function(t, e, n) {
  const r = t.getDay();
  switch (e) {
    case "E":
    case "EE":
    case "EEE":
      return n.day(r, { width: "abbreviated", context: "formatting" });
    case "EEEEE":
      return n.day(r, { width: "narrow", context: "formatting" });
    case "EEEEEE":
      return n.day(r, { width: "short", context: "formatting" });
    case "EEEE":
    default:
      return n.day(r, { width: "wide", context: "formatting" });
  }
}, e: function(t, e, n, r) {
  const a = t.getDay(), i = (a - r.weekStartsOn + 8) % 7 || 7;
  switch (e) {
    case "e":
      return String(i);
    case "ee":
      return tt(i, 2);
    case "eo":
      return n.ordinalNumber(i, { unit: "day" });
    case "eee":
      return n.day(a, { width: "abbreviated", context: "formatting" });
    case "eeeee":
      return n.day(a, { width: "narrow", context: "formatting" });
    case "eeeeee":
      return n.day(a, { width: "short", context: "formatting" });
    case "eeee":
    default:
      return n.day(a, { width: "wide", context: "formatting" });
  }
}, c: function(t, e, n, r) {
  const a = t.getDay(), i = (a - r.weekStartsOn + 8) % 7 || 7;
  switch (e) {
    case "c":
      return String(i);
    case "cc":
      return tt(i, e.length);
    case "co":
      return n.ordinalNumber(i, { unit: "day" });
    case "ccc":
      return n.day(a, { width: "abbreviated", context: "standalone" });
    case "ccccc":
      return n.day(a, { width: "narrow", context: "standalone" });
    case "cccccc":
      return n.day(a, { width: "short", context: "standalone" });
    case "cccc":
    default:
      return n.day(a, { width: "wide", context: "standalone" });
  }
}, i: function(t, e, n) {
  const r = t.getDay(), a = r === 0 ? 7 : r;
  switch (e) {
    case "i":
      return String(a);
    case "ii":
      return tt(a, e.length);
    case "io":
      return n.ordinalNumber(a, { unit: "day" });
    case "iii":
      return n.day(r, { width: "abbreviated", context: "formatting" });
    case "iiiii":
      return n.day(r, { width: "narrow", context: "formatting" });
    case "iiiiii":
      return n.day(r, { width: "short", context: "formatting" });
    case "iiii":
    default:
      return n.day(r, { width: "wide", context: "formatting" });
  }
}, a: function(t, e, n) {
  const a = t.getHours() / 12 >= 1 ? "pm" : "am";
  switch (e) {
    case "a":
    case "aa":
      return n.dayPeriod(a, { width: "abbreviated", context: "formatting" });
    case "aaa":
      return n.dayPeriod(a, { width: "abbreviated", context: "formatting" }).toLowerCase();
    case "aaaaa":
      return n.dayPeriod(a, { width: "narrow", context: "formatting" });
    case "aaaa":
    default:
      return n.dayPeriod(a, { width: "wide", context: "formatting" });
  }
}, b: function(t, e, n) {
  const r = t.getHours();
  let a;
  switch (r === 12 ? a = Ur.noon : r === 0 ? a = Ur.midnight : a = r / 12 >= 1 ? "pm" : "am", e) {
    case "b":
    case "bb":
      return n.dayPeriod(a, { width: "abbreviated", context: "formatting" });
    case "bbb":
      return n.dayPeriod(a, { width: "abbreviated", context: "formatting" }).toLowerCase();
    case "bbbbb":
      return n.dayPeriod(a, { width: "narrow", context: "formatting" });
    case "bbbb":
    default:
      return n.dayPeriod(a, { width: "wide", context: "formatting" });
  }
}, B: function(t, e, n) {
  const r = t.getHours();
  let a;
  switch (r >= 17 ? a = Ur.evening : r >= 12 ? a = Ur.afternoon : r >= 4 ? a = Ur.morning : a = Ur.night, e) {
    case "B":
    case "BB":
    case "BBB":
      return n.dayPeriod(a, { width: "abbreviated", context: "formatting" });
    case "BBBBB":
      return n.dayPeriod(a, { width: "narrow", context: "formatting" });
    case "BBBB":
    default:
      return n.dayPeriod(a, { width: "wide", context: "formatting" });
  }
}, h: function(t, e, n) {
  if (e === "ho") {
    let r = t.getHours() % 12;
    return r === 0 && (r = 12), n.ordinalNumber(r, { unit: "hour" });
  }
  return nr.h(t, e);
}, H: function(t, e, n) {
  return e === "Ho" ? n.ordinalNumber(t.getHours(), { unit: "hour" }) : nr.H(t, e);
}, K: function(t, e, n) {
  const r = t.getHours() % 12;
  return e === "Ko" ? n.ordinalNumber(r, { unit: "hour" }) : tt(r, e.length);
}, k: function(t, e, n) {
  let r = t.getHours();
  return r === 0 && (r = 24), e === "ko" ? n.ordinalNumber(r, { unit: "hour" }) : tt(r, e.length);
}, m: function(t, e, n) {
  return e === "mo" ? n.ordinalNumber(t.getMinutes(), { unit: "minute" }) : nr.m(t, e);
}, s: function(t, e, n) {
  return e === "so" ? n.ordinalNumber(t.getSeconds(), { unit: "second" }) : nr.s(t, e);
}, S: function(t, e) {
  return nr.S(t, e);
}, X: function(t, e, n) {
  const r = t.getTimezoneOffset();
  if (r === 0) return "Z";
  switch (e) {
    case "X":
      return il(r);
    case "XXXX":
    case "XX":
      return Fr(r);
    case "XXXXX":
    case "XXX":
    default:
      return Fr(r, ":");
  }
}, x: function(t, e, n) {
  const r = t.getTimezoneOffset();
  switch (e) {
    case "x":
      return il(r);
    case "xxxx":
    case "xx":
      return Fr(r);
    case "xxxxx":
    case "xxx":
    default:
      return Fr(r, ":");
  }
}, O: function(t, e, n) {
  const r = t.getTimezoneOffset();
  switch (e) {
    case "O":
    case "OO":
    case "OOO":
      return "GMT" + al(r, ":");
    case "OOOO":
    default:
      return "GMT" + Fr(r, ":");
  }
}, z: function(t, e, n) {
  const r = t.getTimezoneOffset();
  switch (e) {
    case "z":
    case "zz":
    case "zzz":
      return "GMT" + al(r, ":");
    case "zzzz":
    default:
      return "GMT" + Fr(r, ":");
  }
}, t: function(t, e, n) {
  const r = Math.trunc(+t / 1e3);
  return tt(r, e.length);
}, T: function(t, e, n) {
  return tt(+t, e.length);
} };
function al(t, e = "") {
  const n = t > 0 ? "-" : "+", r = Math.abs(t), a = Math.trunc(r / 60), i = r % 60;
  return i === 0 ? n + String(a) : n + String(a) + e + tt(i, 2);
}
function il(t, e) {
  return t % 60 === 0 ? (t > 0 ? "-" : "+") + tt(Math.abs(t) / 60, 2) : Fr(t, e);
}
function Fr(t, e = "") {
  const n = t > 0 ? "-" : "+", r = Math.abs(t), a = tt(Math.trunc(r / 60), 2), i = tt(r % 60, 2);
  return n + a + e + i;
}
const sl = (t, e) => {
  switch (t) {
    case "P":
      return e.date({ width: "short" });
    case "PP":
      return e.date({ width: "medium" });
    case "PPP":
      return e.date({ width: "long" });
    case "PPPP":
    default:
      return e.date({ width: "full" });
  }
}, ol = (t, e) => {
  switch (t) {
    case "p":
      return e.time({ width: "short" });
    case "pp":
      return e.time({ width: "medium" });
    case "ppp":
      return e.time({ width: "long" });
    case "pppp":
    default:
      return e.time({ width: "full" });
  }
}, Um = (t, e) => {
  const n = t.match(/(P+)(p+)?/) || [], r = n[1], a = n[2];
  if (!a) return sl(t, e);
  let i;
  switch (r) {
    case "P":
      i = e.dateTime({ width: "short" });
      break;
    case "PP":
      i = e.dateTime({ width: "medium" });
      break;
    case "PPP":
      i = e.dateTime({ width: "long" });
      break;
    case "PPPP":
    default:
      i = e.dateTime({ width: "full" });
      break;
  }
  return i.replace("{{date}}", sl(r, e)).replace("{{time}}", ol(a, e));
}, Ls = { p: ol, P: Um }, Gm = /^D+$/, zm = /^Y+$/, jm = ["D", "DD", "YY", "YYYY"];
function ll(t) {
  return Gm.test(t);
}
function ul(t) {
  return zm.test(t);
}
function ks(t, e, n) {
  const r = $m(t, e, n);
  if (console.warn(r), jm.includes(t)) throw new RangeError(r);
}
function $m(t, e, n) {
  const r = t[0] === "Y" ? "years" : "days of the month";
  return `Use \`${t.toLowerCase()}\` instead of \`${t}\` (in \`${e}\`) for formatting ${r} to the input \`${n}\`; see: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md`;
}
const Vm = /[yYQqMLwIdDecihHKkms]o|(\w)\1*|''|'(''|[^'])+('|$)|./g, Qm = /P+p+|P+|p+|''|'(''|[^'])+('|$)|./g, Wm = /^'([^]*?)'?$/, qm = /''/g, Km = /[a-zA-Z]/;
function bn(t, e, n) {
  const r = Rr(), a = n?.locale ?? r.locale ?? nl, i = n?.firstWeekContainsDate ?? n?.locale?.options?.firstWeekContainsDate ?? r.firstWeekContainsDate ?? r.locale?.options?.firstWeekContainsDate ?? 1, s = n?.weekStartsOn ?? n?.locale?.options?.weekStartsOn ?? r.weekStartsOn ?? r.locale?.options?.weekStartsOn ?? 0, l = Ie(t, n?.in);
  if (!Ea(l)) throw new RangeError("Invalid time value");
  let o = e.match(Qm).map((u) => {
    const T = u[0];
    if (T === "p" || T === "P") {
      const f = Ls[T];
      return f(u, a.formatLong);
    }
    return u;
  }).join("").match(Vm).map((u) => {
    if (u === "''") return { isToken: false, value: "'" };
    const T = u[0];
    if (T === "'") return { isToken: false, value: Jm(u) };
    if (rl[T]) return { isToken: true, value: u };
    if (T.match(Km)) throw new RangeError("Format string contains an unescaped latin alphabet character `" + T + "`");
    return { isToken: false, value: u };
  });
  a.localize.preprocessor && (o = a.localize.preprocessor(l, o));
  const c = { firstWeekContainsDate: i, weekStartsOn: s, locale: a };
  return o.map((u) => {
    if (!u.isToken) return u.value;
    const T = u.value;
    (!n?.useAdditionalWeekYearTokens && ul(T) || !n?.useAdditionalDayOfYearTokens && ll(T)) && ks(T, e, String(t));
    const f = rl[T[0]];
    return f(l, T, a.localize, c);
  }).join("");
}
function Jm(t) {
  const e = t.match(Wm);
  return e ? e[1].replace(qm, "'") : t;
}
function Xm(t, e) {
  return Ie(t, e?.in).getDay();
}
function eE(t, e) {
  const n = Ie(t, e?.in), r = n.getFullYear(), a = n.getMonth(), i = et(n, 0);
  return i.setFullYear(r, a + 1, 0), i.setHours(0, 0, 0, 0), i.getDate();
}
function tE() {
  return Object.assign({}, Rr());
}
function Gn(t, e) {
  return Ie(t, e?.in).getHours();
}
function nE(t, e) {
  const n = Ie(t, e?.in).getDay();
  return n === 0 ? 7 : n;
}
function rr(t, e) {
  return Ie(t, e?.in).getMinutes();
}
function je(t, e) {
  return Ie(t, e?.in).getMonth();
}
function Gr(t) {
  return Ie(t).getSeconds();
}
function xe(t, e) {
  return Ie(t, e?.in).getFullYear();
}
function yr(t, e) {
  return +Ie(t) > +Ie(e);
}
function zr(t, e) {
  return +Ie(t) < +Ie(e);
}
function jr(t, e) {
  return +Ie(t) == +Ie(e);
}
function rE(t, e) {
  const n = aE(e) ? new e(0) : et(e, 0);
  return n.setFullYear(t.getFullYear(), t.getMonth(), t.getDate()), n.setHours(t.getHours(), t.getMinutes(), t.getSeconds(), t.getMilliseconds()), n;
}
function aE(t) {
  return typeof t == "function" && t.prototype?.constructor === t;
}
const iE = 10;
class cl {
  subPriority = 0;
  validate(e, n) {
    return true;
  }
}
class sE extends cl {
  constructor(e, n, r, a, i) {
    super(), this.value = e, this.validateValue = n, this.setValue = r, this.priority = a, i && (this.subPriority = i);
  }
  validate(e, n) {
    return this.validateValue(e, this.value, n);
  }
  set(e, n, r) {
    return this.setValue(e, n, this.value, r);
  }
}
class oE extends cl {
  priority = iE;
  subPriority = -1;
  constructor(e, n) {
    super(), this.context = e || ((r) => et(n, r));
  }
  set(e, n) {
    return n.timestampIsSet ? e : et(e, rE(e, this.context));
  }
}
class Ke {
  run(e, n, r, a) {
    const i = this.parse(e, n, r, a);
    return i ? { setter: new sE(i.value, this.validate, this.set, this.priority, this.subPriority), rest: i.rest } : null;
  }
  validate(e, n, r) {
    return true;
  }
}
class lE extends Ke {
  priority = 140;
  parse(e, n, r) {
    switch (n) {
      case "G":
      case "GG":
      case "GGG":
        return r.era(e, { width: "abbreviated" }) || r.era(e, { width: "narrow" });
      case "GGGGG":
        return r.era(e, { width: "narrow" });
      case "GGGG":
      default:
        return r.era(e, { width: "wide" }) || r.era(e, { width: "abbreviated" }) || r.era(e, { width: "narrow" });
    }
  }
  set(e, n, r) {
    return n.era = r, e.setFullYear(r, 0, 1), e.setHours(0, 0, 0, 0), e;
  }
  incompatibleTokens = ["R", "u", "t", "T"];
}
const Rt = { month: /^(1[0-2]|0?\d)/, date: /^(3[0-1]|[0-2]?\d)/, dayOfYear: /^(36[0-6]|3[0-5]\d|[0-2]?\d?\d)/, week: /^(5[0-3]|[0-4]?\d)/, hour23h: /^(2[0-3]|[0-1]?\d)/, hour24h: /^(2[0-4]|[0-1]?\d)/, hour11h: /^(1[0-1]|0?\d)/, hour12h: /^(1[0-2]|0?\d)/, minute: /^[0-5]?\d/, second: /^[0-5]?\d/, singleDigit: /^\d/, twoDigits: /^\d{1,2}/, threeDigits: /^\d{1,3}/, fourDigits: /^\d{1,4}/, anyDigitsSigned: /^-?\d+/, singleDigitSigned: /^-?\d/, twoDigitsSigned: /^-?\d{1,2}/, threeDigitsSigned: /^-?\d{1,3}/, fourDigitsSigned: /^-?\d{1,4}/ }, Yn = { basicOptionalMinutes: /^([+-])(\d{2})(\d{2})?|Z/, basic: /^([+-])(\d{2})(\d{2})|Z/, basicOptionalSeconds: /^([+-])(\d{2})(\d{2})((\d{2}))?|Z/, extended: /^([+-])(\d{2}):(\d{2})|Z/, extendedOptionalSeconds: /^([+-])(\d{2}):(\d{2})(:(\d{2}))?|Z/ };
function Nt(t, e) {
  return t && { value: e(t.value), rest: t.rest };
}
function ft(t, e) {
  const n = e.match(t);
  return n ? { value: parseInt(n[0], 10), rest: e.slice(n[0].length) } : null;
}
function wn(t, e) {
  const n = e.match(t);
  if (!n) return null;
  if (n[0] === "Z") return { value: 0, rest: e.slice(1) };
  const r = n[1] === "+" ? 1 : -1, a = n[2] ? parseInt(n[2], 10) : 0, i = n[3] ? parseInt(n[3], 10) : 0, s = n[5] ? parseInt(n[5], 10) : 0;
  return { value: r * (a * U0 + i * KA + s * JA), rest: e.slice(n[0].length) };
}
function Tl(t) {
  return ft(Rt.anyDigitsSigned, t);
}
function Et(t, e) {
  switch (t) {
    case 1:
      return ft(Rt.singleDigit, e);
    case 2:
      return ft(Rt.twoDigits, e);
    case 3:
      return ft(Rt.threeDigits, e);
    case 4:
      return ft(Rt.fourDigits, e);
    default:
      return ft(new RegExp("^\\d{1," + t + "}"), e);
  }
}
function Ni(t, e) {
  switch (t) {
    case 1:
      return ft(Rt.singleDigitSigned, e);
    case 2:
      return ft(Rt.twoDigitsSigned, e);
    case 3:
      return ft(Rt.threeDigitsSigned, e);
    case 4:
      return ft(Rt.fourDigitsSigned, e);
    default:
      return ft(new RegExp("^-?\\d{1," + t + "}"), e);
  }
}
function Cs(t) {
  switch (t) {
    case "morning":
      return 4;
    case "evening":
      return 17;
    case "pm":
    case "noon":
    case "afternoon":
      return 12;
    case "am":
    case "midnight":
    case "night":
    default:
      return 0;
  }
}
function dl(t, e) {
  const n = e > 0, r = n ? e : 1 - e;
  let a;
  if (r <= 50) a = t || 100;
  else {
    const i = r + 50, s = Math.trunc(i / 100) * 100, l = t >= i % 100;
    a = t + s - (l ? 100 : 0);
  }
  return n ? a : 1 - a;
}
function hl(t) {
  return t % 400 === 0 || t % 4 === 0 && t % 100 !== 0;
}
class uE extends Ke {
  priority = 130;
  incompatibleTokens = ["Y", "R", "u", "w", "I", "i", "e", "c", "t", "T"];
  parse(e, n, r) {
    const a = (i) => ({ year: i, isTwoDigitYear: n === "yy" });
    switch (n) {
      case "y":
        return Nt(Et(4, e), a);
      case "yo":
        return Nt(r.ordinalNumber(e, { unit: "year" }), a);
      default:
        return Nt(Et(n.length, e), a);
    }
  }
  validate(e, n) {
    return n.isTwoDigitYear || n.year > 0;
  }
  set(e, n, r) {
    const a = e.getFullYear();
    if (r.isTwoDigitYear) {
      const s = dl(r.year, a);
      return e.setFullYear(s, 0, 1), e.setHours(0, 0, 0, 0), e;
    }
    const i = !("era" in n) || n.era === 1 ? r.year : 1 - r.year;
    return e.setFullYear(i, 0, 1), e.setHours(0, 0, 0, 0), e;
  }
}
class cE extends Ke {
  priority = 130;
  parse(e, n, r) {
    const a = (i) => ({ year: i, isTwoDigitYear: n === "YY" });
    switch (n) {
      case "Y":
        return Nt(Et(4, e), a);
      case "Yo":
        return Nt(r.ordinalNumber(e, { unit: "year" }), a);
      default:
        return Nt(Et(n.length, e), a);
    }
  }
  validate(e, n) {
    return n.isTwoDigitYear || n.year > 0;
  }
  set(e, n, r, a) {
    const i = Zs(e, a);
    if (r.isTwoDigitYear) {
      const l = dl(r.year, i);
      return e.setFullYear(l, 0, a.firstWeekContainsDate), e.setHours(0, 0, 0, 0), Sn(e, a);
    }
    const s = !("era" in n) || n.era === 1 ? r.year : 1 - r.year;
    return e.setFullYear(s, 0, a.firstWeekContainsDate), e.setHours(0, 0, 0, 0), Sn(e, a);
  }
  incompatibleTokens = ["y", "R", "u", "Q", "q", "M", "L", "I", "d", "D", "i", "t", "T"];
}
class TE extends Ke {
  priority = 130;
  parse(e, n) {
    return Ni(n === "R" ? 4 : n.length, e);
  }
  set(e, n, r) {
    const a = et(e, 0);
    return a.setFullYear(r, 0, 4), a.setHours(0, 0, 0, 0), Pr(a);
  }
  incompatibleTokens = ["G", "y", "Y", "u", "Q", "q", "M", "L", "w", "d", "D", "e", "c", "t", "T"];
}
class dE extends Ke {
  priority = 130;
  parse(e, n) {
    return Ni(n === "u" ? 4 : n.length, e);
  }
  set(e, n, r) {
    return e.setFullYear(r, 0, 1), e.setHours(0, 0, 0, 0), e;
  }
  incompatibleTokens = ["G", "y", "Y", "R", "w", "I", "i", "e", "c", "t", "T"];
}
class hE extends Ke {
  priority = 120;
  parse(e, n, r) {
    switch (n) {
      case "Q":
      case "QQ":
        return Et(n.length, e);
      case "Qo":
        return r.ordinalNumber(e, { unit: "quarter" });
      case "QQQ":
        return r.quarter(e, { width: "abbreviated", context: "formatting" }) || r.quarter(e, { width: "narrow", context: "formatting" });
      case "QQQQQ":
        return r.quarter(e, { width: "narrow", context: "formatting" });
      case "QQQQ":
      default:
        return r.quarter(e, { width: "wide", context: "formatting" }) || r.quarter(e, { width: "abbreviated", context: "formatting" }) || r.quarter(e, { width: "narrow", context: "formatting" });
    }
  }
  validate(e, n) {
    return n >= 1 && n <= 4;
  }
  set(e, n, r) {
    return e.setMonth((r - 1) * 3, 1), e.setHours(0, 0, 0, 0), e;
  }
  incompatibleTokens = ["Y", "R", "q", "M", "L", "w", "I", "d", "D", "i", "e", "c", "t", "T"];
}
class fE extends Ke {
  priority = 120;
  parse(e, n, r) {
    switch (n) {
      case "q":
      case "qq":
        return Et(n.length, e);
      case "qo":
        return r.ordinalNumber(e, { unit: "quarter" });
      case "qqq":
        return r.quarter(e, { width: "abbreviated", context: "standalone" }) || r.quarter(e, { width: "narrow", context: "standalone" });
      case "qqqqq":
        return r.quarter(e, { width: "narrow", context: "standalone" });
      case "qqqq":
      default:
        return r.quarter(e, { width: "wide", context: "standalone" }) || r.quarter(e, { width: "abbreviated", context: "standalone" }) || r.quarter(e, { width: "narrow", context: "standalone" });
    }
  }
  validate(e, n) {
    return n >= 1 && n <= 4;
  }
  set(e, n, r) {
    return e.setMonth((r - 1) * 3, 1), e.setHours(0, 0, 0, 0), e;
  }
  incompatibleTokens = ["Y", "R", "Q", "M", "L", "w", "I", "d", "D", "i", "e", "c", "t", "T"];
}
class AE extends Ke {
  incompatibleTokens = ["Y", "R", "q", "Q", "L", "w", "I", "D", "i", "e", "c", "t", "T"];
  priority = 110;
  parse(e, n, r) {
    const a = (i) => i - 1;
    switch (n) {
      case "M":
        return Nt(ft(Rt.month, e), a);
      case "MM":
        return Nt(Et(2, e), a);
      case "Mo":
        return Nt(r.ordinalNumber(e, { unit: "month" }), a);
      case "MMM":
        return r.month(e, { width: "abbreviated", context: "formatting" }) || r.month(e, { width: "narrow", context: "formatting" });
      case "MMMMM":
        return r.month(e, { width: "narrow", context: "formatting" });
      case "MMMM":
      default:
        return r.month(e, { width: "wide", context: "formatting" }) || r.month(e, { width: "abbreviated", context: "formatting" }) || r.month(e, { width: "narrow", context: "formatting" });
    }
  }
  validate(e, n) {
    return n >= 0 && n <= 11;
  }
  set(e, n, r) {
    return e.setMonth(r, 1), e.setHours(0, 0, 0, 0), e;
  }
}
class mE extends Ke {
  priority = 110;
  parse(e, n, r) {
    const a = (i) => i - 1;
    switch (n) {
      case "L":
        return Nt(ft(Rt.month, e), a);
      case "LL":
        return Nt(Et(2, e), a);
      case "Lo":
        return Nt(r.ordinalNumber(e, { unit: "month" }), a);
      case "LLL":
        return r.month(e, { width: "abbreviated", context: "standalone" }) || r.month(e, { width: "narrow", context: "standalone" });
      case "LLLLL":
        return r.month(e, { width: "narrow", context: "standalone" });
      case "LLLL":
      default:
        return r.month(e, { width: "wide", context: "standalone" }) || r.month(e, { width: "abbreviated", context: "standalone" }) || r.month(e, { width: "narrow", context: "standalone" });
    }
  }
  validate(e, n) {
    return n >= 0 && n <= 11;
  }
  set(e, n, r) {
    return e.setMonth(r, 1), e.setHours(0, 0, 0, 0), e;
  }
  incompatibleTokens = ["Y", "R", "q", "Q", "M", "w", "I", "D", "i", "e", "c", "t", "T"];
}
function EE(t, e, n) {
  const r = Ie(t, n?.in), a = Is(r, n) - e;
  return r.setDate(r.getDate() - a * 7), Ie(r, n?.in);
}
class pE extends Ke {
  priority = 100;
  parse(e, n, r) {
    switch (n) {
      case "w":
        return ft(Rt.week, e);
      case "wo":
        return r.ordinalNumber(e, { unit: "week" });
      default:
        return Et(n.length, e);
    }
  }
  validate(e, n) {
    return n >= 1 && n <= 53;
  }
  set(e, n, r, a) {
    return Sn(EE(e, r, a), a);
  }
  incompatibleTokens = ["y", "R", "u", "q", "Q", "M", "L", "I", "d", "D", "i", "t", "T"];
}
function DE(t, e, n) {
  const r = Ie(t, n?.in), a = Bs(r, n) - e;
  return r.setDate(r.getDate() - a * 7), r;
}
class SE extends Ke {
  priority = 100;
  parse(e, n, r) {
    switch (n) {
      case "I":
        return ft(Rt.week, e);
      case "Io":
        return r.ordinalNumber(e, { unit: "week" });
      default:
        return Et(n.length, e);
    }
  }
  validate(e, n) {
    return n >= 1 && n <= 53;
  }
  set(e, n, r) {
    return Pr(DE(e, r));
  }
  incompatibleTokens = ["y", "Y", "u", "q", "Q", "M", "L", "w", "d", "D", "e", "c", "t", "T"];
}
const vE = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31], gE = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
class RE extends Ke {
  priority = 90;
  subPriority = 1;
  parse(e, n, r) {
    switch (n) {
      case "d":
        return ft(Rt.date, e);
      case "do":
        return r.ordinalNumber(e, { unit: "date" });
      default:
        return Et(n.length, e);
    }
  }
  validate(e, n) {
    const r = e.getFullYear(), a = hl(r), i = e.getMonth();
    return a ? n >= 1 && n <= gE[i] : n >= 1 && n <= vE[i];
  }
  set(e, n, r) {
    return e.setDate(r), e.setHours(0, 0, 0, 0), e;
  }
  incompatibleTokens = ["Y", "R", "q", "Q", "w", "I", "D", "i", "e", "c", "t", "T"];
}
class NE extends Ke {
  priority = 90;
  subpriority = 1;
  parse(e, n, r) {
    switch (n) {
      case "D":
      case "DD":
        return ft(Rt.dayOfYear, e);
      case "Do":
        return r.ordinalNumber(e, { unit: "date" });
      default:
        return Et(n.length, e);
    }
  }
  validate(e, n) {
    const r = e.getFullYear();
    return hl(r) ? n >= 1 && n <= 366 : n >= 1 && n <= 365;
  }
  set(e, n, r) {
    return e.setMonth(0, r), e.setHours(0, 0, 0, 0), e;
  }
  incompatibleTokens = ["Y", "R", "q", "Q", "M", "L", "w", "I", "d", "E", "i", "e", "c", "t", "T"];
}
function xs(t, e, n) {
  const r = Rr(), a = n?.weekStartsOn ?? n?.locale?.options?.weekStartsOn ?? r.weekStartsOn ?? r.locale?.options?.weekStartsOn ?? 0, i = Ie(t, n?.in), s = i.getDay(), o = (e % 7 + 7) % 7, c = 7 - a, u = e < 0 || e > 6 ? e - (s + c) % 7 : (o + c) % 7 - (s + c) % 7;
  return dn(i, u, n);
}
class FE extends Ke {
  priority = 90;
  parse(e, n, r) {
    switch (n) {
      case "E":
      case "EE":
      case "EEE":
        return r.day(e, { width: "abbreviated", context: "formatting" }) || r.day(e, { width: "short", context: "formatting" }) || r.day(e, { width: "narrow", context: "formatting" });
      case "EEEEE":
        return r.day(e, { width: "narrow", context: "formatting" });
      case "EEEEEE":
        return r.day(e, { width: "short", context: "formatting" }) || r.day(e, { width: "narrow", context: "formatting" });
      case "EEEE":
      default:
        return r.day(e, { width: "wide", context: "formatting" }) || r.day(e, { width: "abbreviated", context: "formatting" }) || r.day(e, { width: "short", context: "formatting" }) || r.day(e, { width: "narrow", context: "formatting" });
    }
  }
  validate(e, n) {
    return n >= 0 && n <= 6;
  }
  set(e, n, r, a) {
    return e = xs(e, r, a), e.setHours(0, 0, 0, 0), e;
  }
  incompatibleTokens = ["D", "i", "e", "c", "t", "T"];
}
class yE extends Ke {
  priority = 90;
  parse(e, n, r, a) {
    const i = (s) => {
      const l = Math.floor((s - 1) / 7) * 7;
      return (s + a.weekStartsOn + 6) % 7 + l;
    };
    switch (n) {
      case "e":
      case "ee":
        return Nt(Et(n.length, e), i);
      case "eo":
        return Nt(r.ordinalNumber(e, { unit: "day" }), i);
      case "eee":
        return r.day(e, { width: "abbreviated", context: "formatting" }) || r.day(e, { width: "short", context: "formatting" }) || r.day(e, { width: "narrow", context: "formatting" });
      case "eeeee":
        return r.day(e, { width: "narrow", context: "formatting" });
      case "eeeeee":
        return r.day(e, { width: "short", context: "formatting" }) || r.day(e, { width: "narrow", context: "formatting" });
      case "eeee":
      default:
        return r.day(e, { width: "wide", context: "formatting" }) || r.day(e, { width: "abbreviated", context: "formatting" }) || r.day(e, { width: "short", context: "formatting" }) || r.day(e, { width: "narrow", context: "formatting" });
    }
  }
  validate(e, n) {
    return n >= 0 && n <= 6;
  }
  set(e, n, r, a) {
    return e = xs(e, r, a), e.setHours(0, 0, 0, 0), e;
  }
  incompatibleTokens = ["y", "R", "u", "q", "Q", "M", "L", "I", "d", "D", "E", "i", "c", "t", "T"];
}
class OE extends Ke {
  priority = 90;
  parse(e, n, r, a) {
    const i = (s) => {
      const l = Math.floor((s - 1) / 7) * 7;
      return (s + a.weekStartsOn + 6) % 7 + l;
    };
    switch (n) {
      case "c":
      case "cc":
        return Nt(Et(n.length, e), i);
      case "co":
        return Nt(r.ordinalNumber(e, { unit: "day" }), i);
      case "ccc":
        return r.day(e, { width: "abbreviated", context: "standalone" }) || r.day(e, { width: "short", context: "standalone" }) || r.day(e, { width: "narrow", context: "standalone" });
      case "ccccc":
        return r.day(e, { width: "narrow", context: "standalone" });
      case "cccccc":
        return r.day(e, { width: "short", context: "standalone" }) || r.day(e, { width: "narrow", context: "standalone" });
      case "cccc":
      default:
        return r.day(e, { width: "wide", context: "standalone" }) || r.day(e, { width: "abbreviated", context: "standalone" }) || r.day(e, { width: "short", context: "standalone" }) || r.day(e, { width: "narrow", context: "standalone" });
    }
  }
  validate(e, n) {
    return n >= 0 && n <= 6;
  }
  set(e, n, r, a) {
    return e = xs(e, r, a), e.setHours(0, 0, 0, 0), e;
  }
  incompatibleTokens = ["y", "R", "u", "q", "Q", "M", "L", "I", "d", "D", "E", "i", "e", "t", "T"];
}
function ME(t, e, n) {
  const r = Ie(t, n?.in), a = nE(r, n), i = e - a;
  return dn(r, i, n);
}
class bE extends Ke {
  priority = 90;
  parse(e, n, r) {
    const a = (i) => i === 0 ? 7 : i;
    switch (n) {
      case "i":
      case "ii":
        return Et(n.length, e);
      case "io":
        return r.ordinalNumber(e, { unit: "day" });
      case "iii":
        return Nt(r.day(e, { width: "abbreviated", context: "formatting" }) || r.day(e, { width: "short", context: "formatting" }) || r.day(e, { width: "narrow", context: "formatting" }), a);
      case "iiiii":
        return Nt(r.day(e, { width: "narrow", context: "formatting" }), a);
      case "iiiiii":
        return Nt(r.day(e, { width: "short", context: "formatting" }) || r.day(e, { width: "narrow", context: "formatting" }), a);
      case "iiii":
      default:
        return Nt(r.day(e, { width: "wide", context: "formatting" }) || r.day(e, { width: "abbreviated", context: "formatting" }) || r.day(e, { width: "short", context: "formatting" }) || r.day(e, { width: "narrow", context: "formatting" }), a);
    }
  }
  validate(e, n) {
    return n >= 1 && n <= 7;
  }
  set(e, n, r) {
    return e = ME(e, r), e.setHours(0, 0, 0, 0), e;
  }
  incompatibleTokens = ["y", "Y", "u", "q", "Q", "M", "L", "w", "d", "D", "E", "e", "c", "t", "T"];
}
class YE extends Ke {
  priority = 80;
  parse(e, n, r) {
    switch (n) {
      case "a":
      case "aa":
      case "aaa":
        return r.dayPeriod(e, { width: "abbreviated", context: "formatting" }) || r.dayPeriod(e, { width: "narrow", context: "formatting" });
      case "aaaaa":
        return r.dayPeriod(e, { width: "narrow", context: "formatting" });
      case "aaaa":
      default:
        return r.dayPeriod(e, { width: "wide", context: "formatting" }) || r.dayPeriod(e, { width: "abbreviated", context: "formatting" }) || r.dayPeriod(e, { width: "narrow", context: "formatting" });
    }
  }
  set(e, n, r) {
    return e.setHours(Cs(r), 0, 0, 0), e;
  }
  incompatibleTokens = ["b", "B", "H", "k", "t", "T"];
}
class wE extends Ke {
  priority = 80;
  parse(e, n, r) {
    switch (n) {
      case "b":
      case "bb":
      case "bbb":
        return r.dayPeriod(e, { width: "abbreviated", context: "formatting" }) || r.dayPeriod(e, { width: "narrow", context: "formatting" });
      case "bbbbb":
        return r.dayPeriod(e, { width: "narrow", context: "formatting" });
      case "bbbb":
      default:
        return r.dayPeriod(e, { width: "wide", context: "formatting" }) || r.dayPeriod(e, { width: "abbreviated", context: "formatting" }) || r.dayPeriod(e, { width: "narrow", context: "formatting" });
    }
  }
  set(e, n, r) {
    return e.setHours(Cs(r), 0, 0, 0), e;
  }
  incompatibleTokens = ["a", "B", "H", "k", "t", "T"];
}
class _E extends Ke {
  priority = 80;
  parse(e, n, r) {
    switch (n) {
      case "B":
      case "BB":
      case "BBB":
        return r.dayPeriod(e, { width: "abbreviated", context: "formatting" }) || r.dayPeriod(e, { width: "narrow", context: "formatting" });
      case "BBBBB":
        return r.dayPeriod(e, { width: "narrow", context: "formatting" });
      case "BBBB":
      default:
        return r.dayPeriod(e, { width: "wide", context: "formatting" }) || r.dayPeriod(e, { width: "abbreviated", context: "formatting" }) || r.dayPeriod(e, { width: "narrow", context: "formatting" });
    }
  }
  set(e, n, r) {
    return e.setHours(Cs(r), 0, 0, 0), e;
  }
  incompatibleTokens = ["a", "b", "t", "T"];
}
class BE extends Ke {
  priority = 70;
  parse(e, n, r) {
    switch (n) {
      case "h":
        return ft(Rt.hour12h, e);
      case "ho":
        return r.ordinalNumber(e, { unit: "hour" });
      default:
        return Et(n.length, e);
    }
  }
  validate(e, n) {
    return n >= 1 && n <= 12;
  }
  set(e, n, r) {
    const a = e.getHours() >= 12;
    return a && r < 12 ? e.setHours(r + 12, 0, 0, 0) : !a && r === 12 ? e.setHours(0, 0, 0, 0) : e.setHours(r, 0, 0, 0), e;
  }
  incompatibleTokens = ["H", "K", "k", "t", "T"];
}
class ZE extends Ke {
  priority = 70;
  parse(e, n, r) {
    switch (n) {
      case "H":
        return ft(Rt.hour23h, e);
      case "Ho":
        return r.ordinalNumber(e, { unit: "hour" });
      default:
        return Et(n.length, e);
    }
  }
  validate(e, n) {
    return n >= 0 && n <= 23;
  }
  set(e, n, r) {
    return e.setHours(r, 0, 0, 0), e;
  }
  incompatibleTokens = ["a", "b", "h", "K", "k", "t", "T"];
}
class IE extends Ke {
  priority = 70;
  parse(e, n, r) {
    switch (n) {
      case "K":
        return ft(Rt.hour11h, e);
      case "Ko":
        return r.ordinalNumber(e, { unit: "hour" });
      default:
        return Et(n.length, e);
    }
  }
  validate(e, n) {
    return n >= 0 && n <= 11;
  }
  set(e, n, r) {
    return e.getHours() >= 12 && r < 12 ? e.setHours(r + 12, 0, 0, 0) : e.setHours(r, 0, 0, 0), e;
  }
  incompatibleTokens = ["h", "H", "k", "t", "T"];
}
class LE extends Ke {
  priority = 70;
  parse(e, n, r) {
    switch (n) {
      case "k":
        return ft(Rt.hour24h, e);
      case "ko":
        return r.ordinalNumber(e, { unit: "hour" });
      default:
        return Et(n.length, e);
    }
  }
  validate(e, n) {
    return n >= 1 && n <= 24;
  }
  set(e, n, r) {
    const a = r <= 24 ? r % 24 : r;
    return e.setHours(a, 0, 0, 0), e;
  }
  incompatibleTokens = ["a", "b", "h", "H", "K", "t", "T"];
}
class kE extends Ke {
  priority = 60;
  parse(e, n, r) {
    switch (n) {
      case "m":
        return ft(Rt.minute, e);
      case "mo":
        return r.ordinalNumber(e, { unit: "minute" });
      default:
        return Et(n.length, e);
    }
  }
  validate(e, n) {
    return n >= 0 && n <= 59;
  }
  set(e, n, r) {
    return e.setMinutes(r, 0, 0), e;
  }
  incompatibleTokens = ["t", "T"];
}
class CE extends Ke {
  priority = 50;
  parse(e, n, r) {
    switch (n) {
      case "s":
        return ft(Rt.second, e);
      case "so":
        return r.ordinalNumber(e, { unit: "second" });
      default:
        return Et(n.length, e);
    }
  }
  validate(e, n) {
    return n >= 0 && n <= 59;
  }
  set(e, n, r) {
    return e.setSeconds(r, 0), e;
  }
  incompatibleTokens = ["t", "T"];
}
class xE extends Ke {
  priority = 30;
  parse(e, n) {
    const r = (a) => Math.trunc(a * Math.pow(10, -n.length + 3));
    return Nt(Et(n.length, e), r);
  }
  set(e, n, r) {
    return e.setMilliseconds(r), e;
  }
  incompatibleTokens = ["t", "T"];
}
class HE extends Ke {
  priority = 10;
  parse(e, n) {
    switch (n) {
      case "X":
        return wn(Yn.basicOptionalMinutes, e);
      case "XX":
        return wn(Yn.basic, e);
      case "XXXX":
        return wn(Yn.basicOptionalSeconds, e);
      case "XXXXX":
        return wn(Yn.extendedOptionalSeconds, e);
      case "XXX":
      default:
        return wn(Yn.extended, e);
    }
  }
  set(e, n, r) {
    return n.timestampIsSet ? e : et(e, e.getTime() - Ri(e) - r);
  }
  incompatibleTokens = ["t", "T", "x"];
}
class PE extends Ke {
  priority = 10;
  parse(e, n) {
    switch (n) {
      case "x":
        return wn(Yn.basicOptionalMinutes, e);
      case "xx":
        return wn(Yn.basic, e);
      case "xxxx":
        return wn(Yn.basicOptionalSeconds, e);
      case "xxxxx":
        return wn(Yn.extendedOptionalSeconds, e);
      case "xxx":
      default:
        return wn(Yn.extended, e);
    }
  }
  set(e, n, r) {
    return n.timestampIsSet ? e : et(e, e.getTime() - Ri(e) - r);
  }
  incompatibleTokens = ["t", "T", "X"];
}
class UE extends Ke {
  priority = 40;
  parse(e) {
    return Tl(e);
  }
  set(e, n, r) {
    return [et(e, r * 1e3), { timestampIsSet: true }];
  }
  incompatibleTokens = "*";
}
class GE extends Ke {
  priority = 20;
  parse(e) {
    return Tl(e);
  }
  set(e, n, r) {
    return [et(e, r), { timestampIsSet: true }];
  }
  incompatibleTokens = "*";
}
const zE = { G: new lE(), y: new uE(), Y: new cE(), R: new TE(), u: new dE(), Q: new hE(), q: new fE(), M: new AE(), L: new mE(), w: new pE(), I: new SE(), d: new RE(), D: new NE(), E: new FE(), e: new yE(), c: new OE(), i: new bE(), a: new YE(), b: new wE(), B: new _E(), h: new BE(), H: new ZE(), K: new IE(), k: new LE(), m: new kE(), s: new CE(), S: new xE(), X: new HE(), x: new PE(), t: new UE(), T: new GE() }, jE = /[yYQqMLwIdDecihHKkms]o|(\w)\1*|''|'(''|[^'])+('|$)|./g, $E = /P+p+|P+|p+|''|'(''|[^'])+('|$)|./g, VE = /^'([^]*?)'?$/, QE = /''/g, WE = /\S/, qE = /[a-zA-Z]/;
function Hs(t, e, n, r) {
  const a = () => et(r?.in || n, NaN), i = tE(), s = r?.locale ?? i.locale ?? nl, l = r?.firstWeekContainsDate ?? r?.locale?.options?.firstWeekContainsDate ?? i.firstWeekContainsDate ?? i.locale?.options?.firstWeekContainsDate ?? 1, o = r?.weekStartsOn ?? r?.locale?.options?.weekStartsOn ?? i.weekStartsOn ?? i.locale?.options?.weekStartsOn ?? 0;
  if (!e) return t ? a() : Ie(n, r?.in);
  const c = { firstWeekContainsDate: l, weekStartsOn: o, locale: s }, u = [new oE(r?.in, n)], T = e.match($E).map((A) => {
    const g = A[0];
    if (g in Ls) {
      const O = Ls[g];
      return O(A, s.formatLong);
    }
    return A;
  }).join("").match(jE), f = [];
  for (let A of T) {
    !r?.useAdditionalWeekYearTokens && ul(A) && ks(A, e, t), !r?.useAdditionalDayOfYearTokens && ll(A) && ks(A, e, t);
    const g = A[0], O = zE[g];
    if (O) {
      const { incompatibleTokens: D } = O;
      if (Array.isArray(D)) {
        const L = f.find((_) => D.includes(_.token) || _.token === g);
        if (L) throw new RangeError(`The format string mustn't contain \`${L.fullToken}\` and \`${A}\` at the same time`);
      } else if (O.incompatibleTokens === "*" && f.length > 0) throw new RangeError(`The format string mustn't contain \`${A}\` and any other token at the same time`);
      f.push({ token: g, fullToken: A });
      const w = O.run(t, A, s.match, c);
      if (!w) return a();
      u.push(w.setter), t = w.rest;
    } else {
      if (g.match(qE)) throw new RangeError("Format string contains an unescaped latin alphabet character `" + g + "`");
      if (A === "''" ? A = "'" : g === "'" && (A = KE(A)), t.indexOf(A) === 0) t = t.slice(A.length);
      else return a();
    }
  }
  if (t.length > 0 && WE.test(t)) return a();
  const m = u.map((A) => A.priority).sort((A, g) => g - A).filter((A, g, O) => O.indexOf(A) === g).map((A) => u.filter((g) => g.priority === A).sort((g, O) => O.subPriority - g.subPriority)).map((A) => A[0]);
  let v = Ie(n, r?.in);
  if (isNaN(+v)) return a();
  const E = {};
  for (const A of m) {
    if (!A.validate(v, c)) return a();
    const g = A.set(v, E, c);
    Array.isArray(g) ? (v = g[0], Object.assign(E, g[1])) : v = g;
  }
  return v;
}
function KE(t) {
  return t.match(VE)[1].replace(QE, "'");
}
function fl(t, e, n) {
  const [r, a] = ma(n?.in, t, e);
  return +Nr(r) == +Nr(a);
}
function Al(t, e, n) {
  return dn(t, -e, n);
}
function ml(t, e, n) {
  const r = Ie(t, n?.in), a = r.getFullYear(), i = r.getDate(), s = et(t, 0);
  s.setFullYear(a, e, 15), s.setHours(0, 0, 0, 0);
  const l = eE(s);
  return r.setMonth(e, Math.min(i, l)), r;
}
function it(t, e, n) {
  let r = Ie(t, n?.in);
  return isNaN(+r) ? et(t, NaN) : (e.year != null && r.setFullYear(e.year), e.month != null && (r = ml(r, e.month)), e.date != null && r.setDate(e.date), e.hours != null && r.setHours(e.hours), e.minutes != null && r.setMinutes(e.minutes), e.seconds != null && r.setSeconds(e.seconds), e.milliseconds != null && r.setMilliseconds(e.milliseconds), r);
}
function JE(t, e, n) {
  const r = Ie(t, n?.in);
  return r.setHours(e), r;
}
function El(t, e, n) {
  const r = Ie(t, n?.in);
  return r.setMilliseconds(e), r;
}
function XE(t, e, n) {
  const r = Ie(t, n?.in);
  return r.setMinutes(e), r;
}
function pl(t, e, n) {
  const r = Ie(t, n?.in);
  return r.setSeconds(e), r;
}
function _n(t, e, n) {
  const r = Ie(t, n?.in);
  return isNaN(+r) ? et(t, NaN) : (r.setFullYear(e), r);
}
function $r(t, e, n) {
  return Dn(t, -e, n);
}
function ep(t, e, n) {
  const { years: r = 0, months: a = 0, weeks: i = 0, days: s = 0, hours: l = 0, minutes: o = 0, seconds: c = 0 } = e, u = $r(t, a + r * 12, n), T = Al(u, s + i * 7, n), f = o + l * 60, v = (c + f * 60) * 1e3;
  return et(t, +T - v);
}
function Dl(t, e, n) {
  return ws(t, -e, n);
}
function Vr() {
  const t = wc();
  return p(), M("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 32 32", fill: "currentColor", "aria-hidden": "true", class: "dp__icon", role: "img", ...t }, [j("path", { d: "M29.333 8c0-2.208-1.792-4-4-4h-18.667c-2.208 0-4 1.792-4 4v18.667c0 2.208 1.792 4 4 4h18.667c2.208 0 4-1.792 4-4v-18.667zM26.667 8v18.667c0 0.736-0.597 1.333-1.333 1.333 0 0-18.667 0-18.667 0-0.736 0-1.333-0.597-1.333-1.333 0 0 0-18.667 0-18.667 0-0.736 0.597-1.333 1.333-1.333 0 0 18.667 0 18.667 0 0.736 0 1.333 0.597 1.333 1.333z" }), j("path", { d: "M20 2.667v5.333c0 0.736 0.597 1.333 1.333 1.333s1.333-0.597 1.333-1.333v-5.333c0-0.736-0.597-1.333-1.333-1.333s-1.333 0.597-1.333 1.333z" }), j("path", { d: "M9.333 2.667v5.333c0 0.736 0.597 1.333 1.333 1.333s1.333-0.597 1.333-1.333v-5.333c0-0.736-0.597-1.333-1.333-1.333s-1.333 0.597-1.333 1.333z" }), j("path", { d: "M4 14.667h24c0.736 0 1.333-0.597 1.333-1.333s-0.597-1.333-1.333-1.333h-24c-0.736 0-1.333 0.597-1.333 1.333s0.597 1.333 1.333 1.333z" })]);
}
Vr.compatConfig = { MODE: 3 };
function Sl() {
  return p(), M("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 32 32", fill: "currentColor", "aria-hidden": "true", class: "dp__icon", role: "img" }, [j("path", { d: "M23.057 7.057l-16 16c-0.52 0.52-0.52 1.365 0 1.885s1.365 0.52 1.885 0l16-16c0.52-0.52 0.52-1.365 0-1.885s-1.365-0.52-1.885 0z" }), j("path", { d: "M7.057 8.943l16 16c0.52 0.52 1.365 0.52 1.885 0s0.52-1.365 0-1.885l-16-16c-0.52-0.52-1.365-0.52-1.885 0s-0.52 1.365 0 1.885z" })]);
}
Sl.compatConfig = { MODE: 3 };
function Ps() {
  return p(), M("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 32 32", fill: "currentColor", "aria-hidden": "true", class: "dp__icon", role: "img" }, [j("path", { d: "M20.943 23.057l-7.057-7.057c0 0 7.057-7.057 7.057-7.057 0.52-0.52 0.52-1.365 0-1.885s-1.365-0.52-1.885 0l-8 8c-0.521 0.521-0.521 1.365 0 1.885l8 8c0.52 0.52 1.365 0.52 1.885 0s0.52-1.365 0-1.885z" })]);
}
Ps.compatConfig = { MODE: 3 };
function Us() {
  return p(), M("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 32 32", fill: "currentColor", "aria-hidden": "true", class: "dp__icon", role: "img" }, [j("path", { d: "M12.943 24.943l8-8c0.521-0.521 0.521-1.365 0-1.885l-8-8c-0.52-0.52-1.365-0.52-1.885 0s-0.52 1.365 0 1.885l7.057 7.057c0 0-7.057 7.057-7.057 7.057-0.52 0.52-0.52 1.365 0 1.885s1.365 0.52 1.885 0z" })]);
}
Us.compatConfig = { MODE: 3 };
function Gs() {
  return p(), M("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 32 32", fill: "currentColor", "aria-hidden": "true", class: "dp__icon", role: "img" }, [j("path", { d: "M16 1.333c-8.095 0-14.667 6.572-14.667 14.667s6.572 14.667 14.667 14.667c8.095 0 14.667-6.572 14.667-14.667s-6.572-14.667-14.667-14.667zM16 4c6.623 0 12 5.377 12 12s-5.377 12-12 12c-6.623 0-12-5.377-12-12s5.377-12 12-12z" }), j("path", { d: "M14.667 8v8c0 0.505 0.285 0.967 0.737 1.193l5.333 2.667c0.658 0.329 1.46 0.062 1.789-0.596s0.062-1.46-0.596-1.789l-4.596-2.298c0 0 0-7.176 0-7.176 0-0.736-0.597-1.333-1.333-1.333s-1.333 0.597-1.333 1.333z" })]);
}
Gs.compatConfig = { MODE: 3 };
function zs() {
  return p(), M("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 32 32", fill: "currentColor", "aria-hidden": "true", class: "dp__icon", role: "img" }, [j("path", { d: "M24.943 19.057l-8-8c-0.521-0.521-1.365-0.521-1.885 0l-8 8c-0.52 0.52-0.52 1.365 0 1.885s1.365 0.52 1.885 0l7.057-7.057c0 0 7.057 7.057 7.057 7.057 0.52 0.52 1.365 0.52 1.885 0s0.52-1.365 0-1.885z" })]);
}
zs.compatConfig = { MODE: 3 };
function js() {
  return p(), M("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 32 32", fill: "currentColor", "aria-hidden": "true", class: "dp__icon", role: "img" }, [j("path", { d: "M7.057 12.943l8 8c0.521 0.521 1.365 0.521 1.885 0l8-8c0.52-0.52 0.52-1.365 0-1.885s-1.365-0.52-1.885 0l-7.057 7.057c0 0-7.057-7.057-7.057-7.057-0.52-0.52-1.365-0.52-1.885 0s-0.52 1.365 0 1.885z" })]);
}
js.compatConfig = { MODE: 3 };
const Xt = (t, e) => e ? new Date(t.toLocaleString("en-US", { timeZone: e })) : new Date(t), $s = (t, e, n) => Vs(t, e, n) || de(), tp = (t, e, n) => {
  const r = e.dateInTz ? Xt(new Date(t), e.dateInTz) : de(t);
  return n ? It(r, true) : r;
}, Vs = (t, e, n) => {
  if (!t) return null;
  const r = n ? It(de(t), true) : de(t);
  return e ? e.exactMatch ? tp(t, e, n) : Xt(r, e.timezone) : r;
}, np = (t) => {
  const e = new Date(t.getFullYear(), 0, 1).getTimezoneOffset();
  return t.getTimezoneOffset() < e;
}, rp = (t, e) => {
  if (!t) return 0;
  const n = /* @__PURE__ */ new Date(), r = new Date(n.toLocaleString("en-US", { timeZone: "UTC" })), a = new Date(n.toLocaleString("en-US", { timeZone: t })), i = (np(e ?? a) ? a : e ?? a).getTimezoneOffset() / 60;
  return (+r - +a) / (1e3 * 60 * 60) - i;
};
var vn = ((t) => (t.month = "month", t.year = "year", t))(vn || {}), gn = ((t) => (t.top = "top", t.bottom = "bottom", t))(gn || {}), Or = ((t) => (t.header = "header", t.calendar = "calendar", t.timePicker = "timePicker", t))(Or || {}), Pt = ((t) => (t.month = "month", t.year = "year", t.calendar = "calendar", t.time = "time", t.minutes = "minutes", t.hours = "hours", t.seconds = "seconds", t))(Pt || {});
const ap = ["timestamp", "date", "iso"];
var Vt = ((t) => (t.up = "up", t.down = "down", t.left = "left", t.right = "right", t))(Vt || {}), ut = ((t) => (t.arrowUp = "ArrowUp", t.arrowDown = "ArrowDown", t.arrowLeft = "ArrowLeft", t.arrowRight = "ArrowRight", t.enter = "Enter", t.space = " ", t.esc = "Escape", t.tab = "Tab", t.home = "Home", t.end = "End", t.pageUp = "PageUp", t.pageDown = "PageDown", t))(ut || {}), Qr = ((t) => (t.MONTH_AND_YEAR = "MM-yyyy", t.YEAR = "yyyy", t.DATE = "dd-MM-yyyy", t))(Qr || {});
function vl(t) {
  return (e) => {
    const n = new Intl.DateTimeFormat(t, { weekday: "short", timeZone: "UTC" }).format(/* @__PURE__ */ new Date(`2017-01-0${e}T00:00:00+00:00`));
    return t === "ar" ? n.slice(2, 5) : n.slice(0, 2);
  };
}
function ip(t) {
  return (e) => bn(Xt(/* @__PURE__ */ new Date(`2017-01-0${e}T00:00:00+00:00`), "UTC"), "EEEEEE", { locale: t });
}
const sp = (t, e, n) => {
  const r = [1, 2, 3, 4, 5, 6, 7];
  let a;
  if (t !== null) try {
    a = r.map(ip(t));
  } catch {
    a = r.map(vl(e));
  }
  else a = r.map(vl(e));
  const i = a.slice(0, n), s = a.slice(n + 1, a.length);
  return [a[n]].concat(...s).concat(...i);
}, Qs = (t, e, n) => {
  const r = [];
  for (let a = +t[0]; a <= +t[1]; a++) r.push({ value: +a, text: Ol(a, e) });
  return n ? r.reverse() : r;
}, gl = (t, e, n) => {
  const r = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((i) => {
    const s = i < 10 ? `0${i}` : i;
    return /* @__PURE__ */ new Date(`2017-${s}-01T00:00:00+00:00`);
  });
  if (t !== null) try {
    const i = n === "long" ? "LLLL" : "LLL";
    return r.map((s, l) => {
      const o = bn(Xt(s, "UTC"), i, { locale: t });
      return { text: o.charAt(0).toUpperCase() + o.substring(1), value: l };
    });
  } catch {
  }
  const a = new Intl.DateTimeFormat(e, { month: n, timeZone: "UTC" });
  return r.map((i, s) => {
    const l = a.format(i);
    return { text: l.charAt(0).toUpperCase() + l.substring(1), value: s };
  });
}, op = (t) => [12, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11][t], Yt = (t) => {
  const e = S(t);
  return e != null && e.$el ? e?.$el : e;
}, lp = (t) => ({ type: "dot", ...t ?? {} }), Rl = (t) => Array.isArray(t) ? !!t[0] && !!t[1] : false, Ws = { prop: (t) => `"${t}" prop must be enabled!`, dateArr: (t) => `You need to use array as "model-value" binding in order to support "${t}"` }, Zt = (t) => t, Nl = (t) => t === 0 ? t : !t || isNaN(+t) ? null : +t, Fl = (t) => t === null, yl = (t) => {
  if (t) return [...t.querySelectorAll("input, button, select, textarea, a[href]")][0];
}, up = (t) => {
  const e = [], n = (r) => r.filter((a) => a);
  for (let r = 0; r < t.length; r += 3) {
    const a = [t[r], t[r + 1], t[r + 2]];
    e.push(n(a));
  }
  return e;
}, va = (t, e, n) => {
  const r = n != null, a = e != null;
  if (!r && !a) return false;
  const i = +n, s = +e;
  return r && a ? +t > i || +t < s : r ? +t > i : a ? +t < s : false;
}, Wr = (t, e) => up(t).map((n) => n.map((r) => {
  const { active: a, disabled: i, isBetween: s, highlighted: l } = e(r);
  return { ...r, active: a, disabled: i, className: { dp__overlay_cell_active: a, dp__overlay_cell: !a, dp__overlay_cell_disabled: i, dp__overlay_cell_pad: true, dp__overlay_cell_active_disabled: i && a, dp__cell_in_between: s, "dp--highlighted": l } };
})), ar = (t, e, n = false) => {
  t && e.allowStopPropagation && (n && t.stopImmediatePropagation(), t.stopPropagation());
}, cp = () => ["a[href]", "area[href]", "input:not([disabled]):not([type='hidden'])", "select:not([disabled])", "textarea:not([disabled])", "button:not([disabled])", "[tabindex]:not([tabindex='-1'])", "[data-datepicker-instance]"].join(", ");
function Tp(t, e) {
  let n = [...document.querySelectorAll(cp())];
  n = n.filter((a) => !t.contains(a) || a.hasAttribute("data-datepicker-instance"));
  const r = n.indexOf(t);
  if (r >= 0 && (e ? r - 1 >= 0 : r + 1 <= n.length)) return n[r + (e ? -1 : 1)];
}
const qs = (t, e) => t?.querySelector(`[data-dp-element="${e}"]`), Ol = (t, e) => new Intl.NumberFormat(e, { useGrouping: false, style: "decimal" }).format(t), Ks = (t, e) => bn(t, e ?? Qr.DATE), Js = (t) => Array.isArray(t), Fi = (t, e, n) => e.get(Ks(t, n)), dp = (t, e) => t ? e ? e instanceof Map ? !!Fi(t, e) : e(de(t)) : false : true, Qt = (t, e, n = false, r) => {
  if (t.key === ut.enter || t.key === ut.space) return n && t.preventDefault(), e();
  if (r) return r(t);
}, hp = () => "ontouchstart" in window || navigator.maxTouchPoints > 0, Ml = (t, e) => t ? Qr.MONTH_AND_YEAR : e ? Qr.YEAR : Qr.DATE, bl = (t) => t < 10 ? `0${t}` : t, Yl = (t, e, n, r, a, i) => {
  const s = Hs(t, e.slice(0, t.length), /* @__PURE__ */ new Date(), { locale: i });
  return Ea(s) && W0(s) ? r || a ? s : it(s, { hours: +n.hours, minutes: +n?.minutes, seconds: +n?.seconds, milliseconds: 0 }) : null;
}, fp = (t, e, n, r, a, i) => {
  const s = Array.isArray(n) ? n[0] : n;
  if (typeof e == "string") return Yl(t, e, s, r, a, i);
  if (Array.isArray(e)) {
    let l = null;
    for (const o of e) if (l = Yl(t, o, s, r, a, i), l) break;
    return l;
  }
  return typeof e == "function" ? e(t) : null;
}, de = (t) => t ? new Date(t) : /* @__PURE__ */ new Date(), Ap = (t, e, n) => {
  if (e) {
    const a = (t.getMonth() + 1).toString().padStart(2, "0"), i = t.getDate().toString().padStart(2, "0"), s = t.getHours().toString().padStart(2, "0"), l = t.getMinutes().toString().padStart(2, "0"), o = n ? t.getSeconds().toString().padStart(2, "0") : "00";
    return `${t.getFullYear()}-${a}-${i}T${s}:${l}:${o}.000Z`;
  }
  const r = Date.UTC(t.getUTCFullYear(), t.getUTCMonth(), t.getUTCDate(), t.getUTCHours(), t.getUTCMinutes(), t.getUTCSeconds());
  return new Date(r).toISOString();
}, It = (t, e) => {
  const n = de(JSON.parse(JSON.stringify(t))), r = it(n, { hours: 0, minutes: 0, seconds: 0, milliseconds: 0 });
  return e ? om(r) : r;
}, ir = (t, e, n, r) => {
  let a = t ? de(t) : de();
  return (e || e === 0) && (a = JE(a, +e)), (n || n === 0) && (a = XE(a, +n)), (r || r === 0) && (a = pl(a, +r)), El(a, 0);
}, pt = (t, e) => !t || !e ? false : zr(It(t), It(e)), $e = (t, e) => !t || !e ? false : jr(It(t), It(e)), Ft = (t, e) => !t || !e ? false : yr(It(t), It(e)), ga = (t, e, n) => t != null && t[0] && t != null && t[1] ? Ft(n, t[0]) && pt(n, t[1]) : t != null && t[0] && e ? Ft(n, t[0]) && pt(n, e) || pt(n, t[0]) && Ft(n, e) : false, Rn = (t) => {
  const e = it(new Date(t), { date: 1 });
  return It(e);
}, Xs = (t, e, n) => e && (n || n === 0) ? Object.fromEntries(["hours", "minutes", "seconds"].map((r) => r === e ? [r, n] : [r, isNaN(+t[r]) ? void 0 : +t[r]])) : { hours: isNaN(+t.hours) ? void 0 : +t.hours, minutes: isNaN(+t.minutes) ? void 0 : +t.minutes, seconds: isNaN(+t.seconds) ? void 0 : +t.seconds }, Mr = (t) => ({ hours: Gn(t), minutes: rr(t), seconds: Gr(t) }), wl = (t, e) => {
  if (e) {
    const n = xe(de(e));
    if (n > t) return 12;
    if (n === t) return je(de(e));
  }
}, _l = (t, e) => {
  if (e) {
    const n = xe(de(e));
    return n < t ? -1 : n === t ? je(de(e)) : void 0;
  }
}, qr = (t) => {
  if (t) return xe(de(t));
}, Bl = (t, e) => {
  const n = Ft(t, e) ? e : t, r = Ft(e, t) ? e : t;
  return J0({ start: n, end: r });
}, mp = (t) => {
  const e = Dn(t, 1);
  return { month: je(e), year: xe(e) };
}, zn = (t, e) => {
  const n = Sn(t, { weekStartsOn: +e }), r = el(t, { weekStartsOn: +e });
  return [n, r];
}, Zl = (t, e) => {
  const n = { hours: Gn(de()), minutes: rr(de()), seconds: e ? Gr(de()) : 0 };
  return Object.assign(n, t);
}, sr = (t, e, n) => [it(de(t), { date: 1 }), it(de(), { month: e, year: n, date: 1 })], jn = (t, e, n) => {
  let r = t ? de(t) : de();
  return (e || e === 0) && (r = ml(r, e)), n && (r = _n(r, n)), r;
}, Il = (t, e, n, r, a) => {
  if (!r || a && !e || !a && !n) return false;
  const i = a ? Dn(t, 1) : $r(t, 1), s = [je(i), xe(i)];
  return a ? !pp(...s, e) : !Ep(...s, n);
}, Ep = (t, e, n) => pt(...sr(n, t, e)) || $e(...sr(n, t, e)), pp = (t, e, n) => Ft(...sr(n, t, e)) || $e(...sr(n, t, e)), Ll = (t, e, n, r, a, i, s) => {
  if (typeof e == "function" && !s) return e(t);
  const l = n ? { locale: n } : void 0;
  return Array.isArray(t) ? `${bn(t[0], i, l)}${a && !t[1] ? "" : r}${t[1] ? bn(t[1], i, l) : ""}` : bn(t, i, l);
}, Kr = (t) => {
  if (t) return null;
  throw new Error(Ws.prop("partial-range"));
}, yi = (t, e) => {
  if (e) return t();
  throw new Error(Ws.prop("range"));
}, eo = (t) => Array.isArray(t) ? Ea(t[0]) && (t[1] ? Ea(t[1]) : true) : t ? Ea(t) : false, Dp = (t, e) => it(e ?? de(), { hours: +t.hours || 0, minutes: +t.minutes || 0, seconds: +t.seconds || 0 }), to = (t, e, n, r) => {
  if (!t) return true;
  if (r) {
    const a = n === "max" ? zr(t, e) : yr(t, e), i = { seconds: 0, milliseconds: 0 };
    return a || jr(it(t, i), it(e, i));
  }
  return n === "max" ? t.getTime() <= e.getTime() : t.getTime() >= e.getTime();
}, no = (t, e, n) => t ? Dp(t, e) : de(n ?? e), kl = (t, e, n, r, a) => {
  if (Array.isArray(r)) {
    const s = no(t, r[0], e), l = no(t, r[1], e);
    return to(r[0], s, n, !!e) && to(r[1], l, n, !!e) && a;
  }
  const i = no(t, r, e);
  return to(r, i, n, !!e) && a;
}, ro = (t) => it(de(), Mr(t)), Sp = (t, e, n) => {
  if (t instanceof Map) {
    const r = `${bl(n + 1)}-${e}`;
    return t.size ? t.has(r) : false;
  }
  return typeof t == "function" ? t(It(it(de(), { month: n, year: e }), true)) : false;
}, vp = (t, e, n) => {
  if (t instanceof Map) {
    const r = `${bl(n + 1)}-${e}`;
    return t.size ? t.has(r) : true;
  }
  return true;
}, Cl = (t, e, n) => typeof t == "function" ? t({ month: e, year: n }) : !!t.months.find((r) => r.month === e && r.year === n), ao = (t, e) => typeof t == "function" ? t(e) : t.years.includes(e), io = (t) => `dp-${bn(t, "yyyy-MM-dd")}`, xl = (t, e) => {
  const n = Al(It(e), t), r = dn(It(e), t);
  return { before: n, after: r };
}, Ra = na({ menuFocused: false, shiftKeyInMenu: false }), Hl = () => {
  const t = (n) => {
    Ra.menuFocused = n;
  }, e = (n) => {
    Ra.shiftKeyInMenu !== n && (Ra.shiftKeyInMenu = n);
  };
  return { control: Q(() => ({ shiftKeyInMenu: Ra.shiftKeyInMenu, menuFocused: Ra.menuFocused })), setMenuFocused: t, setShiftKey: e };
}, ct = na({ monthYear: [], calendar: [], time: [], actionRow: [], selectionGrid: [], timePicker: { 0: [], 1: [] }, monthPicker: [] }), so = se(null), Oi = se(false), oo = se(false), lo = se(false), uo = se(false), Ut = se(0), yt = se(0), or = () => {
  const t = Q(() => Oi.value ? [...ct.selectionGrid, ct.actionRow].filter((T) => T.length) : oo.value ? [...ct.timePicker[0], ...ct.timePicker[1], uo.value ? [] : [so.value], ct.actionRow].filter((T) => T.length) : lo.value ? [...ct.monthPicker, ct.actionRow] : [ct.monthYear, ...ct.calendar, ct.time, ct.actionRow].filter((T) => T.length)), e = (T) => {
    Ut.value = T ? Ut.value + 1 : Ut.value - 1;
    let f = null;
    t.value[yt.value] && (f = t.value[yt.value][Ut.value]), !f && t.value[yt.value + (T ? 1 : -1)] ? (yt.value = yt.value + (T ? 1 : -1), Ut.value = T ? 0 : t.value[yt.value].length - 1) : f || (Ut.value = T ? Ut.value - 1 : Ut.value + 1);
  }, n = (T) => {
    yt.value === 0 && !T || yt.value === t.value.length && T || (yt.value = T ? yt.value + 1 : yt.value - 1, t.value[yt.value] ? t.value[yt.value] && !t.value[yt.value][Ut.value] && Ut.value !== 0 && (Ut.value = t.value[yt.value].length - 1) : yt.value = T ? yt.value - 1 : yt.value + 1);
  }, r = (T) => {
    let f = null;
    t.value[yt.value] && (f = t.value[yt.value][Ut.value]), f ? f.focus({ preventScroll: !Oi.value }) : Ut.value = T ? Ut.value - 1 : Ut.value + 1;
  }, a = () => {
    e(true), r(true);
  }, i = () => {
    e(false), r(false);
  }, s = () => {
    n(false), r(true);
  }, l = () => {
    n(true), r(true);
  }, o = (T, f) => {
    ct[f] = T;
  }, c = (T, f) => {
    ct[f] = T;
  }, u = () => {
    Ut.value = 0, yt.value = 0;
  };
  return { buildMatrix: o, buildMultiLevelMatrix: c, setTimePickerBackRef: (T) => {
    so.value = T;
  }, setSelectionGrid: (T) => {
    Oi.value = T, u(), T || (ct.selectionGrid = []);
  }, setTimePicker: (T, f = false) => {
    oo.value = T, uo.value = f, u(), T || (ct.timePicker[0] = [], ct.timePicker[1] = []);
  }, setTimePickerElements: (T, f = 0) => {
    ct.timePicker[f] = T;
  }, arrowRight: a, arrowLeft: i, arrowUp: s, arrowDown: l, clearArrowNav: () => {
    ct.monthYear = [], ct.calendar = [], ct.time = [], ct.actionRow = [], ct.selectionGrid = [], ct.timePicker[0] = [], ct.timePicker[1] = [], Oi.value = false, oo.value = false, uo.value = false, lo.value = false, u(), so.value = null;
  }, setMonthPicker: (T) => {
    lo.value = T, u();
  }, refSets: ct };
}, Pl = (t) => ({ menuAppearTop: "dp-menu-appear-top", menuAppearBottom: "dp-menu-appear-bottom", open: "dp-slide-down", close: "dp-slide-up", next: "calendar-next", previous: "calendar-prev", vNext: "dp-slide-up", vPrevious: "dp-slide-down", ...t ?? {} }), gp = (t) => ({ toggleOverlay: "Toggle overlay", menu: "Datepicker menu", input: "Datepicker input", openTimePicker: "Open time picker", closeTimePicker: "Close time Picker", incrementValue: (e) => `Increment ${e}`, decrementValue: (e) => `Decrement ${e}`, openTpOverlay: (e) => `Open ${e} overlay`, amPmButton: "Switch AM/PM mode", openYearsOverlay: "Open years overlay", openMonthsOverlay: "Open months overlay", nextMonth: "Next month", prevMonth: "Previous month", nextYear: "Next year", prevYear: "Previous year", day: void 0, weekDay: void 0, clearInput: "Clear value", calendarIcon: "Calendar icon", timePicker: "Time picker", monthPicker: (e) => `Month picker${e ? " overlay" : ""}`, yearPicker: (e) => `Year picker${e ? " overlay" : ""}`, timeOverlay: (e) => `${e} overlay`, ...t ?? {} }), Ul = (t) => t ? typeof t == "boolean" ? t ? 2 : 0 : +t >= 2 ? +t : 2 : 0, Rp = (t) => {
  const e = typeof t == "object" && t, n = { static: true, solo: false };
  if (!t) return { ...n, count: Ul(false) };
  const r = e ? t : {}, a = e ? r.count ?? true : t, i = Ul(a);
  return Object.assign(n, r, { count: i });
}, Np = (t, e, n) => t || (typeof n == "string" ? n : e), Fp = (t) => typeof t == "boolean" ? t ? Pl({}) : false : Pl(t), yp = (t) => {
  const e = { enterSubmit: true, tabSubmit: true, openMenu: "open", selectOnFocus: false, rangeSeparator: " - ", escClose: true };
  return typeof t == "object" ? { ...e, ...t ?? {}, enabled: true } : { ...e, enabled: t };
}, Op = (t) => ({ months: [], years: [], times: { hours: [], minutes: [], seconds: [] }, ...t ?? {} }), Mp = (t) => ({ showSelect: true, showCancel: true, showNow: false, showPreview: true, ...t ?? {} }), bp = (t) => {
  const e = { input: false };
  return typeof t == "object" ? { ...e, ...t ?? {}, enabled: true } : { enabled: t, ...e };
}, Yp = (t) => ({ allowStopPropagation: true, closeOnScroll: false, modeHeight: 255, allowPreventDefault: false, closeOnClearValue: true, closeOnAutoApply: true, noSwipe: false, keepActionRow: false, onClickOutside: void 0, tabOutClosesMenu: true, arrowLeft: void 0, keepViewOnOffsetClick: false, timeArrowHoldThreshold: 0, shadowDom: false, mobileBreakpoint: 600, setDateOnMenuClose: false, ...t ?? {} }), wp = (t) => {
  const e = { dates: Array.isArray(t) ? t.map((n) => de(n)) : [], years: [], months: [], quarters: [], weeks: [], weekdays: [], options: { highlightDisabled: false } };
  return typeof t == "function" ? t : { ...e, ...t ?? {} };
}, _p = (t) => typeof t == "object" ? { type: t?.type ?? "local", hideOnOffsetDates: t?.hideOnOffsetDates ?? false } : { type: t, hideOnOffsetDates: false }, Bp = (t) => {
  const e = { noDisabledRange: false, showLastInRange: true, minMaxRawRange: false, partialRange: true, disableTimeRangeValidation: false, maxRange: void 0, minRange: void 0, autoRange: void 0, fixedStart: false, fixedEnd: false };
  return typeof t == "object" ? { enabled: true, ...e, ...t } : { enabled: t, ...e };
}, Zp = (t) => t ? typeof t == "string" ? { timezone: t, exactMatch: false, dateInTz: void 0, emitTimezone: void 0, convertModel: true } : { timezone: t.timezone, exactMatch: t.exactMatch ?? false, dateInTz: t.dateInTz ?? void 0, emitTimezone: t.emitTimezone ?? void 0, convertModel: t.convertModel ?? true } : { timezone: void 0, exactMatch: false, emitTimezone: void 0 }, co = (t, e, n, r) => new Map(t.map((a) => {
  const i = $s(a, e, r);
  return [Ks(i, n), i];
})), Ip = (t, e) => t.length ? new Map(t.map((n) => {
  const r = $s(n.date, e);
  return [Ks(r, Qr.DATE), n];
})) : null, Lp = (t) => {
  var e;
  const n = Ml(t.isMonthPicker, t.isYearPicker);
  return { minDate: Vs(t.minDate, t.timezone, t.isSpecific), maxDate: Vs(t.maxDate, t.timezone, t.isSpecific), disabledDates: Js(t.disabledDates) ? co(t.disabledDates, t.timezone, n, t.isSpecific) : t.disabledDates, allowedDates: Js(t.allowedDates) ? co(t.allowedDates, t.timezone, n, t.isSpecific) : null, highlight: typeof t.highlight == "object" && Js((e = t.highlight) == null ? void 0 : e.dates) ? co(t.highlight.dates, t.timezone, n) : t.highlight, markers: Ip(t.markers, t.timezone) };
}, kp = (t) => typeof t == "boolean" ? { enabled: t, dragSelect: true, limit: null } : { enabled: !!t, limit: t.limit ? +t.limit : null, dragSelect: t.dragSelect ?? true }, Cp = (t) => ({ ...Object.fromEntries(Object.keys(t).map((e) => {
  const n = e, r = t[n], a = typeof t[n] == "string" ? { [r]: true } : Object.fromEntries(r.map((i) => [i, true]));
  return [e, a];
})) }), dt = (t) => {
  const e = () => {
    const _ = t.enableSeconds ? ":ss" : "", I = t.enableMinutes ? ":mm" : "";
    return t.is24 ? `HH${I}${_}` : `hh${I}${_} aa`;
  }, n = () => {
    var _;
    return t.format ? t.format : t.monthPicker ? "MM/yyyy" : t.timePicker ? e() : t.weekPicker ? `${((_ = A.value) == null ? void 0 : _.type) === "iso" ? "II" : "ww"}-RR` : t.yearPicker ? "yyyy" : t.quarterPicker ? "QQQ/yyyy" : t.enableTimePicker ? `MM/dd/yyyy, ${e()}` : "MM/dd/yyyy";
  }, r = (_) => Zl(_, t.enableSeconds), a = () => w.value.enabled ? t.startTime && Array.isArray(t.startTime) ? [r(t.startTime[0]), r(t.startTime[1])] : null : t.startTime && !Array.isArray(t.startTime) ? r(t.startTime) : null, i = Q(() => Rp(t.multiCalendars)), s = Q(() => a()), l = Q(() => gp(t.ariaLabels)), o = Q(() => Op(t.filters)), c = Q(() => Fp(t.transitions)), u = Q(() => Mp(t.actionRow)), T = Q(() => Np(t.previewFormat, t.format, n())), f = Q(() => yp(t.textInput)), m = Q(() => bp(t.inline)), v = Q(() => Yp(t.config)), E = Q(() => wp(t.highlight)), A = Q(() => _p(t.weekNumbers)), g = Q(() => Zp(t.timezone)), O = Q(() => kp(t.multiDates)), D = Q(() => Lp({ minDate: t.minDate, maxDate: t.maxDate, disabledDates: t.disabledDates, allowedDates: t.allowedDates, highlight: E.value, markers: t.markers, timezone: g.value, isSpecific: t.monthPicker || t.yearPicker || t.quarterPicker, isMonthPicker: t.monthPicker, isYearPicker: t.yearPicker })), w = Q(() => Bp(t.range)), L = Q(() => Cp(t.ui));
  return { defaultedTransitions: c, defaultedMultiCalendars: i, defaultedStartTime: s, defaultedAriaLabels: l, defaultedFilters: o, defaultedActionRow: u, defaultedPreviewFormat: T, defaultedTextInput: f, defaultedInline: m, defaultedConfig: v, defaultedHighlight: E, defaultedWeekNumbers: A, defaultedRange: w, propDates: D, defaultedTz: g, defaultedMultiDates: O, defaultedUI: L, getDefaultPattern: n, getDefaultStartTime: a, handleEventPropagation: (_) => {
    v.value.allowStopPropagation && _.stopPropagation(), v.value.allowPreventDefault && _.preventDefault();
  } };
}, xp = (t, e, n) => {
  const r = se(), { defaultedTextInput: a, defaultedRange: i, defaultedTz: s, defaultedMultiDates: l, getDefaultPattern: o } = dt(e), c = se(""), u = ra(e, "format"), T = ra(e, "formatLocale");
  vt(r, () => {
    typeof e.onInternalModelChange == "function" && t("internal-model-change", r.value, ie(true));
  }, { deep: true }), vt(i, (h, F) => {
    h.enabled !== F.enabled && (r.value = null);
  }), vt(u, () => {
    Ee();
  });
  const f = (h) => s.value.timezone && s.value.convertModel ? Xt(h, s.value.timezone) : h, m = (h) => {
    if (s.value.timezone && s.value.convertModel) {
      const F = rp(s.value.timezone, h);
      return em(h, F);
    }
    return h;
  }, v = (h, F, U = false) => Ll(h, e.format, e.formatLocale, a.value.rangeSeparator, e.modelAuto, F ?? o(), U), E = (h) => h ? e.modelType ? Ae(h) : { hours: Gn(h), minutes: rr(h), seconds: e.enableSeconds ? Gr(h) : 0 } : null, A = (h) => e.modelType ? Ae(h) : { month: je(h), year: xe(h) }, g = (h) => Array.isArray(h) ? l.value.enabled ? h.map((F) => O(F, _n(de(), F))) : yi(() => [_n(de(), h[0]), h[1] ? _n(de(), h[1]) : Kr(i.value.partialRange)], i.value.enabled) : _n(de(), +h), O = (h, F) => (typeof h == "string" || typeof h == "number") && e.modelType ? ee(h) : F, D = (h) => Array.isArray(h) ? [O(h[0], ir(null, +h[0].hours, +h[0].minutes, h[0].seconds)), O(h[1], ir(null, +h[1].hours, +h[1].minutes, h[1].seconds))] : O(h, ir(null, h.hours, h.minutes, h.seconds)), w = (h) => {
    const F = it(de(), { date: 1 });
    return Array.isArray(h) ? l.value.enabled ? h.map((U) => O(U, jn(F, +U.month, +U.year))) : yi(() => [O(h[0], jn(F, +h[0].month, +h[0].year)), O(h[1], h[1] ? jn(F, +h[1].month, +h[1].year) : Kr(i.value.partialRange))], i.value.enabled) : O(h, jn(F, +h.month, +h.year));
  }, L = (h) => {
    if (Array.isArray(h)) return h.map((F) => ee(F));
    throw new Error(Ws.dateArr("multi-dates"));
  }, _ = (h) => {
    if (Array.isArray(h) && i.value.enabled) {
      const F = h[0], U = h[1];
      return [de(Array.isArray(F) ? F[0] : null), Array.isArray(U) && U.length ? de(U[0]) : null];
    }
    return de(h[0]);
  }, I = (h) => e.modelAuto ? Array.isArray(h) ? [ee(h[0]), ee(h[1])] : e.autoApply ? [ee(h)] : [ee(h), null] : Array.isArray(h) ? yi(() => h[1] ? [ee(h[0]), h[1] ? ee(h[1]) : Kr(i.value.partialRange)] : [ee(h[0])], i.value.enabled) : ee(h), V = () => {
    Array.isArray(r.value) && i.value.enabled && r.value.length === 1 && r.value.push(Kr(i.value.partialRange));
  }, H = () => {
    const h = r.value;
    return [Ae(h[0]), h[1] ? Ae(h[1]) : Kr(i.value.partialRange)];
  }, Z = () => Array.isArray(r.value) ? r.value[1] ? H() : Ae(Zt(r.value[0])) : [], J = () => (r.value || []).map((h) => Ae(h)), re = (h = false) => (h || V(), e.modelAuto ? Z() : l.value.enabled ? J() : Array.isArray(r.value) ? yi(() => H(), i.value.enabled) : Ae(Zt(r.value))), oe = (h) => !h || Array.isArray(h) && !h.length ? null : e.timePicker ? D(Zt(h)) : e.monthPicker ? w(Zt(h)) : e.yearPicker ? g(Zt(h)) : l.value.enabled ? L(Zt(h)) : e.weekPicker ? _(Zt(h)) : I(Zt(h)), b = (h) => {
    const F = oe(h);
    eo(Zt(F)) ? (r.value = Zt(F), Ee()) : (r.value = null, c.value = "");
  }, P = () => {
    const h = (F) => bn(F, a.value.format);
    return `${h(r.value[0])} ${a.value.rangeSeparator} ${r.value[1] ? h(r.value[1]) : ""}`;
  }, k = () => n.value && r.value ? Array.isArray(r.value) ? P() : bn(r.value, a.value.format) : v(r.value), te = () => r.value ? l.value.enabled ? r.value.map((h) => v(h)).join("; ") : a.value.enabled && typeof a.value.format == "string" ? k() : v(r.value) : "", Ee = () => {
    !e.format || typeof e.format == "string" || a.value.enabled && typeof a.value.format == "string" ? c.value = te() : c.value = e.format(r.value);
  }, ee = (h) => {
    if (e.utc) {
      const F = new Date(h);
      return e.utc === "preserve" ? new Date(F.getTime() + F.getTimezoneOffset() * 6e4) : F;
    }
    return e.modelType ? ap.includes(e.modelType) ? f(new Date(h)) : e.modelType === "format" && (typeof e.format == "string" || !e.format) ? f(Hs(h, o(), /* @__PURE__ */ new Date(), { locale: T.value })) : f(Hs(h, e.modelType, /* @__PURE__ */ new Date(), { locale: T.value })) : f(new Date(h));
  }, Ae = (h) => h ? e.utc ? Ap(h, e.utc === "preserve", e.enableSeconds) : e.modelType ? e.modelType === "timestamp" ? +m(h) : e.modelType === "iso" ? m(h).toISOString() : e.modelType === "format" && (typeof e.format == "string" || !e.format) ? v(m(h)) : v(m(h), e.modelType, true) : m(h) : "", $ = (h, F = false, U = false) => {
    if (U) return h;
    if (t("update:model-value", h), s.value.emitTimezone && F) {
      const ne = Array.isArray(h) ? h.map((Y) => Xt(Zt(Y), s.value.emitTimezone)) : Xt(Zt(h), s.value.emitTimezone);
      t("update:model-timezone-value", ne);
    }
  }, Me = (h) => Array.isArray(r.value) ? l.value.enabled ? r.value.map((F) => h(F)) : [h(r.value[0]), r.value[1] ? h(r.value[1]) : Kr(i.value.partialRange)] : h(Zt(r.value)), B = () => {
    if (Array.isArray(r.value)) {
      const h = zn(r.value[0], e.weekStart), F = r.value[1] ? zn(r.value[1], e.weekStart) : [];
      return [h.map((U) => de(U)), F.map((U) => de(U))];
    }
    return zn(r.value, e.weekStart).map((h) => de(h));
  }, z = (h, F) => $(Zt(Me(h)), false, F), W = (h) => {
    const F = B();
    return h ? F : t("update:model-value", B());
  }, ie = (h = false) => (h || Ee(), e.monthPicker ? z(A, h) : e.timePicker ? z(E, h) : e.yearPicker ? z(xe, h) : e.weekPicker ? W(h) : $(re(h), true, h));
  return { inputValue: c, internalModelValue: r, checkBeforeEmit: () => r.value ? i.value.enabled ? i.value.partialRange ? r.value.length >= 1 : r.value.length === 2 : !!r.value : false, parseExternalModelValue: b, formatInputValue: Ee, emitModelValue: ie };
}, Hp = (t, e) => {
  const { defaultedFilters: n, propDates: r } = dt(t), { validateMonthYearInRange: a } = ur(t), i = (u, T) => {
    let f = u;
    return n.value.months.includes(je(f)) ? (f = T ? Dn(u, 1) : $r(u, 1), i(f, T)) : f;
  }, s = (u, T) => {
    let f = u;
    return n.value.years.includes(xe(f)) ? (f = T ? ws(u, 1) : Dl(u, 1), s(f, T)) : f;
  }, l = (u, T = false) => {
    const f = it(de(), { month: t.month, year: t.year });
    let m = u ? Dn(f, 1) : $r(f, 1);
    t.disableYearSelect && (m = _n(m, t.year));
    let v = je(m), E = xe(m);
    n.value.months.includes(v) && (m = i(m, u), v = je(m), E = xe(m)), n.value.years.includes(E) && (m = s(m, u), E = xe(m)), a(v, E, u, t.preventMinMaxNavigation) && o(v, E, T);
  }, o = (u, T, f) => {
    e("update-month-year", { month: u, year: T, fromNav: f });
  }, c = Q(() => (u) => Il(it(de(), { month: t.month, year: t.year }), r.value.maxDate, r.value.minDate, t.preventMinMaxNavigation, u));
  return { handleMonthYearChange: l, isDisabled: c, updateMonthYear: o };
}, Mi = { multiCalendars: { type: [Boolean, Number, String, Object], default: void 0 }, modelValue: { type: [String, Date, Array, Object, Number], default: null }, modelType: { type: String, default: null }, position: { type: String, default: "center" }, dark: { type: Boolean, default: false }, format: { type: [String, Function], default: () => null }, autoPosition: { type: [Boolean, String], default: true }, altPosition: { type: Function, default: null }, transitions: { type: [Boolean, Object], default: true }, formatLocale: { type: Object, default: null }, utc: { type: [Boolean, String], default: false }, ariaLabels: { type: Object, default: () => ({}) }, offset: { type: [Number, String], default: 10 }, hideNavigation: { type: Array, default: () => [] }, timezone: { type: [String, Object], default: null }, vertical: { type: Boolean, default: false }, disableMonthYearSelect: { type: Boolean, default: false }, disableYearSelect: { type: Boolean, default: false }, dayClass: { type: Function, default: null }, yearRange: { type: Array, default: () => [1900, 2100] }, enableTimePicker: { type: Boolean, default: true }, autoApply: { type: Boolean, default: false }, disabledDates: { type: [Array, Function], default: () => [] }, monthNameFormat: { type: String, default: "short" }, startDate: { type: [Date, String], default: null }, startTime: { type: [Object, Array], default: null }, hideOffsetDates: { type: Boolean, default: false }, noToday: { type: Boolean, default: false }, disabledWeekDays: { type: Array, default: () => [] }, allowedDates: { type: Array, default: null }, nowButtonLabel: { type: String, default: "Now" }, markers: { type: Array, default: () => [] }, escClose: { type: Boolean, default: true }, spaceConfirm: { type: Boolean, default: true }, monthChangeOnArrows: { type: Boolean, default: true }, presetDates: { type: Array, default: () => [] }, flow: { type: Array, default: () => [] }, partialFlow: { type: Boolean, default: false }, preventMinMaxNavigation: { type: Boolean, default: false }, reverseYears: { type: Boolean, default: false }, weekPicker: { type: Boolean, default: false }, filters: { type: Object, default: () => ({}) }, arrowNavigation: { type: Boolean, default: false }, highlight: { type: [Function, Object], default: null }, teleport: { type: [Boolean, String, Object], default: null }, teleportCenter: { type: Boolean, default: false }, locale: { type: String, default: "en-Us" }, weekNumName: { type: String, default: "W" }, weekStart: { type: [Number, String], default: 1 }, weekNumbers: { type: [String, Function, Object], default: null }, monthChangeOnScroll: { type: [Boolean, String], default: true }, dayNames: { type: [Function, Array], default: null }, monthPicker: { type: Boolean, default: false }, customProps: { type: Object, default: null }, yearPicker: { type: Boolean, default: false }, modelAuto: { type: Boolean, default: false }, selectText: { type: String, default: "Select" }, cancelText: { type: String, default: "Cancel" }, previewFormat: { type: [String, Function], default: () => "" }, multiDates: { type: [Object, Boolean], default: false }, ignoreTimeValidation: { type: Boolean, default: false }, minDate: { type: [Date, String], default: null }, maxDate: { type: [Date, String], default: null }, minTime: { type: Object, default: null }, maxTime: { type: Object, default: null }, name: { type: String, default: null }, placeholder: { type: String, default: "" }, hideInputIcon: { type: Boolean, default: false }, clearable: { type: Boolean, default: true }, alwaysClearable: { type: Boolean, default: false }, state: { type: Boolean, default: null }, required: { type: Boolean, default: false }, autocomplete: { type: String, default: "off" }, timePicker: { type: Boolean, default: false }, enableSeconds: { type: Boolean, default: false }, is24: { type: Boolean, default: true }, noHoursOverlay: { type: Boolean, default: false }, noMinutesOverlay: { type: Boolean, default: false }, noSecondsOverlay: { type: Boolean, default: false }, hoursGridIncrement: { type: [String, Number], default: 1 }, minutesGridIncrement: { type: [String, Number], default: 5 }, secondsGridIncrement: { type: [String, Number], default: 5 }, hoursIncrement: { type: [Number, String], default: 1 }, minutesIncrement: { type: [Number, String], default: 1 }, secondsIncrement: { type: [Number, String], default: 1 }, range: { type: [Boolean, Object], default: false }, uid: { type: String, default: null }, disabled: { type: Boolean, default: false }, readonly: { type: Boolean, default: false }, inline: { type: [Boolean, Object], default: false }, textInput: { type: [Boolean, Object], default: false }, sixWeeks: { type: [Boolean, String], default: false }, actionRow: { type: Object, default: () => ({}) }, focusStartDate: { type: Boolean, default: false }, disabledTimes: { type: [Function, Array], default: void 0 }, timePickerInline: { type: Boolean, default: false }, calendar: { type: Function, default: null }, config: { type: Object, default: void 0 }, quarterPicker: { type: Boolean, default: false }, yearFirst: { type: Boolean, default: false }, loading: { type: Boolean, default: false }, onInternalModelChange: { type: [Function, Object], default: null }, enableMinutes: { type: Boolean, default: true }, ui: { type: Object, default: () => ({}) } }, Nn = { ...Mi, shadow: { type: Boolean, default: false }, flowStep: { type: Number, default: 0 }, internalModelValue: { type: [Date, Array], default: null }, noOverlayFocus: { type: Boolean, default: false }, collapse: { type: Boolean, default: false }, menuWrapRef: { type: Object, default: null }, getInputRect: { type: Function, default: () => ({}) }, isTextInputDate: { type: Boolean, default: false }, isMobile: { type: Boolean, default: void 0 } }, Pp = ["title"], Up = ["disabled"], Gp = Ve({ compatConfig: { MODE: 3 }, __name: "ActionRow", props: { menuMount: { type: Boolean, default: false }, calendarWidth: { type: Number, default: 0 }, ...Nn }, emits: ["close-picker", "select-date", "select-now", "invalid-select"], setup(t, { emit: e }) {
  const n = e, r = t, { defaultedActionRow: a, defaultedPreviewFormat: i, defaultedMultiCalendars: s, defaultedTextInput: l, defaultedInline: o, defaultedRange: c, defaultedMultiDates: u } = dt(r), { isTimeValid: T, isMonthValid: f } = ur(r), { buildMatrix: m } = or(), v = se(null), E = se(null), A = se(false), g = se({}), O = se(null), D = se(null);
  gt(() => {
    r.arrowNavigation && m([Yt(v), Yt(E)], "actionRow"), w(), window.addEventListener("resize", w);
  }), Sr(() => {
    window.removeEventListener("resize", w);
  });
  const w = () => {
    A.value = false, setTimeout(() => {
      var b, P;
      const k = (b = O.value) == null ? void 0 : b.getBoundingClientRect(), te = (P = D.value) == null ? void 0 : P.getBoundingClientRect();
      k && te && (g.value.maxWidth = `${te.width - k.width - 20}px`), A.value = true;
    }, 0);
  }, L = Q(() => c.value.enabled && !c.value.partialRange && r.internalModelValue ? r.internalModelValue.length === 2 : true), _ = Q(() => !T.value(r.internalModelValue) || !f.value(r.internalModelValue) || !L.value), I = () => {
    const b = i.value;
    return r.timePicker || r.monthPicker, b(Zt(r.internalModelValue));
  }, V = () => {
    const b = r.internalModelValue;
    return s.value.count > 0 ? `${H(b[0])} - ${H(b[1])}` : [H(b[0]), H(b[1])];
  }, H = (b) => Ll(b, i.value, r.formatLocale, l.value.rangeSeparator, r.modelAuto, i.value), Z = Q(() => !r.internalModelValue || !r.menuMount ? "" : typeof i.value == "string" ? Array.isArray(r.internalModelValue) ? r.internalModelValue.length === 2 && r.internalModelValue[1] ? V() : u.value.enabled ? r.internalModelValue.map((b) => `${H(b)}`) : r.modelAuto ? `${H(r.internalModelValue[0])}` : `${H(r.internalModelValue[0])} -` : H(r.internalModelValue) : I()), J = () => u.value.enabled ? "; " : " - ", re = Q(() => Array.isArray(Z.value) ? Z.value.join(J()) : Z.value), oe = () => {
    T.value(r.internalModelValue) && f.value(r.internalModelValue) && L.value ? n("select-date") : n("invalid-select");
  };
  return (b, P) => (p(), M("div", { ref_key: "actionRowRef", ref: D, class: "dp__action_row" }, [b.$slots["action-row"] ? le(b.$slots, "action-row", bt(Le({ key: 0 }, { internalModelValue: b.internalModelValue, disabled: _.value, selectDate: () => b.$emit("select-date"), closePicker: () => b.$emit("close-picker") }))) : (p(), M(He, { key: 1 }, [S(a).showPreview ? (p(), M("div", { key: 0, class: "dp__selection_preview", title: re.value, style: Tt(g.value) }, [b.$slots["action-preview"] && A.value ? le(b.$slots, "action-preview", { key: 0, value: b.internalModelValue }) : x("", true), !b.$slots["action-preview"] && A.value ? (p(), M(He, { key: 1 }, [Mt(Be(re.value), 1)], 64)) : x("", true)], 12, Pp)) : x("", true), j("div", { ref_key: "actionBtnContainer", ref: O, class: "dp__action_buttons", "data-dp-element": "action-row" }, [b.$slots["action-buttons"] ? le(b.$slots, "action-buttons", { key: 0, value: b.internalModelValue }) : x("", true), b.$slots["action-buttons"] ? x("", true) : (p(), M(He, { key: 1 }, [!S(o).enabled && S(a).showCancel ? (p(), M("button", { key: 0, ref_key: "cancelButtonRef", ref: v, type: "button", class: "dp__action_button dp__action_cancel", onClick: P[0] || (P[0] = (k) => b.$emit("close-picker")), onKeydown: P[1] || (P[1] = (k) => S(Qt)(k, () => b.$emit("close-picker"))) }, Be(b.cancelText), 545)) : x("", true), S(a).showNow ? (p(), M("button", { key: 1, type: "button", class: "dp__action_button dp__action_cancel", onClick: P[2] || (P[2] = (k) => b.$emit("select-now")), onKeydown: P[3] || (P[3] = (k) => S(Qt)(k, () => b.$emit("select-now"))) }, Be(b.nowButtonLabel), 33)) : x("", true), S(a).showSelect ? (p(), M("button", { key: 2, ref_key: "selectButtonRef", ref: E, type: "button", class: "dp__action_button dp__action_select", disabled: _.value, "data-test-id": "select-button", onKeydown: P[4] || (P[4] = (k) => S(Qt)(k, () => oe())), onClick: oe }, Be(b.selectText), 41, Up)) : x("", true)], 64))], 512)], 64))], 512));
} }), zp = ["role", "aria-label", "tabindex"], jp = { class: "dp__selection_grid_header" }, $p = ["aria-selected", "aria-disabled", "data-test-id", "onClick", "onKeydown", "onMouseover"], Vp = ["aria-label"], Na = Ve({ __name: "SelectionOverlay", props: { items: {}, type: {}, isLast: { type: Boolean }, arrowNavigation: { type: Boolean }, skipButtonRef: { type: Boolean }, headerRefs: {}, hideNavigation: {}, escClose: { type: Boolean }, useRelative: { type: Boolean }, height: {}, textInput: { type: [Boolean, Object] }, config: {}, noOverlayFocus: { type: Boolean }, focusValue: {}, menuWrapRef: {}, ariaLabels: {}, overlayLabel: {} }, emits: ["selected", "toggle", "reset-flow", "hover-value"], setup(t, { expose: e, emit: n }) {
  const { setSelectionGrid: r, buildMultiLevelMatrix: a, setMonthPicker: i } = or(), s = n, l = t, { defaultedAriaLabels: o, defaultedTextInput: c, defaultedConfig: u, handleEventPropagation: T } = dt(l), { hideNavigationButtons: f } = wi(), m = se(false), v = se(null), E = se(null), A = se([]), g = se(), O = se(null), D = se(0), w = se(null);
  Zc(() => {
    v.value = null;
  }), gt(() => {
    Bt().then(() => re()), l.noOverlayFocus || _(), L(true);
  }), Sr(() => L(false));
  const L = (B) => {
    var z;
    l.arrowNavigation && ((z = l.headerRefs) != null && z.length ? i(B) : r(B));
  }, _ = () => {
    var B;
    const z = Yt(E);
    z && (c.value.enabled || (v.value ? (B = v.value) == null || B.focus({ preventScroll: true }) : z.focus({ preventScroll: true })), m.value = z.clientHeight < z.scrollHeight);
  }, I = Q(() => ({ dp__overlay: true, "dp--overlay-absolute": !l.useRelative, "dp--overlay-relative": l.useRelative })), V = Q(() => l.useRelative ? { height: `${l.height}px`, width: "var(--dp-menu-min-width)" } : void 0), H = Q(() => ({ dp__overlay_col: true })), Z = Q(() => ({ dp__btn: true, dp__button: true, dp__overlay_action: true, dp__over_action_scroll: m.value, dp__button_bottom: l.isLast })), J = Q(() => {
    var B, z;
    return { dp__overlay_container: true, dp__container_flex: ((B = l.items) == null ? void 0 : B.length) <= 6, dp__container_block: ((z = l.items) == null ? void 0 : z.length) > 6 };
  });
  vt(() => l.items, () => re(false), { deep: true });
  const re = (B = true) => {
    Bt().then(() => {
      const z = Yt(v), W = Yt(E), ie = Yt(O), h = Yt(w), F = ie ? ie.getBoundingClientRect().height : 0;
      W && (W.getBoundingClientRect().height ? D.value = W.getBoundingClientRect().height - F : D.value = u.value.modeHeight - F), z && h && B && (h.scrollTop = z.offsetTop - h.offsetTop - (D.value / 2 - z.getBoundingClientRect().height) - F);
    });
  }, oe = (B) => {
    B.disabled || s("selected", B.value);
  }, b = () => {
    s("toggle"), s("reset-flow");
  }, P = (B) => {
    l.escClose && (b(), T(B));
  }, k = (B, z, W, ie) => {
    B && ((z.active || z.value === l.focusValue) && (v.value = B), l.arrowNavigation && (Array.isArray(A.value[W]) ? A.value[W][ie] = B : A.value[W] = [B], te()));
  }, te = () => {
    var B, z;
    const W = (B = l.headerRefs) != null && B.length ? [l.headerRefs].concat(A.value) : A.value.concat([l.skipButtonRef ? [] : [O.value]]);
    a(Zt(W), (z = l.headerRefs) != null && z.length ? "monthPicker" : "selectionGrid");
  }, Ee = (B) => {
    l.arrowNavigation || ar(B, u.value, true);
  }, ee = (B) => {
    g.value = B, s("hover-value", B);
  }, Ae = () => {
    if (b(), !l.isLast) {
      const B = qs(l.menuWrapRef ?? null, "action-row");
      if (B) {
        const z = yl(B);
        z?.focus();
      }
    }
  }, $ = (B) => {
    switch (B.key) {
      case ut.esc:
        return P(B);
      case ut.arrowLeft:
        return Ee(B);
      case ut.arrowRight:
        return Ee(B);
      case ut.arrowUp:
        return Ee(B);
      case ut.arrowDown:
        return Ee(B);
      default:
        return;
    }
  }, Me = (B) => {
    if (B.key === ut.enter) return b();
    if (B.key === ut.tab) return Ae();
  };
  return e({ focusGrid: _ }), (B, z) => {
    var W;
    return p(), M("div", { ref_key: "gridWrapRef", ref: E, class: ye(I.value), style: Tt(V.value), role: B.useRelative ? void 0 : "dialog", "aria-label": B.overlayLabel, tabindex: B.useRelative ? void 0 : "0", onKeydown: $, onClick: z[0] || (z[0] = at(() => {
    }, ["prevent"])) }, [j("div", { ref_key: "containerRef", ref: w, class: ye(J.value), style: Tt({ "--dp-overlay-height": `${D.value}px` }), role: "grid" }, [j("div", jp, [le(B.$slots, "header")]), B.$slots.overlay ? le(B.$slots, "overlay", { key: 0 }) : (p(true), M(He, { key: 1 }, rt(B.items, (ie, h) => (p(), M("div", { key: h, class: ye(["dp__overlay_row", { dp__flex_row: B.items.length >= 3 }]), role: "row" }, [(p(true), M(He, null, rt(ie, (F, U) => (p(), M("div", { key: F.value, ref_for: true, ref: (ne) => k(ne, F, h, U), role: "gridcell", class: ye(H.value), "aria-selected": F.active || void 0, "aria-disabled": F.disabled || void 0, tabindex: "0", "data-test-id": F.text, onClick: at((ne) => oe(F), ["prevent"]), onKeydown: (ne) => S(Qt)(ne, () => oe(F), true), onMouseover: (ne) => ee(F.value) }, [j("div", { class: ye(F.className) }, [B.$slots.item ? le(B.$slots, "item", { key: 0, item: F }) : x("", true), B.$slots.item ? x("", true) : (p(), M(He, { key: 1 }, [Mt(Be(F.text), 1)], 64))], 2)], 42, $p))), 128))], 2))), 128))], 6), B.$slots["button-icon"] ? Ot((p(), M("button", { key: 0, ref_key: "toggleButton", ref: O, type: "button", "aria-label": (W = S(o)) == null ? void 0 : W.toggleOverlay, class: ye(Z.value), tabindex: "0", onClick: b, onKeydown: Me }, [le(B.$slots, "button-icon")], 42, Vp)), [[Kt, !S(f)(B.hideNavigation, B.type)]]) : x("", true)], 46, zp);
  };
} }), Qp = ["data-dp-mobile"], bi = Ve({ __name: "InstanceWrap", props: { multiCalendars: {}, stretch: { type: Boolean }, collapse: { type: Boolean }, isMobile: { type: Boolean } }, setup(t) {
  const e = t, n = Q(() => e.multiCalendars > 0 ? [...Array(e.multiCalendars).keys()] : [0]), r = Q(() => ({ dp__instance_calendar: e.multiCalendars > 0 }));
  return (a, i) => (p(), M("div", { class: ye({ dp__menu_inner: !a.stretch, "dp--menu--inner-stretched": a.stretch, dp__flex_display: a.multiCalendars > 0, "dp--flex-display-collapsed": a.collapse }), "data-dp-mobile": a.isMobile }, [(p(true), M(He, null, rt(n.value, (s, l) => (p(), M("div", { key: s, class: ye(r.value) }, [le(a.$slots, "default", { instance: s, index: l })], 2))), 128))], 10, Qp));
} }), Wp = ["data-dp-element", "aria-label", "aria-disabled"], Fa = Ve({ compatConfig: { MODE: 3 }, __name: "ArrowBtn", props: { ariaLabel: {}, elName: {}, disabled: { type: Boolean } }, emits: ["activate", "set-ref"], setup(t, { emit: e }) {
  const n = e, r = se(null);
  return gt(() => n("set-ref", r)), (a, i) => (p(), M("button", { ref_key: "elRef", ref: r, type: "button", "data-dp-element": a.elName, class: "dp__btn dp--arrow-btn-nav", tabindex: "0", "aria-label": a.ariaLabel, "aria-disabled": a.disabled || void 0, onClick: i[0] || (i[0] = (s) => a.$emit("activate")), onKeydown: i[1] || (i[1] = (s) => S(Qt)(s, () => a.$emit("activate"), true)) }, [j("span", { class: ye(["dp__inner_nav", { dp__inner_nav_disabled: a.disabled }]) }, [le(a.$slots, "default")], 2)], 40, Wp));
} }), qp = ["aria-label", "data-test-id"], Gl = Ve({ __name: "YearModePicker", props: { ...Nn, showYearPicker: { type: Boolean, default: false }, items: { type: Array, default: () => [] }, instance: { type: Number, default: 0 }, year: { type: Number, default: 0 }, isDisabled: { type: Function, default: () => false } }, emits: ["toggle-year-picker", "year-select", "handle-year"], setup(t, { emit: e }) {
  const n = e, r = t, { showRightIcon: a, showLeftIcon: i } = wi(), { defaultedConfig: s, defaultedMultiCalendars: l, defaultedAriaLabels: o, defaultedTransitions: c, defaultedUI: u } = dt(r), { showTransition: T, transitionName: f } = ya(c), m = se(false), v = (g = false, O) => {
    m.value = !m.value, n("toggle-year-picker", { flow: g, show: O });
  }, E = (g) => {
    m.value = false, n("year-select", g);
  }, A = (g = false) => {
    n("handle-year", g);
  };
  return (g, O) => {
    var D, w, L, _, I;
    return p(), M(He, null, [j("div", { class: ye(["dp--year-mode-picker", { "dp--hidden-el": m.value }]) }, [S(i)(S(l), t.instance) ? (p(), De(Fa, { key: 0, ref: "mpPrevIconRef", "aria-label": (D = S(o)) == null ? void 0 : D.prevYear, disabled: t.isDisabled(false), class: ye((w = S(u)) == null ? void 0 : w.navBtnPrev), onActivate: O[0] || (O[0] = (V) => A(false)) }, { default: he(() => [g.$slots["arrow-left"] ? le(g.$slots, "arrow-left", { key: 0 }) : x("", true), g.$slots["arrow-left"] ? x("", true) : (p(), De(S(Ps), { key: 1 }))]), _: 3 }, 8, ["aria-label", "disabled", "class"])) : x("", true), j("button", { ref: "mpYearButtonRef", class: "dp__btn dp--year-select", type: "button", "aria-label": `${t.year}-${(L = S(o)) == null ? void 0 : L.openYearsOverlay}`, "data-test-id": `year-mode-btn-${t.instance}`, onClick: O[1] || (O[1] = () => v(false)), onKeydown: O[2] || (O[2] = Ct(() => v(false), ["enter"])) }, [g.$slots.year ? le(g.$slots, "year", { key: 0, year: t.year }) : x("", true), g.$slots.year ? x("", true) : (p(), M(He, { key: 1 }, [Mt(Be(t.year), 1)], 64))], 40, qp), S(a)(S(l), t.instance) ? (p(), De(Fa, { key: 1, ref: "mpNextIconRef", "aria-label": (_ = S(o)) == null ? void 0 : _.nextYear, disabled: t.isDisabled(true), class: ye((I = S(u)) == null ? void 0 : I.navBtnNext), onActivate: O[3] || (O[3] = (V) => A(true)) }, { default: he(() => [g.$slots["arrow-right"] ? le(g.$slots, "arrow-right", { key: 0 }) : x("", true), g.$slots["arrow-right"] ? x("", true) : (p(), De(S(Us), { key: 1 }))]), _: 3 }, 8, ["aria-label", "disabled", "class"])) : x("", true)], 2), Oe(qn, { name: S(f)(t.showYearPicker), css: S(T) }, { default: he(() => {
      var V, H;
      return [t.showYearPicker ? (p(), De(Na, { key: 0, items: t.items, "text-input": g.textInput, "esc-close": g.escClose, config: g.config, "is-last": g.autoApply && !S(s).keepActionRow, "hide-navigation": g.hideNavigation, "aria-labels": g.ariaLabels, "overlay-label": (H = (V = S(o)) == null ? void 0 : V.yearPicker) == null ? void 0 : H.call(V, true), type: "year", onToggle: v, onSelected: O[4] || (O[4] = (Z) => E(Z)) }, wt({ "button-icon": he(() => [g.$slots["calendar-icon"] ? le(g.$slots, "calendar-icon", { key: 0 }) : x("", true), g.$slots["calendar-icon"] ? x("", true) : (p(), De(S(Vr), { key: 1 }))]), _: 2 }, [g.$slots["year-overlay-value"] ? { name: "item", fn: he(({ item: Z }) => [le(g.$slots, "year-overlay-value", { text: Z.text, value: Z.value })]), key: "0" } : void 0]), 1032, ["items", "text-input", "esc-close", "config", "is-last", "hide-navigation", "aria-labels", "overlay-label"])) : x("", true)];
    }), _: 3 }, 8, ["name", "css"])], 64);
  };
} }), To = (t, e, n) => {
  if (e.value && Array.isArray(e.value)) if (e.value.some((r) => $e(t, r))) {
    const r = e.value.filter((a) => !$e(a, t));
    e.value = r.length ? r : null;
  } else (n && +n > e.value.length || !n) && e.value.push(t);
  else e.value = [t];
}, ho = (t, e, n) => {
  let r = t.value ? t.value.slice() : [];
  return r.length === 2 && r[1] !== null && (r = []), r.length ? (pt(e, r[0]) ? r.unshift(e) : r[1] = e, n("range-end", e)) : (r = [e], n("range-start", e)), r;
}, Yi = (t, e, n, r) => {
  t && (t[0] && t[1] && n && e("auto-apply"), t[0] && !t[1] && r && n && e("auto-apply"));
}, zl = (t) => {
  Array.isArray(t.value) && t.value.length <= 2 && t.range ? t.modelValue.value = t.value.map((e) => Xt(de(e), t.timezone)) : Array.isArray(t.value) || (t.modelValue.value = Xt(de(t.value), t.timezone));
}, jl = (t, e, n, r) => Array.isArray(e.value) && (e.value.length === 2 || e.value.length === 1 && r.value.partialRange) ? r.value.fixedStart && (Ft(t, e.value[0]) || $e(t, e.value[0])) ? [e.value[0], t] : r.value.fixedEnd && (pt(t, e.value[1]) || $e(t, e.value[1])) ? [t, e.value[1]] : (n("invalid-fixed-range", t), e.value) : [], $l = ({ multiCalendars: t, range: e, highlight: n, propDates: r, calendars: a, modelValue: i, props: s, filters: l, year: o, month: c, emit: u }) => {
  const T = Q(() => Qs(s.yearRange, s.locale, s.reverseYears)), f = se([false]), m = Q(() => (Z, J) => {
    const re = it(Rn(/* @__PURE__ */ new Date()), { month: c.value(Z), year: o.value(Z) }), oe = J ? X0(re) : pa(re);
    return Il(oe, r.value.maxDate, r.value.minDate, s.preventMinMaxNavigation, J);
  }), v = () => Array.isArray(i.value) && t.value.solo && i.value[1], E = () => {
    for (let Z = 0; Z < t.value.count; Z++) if (Z === 0) a.value[Z] = a.value[0];
    else if (Z === t.value.count - 1 && v()) a.value[Z] = { month: je(i.value[1]), year: xe(i.value[1]) };
    else {
      const J = it(de(), a.value[Z - 1]);
      a.value[Z] = { month: je(J), year: xe(ws(J, 1)) };
    }
  }, A = (Z) => {
    if (!Z) return E();
    const J = it(de(), a.value[Z]);
    return a.value[0].year = xe(Dl(J, t.value.count - 1)), E();
  }, g = (Z, J) => {
    const re = im(J, Z);
    return e.value.showLastInRange && re > 1 ? J : Z;
  }, O = (Z) => s.focusStartDate || t.value.solo ? Z[0] : Z[1] ? g(Z[0], Z[1]) : Z[0], D = () => {
    if (i.value) {
      const Z = Array.isArray(i.value) ? O(i.value) : i.value;
      a.value[0] = { month: je(Z), year: xe(Z) };
    }
  }, w = () => {
    D(), t.value.count && E();
  };
  vt(i, (Z, J) => {
    s.isTextInputDate && JSON.stringify(Z ?? {}) !== JSON.stringify(J ?? {}) && w();
  }), gt(() => {
    w();
  });
  const L = (Z, J) => {
    a.value[J].year = Z, u("update-month-year", { instance: J, year: Z, month: a.value[J].month }), t.value.count && !t.value.solo && A(J);
  }, _ = Q(() => (Z) => Wr(T.value, (J) => {
    var re;
    const oe = o.value(Z) === J.value, b = va(J.value, qr(r.value.minDate), qr(r.value.maxDate)) || ((re = l.value.years) == null ? void 0 : re.includes(o.value(Z))), P = ao(n.value, J.value);
    return { active: oe, disabled: b, highlighted: P };
  })), I = (Z, J) => {
    L(Z, J), H(J);
  }, V = (Z, J = false) => {
    if (!m.value(Z, J)) {
      const re = J ? o.value(Z) + 1 : o.value(Z) - 1;
      L(re, Z);
    }
  }, H = (Z, J = false, re) => {
    J || u("reset-flow"), re !== void 0 ? f.value[Z] = re : f.value[Z] = !f.value[Z], f.value[Z] ? u("overlay-toggle", { open: true, overlay: Pt.year }) : (u("overlay-closed"), u("overlay-toggle", { open: false, overlay: Pt.year }));
  };
  return { isDisabled: m, groupedYears: _, showYearPicker: f, selectYear: L, toggleYearPicker: H, handleYearSelect: I, handleYear: V };
}, Kp = (t, e) => {
  const { defaultedMultiCalendars: n, defaultedAriaLabels: r, defaultedTransitions: a, defaultedConfig: i, defaultedRange: s, defaultedHighlight: l, propDates: o, defaultedTz: c, defaultedFilters: u, defaultedMultiDates: T } = dt(t), f = () => {
    t.isTextInputDate && w(xe(de(t.startDate)), 0);
  }, { modelValue: m, year: v, month: E, calendars: A } = Oa(t, e, f), g = Q(() => gl(t.formatLocale, t.locale, t.monthNameFormat)), O = se(null), { checkMinMaxRange: D } = ur(t), { selectYear: w, groupedYears: L, showYearPicker: _, toggleYearPicker: I, handleYearSelect: V, handleYear: H, isDisabled: Z } = $l({ modelValue: m, multiCalendars: n, range: s, highlight: l, calendars: A, year: v, propDates: o, month: E, filters: u, props: t, emit: e });
  gt(() => {
    t.startDate && (m.value && t.focusStartDate || !m.value) && w(xe(de(t.startDate)), 0);
  });
  const J = (z) => z ? { month: je(z), year: xe(z) } : { month: null, year: null }, re = () => m.value ? Array.isArray(m.value) ? m.value.map((z) => J(z)) : J(m.value) : J(), oe = (z, W) => {
    const ie = A.value[z], h = re();
    return Array.isArray(h) ? h.some((F) => F.year === ie?.year && F.month === W) : ie?.year === h.year && W === h.month;
  }, b = (z, W, ie) => {
    var h, F;
    const U = re();
    return Array.isArray(U) ? v.value(W) === ((h = U[ie]) == null ? void 0 : h.year) && z === ((F = U[ie]) == null ? void 0 : F.month) : false;
  }, P = (z, W) => {
    if (s.value.enabled) {
      const ie = re();
      if (Array.isArray(m.value) && Array.isArray(ie)) {
        const h = b(z, W, 0) || b(z, W, 1), F = jn(Rn(de()), z, v.value(W));
        return ga(m.value, O.value, F) && !h;
      }
      return false;
    }
    return false;
  }, k = Q(() => (z) => Wr(g.value, (W) => {
    var ie;
    const h = oe(z, W.value), F = va(W.value, wl(v.value(z), o.value.minDate), _l(v.value(z), o.value.maxDate)) || Sp(o.value.disabledDates, v.value(z), W.value) || ((ie = u.value.months) == null ? void 0 : ie.includes(W.value)) || !vp(o.value.allowedDates, v.value(z), W.value), U = P(W.value, z), ne = Cl(l.value, W.value, v.value(z));
    return { active: h, disabled: F, isBetween: U, highlighted: ne };
  })), te = (z, W) => jn(Rn(de()), z, v.value(W)), Ee = (z, W) => {
    const ie = m.value ? m.value : Rn(/* @__PURE__ */ new Date());
    m.value = jn(ie, z, v.value(W)), e("auto-apply"), e("update-flow-step");
  }, ee = (z, W) => {
    const ie = te(z, W);
    s.value.fixedEnd || s.value.fixedStart ? m.value = jl(ie, m, e, s) : m.value ? D(ie, m.value) && (m.value = ho(m, te(z, W), e)) : m.value = [te(z, W)], Bt().then(() => {
      Yi(m.value, e, t.autoApply, t.modelAuto);
    });
  }, Ae = (z, W) => {
    To(te(z, W), m, T.value.limit), e("auto-apply", true);
  }, $ = (z, W) => (A.value[W].month = z, B(W, A.value[W].year, z), T.value.enabled ? Ae(z, W) : s.value.enabled ? ee(z, W) : Ee(z, W)), Me = (z, W) => {
    w(z, W), B(W, z, null);
  }, B = (z, W, ie) => {
    let h = ie;
    if (!h && h !== 0) {
      const F = re();
      h = Array.isArray(F) ? F[z].month : F.month;
    }
    e("update-month-year", { instance: z, year: W, month: h });
  };
  return { groupedMonths: k, groupedYears: L, year: v, isDisabled: Z, defaultedMultiCalendars: n, defaultedAriaLabels: r, defaultedTransitions: a, defaultedConfig: i, showYearPicker: _, modelValue: m, presetDate: (z, W) => {
    zl({ value: z, modelValue: m, range: s.value.enabled, timezone: W ? void 0 : c.value.timezone }), e("auto-apply");
  }, setHoverDate: (z, W) => {
    O.value = te(z, W);
  }, selectMonth: $, selectYear: Me, toggleYearPicker: I, handleYearSelect: V, handleYear: H, getModelMonthYear: re };
}, Jp = Ve({ compatConfig: { MODE: 3 }, __name: "MonthPicker", props: { ...Nn }, emits: ["update:internal-model-value", "overlay-closed", "reset-flow", "range-start", "range-end", "auto-apply", "update-month-year", "update-flow-step", "mount", "invalid-fixed-range", "overlay-toggle"], setup(t, { expose: e, emit: n }) {
  const r = n, a = mn(), i = sn(a, "yearMode"), s = t;
  gt(() => {
    s.shadow || r("mount", null);
  });
  const { groupedMonths: l, groupedYears: o, year: c, isDisabled: u, defaultedMultiCalendars: T, defaultedConfig: f, showYearPicker: m, modelValue: v, presetDate: E, setHoverDate: A, selectMonth: g, selectYear: O, toggleYearPicker: D, handleYearSelect: w, handleYear: L, getModelMonthYear: _ } = Kp(s, r);
  return e({ getSidebarProps: () => ({ modelValue: v, year: c, getModelMonthYear: _, selectMonth: g, selectYear: O, handleYear: L }), presetDate: E, toggleYearPicker: (I) => D(0, I) }), (I, V) => (p(), De(bi, { "multi-calendars": S(T).count, collapse: I.collapse, stretch: "", "is-mobile": I.isMobile }, { default: he(({ instance: H }) => [I.$slots["top-extra"] ? le(I.$slots, "top-extra", { key: 0, value: I.internalModelValue }) : x("", true), I.$slots["month-year"] ? le(I.$slots, "month-year", bt(Le({ key: 1 }, { year: S(c), months: S(l)(H), years: S(o)(H), selectMonth: S(g), selectYear: S(O), instance: H }))) : (p(), De(Na, { key: 2, items: S(l)(H), "arrow-navigation": I.arrowNavigation, "is-last": I.autoApply && !S(f).keepActionRow, "esc-close": I.escClose, height: S(f).modeHeight, config: I.config, "no-overlay-focus": !!(I.noOverlayFocus || I.textInput), "use-relative": "", type: "month", onSelected: (Z) => S(g)(Z, H), onHoverValue: (Z) => S(A)(Z, H) }, wt({ header: he(() => [Oe(Gl, Le(I.$props, { items: S(o)(H), instance: H, "show-year-picker": S(m)[H], year: S(c)(H), "is-disabled": (Z) => S(u)(H, Z), onHandleYear: (Z) => S(L)(H, Z), onYearSelect: (Z) => S(w)(Z, H), onToggleYearPicker: (Z) => S(D)(H, Z?.flow, Z?.show) }), wt({ _: 2 }, [rt(S(i), (Z, J) => ({ name: Z, fn: he((re) => [le(I.$slots, Z, bt(Ht(re)))]) }))]), 1040, ["items", "instance", "show-year-picker", "year", "is-disabled", "onHandleYear", "onYearSelect", "onToggleYearPicker"])]), _: 2 }, [I.$slots["month-overlay-value"] ? { name: "item", fn: he(({ item: Z }) => [le(I.$slots, "month-overlay-value", { text: Z.text, value: Z.value })]), key: "0" } : void 0]), 1032, ["items", "arrow-navigation", "is-last", "esc-close", "height", "config", "no-overlay-focus", "onSelected", "onHoverValue"]))]), _: 3 }, 8, ["multi-calendars", "collapse", "is-mobile"]));
} }), Xp = (t, e) => {
  const n = () => {
    t.isTextInputDate && (u.value = xe(de(t.startDate)));
  }, { modelValue: r } = Oa(t, e, n), a = se(null), { defaultedHighlight: i, defaultedMultiDates: s, defaultedFilters: l, defaultedRange: o, propDates: c } = dt(t), u = se();
  gt(() => {
    t.startDate && (r.value && t.focusStartDate || !r.value) && (u.value = xe(de(t.startDate)));
  });
  const T = (g) => Array.isArray(r.value) ? r.value.some((O) => xe(O) === g) : r.value ? xe(r.value) === g : false, f = (g) => o.value.enabled && Array.isArray(r.value) ? ga(r.value, a.value, A(g)) : false, m = (g) => c.value.allowedDates instanceof Map ? c.value.allowedDates.size ? c.value.allowedDates.has(`${g}`) : false : true, v = (g) => c.value.disabledDates instanceof Map ? c.value.disabledDates.size ? c.value.disabledDates.has(`${g}`) : false : true, E = Q(() => Wr(Qs(t.yearRange, t.locale, t.reverseYears), (g) => {
    const O = T(g.value), D = va(g.value, qr(c.value.minDate), qr(c.value.maxDate)) || l.value.years.includes(g.value) || !m(g.value) || v(g.value), w = f(g.value) && !O, L = ao(i.value, g.value);
    return { active: O, disabled: D, isBetween: w, highlighted: L };
  })), A = (g) => _n(Rn(pa(/* @__PURE__ */ new Date())), g);
  return { groupedYears: E, modelValue: r, focusYear: u, setHoverValue: (g) => {
    a.value = _n(Rn(/* @__PURE__ */ new Date()), g);
  }, selectYear: (g) => {
    var O;
    if (e("update-month-year", { instance: 0, year: g }), s.value.enabled) return r.value ? Array.isArray(r.value) && (((O = r.value) == null ? void 0 : O.map((D) => xe(D))).includes(g) ? r.value = r.value.filter((D) => xe(D) !== g) : r.value.push(_n(It(de()), g))) : r.value = [_n(It(pa(de())), g)], e("auto-apply", true);
    o.value.enabled ? (r.value = ho(r, A(g), e), Bt().then(() => {
      Yi(r.value, e, t.autoApply, t.modelAuto);
    })) : (r.value = A(g), e("auto-apply"));
  } };
}, eD = Ve({ compatConfig: { MODE: 3 }, __name: "YearPicker", props: { ...Nn }, emits: ["update:internal-model-value", "reset-flow", "range-start", "range-end", "auto-apply", "update-month-year"], setup(t, { expose: e, emit: n }) {
  const r = n, a = t, { groupedYears: i, modelValue: s, focusYear: l, selectYear: o, setHoverValue: c } = Xp(a, r), { defaultedConfig: u } = dt(a);
  return e({ getSidebarProps: () => ({ modelValue: s, selectYear: o }) }), (T, f) => (p(), M("div", null, [T.$slots["top-extra"] ? le(T.$slots, "top-extra", { key: 0, value: T.internalModelValue }) : x("", true), T.$slots["month-year"] ? le(T.$slots, "month-year", bt(Le({ key: 1 }, { years: S(i), selectYear: S(o) }))) : (p(), De(Na, { key: 2, items: S(i), "is-last": T.autoApply && !S(u).keepActionRow, height: S(u).modeHeight, config: T.config, "no-overlay-focus": !!(T.noOverlayFocus || T.textInput), "focus-value": S(l), type: "year", "use-relative": "", onSelected: S(o), onHoverValue: S(c) }, wt({ _: 2 }, [T.$slots["year-overlay-value"] ? { name: "item", fn: he(({ item: m }) => [le(T.$slots, "year-overlay-value", { text: m.text, value: m.value })]), key: "0" } : void 0]), 1032, ["items", "is-last", "height", "config", "no-overlay-focus", "focus-value", "onSelected", "onHoverValue"]))]));
} }), tD = { key: 0, class: "dp__time_input" }, nD = ["data-compact", "data-collapsed"], rD = ["data-test-id", "aria-label", "onKeydown", "onClick", "onMousedown"], aD = ["aria-label", "disabled", "data-test-id", "onKeydown", "onClick"], iD = ["data-test-id", "aria-label", "onKeydown", "onClick", "onMousedown"], sD = { key: 0 }, oD = ["aria-label", "data-compact"], lD = Ve({ compatConfig: { MODE: 3 }, __name: "TimeInput", props: { hours: { type: Number, default: 0 }, minutes: { type: Number, default: 0 }, seconds: { type: Number, default: 0 }, closeTimePickerBtn: { type: Object, default: null }, order: { type: Number, default: 0 }, disabledTimesConfig: { type: Function, default: null }, validateTime: { type: Function, default: () => false }, ...Nn }, emits: ["set-hours", "set-minutes", "update:hours", "update:minutes", "update:seconds", "reset-flow", "mounted", "overlay-closed", "overlay-opened", "am-pm-change"], setup(t, { expose: e, emit: n }) {
  const r = n, a = t, { setTimePickerElements: i, setTimePickerBackRef: s } = or(), { defaultedAriaLabels: l, defaultedTransitions: o, defaultedFilters: c, defaultedConfig: u, defaultedRange: T, defaultedMultiCalendars: f } = dt(a), { transitionName: m, showTransition: v } = ya(o), E = na({ hours: false, minutes: false, seconds: false }), A = se("AM"), g = se(null), O = se([]), D = se(), w = se(false);
  gt(() => {
    r("mounted");
  });
  const L = (R) => it(/* @__PURE__ */ new Date(), { hours: R.hours, minutes: R.minutes, seconds: a.enableSeconds ? R.seconds : 0, milliseconds: 0 }), _ = Q(() => (R) => ee(R, a[R]) || V(R, a[R])), I = Q(() => ({ hours: a.hours, minutes: a.minutes, seconds: a.seconds })), V = (R, me) => T.value.enabled && !T.value.disableTimeRangeValidation ? !a.validateTime(R, me) : false, H = (R, me) => {
    if (T.value.enabled && !T.value.disableTimeRangeValidation) {
      const Se = me ? +a[`${R}Increment`] : -+a[`${R}Increment`], ve = a[R] + Se;
      return !a.validateTime(R, ve);
    }
    return false;
  }, Z = Q(() => (R) => !z(+a[R] + +a[`${R}Increment`], R) || H(R, true)), J = Q(() => (R) => !z(+a[R] - +a[`${R}Increment`], R) || H(R, false)), re = (R, me) => z0(it(de(), R), me), oe = (R, me) => ep(it(de(), R), me), b = Q(() => ({ dp__time_col: true, dp__time_col_block: !a.timePickerInline, dp__time_col_reg_block: !a.enableSeconds && a.is24 && !a.timePickerInline, dp__time_col_reg_inline: !a.enableSeconds && a.is24 && a.timePickerInline, dp__time_col_reg_with_button: !a.enableSeconds && !a.is24, dp__time_col_sec: a.enableSeconds && a.is24, dp__time_col_sec_with_button: a.enableSeconds && !a.is24 })), P = Q(() => a.timePickerInline && T.value.enabled && !f.value.count), k = Q(() => {
    const R = [{ type: "hours" }];
    return a.enableMinutes && R.push({ type: "", separator: true }, { type: "minutes" }), a.enableSeconds && R.push({ type: "", separator: true }, { type: "seconds" }), R;
  }), te = Q(() => k.value.filter((R) => !R.separator)), Ee = Q(() => (R) => {
    if (R === "hours") {
      const me = ne(+a.hours);
      return { text: me < 10 ? `0${me}` : `${me}`, value: me };
    }
    return { text: a[R] < 10 ? `0${a[R]}` : `${a[R]}`, value: a[R] };
  }), ee = (R, me) => {
    var Se;
    if (!a.disabledTimesConfig) return false;
    const ve = a.disabledTimesConfig(a.order, R === "hours" ? me : void 0);
    return ve[R] ? !!((Se = ve[R]) != null && Se.includes(me)) : true;
  }, Ae = (R, me) => me !== "hours" || A.value === "AM" ? R : R + 12, $ = (R) => {
    const me = a.is24 ? 24 : 12, Se = R === "hours" ? me : 60, ve = +a[`${R}GridIncrement`], ze = R === "hours" && !a.is24 ? ve : 0, Ue = [];
    for (let We = ze; We < Se; We += ve) Ue.push({ value: a.is24 ? We : Ae(We, R), text: We < 10 ? `0${We}` : `${We}` });
    return R === "hours" && !a.is24 && Ue.unshift({ value: A.value === "PM" ? 12 : 0, text: "12" }), Wr(Ue, (We) => ({ active: false, disabled: c.value.times[R].includes(We.value) || !z(We.value, R) || ee(R, We.value) || V(R, We.value) }));
  }, Me = (R) => R >= 0 ? R : 59, B = (R) => R >= 0 ? R : 23, z = (R, me) => {
    const Se = a.minTime ? L(Xs(a.minTime)) : null, ve = a.maxTime ? L(Xs(a.maxTime)) : null, ze = L(Xs(I.value, me, me === "minutes" || me === "seconds" ? Me(R) : B(R)));
    return Se && ve ? (zr(ze, ve) || jr(ze, ve)) && (yr(ze, Se) || jr(ze, Se)) : Se ? yr(ze, Se) || jr(ze, Se) : ve ? zr(ze, ve) || jr(ze, ve) : true;
  }, W = (R) => a[`no${R[0].toUpperCase() + R.slice(1)}Overlay`], ie = (R) => {
    W(R) || (E[R] = !E[R], E[R] ? (w.value = true, r("overlay-opened", R)) : (w.value = false, r("overlay-closed", R)));
  }, h = (R) => R === "hours" ? Gn : R === "minutes" ? rr : Gr, F = () => {
    D.value && clearTimeout(D.value);
  }, U = (R, me = true, Se) => {
    const ve = me ? re : oe, ze = me ? +a[`${R}Increment`] : -+a[`${R}Increment`];
    z(+a[R] + ze, R) && r(`update:${R}`, h(R)(ve({ [R]: +a[R] }, { [R]: +a[`${R}Increment`] }))), !(Se != null && Se.keyboard) && u.value.timeArrowHoldThreshold && (D.value = setTimeout(() => {
      U(R, me);
    }, u.value.timeArrowHoldThreshold));
  }, ne = (R) => a.is24 ? R : (R >= 12 ? A.value = "PM" : A.value = "AM", op(R)), Y = () => {
    A.value === "PM" ? (A.value = "AM", r("update:hours", a.hours - 12)) : (A.value = "PM", r("update:hours", a.hours + 12)), r("am-pm-change", A.value);
  }, pe = (R) => {
    E[R] = true;
  }, q = (R, me, Se) => {
    if (R && a.arrowNavigation) {
      Array.isArray(O.value[me]) ? O.value[me][Se] = R : O.value[me] = [R];
      const ve = O.value.reduce((ze, Ue) => Ue.map((We, ht) => [...ze[ht] || [], Ue[ht]]), []);
      s(a.closeTimePickerBtn), g.value && (ve[1] = ve[1].concat(g.value)), i(ve, a.order);
    }
  }, Te = (R, me) => (ie(R), r(`update:${R}`, me));
  return e({ openChildCmp: pe }), (R, me) => {
    var Se;
    return R.disabled ? x("", true) : (p(), M("div", tD, [(p(true), M(He, null, rt(k.value, (ve, ze) => {
      var Ue, We, ht;
      return p(), M("div", { key: ze, class: ye(b.value), "data-compact": P.value && !R.enableSeconds, "data-collapsed": P.value && R.enableSeconds }, [ve.separator ? (p(), M(He, { key: 0 }, [w.value ? x("", true) : (p(), M(He, { key: 0 }, [Mt(":")], 64))], 64)) : (p(), M(He, { key: 1 }, [j("button", { ref_for: true, ref: (G) => q(G, ze, 0), type: "button", class: ye({ dp__btn: true, dp__inc_dec_button: !R.timePickerInline, dp__inc_dec_button_inline: R.timePickerInline, dp__tp_inline_btn_top: R.timePickerInline, dp__inc_dec_button_disabled: Z.value(ve.type), "dp--hidden-el": w.value }), "data-test-id": `${ve.type}-time-inc-btn-${a.order}`, "aria-label": (Ue = S(l)) == null ? void 0 : Ue.incrementValue(ve.type), tabindex: "0", onKeydown: (G) => S(Qt)(G, () => U(ve.type, true, { keyboard: true }), true), onClick: (G) => S(u).timeArrowHoldThreshold ? void 0 : U(ve.type, true), onMousedown: (G) => S(u).timeArrowHoldThreshold ? U(ve.type, true) : void 0, onMouseup: F }, [a.timePickerInline ? (p(), M(He, { key: 1 }, [R.$slots["tp-inline-arrow-up"] ? le(R.$slots, "tp-inline-arrow-up", { key: 0 }) : (p(), M(He, { key: 1 }, [me[2] || (me[2] = j("span", { class: "dp__tp_inline_btn_bar dp__tp_btn_in_l" }, null, -1)), me[3] || (me[3] = j("span", { class: "dp__tp_inline_btn_bar dp__tp_btn_in_r" }, null, -1))], 64))], 64)) : (p(), M(He, { key: 0 }, [R.$slots["arrow-up"] ? le(R.$slots, "arrow-up", { key: 0 }) : x("", true), R.$slots["arrow-up"] ? x("", true) : (p(), De(S(zs), { key: 1 }))], 64))], 42, rD), j("button", { ref_for: true, ref: (G) => q(G, ze, 1), type: "button", "aria-label": `${Ee.value(ve.type).text}-${(We = S(l)) == null ? void 0 : We.openTpOverlay(ve.type)}`, class: ye({ dp__time_display: true, dp__time_display_block: !R.timePickerInline, dp__time_display_inline: R.timePickerInline, "dp--time-invalid": _.value(ve.type), "dp--time-overlay-btn": !_.value(ve.type), "dp--hidden-el": w.value }), disabled: W(ve.type), tabindex: "0", "data-test-id": `${ve.type}-toggle-overlay-btn-${a.order}`, onKeydown: (G) => S(Qt)(G, () => ie(ve.type), true), onClick: (G) => ie(ve.type) }, [R.$slots[ve.type] ? le(R.$slots, ve.type, { key: 0, text: Ee.value(ve.type).text, value: Ee.value(ve.type).value }) : x("", true), R.$slots[ve.type] ? x("", true) : (p(), M(He, { key: 1 }, [Mt(Be(Ee.value(ve.type).text), 1)], 64))], 42, aD), j("button", { ref_for: true, ref: (G) => q(G, ze, 2), type: "button", class: ye({ dp__btn: true, dp__inc_dec_button: !R.timePickerInline, dp__inc_dec_button_inline: R.timePickerInline, dp__tp_inline_btn_bottom: R.timePickerInline, dp__inc_dec_button_disabled: J.value(ve.type), "dp--hidden-el": w.value }), "data-test-id": `${ve.type}-time-dec-btn-${a.order}`, "aria-label": (ht = S(l)) == null ? void 0 : ht.decrementValue(ve.type), tabindex: "0", onKeydown: (G) => S(Qt)(G, () => U(ve.type, false, { keyboard: true }), true), onClick: (G) => S(u).timeArrowHoldThreshold ? void 0 : U(ve.type, false), onMousedown: (G) => S(u).timeArrowHoldThreshold ? U(ve.type, false) : void 0, onMouseup: F }, [a.timePickerInline ? (p(), M(He, { key: 1 }, [R.$slots["tp-inline-arrow-down"] ? le(R.$slots, "tp-inline-arrow-down", { key: 0 }) : (p(), M(He, { key: 1 }, [me[4] || (me[4] = j("span", { class: "dp__tp_inline_btn_bar dp__tp_btn_in_l" }, null, -1)), me[5] || (me[5] = j("span", { class: "dp__tp_inline_btn_bar dp__tp_btn_in_r" }, null, -1))], 64))], 64)) : (p(), M(He, { key: 0 }, [R.$slots["arrow-down"] ? le(R.$slots, "arrow-down", { key: 0 }) : x("", true), R.$slots["arrow-down"] ? x("", true) : (p(), De(S(js), { key: 1 }))], 64))], 42, iD)], 64))], 10, nD);
    }), 128)), R.is24 ? x("", true) : (p(), M("div", sD, [R.$slots["am-pm-button"] ? le(R.$slots, "am-pm-button", { key: 0, toggle: Y, value: A.value }) : x("", true), R.$slots["am-pm-button"] ? x("", true) : (p(), M("button", { key: 1, ref_key: "amPmButton", ref: g, type: "button", class: "dp__pm_am_button", role: "button", "aria-label": (Se = S(l)) == null ? void 0 : Se.amPmButton, tabindex: "0", "data-compact": P.value, onClick: Y, onKeydown: me[0] || (me[0] = (ve) => S(Qt)(ve, () => Y(), true)) }, Be(A.value), 41, oD))])), (p(true), M(He, null, rt(te.value, (ve, ze) => (p(), De(qn, { key: ze, name: S(m)(E[ve.type]), css: S(v) }, { default: he(() => {
      var Ue, We;
      return [E[ve.type] ? (p(), De(Na, { key: 0, items: $(ve.type), "is-last": R.autoApply && !S(u).keepActionRow, "esc-close": R.escClose, type: ve.type, "text-input": R.textInput, config: R.config, "arrow-navigation": R.arrowNavigation, "aria-labels": R.ariaLabels, "overlay-label": (We = (Ue = S(l)).timeOverlay) == null ? void 0 : We.call(Ue, ve.type), onSelected: (ht) => Te(ve.type, ht), onToggle: (ht) => ie(ve.type), onResetFlow: me[1] || (me[1] = (ht) => R.$emit("reset-flow")) }, wt({ "button-icon": he(() => [R.$slots["clock-icon"] ? le(R.$slots, "clock-icon", { key: 0 }) : x("", true), R.$slots["clock-icon"] ? x("", true) : (p(), De(pr(R.timePickerInline ? S(Vr) : S(Gs)), { key: 1 }))]), _: 2 }, [R.$slots[`${ve.type}-overlay-value`] ? { name: "item", fn: he(({ item: ht }) => [le(R.$slots, `${ve.type}-overlay-value`, { text: ht.text, value: ht.value })]), key: "0" } : void 0, R.$slots[`${ve.type}-overlay-header`] ? { name: "header", fn: he(() => [le(R.$slots, `${ve.type}-overlay-header`, { toggle: () => ie(ve.type) })]), key: "1" } : void 0]), 1032, ["items", "is-last", "esc-close", "type", "text-input", "config", "arrow-navigation", "aria-labels", "overlay-label", "onSelected", "onToggle"])) : x("", true)];
    }), _: 2 }, 1032, ["name", "css"]))), 128))]));
  };
} }), uD = ["data-dp-mobile"], cD = ["aria-label", "tabindex"], TD = ["role", "aria-label", "tabindex"], dD = ["aria-label"], Vl = Ve({ compatConfig: { MODE: 3 }, __name: "TimePicker", props: { hours: { type: [Number, Array], default: 0 }, minutes: { type: [Number, Array], default: 0 }, seconds: { type: [Number, Array], default: 0 }, disabledTimesConfig: { type: Function, default: null }, validateTime: { type: Function, default: () => false }, ...Nn }, emits: ["update:hours", "update:minutes", "update:seconds", "mount", "reset-flow", "overlay-opened", "overlay-closed", "am-pm-change"], setup(t, { expose: e, emit: n }) {
  const r = n, a = t, { buildMatrix: i, setTimePicker: s } = or(), l = mn(), { defaultedTransitions: o, defaultedAriaLabels: c, defaultedTextInput: u, defaultedConfig: T, defaultedRange: f } = dt(a), { transitionName: m, showTransition: v } = ya(o), { hideNavigationButtons: E } = wi(), A = se(null), g = se(null), O = se([]), D = se(null), w = se(false);
  gt(() => {
    r("mount"), !a.timePicker && a.arrowNavigation ? i([Yt(A.value)], "time") : s(true, a.timePicker);
  });
  const L = Q(() => f.value.enabled && a.modelAuto ? Rl(a.internalModelValue) : true), _ = se(false), I = (ee) => ({ hours: Array.isArray(a.hours) ? a.hours[ee] : a.hours, minutes: Array.isArray(a.minutes) ? a.minutes[ee] : a.minutes, seconds: Array.isArray(a.seconds) ? a.seconds[ee] : a.seconds }), V = Q(() => {
    const ee = [];
    if (f.value.enabled) for (let Ae = 0; Ae < 2; Ae++) ee.push(I(Ae));
    else ee.push(I(0));
    return ee;
  }), H = (ee, Ae = false, $ = "") => {
    Ae || r("reset-flow"), _.value = ee, r(ee ? "overlay-opened" : "overlay-closed", Pt.time), a.arrowNavigation && s(ee), Bt(() => {
      $ !== "" && O.value[0] && O.value[0].openChildCmp($);
    });
  }, Z = Q(() => ({ dp__btn: true, dp__button: true, dp__button_bottom: a.autoApply && !T.value.keepActionRow })), J = sn(l, "timePicker"), re = (ee, Ae, $) => f.value.enabled ? Ae === 0 ? [ee, V.value[1][$]] : [V.value[0][$], ee] : ee, oe = (ee) => {
    r("update:hours", ee);
  }, b = (ee) => {
    r("update:minutes", ee);
  }, P = (ee) => {
    r("update:seconds", ee);
  }, k = () => {
    if (D.value && !u.value.enabled && !a.noOverlayFocus) {
      const ee = yl(D.value);
      ee && ee.focus({ preventScroll: true });
    }
  }, te = (ee) => {
    w.value = false, r("overlay-closed", ee);
  }, Ee = (ee) => {
    w.value = true, r("overlay-opened", ee);
  };
  return e({ toggleTimePicker: H }), (ee, Ae) => {
    var $;
    return p(), M("div", { class: "dp--tp-wrap", "data-dp-mobile": ee.isMobile }, [!ee.timePicker && !ee.timePickerInline ? Ot((p(), M("button", { key: 0, ref_key: "openTimePickerBtn", ref: A, type: "button", class: ye({ ...Z.value, "dp--hidden-el": _.value }), "aria-label": ($ = S(c)) == null ? void 0 : $.openTimePicker, tabindex: ee.noOverlayFocus ? void 0 : 0, "data-test-id": "open-time-picker-btn", onKeydown: Ae[0] || (Ae[0] = (Me) => S(Qt)(Me, () => H(true))), onClick: Ae[1] || (Ae[1] = (Me) => H(true)) }, [ee.$slots["clock-icon"] ? le(ee.$slots, "clock-icon", { key: 0 }) : x("", true), ee.$slots["clock-icon"] ? x("", true) : (p(), De(S(Gs), { key: 1 }))], 42, cD)), [[Kt, !S(E)(ee.hideNavigation, "time")]]) : x("", true), Oe(qn, { name: S(m)(_.value), css: S(v) && !ee.timePickerInline }, { default: he(() => {
      var Me, B;
      return [_.value || ee.timePicker || ee.timePickerInline ? (p(), M("div", { key: 0, ref_key: "overlayRef", ref: D, role: ee.timePickerInline ? void 0 : "dialog", class: ye({ dp__overlay: !ee.timePickerInline, "dp--overlay-absolute": !a.timePicker && !ee.timePickerInline, "dp--overlay-relative": a.timePicker }), style: Tt(ee.timePicker ? { height: `${S(T).modeHeight}px` } : void 0), "aria-label": (Me = S(c)) == null ? void 0 : Me.timePicker, tabindex: ee.timePickerInline ? void 0 : 0 }, [j("div", { class: ye(ee.timePickerInline ? "dp__time_picker_inline_container" : "dp__overlay_container dp__container_flex dp__time_picker_overlay_container"), style: { display: "flex" } }, [ee.$slots["time-picker-overlay"] ? le(ee.$slots, "time-picker-overlay", { key: 0, hours: t.hours, minutes: t.minutes, seconds: t.seconds, setHours: oe, setMinutes: b, setSeconds: P }) : x("", true), ee.$slots["time-picker-overlay"] ? x("", true) : (p(), M("div", { key: 1, class: ye(ee.timePickerInline ? "dp__flex" : "dp__overlay_row dp__flex_row") }, [(p(true), M(He, null, rt(V.value, (z, W) => Ot((p(), De(lD, Le({ key: W, ref_for: true }, { ...ee.$props, order: W, hours: z.hours, minutes: z.minutes, seconds: z.seconds, closeTimePickerBtn: g.value, disabledTimesConfig: t.disabledTimesConfig, disabled: W === 0 ? S(f).fixedStart : S(f).fixedEnd }, { ref_for: true, ref_key: "timeInputRefs", ref: O, "validate-time": (ie, h) => t.validateTime(ie, re(h, W, ie)), "onUpdate:hours": (ie) => oe(re(ie, W, "hours")), "onUpdate:minutes": (ie) => b(re(ie, W, "minutes")), "onUpdate:seconds": (ie) => P(re(ie, W, "seconds")), onMounted: k, onOverlayClosed: te, onOverlayOpened: Ee, onAmPmChange: Ae[2] || (Ae[2] = (ie) => ee.$emit("am-pm-change", ie)) }), wt({ _: 2 }, [rt(S(J), (ie, h) => ({ name: ie, fn: he((F) => [le(ee.$slots, ie, Le({ ref_for: true }, F))]) }))]), 1040, ["validate-time", "onUpdate:hours", "onUpdate:minutes", "onUpdate:seconds"])), [[Kt, W === 0 ? true : L.value]])), 128))], 2)), !ee.timePicker && !ee.timePickerInline ? Ot((p(), M("button", { key: 2, ref_key: "closeTimePickerBtn", ref: g, type: "button", class: ye({ ...Z.value, "dp--hidden-el": w.value }), "aria-label": (B = S(c)) == null ? void 0 : B.closeTimePicker, tabindex: "0", onKeydown: Ae[3] || (Ae[3] = (z) => S(Qt)(z, () => H(false))), onClick: Ae[4] || (Ae[4] = (z) => H(false)) }, [ee.$slots["calendar-icon"] ? le(ee.$slots, "calendar-icon", { key: 0 }) : x("", true), ee.$slots["calendar-icon"] ? x("", true) : (p(), De(S(Vr), { key: 1 }))], 42, dD)), [[Kt, !S(E)(ee.hideNavigation, "time")]]) : x("", true)], 2)], 14, TD)) : x("", true)];
    }), _: 3 }, 8, ["name", "css"])], 8, uD);
  };
} }), Ql = (t, e, n, r) => {
  const { defaultedRange: a } = dt(t), i = (D, w) => Array.isArray(e[D]) ? e[D][w] : e[D], s = (D) => t.enableSeconds ? Array.isArray(e.seconds) ? e.seconds[D] : e.seconds : 0, l = (D, w) => D ? w !== void 0 ? ir(D, i("hours", w), i("minutes", w), s(w)) : ir(D, e.hours, e.minutes, s()) : pl(de(), s(w)), o = (D, w) => {
    e[D] = w;
  }, c = Q(() => t.modelAuto && a.value.enabled ? Array.isArray(n.value) ? n.value.length > 1 : false : a.value.enabled), u = (D, w) => {
    const L = Object.fromEntries(Object.keys(e).map((_) => _ === D ? [_, w] : [_, e[_]].slice()));
    if (c.value && !a.value.disableTimeRangeValidation) {
      const _ = (V) => n.value ? ir(n.value[V], L.hours[V], L.minutes[V], L.seconds[V]) : null, I = (V) => El(n.value[V], 0);
      return !($e(_(0), _(1)) && (yr(_(0), I(1)) || zr(_(1), I(0))));
    }
    return true;
  }, T = (D, w) => {
    u(D, w) && (o(D, w), r && r());
  }, f = (D) => {
    T("hours", D);
  }, m = (D) => {
    T("minutes", D);
  }, v = (D) => {
    T("seconds", D);
  }, E = (D, w, L, _) => {
    w && f(D), !w && !L && m(D), L && v(D), n.value && _(n.value);
  }, A = (D) => {
    if (D) {
      const w = Array.isArray(D), L = w ? [+D[0].hours, +D[1].hours] : +D.hours, _ = w ? [+D[0].minutes, +D[1].minutes] : +D.minutes, I = w ? [+D[0].seconds, +D[1].seconds] : +D.seconds;
      o("hours", L), o("minutes", _), t.enableSeconds && o("seconds", I);
    }
  }, g = (D, w) => {
    const L = { hours: Array.isArray(e.hours) ? e.hours[D] : e.hours, disabledArr: [] };
    return (w || w === 0) && (L.hours = w), Array.isArray(t.disabledTimes) && (L.disabledArr = a.value.enabled && Array.isArray(t.disabledTimes[D]) ? t.disabledTimes[D] : t.disabledTimes), L;
  }, O = Q(() => (D, w) => {
    var L;
    if (Array.isArray(t.disabledTimes)) {
      const { disabledArr: _, hours: I } = g(D, w), V = _.filter((H) => +H.hours === I);
      return ((L = V[0]) == null ? void 0 : L.minutes) === "*" ? { hours: [I], minutes: void 0, seconds: void 0 } : { hours: [], minutes: V?.map((H) => +H.minutes) ?? [], seconds: V?.map((H) => H.seconds ? +H.seconds : void 0) ?? [] };
    }
    return { hours: [], minutes: [], seconds: [] };
  });
  return { setTime: o, updateHours: f, updateMinutes: m, updateSeconds: v, getSetDateTime: l, updateTimeValues: E, getSecondsValue: s, assignStartTime: A, validateTime: u, disabledTimesConfig: O };
}, hD = (t, e) => {
  const n = () => {
    t.isTextInputDate && w();
  }, { modelValue: r, time: a } = Oa(t, e, n), { defaultedStartTime: i, defaultedRange: s, defaultedTz: l } = dt(t), { updateTimeValues: o, getSetDateTime: c, setTime: u, assignStartTime: T, disabledTimesConfig: f, validateTime: m } = Ql(t, a, r, v);
  function v() {
    e("update-flow-step");
  }
  const E = (_) => {
    const { hours: I, minutes: V, seconds: H } = _;
    return { hours: +I, minutes: +V, seconds: H ? +H : 0 };
  }, A = () => {
    if (t.startTime) {
      if (Array.isArray(t.startTime)) {
        const I = E(t.startTime[0]), V = E(t.startTime[1]);
        return [it(de(), I), it(de(), V)];
      }
      const _ = E(t.startTime);
      return it(de(), _);
    }
    return s.value.enabled ? [null, null] : null;
  }, g = () => {
    if (s.value.enabled) {
      const [_, I] = A();
      r.value = [Xt(c(_, 0), l.value.timezone), Xt(c(I, 1), l.value.timezone)];
    } else r.value = Xt(c(A()), l.value.timezone);
  }, O = (_) => Array.isArray(_) ? [Mr(de(_[0])), Mr(de(_[1]))] : [Mr(_ ?? de())], D = (_, I, V) => {
    u("hours", _), u("minutes", I), u("seconds", t.enableSeconds ? V : 0);
  }, w = () => {
    const [_, I] = O(r.value);
    return s.value.enabled ? D([_.hours, I.hours], [_.minutes, I.minutes], [_.seconds, I.seconds]) : D(_.hours, _.minutes, _.seconds);
  };
  gt(() => {
    if (!t.shadow) return T(i.value), r.value ? w() : g();
  });
  const L = () => {
    Array.isArray(r.value) ? r.value = r.value.map((_, I) => _ && c(_, I)) : r.value = c(r.value), e("time-update");
  };
  return { modelValue: r, time: a, disabledTimesConfig: f, updateTime: (_, I = true, V = false) => {
    o(_, I, V, L);
  }, validateTime: m };
}, fD = Ve({ compatConfig: { MODE: 3 }, __name: "TimePickerSolo", props: { ...Nn }, emits: ["update:internal-model-value", "time-update", "am-pm-change", "mount", "reset-flow", "update-flow-step", "overlay-toggle"], setup(t, { expose: e, emit: n }) {
  const r = n, a = t, i = mn(), s = sn(i, "timePicker"), l = se(null), { time: o, modelValue: c, disabledTimesConfig: u, updateTime: T, validateTime: f } = hD(a, r);
  return gt(() => {
    a.shadow || r("mount", null);
  }), e({ getSidebarProps: () => ({ modelValue: c, time: o, updateTime: T }), toggleTimePicker: (m, v = false, E = "") => {
    var A;
    (A = l.value) == null || A.toggleTimePicker(m, v, E);
  } }), (m, v) => (p(), De(bi, { "multi-calendars": 0, stretch: "", "is-mobile": m.isMobile }, { default: he(() => [Oe(Vl, Le({ ref_key: "tpRef", ref: l }, m.$props, { hours: S(o).hours, minutes: S(o).minutes, seconds: S(o).seconds, "internal-model-value": m.internalModelValue, "disabled-times-config": S(u), "validate-time": S(f), "onUpdate:hours": v[0] || (v[0] = (E) => S(T)(E)), "onUpdate:minutes": v[1] || (v[1] = (E) => S(T)(E, false)), "onUpdate:seconds": v[2] || (v[2] = (E) => S(T)(E, false, true)), onAmPmChange: v[3] || (v[3] = (E) => m.$emit("am-pm-change", E)), onResetFlow: v[4] || (v[4] = (E) => m.$emit("reset-flow")), onOverlayClosed: v[5] || (v[5] = (E) => m.$emit("overlay-toggle", { open: false, overlay: E })), onOverlayOpened: v[6] || (v[6] = (E) => m.$emit("overlay-toggle", { open: true, overlay: E })) }), wt({ _: 2 }, [rt(S(s), (E, A) => ({ name: E, fn: he((g) => [le(m.$slots, E, bt(Ht(g)))]) }))]), 1040, ["hours", "minutes", "seconds", "internal-model-value", "disabled-times-config", "validate-time"])]), _: 3 }, 8, ["is-mobile"]));
} }), AD = { class: "dp--header-wrap" }, mD = { key: 0, class: "dp__month_year_wrap" }, ED = { key: 0 }, pD = { class: "dp__month_year_wrap" }, DD = ["data-dp-element", "aria-label", "data-test-id", "onClick", "onKeydown"], SD = Ve({ compatConfig: { MODE: 3 }, __name: "DpHeader", props: { month: { type: Number, default: 0 }, year: { type: Number, default: 0 }, instance: { type: Number, default: 0 }, years: { type: Array, default: () => [] }, months: { type: Array, default: () => [] }, ...Nn }, emits: ["update-month-year", "mount", "reset-flow", "overlay-closed", "overlay-opened"], setup(t, { expose: e, emit: n }) {
  const r = n, a = t, { defaultedTransitions: i, defaultedAriaLabels: s, defaultedMultiCalendars: l, defaultedFilters: o, defaultedConfig: c, defaultedHighlight: u, propDates: T, defaultedUI: f } = dt(a), { transitionName: m, showTransition: v } = ya(i), { buildMatrix: E } = or(), { handleMonthYearChange: A, isDisabled: g, updateMonthYear: O } = Hp(a, r), { showLeftIcon: D, showRightIcon: w } = wi(), L = se(false), _ = se(false), I = se(false), V = se([null, null, null, null]);
  gt(() => {
    r("mount");
  });
  const H = (B) => ({ get: () => a[B], set: (z) => {
    const W = B === vn.month ? vn.year : vn.month;
    r("update-month-year", { [B]: z, [W]: a[W] }), B === vn.month ? te(true) : Ee(true);
  } }), Z = Q(H(vn.month)), J = Q(H(vn.year)), re = Q(() => (B) => ({ month: a.month, year: a.year, items: B === vn.month ? a.months : a.years, instance: a.instance, updateMonthYear: O, toggle: B === vn.month ? te : Ee })), oe = Q(() => a.months.find((z) => z.value === a.month) || { text: "", value: 0 }), b = Q(() => Wr(a.months, (B) => {
    const z = a.month === B.value, W = va(B.value, wl(a.year, T.value.minDate), _l(a.year, T.value.maxDate)) || o.value.months.includes(B.value), ie = Cl(u.value, B.value, a.year);
    return { active: z, disabled: W, highlighted: ie };
  })), P = Q(() => Wr(a.years, (B) => {
    const z = a.year === B.value, W = va(B.value, qr(T.value.minDate), qr(T.value.maxDate)) || o.value.years.includes(B.value), ie = ao(u.value, B.value);
    return { active: z, disabled: W, highlighted: ie };
  })), k = (B, z, W) => {
    W !== void 0 ? B.value = W : B.value = !B.value, B.value ? (I.value = true, r("overlay-opened", z)) : (I.value = false, r("overlay-closed", z));
  }, te = (B = false, z) => {
    ee(B), k(L, Pt.month, z);
  }, Ee = (B = false, z) => {
    ee(B), k(_, Pt.year, z);
  }, ee = (B) => {
    B || r("reset-flow");
  }, Ae = (B, z) => {
    a.arrowNavigation && (V.value[z] = Yt(B), E(V.value, "monthYear"));
  }, $ = Q(() => {
    var B, z, W, ie, h, F;
    return [{ type: vn.month, index: 1, toggle: te, modelValue: Z.value, updateModelValue: (U) => Z.value = U, text: oe.value.text, showSelectionGrid: L.value, items: b.value, ariaLabel: (B = s.value) == null ? void 0 : B.openMonthsOverlay, overlayLabel: ((W = (z = s.value).monthPicker) == null ? void 0 : W.call(z, true)) ?? void 0 }, { type: vn.year, index: 2, toggle: Ee, modelValue: J.value, updateModelValue: (U) => J.value = U, text: Ol(a.year, a.locale), showSelectionGrid: _.value, items: P.value, ariaLabel: (ie = s.value) == null ? void 0 : ie.openYearsOverlay, overlayLabel: ((F = (h = s.value).yearPicker) == null ? void 0 : F.call(h, true)) ?? void 0 }];
  }), Me = Q(() => a.disableYearSelect ? [$.value[0]] : a.yearFirst ? [...$.value].reverse() : $.value);
  return e({ toggleMonthPicker: te, toggleYearPicker: Ee, handleMonthYearChange: A }), (B, z) => {
    var W, ie, h, F, U, ne;
    return p(), M("div", AD, [B.$slots["month-year"] ? (p(), M("div", mD, [le(B.$slots, "month-year", bt(Ht({ month: t.month, year: t.year, months: t.months, years: t.years, updateMonthYear: S(O), handleMonthYearChange: S(A), instance: t.instance, isDisabled: S(g) })))])) : (p(), M(He, { key: 1 }, [B.$slots["top-extra"] ? (p(), M("div", ED, [le(B.$slots, "top-extra", { value: B.internalModelValue })])) : x("", true), j("div", pD, [S(D)(S(l), t.instance) && !B.vertical ? (p(), De(Fa, { key: 0, "aria-label": (W = S(s)) == null ? void 0 : W.prevMonth, disabled: S(g)(false), class: ye((ie = S(f)) == null ? void 0 : ie.navBtnPrev), "el-name": "action-prev", onActivate: z[0] || (z[0] = (Y) => S(A)(false, true)), onSetRef: z[1] || (z[1] = (Y) => Ae(Y, 0)) }, { default: he(() => [B.$slots["arrow-left"] ? le(B.$slots, "arrow-left", { key: 0 }) : x("", true), B.$slots["arrow-left"] ? x("", true) : (p(), De(S(Ps), { key: 1 }))]), _: 3 }, 8, ["aria-label", "disabled", "class"])) : x("", true), j("div", { class: ye(["dp__month_year_wrap", { dp__year_disable_select: B.disableYearSelect }]) }, [(p(true), M(He, null, rt(Me.value, (Y, pe) => (p(), M(He, { key: Y.type }, [j("button", { ref_for: true, ref: (q) => Ae(q, pe + 1), type: "button", "data-dp-element": `overlay-${Y.type}`, class: ye(["dp__btn dp__month_year_select", { "dp--hidden-el": I.value }]), "aria-label": `${Y.text}-${Y.ariaLabel}`, "data-test-id": `${Y.type}-toggle-overlay-${t.instance}`, onClick: Y.toggle, onKeydown: (q) => S(Qt)(q, () => Y.toggle(), true) }, [B.$slots[Y.type] ? le(B.$slots, Y.type, { key: 0, text: Y.text, value: a[Y.type] }) : x("", true), B.$slots[Y.type] ? x("", true) : (p(), M(He, { key: 1 }, [Mt(Be(Y.text), 1)], 64))], 42, DD), Oe(qn, { name: S(m)(Y.showSelectionGrid), css: S(v) }, { default: he(() => [Y.showSelectionGrid ? (p(), De(Na, { key: 0, items: Y.items, "arrow-navigation": B.arrowNavigation, "hide-navigation": B.hideNavigation, "is-last": B.autoApply && !S(c).keepActionRow, "skip-button-ref": false, config: B.config, type: Y.type, "header-refs": [], "esc-close": B.escClose, "menu-wrap-ref": B.menuWrapRef, "text-input": B.textInput, "aria-labels": B.ariaLabels, "overlay-label": Y.overlayLabel, onSelected: Y.updateModelValue, onToggle: Y.toggle }, wt({ "button-icon": he(() => [B.$slots["calendar-icon"] ? le(B.$slots, "calendar-icon", { key: 0 }) : x("", true), B.$slots["calendar-icon"] ? x("", true) : (p(), De(S(Vr), { key: 1 }))]), _: 2 }, [B.$slots[`${Y.type}-overlay-value`] ? { name: "item", fn: he(({ item: q }) => [le(B.$slots, `${Y.type}-overlay-value`, { text: q.text, value: q.value })]), key: "0" } : void 0, B.$slots[`${Y.type}-overlay`] ? { name: "overlay", fn: he(() => [le(B.$slots, `${Y.type}-overlay`, Le({ ref_for: true }, re.value(Y.type)))]), key: "1" } : void 0, B.$slots[`${Y.type}-overlay-header`] ? { name: "header", fn: he(() => [le(B.$slots, `${Y.type}-overlay-header`, { toggle: Y.toggle })]), key: "2" } : void 0]), 1032, ["items", "arrow-navigation", "hide-navigation", "is-last", "config", "type", "esc-close", "menu-wrap-ref", "text-input", "aria-labels", "overlay-label", "onSelected", "onToggle"])) : x("", true)]), _: 2 }, 1032, ["name", "css"])], 64))), 128))], 2), S(D)(S(l), t.instance) && B.vertical ? (p(), De(Fa, { key: 1, "aria-label": (h = S(s)) == null ? void 0 : h.prevMonth, "el-name": "action-prev", disabled: S(g)(false), class: ye((F = S(f)) == null ? void 0 : F.navBtnPrev), onActivate: z[2] || (z[2] = (Y) => S(A)(false, true)) }, { default: he(() => [B.$slots["arrow-up"] ? le(B.$slots, "arrow-up", { key: 0 }) : x("", true), B.$slots["arrow-up"] ? x("", true) : (p(), De(S(zs), { key: 1 }))]), _: 3 }, 8, ["aria-label", "disabled", "class"])) : x("", true), S(w)(S(l), t.instance) ? (p(), De(Fa, { key: 2, ref: "rightIcon", "el-name": "action-next", disabled: S(g)(true), "aria-label": (U = S(s)) == null ? void 0 : U.nextMonth, class: ye((ne = S(f)) == null ? void 0 : ne.navBtnNext), onActivate: z[3] || (z[3] = (Y) => S(A)(true, true)), onSetRef: z[4] || (z[4] = (Y) => Ae(Y, B.disableYearSelect ? 2 : 3)) }, { default: he(() => [B.$slots[B.vertical ? "arrow-down" : "arrow-right"] ? le(B.$slots, B.vertical ? "arrow-down" : "arrow-right", { key: 0 }) : x("", true), B.$slots[B.vertical ? "arrow-down" : "arrow-right"] ? x("", true) : (p(), De(pr(B.vertical ? S(js) : S(Us)), { key: 1 }))]), _: 3 }, 8, ["disabled", "aria-label", "class"])) : x("", true)])], 64))]);
  };
} }), vD = { class: "dp__calendar_header", role: "row" }, gD = { key: 0, class: "dp__calendar_header_item", role: "gridcell" }, RD = ["aria-label"], ND = { key: 0, class: "dp__calendar_item dp__week_num", role: "gridcell" }, FD = { class: "dp__cell_inner" }, yD = ["id", "aria-pressed", "aria-disabled", "aria-label", "tabindex", "data-test-id", "onClick", "onTouchend", "onKeydown", "onMouseenter", "onMouseleave", "onMousedown"], OD = Ve({ compatConfig: { MODE: 3 }, __name: "DpCalendar", props: { mappedDates: { type: Array, default: () => [] }, instance: { type: Number, default: 0 }, month: { type: Number, default: 0 }, year: { type: Number, default: 0 }, ...Nn }, emits: ["select-date", "set-hover-date", "handle-scroll", "mount", "handle-swipe", "handle-space", "tooltip-open", "tooltip-close"], setup(t, { expose: e, emit: n }) {
  const r = n, a = t, { buildMultiLevelMatrix: i } = or(), { defaultedTransitions: s, defaultedConfig: l, defaultedAriaLabels: o, defaultedMultiCalendars: c, defaultedWeekNumbers: u, defaultedMultiDates: T, defaultedUI: f } = dt(a), m = se(null), v = se({ bottom: "", left: "", transform: "" }), E = se([]), A = se(null), g = se(true), O = se(""), D = se({ startX: 0, endX: 0, startY: 0, endY: 0 }), w = se([]), L = se({ left: "50%" }), _ = se(false), I = Q(() => a.calendar ? a.calendar(a.mappedDates) : a.mappedDates), V = Q(() => a.dayNames ? Array.isArray(a.dayNames) ? a.dayNames : a.dayNames(a.locale, +a.weekStart) : sp(a.formatLocale, a.locale, +a.weekStart));
  gt(() => {
    r("mount", { cmp: "calendar", refs: E }), l.value.noSwipe || A.value && (A.value.addEventListener("touchstart", Ae, { passive: false }), A.value.addEventListener("touchend", $, { passive: false }), A.value.addEventListener("touchmove", Me, { passive: false })), a.monthChangeOnScroll && A.value && A.value.addEventListener("wheel", W, { passive: false });
  }), Sr(() => {
    l.value.noSwipe || A.value && (A.value.removeEventListener("touchstart", Ae), A.value.removeEventListener("touchend", $), A.value.removeEventListener("touchmove", Me)), a.monthChangeOnScroll && A.value && A.value.removeEventListener("wheel", W);
  });
  const H = (Y) => Y ? a.vertical ? "vNext" : "next" : a.vertical ? "vPrevious" : "previous", Z = (Y, pe) => {
    if (a.transitions) {
      const q = It(jn(de(), a.month, a.year));
      O.value = Ft(It(jn(de(), Y, pe)), q) ? s.value[H(true)] : s.value[H(false)], g.value = false, Bt(() => {
        g.value = true;
      });
    }
  }, J = Q(() => ({ ...f.value.calendar ?? {} })), re = Q(() => (Y) => {
    const pe = lp(Y);
    return { dp__marker_dot: pe.type === "dot", dp__marker_line: pe.type === "line" };
  }), oe = Q(() => (Y) => $e(Y, m.value)), b = Q(() => ({ dp__calendar: true, dp__calendar_next: c.value.count > 0 && a.instance !== 0 })), P = Q(() => (Y) => a.hideOffsetDates ? Y.current : true), k = async (Y, pe) => {
    const { width: q, height: Te } = Y.getBoundingClientRect();
    m.value = pe.value;
    let R = { left: `${q / 2}px` }, me = -50;
    if (await Bt(), w.value[0]) {
      const { left: Se, width: ve } = w.value[0].getBoundingClientRect();
      Se < 0 && (R = { left: "0" }, me = 0, L.value.left = `${q / 2}px`), window.innerWidth < Se + ve && (R = { right: "0" }, me = 0, L.value.left = `${ve - q / 2}px`);
    }
    v.value = { bottom: `${Te}px`, ...R, transform: `translateX(${me}%)` };
  }, te = async (Y, pe, q) => {
    var Te, R, me;
    const Se = Yt(E.value[pe][q]);
    Se && ((Te = Y.marker) != null && Te.customPosition && (me = (R = Y.marker) == null ? void 0 : R.tooltip) != null && me.length ? v.value = Y.marker.customPosition(Se) : await k(Se, Y), r("tooltip-open", Y.marker));
  }, Ee = async (Y, pe, q) => {
    var Te, R;
    if (_.value && T.value.enabled && T.value.dragSelect) return r("select-date", Y);
    if (r("set-hover-date", Y), (R = (Te = Y.marker) == null ? void 0 : Te.tooltip) != null && R.length) {
      if (a.hideOffsetDates && !Y.current) return;
      await te(Y, pe, q);
    }
  }, ee = (Y) => {
    m.value && (m.value = null, v.value = JSON.parse(JSON.stringify({ bottom: "", left: "", transform: "" })), r("tooltip-close", Y.marker));
  }, Ae = (Y) => {
    D.value.startX = Y.changedTouches[0].screenX, D.value.startY = Y.changedTouches[0].screenY;
  }, $ = (Y) => {
    D.value.endX = Y.changedTouches[0].screenX, D.value.endY = Y.changedTouches[0].screenY, B();
  }, Me = (Y) => {
    a.vertical && !a.inline && Y.preventDefault();
  }, B = () => {
    const Y = a.vertical ? "Y" : "X";
    Math.abs(D.value[`start${Y}`] - D.value[`end${Y}`]) > 10 && r("handle-swipe", D.value[`start${Y}`] > D.value[`end${Y}`] ? "right" : "left");
  }, z = (Y, pe, q) => {
    Y && (Array.isArray(E.value[pe]) ? E.value[pe][q] = Y : E.value[pe] = [Y]), a.arrowNavigation && i(E.value, "calendar");
  }, W = (Y) => {
    a.monthChangeOnScroll && (Y.preventDefault(), r("handle-scroll", Y));
  }, ie = (Y) => u.value.type === "local" ? Is(Y.value, { weekStartsOn: +a.weekStart }) : u.value.type === "iso" ? Bs(Y.value) : typeof u.value.type == "function" ? u.value.type(Y.value) : "", h = (Y) => {
    const pe = Y[0];
    return u.value.hideOnOffsetDates ? Y.some((q) => q.current) ? ie(pe) : "" : ie(pe);
  }, F = (Y, pe, q = true) => {
    !q && hp() || (!T.value.enabled || l.value.allowPreventDefault) && (ar(Y, l.value), r("select-date", pe));
  }, U = (Y) => {
    ar(Y, l.value);
  }, ne = (Y) => {
    T.value.enabled && T.value.dragSelect ? (_.value = true, r("select-date", Y)) : T.value.enabled && r("select-date", Y);
  };
  return e({ triggerTransition: Z }), (Y, pe) => (p(), M("div", { class: ye(b.value) }, [j("div", { ref_key: "calendarWrapRef", ref: A, class: ye(J.value), role: "grid" }, [j("div", vD, [Y.weekNumbers ? (p(), M("div", gD, Be(Y.weekNumName), 1)) : x("", true), (p(true), M(He, null, rt(V.value, (q, Te) => {
    var R, me;
    return p(), M("div", { key: Te, class: "dp__calendar_header_item", role: "gridcell", "data-test-id": "calendar-header", "aria-label": (me = (R = S(o)) == null ? void 0 : R.weekDay) == null ? void 0 : me.call(R, Te) }, [Y.$slots["calendar-header"] ? le(Y.$slots, "calendar-header", { key: 0, day: q, index: Te }) : x("", true), Y.$slots["calendar-header"] ? x("", true) : (p(), M(He, { key: 1 }, [Mt(Be(q), 1)], 64))], 8, RD);
  }), 128))]), pe[2] || (pe[2] = j("div", { class: "dp__calendar_header_separator" }, null, -1)), Oe(qn, { name: O.value, css: !!Y.transitions }, { default: he(() => [g.value ? (p(), M("div", { key: 0, class: "dp__calendar", role: "rowgroup", onMouseleave: pe[1] || (pe[1] = (q) => _.value = false) }, [(p(true), M(He, null, rt(I.value, (q, Te) => (p(), M("div", { key: Te, class: "dp__calendar_row", role: "row" }, [Y.weekNumbers ? (p(), M("div", ND, [j("div", FD, Be(h(q.days)), 1)])) : x("", true), (p(true), M(He, null, rt(q.days, (R, me) => {
    var Se, ve, ze;
    return p(), M("div", { id: S(io)(R.value), ref_for: true, ref: (Ue) => z(Ue, Te, me), key: me + Te, role: "gridcell", class: "dp__calendar_item", "aria-pressed": (R.classData.dp__active_date || R.classData.dp__range_start || R.classData.dp__range_start) ?? void 0, "aria-disabled": R.classData.dp__cell_disabled || void 0, "aria-label": (ve = (Se = S(o)) == null ? void 0 : Se.day) == null ? void 0 : ve.call(Se, R), tabindex: !R.current && Y.hideOffsetDates ? void 0 : 0, "data-test-id": S(io)(R.value), onClick: at((Ue) => F(Ue, R), ["prevent"]), onTouchend: (Ue) => F(Ue, R, false), onKeydown: (Ue) => S(Qt)(Ue, () => Y.$emit("select-date", R)), onMouseenter: (Ue) => Ee(R, Te, me), onMouseleave: (Ue) => ee(R), onMousedown: (Ue) => ne(R), onMouseup: pe[0] || (pe[0] = (Ue) => _.value = false) }, [j("div", { class: ye(["dp__cell_inner", R.classData]) }, [Y.$slots.day && P.value(R) ? le(Y.$slots, "day", { key: 0, day: +R.text, date: R.value }) : x("", true), Y.$slots.day ? x("", true) : (p(), M(He, { key: 1 }, [Mt(Be(R.text), 1)], 64)), R.marker && P.value(R) ? (p(), M(He, { key: 2 }, [Y.$slots.marker ? le(Y.$slots, "marker", { key: 0, marker: R.marker, day: +R.text, date: R.value }) : (p(), M("div", { key: 1, class: ye(re.value(R.marker)), style: Tt(R.marker.color ? { backgroundColor: R.marker.color } : {}) }, null, 6))], 64)) : x("", true), oe.value(R.value) ? (p(), M("div", { key: 3, ref_for: true, ref_key: "activeTooltip", ref: w, class: "dp__marker_tooltip", style: Tt(v.value) }, [(ze = R.marker) != null && ze.tooltip ? (p(), M("div", { key: 0, class: "dp__tooltip_content", onClick: U }, [(p(true), M(He, null, rt(R.marker.tooltip, (Ue, We) => (p(), M("div", { key: We, class: "dp__tooltip_text" }, [Y.$slots["marker-tooltip"] ? le(Y.$slots, "marker-tooltip", { key: 0, tooltip: Ue, day: R.value }) : x("", true), Y.$slots["marker-tooltip"] ? x("", true) : (p(), M(He, { key: 1 }, [j("div", { class: "dp__tooltip_mark", style: Tt(Ue.color ? { backgroundColor: Ue.color } : {}) }, null, 4), j("div", null, Be(Ue.text), 1)], 64))]))), 128)), j("div", { class: "dp__arrow_bottom_tp", style: Tt(L.value) }, null, 4)])) : x("", true)], 4)) : x("", true)], 2)], 40, yD);
  }), 128))]))), 128))], 32)) : x("", true)]), _: 3 }, 8, ["name", "css"])], 2)], 2));
} }), Wl = (t) => Array.isArray(t), MD = (t, e, n, r) => {
  const a = se([]), i = se(/* @__PURE__ */ new Date()), s = se(), l = () => $(t.isTextInputDate), { modelValue: o, calendars: c, time: u, today: T } = Oa(t, e, l), { defaultedMultiCalendars: f, defaultedStartTime: m, defaultedRange: v, defaultedConfig: E, defaultedTz: A, propDates: g, defaultedMultiDates: O } = dt(t), { validateMonthYearInRange: D, isDisabled: w, isDateRangeAllowed: L, checkMinMaxRange: _ } = ur(t), { updateTimeValues: I, getSetDateTime: V, setTime: H, assignStartTime: Z, validateTime: J, disabledTimesConfig: re } = Ql(t, u, o, r), oe = Q(() => (C) => c.value[C] ? c.value[C].month : 0), b = Q(() => (C) => c.value[C] ? c.value[C].year : 0), P = (C) => !E.value.keepViewOnOffsetClick || C ? true : !s.value, k = (C, ue, _e, Ce = false) => {
    var X, Fe;
    P(Ce) && (c.value[C] || (c.value[C] = { month: 0, year: 0 }), c.value[C].month = Fl(ue) ? (X = c.value[C]) == null ? void 0 : X.month : ue, c.value[C].year = Fl(_e) ? (Fe = c.value[C]) == null ? void 0 : Fe.year : _e);
  }, te = () => {
    t.autoApply && e("select-date");
  }, Ee = () => {
    m.value && Z(m.value);
  };
  gt(() => {
    t.shadow || (o.value || (pe(), Ee()), $(true), t.focusStartDate && t.startDate && pe());
  });
  const ee = Q(() => {
    var C;
    return (C = t.flow) != null && C.length && !t.partialFlow ? t.flowStep === t.flow.length : true;
  }), Ae = () => {
    t.autoApply && ee.value && e("auto-apply", t.partialFlow ? t.flowStep !== t.flow.length : false);
  }, $ = (C = false) => {
    if (o.value) return Array.isArray(o.value) ? (a.value = o.value, F(C)) : z(o.value, C);
    if (f.value.count && C && !t.startDate) return B(de(), C);
  }, Me = () => Array.isArray(o.value) && v.value.enabled ? je(o.value[0]) === je(o.value[1] ?? o.value[0]) : false, B = (C = /* @__PURE__ */ new Date(), ue = false) => {
    if ((!f.value.count || !f.value.static || ue) && k(0, je(C), xe(C)), f.value.count && (!o.value || Me() || !f.value.solo) && (!f.value.solo || ue)) for (let _e = 1; _e < f.value.count; _e++) {
      const Ce = it(de(), { month: oe.value(_e - 1), year: b.value(_e - 1) }), X = z0(Ce, { months: 1 });
      c.value[_e] = { month: je(X), year: xe(X) };
    }
  }, z = (C, ue) => {
    B(C), H("hours", Gn(C)), H("minutes", rr(C)), H("seconds", Gr(C)), f.value.count && ue && Y();
  }, W = (C) => {
    if (f.value.count) {
      if (f.value.solo) return 0;
      const ue = je(C[0]), _e = je(C[1]);
      return Math.abs(_e - ue) < f.value.count ? 0 : 1;
    }
    return 1;
  }, ie = (C, ue) => {
    C[1] && v.value.showLastInRange ? B(C[W(C)], ue) : B(C[0], ue);
    const _e = (Ce, X) => [Ce(C[0]), C[1] ? Ce(C[1]) : u[X][1]];
    H("hours", _e(Gn, "hours")), H("minutes", _e(rr, "minutes")), H("seconds", _e(Gr, "seconds"));
  }, h = (C, ue) => {
    if ((v.value.enabled || t.weekPicker) && !O.value.enabled) return ie(C, ue);
    if (O.value.enabled && ue) {
      const _e = C[C.length - 1];
      return z(_e, ue);
    }
  }, F = (C) => {
    const ue = o.value;
    h(ue, C), f.value.count && f.value.solo && Y();
  }, U = (C, ue) => {
    const _e = it(de(), { month: oe.value(ue), year: b.value(ue) }), Ce = C < 0 ? Dn(_e, 1) : $r(_e, 1);
    D(je(Ce), xe(Ce), C < 0, t.preventMinMaxNavigation) && (k(ue, je(Ce), xe(Ce)), e("update-month-year", { instance: ue, month: je(Ce), year: xe(Ce) }), f.value.count && !f.value.solo && ne(ue), n());
  }, ne = (C) => {
    for (let ue = C - 1; ue >= 0; ue--) {
      const _e = $r(it(de(), { month: oe.value(ue + 1), year: b.value(ue + 1) }), 1);
      k(ue, je(_e), xe(_e));
    }
    for (let ue = C + 1; ue <= f.value.count - 1; ue++) {
      const _e = Dn(it(de(), { month: oe.value(ue - 1), year: b.value(ue - 1) }), 1);
      k(ue, je(_e), xe(_e));
    }
  }, Y = () => {
    if (Array.isArray(o.value) && o.value.length === 2) {
      const C = de(de(o.value[1] ? o.value[1] : Dn(o.value[0], 1))), [ue, _e] = [je(o.value[0]), xe(o.value[0])], [Ce, X] = [je(o.value[1]), xe(o.value[1])];
      (ue !== Ce || ue === Ce && _e !== X) && f.value.solo && k(1, je(C), xe(C));
    } else o.value && !Array.isArray(o.value) && (k(0, je(o.value), xe(o.value)), B(de()));
  }, pe = () => {
    t.startDate && (k(0, je(de(t.startDate)), xe(de(t.startDate))), f.value.count && ne(0));
  }, q = (C, ue) => {
    if (t.monthChangeOnScroll) {
      const _e = (/* @__PURE__ */ new Date()).getTime() - i.value.getTime(), Ce = Math.abs(C.deltaY);
      let X = 500;
      Ce > 1 && (X = 100), Ce > 100 && (X = 0), _e > X && (i.value = /* @__PURE__ */ new Date(), U(t.monthChangeOnScroll !== "inverse" ? -C.deltaY : C.deltaY, ue));
    }
  }, Te = (C, ue, _e = false) => {
    t.monthChangeOnArrows && t.vertical === _e && R(C, ue);
  }, R = (C, ue) => {
    U(C === "right" ? -1 : 1, ue);
  }, me = (C) => {
    if (g.value.markers) return Fi(C.value, g.value.markers);
  }, Se = (C, ue) => {
    switch (t.sixWeeks === true ? "append" : t.sixWeeks) {
      case "prepend":
        return [true, false];
      case "center":
        return [C == 0, true];
      case "fair":
        return [C == 0 || ue > C, true];
      case "append":
        return [false, false];
      default:
        return [false, false];
    }
  }, ve = (C, ue, _e, Ce) => {
    if (t.sixWeeks && C.length < 6) {
      const X = 6 - C.length, Fe = (ue.getDay() + 7 - Ce) % 7, be = 6 - (_e.getDay() + 7 - Ce) % 7, [hn, nn] = Se(Fe, be);
      for (let yn = 1; yn <= X; yn++) if (nn ? !!(yn % 2) == hn : hn) {
        const fn = C[0].days[0], ta = ze(dn(fn.value, -7), je(ue));
        C.unshift({ days: ta });
      } else {
        const fn = C[C.length - 1], ta = fn.days[fn.days.length - 1], ji = ze(dn(ta.value, 1), je(ue));
        C.push({ days: ji });
      }
    }
    return C;
  }, ze = (C, ue) => {
    const _e = de(C), Ce = [];
    for (let X = 0; X < 7; X++) {
      const Fe = dn(_e, X), be = je(Fe) !== ue;
      Ce.push({ text: t.hideOffsetDates && be ? "" : Fe.getDate(), value: Fe, current: !be, classData: {} });
    }
    return Ce;
  }, Ue = (C, ue) => {
    const _e = [], Ce = new Date(ue, C), X = new Date(ue, C + 1, 0), Fe = t.weekStart, be = Sn(Ce, { weekStartsOn: Fe }), hn = (nn) => {
      const yn = ze(nn, C);
      if (_e.push({ days: yn }), !_e[_e.length - 1].days.some((fn) => $e(It(fn.value), It(X)))) {
        const fn = dn(nn, 7);
        hn(fn);
      }
    };
    return hn(be), ve(_e, Ce, X, Fe);
  }, We = (C) => {
    const ue = ir(de(C.value), u.hours, u.minutes, we());
    e("date-update", ue), O.value.enabled ? To(ue, o, O.value.limit) : o.value = ue, r(), Bt().then(() => {
      Ae();
    });
  }, ht = (C) => v.value.noDisabledRange ? Bl(a.value[0], C).some((ue) => w(ue)) : false, G = () => {
    a.value = o.value ? o.value.slice() : [], a.value.length === 2 && !(v.value.fixedStart || v.value.fixedEnd) && (a.value = []);
  }, Re = (C, ue) => {
    const _e = [de(C.value), dn(de(C.value), +v.value.autoRange)];
    L(_e) ? (ue && Qe(C.value), a.value = _e) : e("invalid-date", C.value);
  }, Qe = (C) => {
    const ue = je(de(C)), _e = xe(de(C));
    if (k(0, ue, _e), f.value.count > 0) for (let Ce = 1; Ce < f.value.count; Ce++) {
      const X = mp(it(de(C), { year: b.value(Ce - 1), month: oe.value(Ce - 1) }));
      k(Ce, X.month, X.year);
    }
  }, St = (C) => {
    if (ht(C.value) || !_(C.value, o.value, v.value.fixedStart ? 0 : 1)) return e("invalid-date", C.value);
    a.value = jl(de(C.value), o, e, v);
  }, un = (C, ue) => {
    if (G(), v.value.autoRange) return Re(C, ue);
    if (v.value.fixedStart || v.value.fixedEnd) return St(C);
    a.value[0] ? _(de(C.value), o.value) && !ht(C.value) ? pt(de(C.value), de(a.value[0])) ? (a.value.unshift(de(C.value)), e("range-end", a.value[0])) : (a.value[1] = de(C.value), e("range-end", a.value[1])) : (t.autoApply && e("auto-apply-invalid", C.value), e("invalid-date", C.value)) : (a.value[0] = de(C.value), e("range-start", a.value[0]));
  }, we = (C = true) => t.enableSeconds ? Array.isArray(u.seconds) ? C ? u.seconds[0] : u.seconds[1] : u.seconds : 0, d = (C) => {
    a.value[C] = ir(a.value[C], u.hours[C], u.minutes[C], we(C !== 1));
  }, N = () => {
    var C, ue;
    a.value[0] && a.value[1] && +((C = a.value) == null ? void 0 : C[0]) > +((ue = a.value) == null ? void 0 : ue[1]) && (a.value.reverse(), e("range-start", a.value[0]), e("range-end", a.value[1]));
  }, y = () => {
    a.value.length && (a.value[0] && !a.value[1] ? d(0) : (d(0), d(1), r()), N(), o.value = a.value.slice(), Yi(a.value, e, t.autoApply, t.modelAuto));
  }, K = (C, ue = false) => {
    if (w(C.value) || !C.current && t.hideOffsetDates) return e("invalid-date", C.value);
    if (s.value = JSON.parse(JSON.stringify(C)), !v.value.enabled) return We(C);
    Wl(u.hours) && Wl(u.minutes) && !O.value.enabled && (un(C, ue), y());
  }, ge = (C, ue) => {
    var _e;
    k(C, ue.month, ue.year, true), f.value.count && !f.value.solo && ne(C), e("update-month-year", { instance: C, month: ue.month, year: ue.year }), n(f.value.solo ? C : void 0);
    const Ce = (_e = t.flow) != null && _e.length ? t.flow[t.flowStep] : void 0;
    !ue.fromNav && (Ce === Pt.month || Ce === Pt.year) && r();
  }, Ne = (C, ue) => {
    zl({ value: C, modelValue: o, range: v.value.enabled, timezone: ue ? void 0 : A.value.timezone }), te(), t.multiCalendars && Bt().then(() => $(true));
  }, Ye = () => {
    const C = $s(de(), A.value);
    !v.value.enabled && !O.value.enabled ? o.value = C : o.value && Array.isArray(o.value) && o.value[0] ? O.value.enabled ? o.value = [...o.value, C] : o.value = pt(C, o.value[0]) ? [C, o.value[0]] : [o.value[0], C] : o.value = [C], te();
  }, ke = () => {
    if (Array.isArray(o.value)) if (O.value.enabled) {
      const C = Ze();
      o.value[o.value.length - 1] = V(C);
    } else o.value = o.value.map((C, ue) => C && V(C, ue));
    else o.value = V(o.value);
    e("time-update");
  }, Ze = () => Array.isArray(o.value) && o.value.length ? o.value[o.value.length - 1] : null;
  return { calendars: c, modelValue: o, month: oe, year: b, time: u, disabledTimesConfig: re, today: T, validateTime: J, getCalendarDays: Ue, getMarker: me, handleScroll: q, handleSwipe: R, handleArrow: Te, selectDate: K, updateMonthYear: ge, presetDate: Ne, selectCurrentDate: Ye, updateTime: (C, ue = true, _e = false) => {
    I(C, ue, _e, ke);
  }, assignMonthAndYear: B, setStartTime: Ee };
}, bD = { key: 0 }, YD = Ve({ __name: "DatePicker", props: { ...Nn }, emits: ["tooltip-open", "tooltip-close", "mount", "update:internal-model-value", "update-flow-step", "reset-flow", "auto-apply", "focus-menu", "select-date", "range-start", "range-end", "invalid-fixed-range", "time-update", "am-pm-change", "time-picker-open", "time-picker-close", "recalculate-position", "update-month-year", "auto-apply-invalid", "date-update", "invalid-date", "overlay-toggle"], setup(t, { expose: e, emit: n }) {
  const r = n, a = t, { calendars: i, month: s, year: l, modelValue: o, time: c, disabledTimesConfig: u, today: T, validateTime: f, getCalendarDays: m, getMarker: v, handleArrow: E, handleScroll: A, handleSwipe: g, selectDate: O, updateMonthYear: D, presetDate: w, selectCurrentDate: L, updateTime: _, assignMonthAndYear: I, setStartTime: V } = MD(a, r, Me, B), H = mn(), { setHoverDate: Z, getDayClassData: J, clearHoverDate: re } = VD(o, a), { defaultedMultiCalendars: oe } = dt(a), b = se([]), P = se([]), k = se(null), te = sn(H, "calendar"), Ee = sn(H, "monthYear"), ee = sn(H, "timePicker"), Ae = (q) => {
    a.shadow || r("mount", q);
  };
  vt(i, () => {
    a.shadow || setTimeout(() => {
      r("recalculate-position");
    }, 0);
  }, { deep: true }), vt(oe, (q, Te) => {
    q.count - Te.count > 0 && I();
  }, { deep: true });
  const $ = Q(() => (q) => m(s.value(q), l.value(q)).map((Te) => ({ ...Te, days: Te.days.map((R) => (R.marker = v(R), R.classData = J(R), R)) })));
  function Me(q) {
    var Te;
    q || q === 0 ? (Te = P.value[q]) == null || Te.triggerTransition(s.value(q), l.value(q)) : P.value.forEach((R, me) => R.triggerTransition(s.value(me), l.value(me)));
  }
  function B() {
    r("update-flow-step");
  }
  const z = (q, Te = false) => {
    O(q, Te), a.spaceConfirm && r("select-date");
  }, W = (q, Te, R = 0) => {
    var me;
    (me = b.value[R]) == null || me.toggleMonthPicker(q, Te);
  }, ie = (q, Te, R = 0) => {
    var me;
    (me = b.value[R]) == null || me.toggleYearPicker(q, Te);
  }, h = (q, Te, R) => {
    var me;
    (me = k.value) == null || me.toggleTimePicker(q, Te, R);
  }, F = (q, Te) => {
    var R;
    if (!a.range) {
      const me = o.value ? o.value : T, Se = Te ? new Date(Te) : me, ve = q ? Sn(Se, { weekStartsOn: 1 }) : el(Se, { weekStartsOn: 1 });
      O({ value: ve, current: je(Se) === s.value(0), text: "", classData: {} }), (R = document.getElementById(io(ve))) == null || R.focus();
    }
  }, U = (q) => {
    var Te;
    (Te = b.value[0]) == null || Te.handleMonthYearChange(q, true);
  }, ne = (q) => {
    D(0, { month: s.value(0), year: l.value(0) + (q ? 1 : -1), fromNav: true });
  }, Y = (q, Te) => {
    q === Pt.time && r(`time-picker-${Te ? "open" : "close"}`), r("overlay-toggle", { open: Te, overlay: q });
  }, pe = (q) => {
    r("overlay-toggle", { open: false, overlay: q }), r("focus-menu");
  };
  return e({ clearHoverDate: re, presetDate: w, selectCurrentDate: L, toggleMonthPicker: W, toggleYearPicker: ie, toggleTimePicker: h, handleArrow: E, updateMonthYear: D, getSidebarProps: () => ({ modelValue: o, month: s, year: l, time: c, updateTime: _, updateMonthYear: D, selectDate: O, presetDate: w }), changeMonth: U, changeYear: ne, selectWeekDate: F, setStartTime: V }), (q, Te) => (p(), M(He, null, [Oe(bi, { "multi-calendars": S(oe).count, collapse: q.collapse, "is-mobile": q.isMobile }, { default: he(({ instance: R, index: me }) => [q.disableMonthYearSelect ? x("", true) : (p(), De(SD, Le({ key: 0, ref: (Se) => {
    Se && (b.value[me] = Se);
  }, months: S(gl)(q.formatLocale, q.locale, q.monthNameFormat), years: S(Qs)(q.yearRange, q.locale, q.reverseYears), month: S(s)(R), year: S(l)(R), instance: R }, q.$props, { onMount: Te[0] || (Te[0] = (Se) => Ae(S(Or).header)), onResetFlow: Te[1] || (Te[1] = (Se) => q.$emit("reset-flow")), onUpdateMonthYear: (Se) => S(D)(R, Se), onOverlayClosed: pe, onOverlayOpened: Te[2] || (Te[2] = (Se) => q.$emit("overlay-toggle", { open: true, overlay: Se })) }), wt({ _: 2 }, [rt(S(Ee), (Se, ve) => ({ name: Se, fn: he((ze) => [le(q.$slots, Se, bt(Ht(ze)))]) }))]), 1040, ["months", "years", "month", "year", "instance", "onUpdateMonthYear"])), Oe(OD, Le({ ref: (Se) => {
    Se && (P.value[me] = Se);
  }, "mapped-dates": $.value(R), month: S(s)(R), year: S(l)(R), instance: R }, q.$props, { onSelectDate: (Se) => S(O)(Se, R !== 1), onHandleSpace: (Se) => z(Se, R !== 1), onSetHoverDate: Te[3] || (Te[3] = (Se) => S(Z)(Se)), onHandleScroll: (Se) => S(A)(Se, R), onHandleSwipe: (Se) => S(g)(Se, R), onMount: Te[4] || (Te[4] = (Se) => Ae(S(Or).calendar)), onResetFlow: Te[5] || (Te[5] = (Se) => q.$emit("reset-flow")), onTooltipOpen: Te[6] || (Te[6] = (Se) => q.$emit("tooltip-open", Se)), onTooltipClose: Te[7] || (Te[7] = (Se) => q.$emit("tooltip-close", Se)) }), wt({ _: 2 }, [rt(S(te), (Se, ve) => ({ name: Se, fn: he((ze) => [le(q.$slots, Se, bt(Ht({ ...ze })))]) }))]), 1040, ["mapped-dates", "month", "year", "instance", "onSelectDate", "onHandleSpace", "onHandleScroll", "onHandleSwipe"])]), _: 3 }, 8, ["multi-calendars", "collapse", "is-mobile"]), q.enableTimePicker ? (p(), M("div", bD, [q.$slots["time-picker"] ? le(q.$slots, "time-picker", bt(Le({ key: 0 }, { time: S(c), updateTime: S(_) }))) : (p(), De(Vl, Le({ key: 1, ref_key: "timePickerRef", ref: k }, q.$props, { hours: S(c).hours, minutes: S(c).minutes, seconds: S(c).seconds, "internal-model-value": q.internalModelValue, "disabled-times-config": S(u), "validate-time": S(f), onMount: Te[8] || (Te[8] = (R) => Ae(S(Or).timePicker)), "onUpdate:hours": Te[9] || (Te[9] = (R) => S(_)(R)), "onUpdate:minutes": Te[10] || (Te[10] = (R) => S(_)(R, false)), "onUpdate:seconds": Te[11] || (Te[11] = (R) => S(_)(R, false, true)), onResetFlow: Te[12] || (Te[12] = (R) => q.$emit("reset-flow")), onOverlayClosed: Te[13] || (Te[13] = (R) => Y(R, false)), onOverlayOpened: Te[14] || (Te[14] = (R) => Y(R, true)), onAmPmChange: Te[15] || (Te[15] = (R) => q.$emit("am-pm-change", R)) }), wt({ _: 2 }, [rt(S(ee), (R, me) => ({ name: R, fn: he((Se) => [le(q.$slots, R, bt(Ht(Se)))]) }))]), 1040, ["hours", "minutes", "seconds", "internal-model-value", "disabled-times-config", "validate-time"]))])) : x("", true)], 64));
} }), wD = (t, e) => {
  const n = se(), { defaultedMultiCalendars: r, defaultedConfig: a, defaultedHighlight: i, defaultedRange: s, propDates: l, defaultedFilters: o, defaultedMultiDates: c } = dt(t), { modelValue: u, year: T, month: f, calendars: m } = Oa(t, e), { isDisabled: v } = ur(t), { selectYear: E, groupedYears: A, showYearPicker: g, isDisabled: O, toggleYearPicker: D, handleYearSelect: w, handleYear: L } = $l({ modelValue: u, multiCalendars: r, range: s, highlight: i, calendars: m, propDates: l, month: f, year: T, filters: o, props: t, emit: e }), _ = (P, k) => [P, k].map((te) => bn(te, "MMMM", { locale: t.formatLocale })).join("-"), I = Q(() => (P) => u.value ? Array.isArray(u.value) ? u.value.some((k) => fl(P, k)) : fl(u.value, P) : false), V = (P) => {
    if (s.value.enabled) {
      if (Array.isArray(u.value)) {
        const k = $e(P, u.value[0]) || $e(P, u.value[1]);
        return ga(u.value, n.value, P) && !k;
      }
      return false;
    }
    return false;
  }, H = (P, k) => P.quarter === q0(k) && P.year === xe(k), Z = (P) => typeof i.value == "function" ? i.value({ quarter: q0(P), year: xe(P) }) : !!i.value.quarters.find((k) => H(k, P)), J = Q(() => (P) => {
    const k = it(/* @__PURE__ */ new Date(), { year: T.value(P) });
    return sm({ start: pa(k), end: X0(k) }).map((te) => {
      const Ee = Nr(te), ee = tl(te), Ae = v(te), $ = V(Ee), Me = Z(Ee);
      return { text: _(Ee, ee), value: Ee, active: I.value(Ee), highlighted: Me, disabled: Ae, isBetween: $ };
    });
  }), re = (P) => {
    To(P, u, c.value.limit), e("auto-apply", true);
  }, oe = (P) => {
    u.value = ho(u, P, e), Yi(u.value, e, t.autoApply, t.modelAuto);
  }, b = (P) => {
    u.value = P, e("auto-apply");
  };
  return { defaultedConfig: a, defaultedMultiCalendars: r, groupedYears: A, year: T, isDisabled: O, quarters: J, showYearPicker: g, modelValue: u, setHoverDate: (P) => {
    n.value = P;
  }, selectYear: E, selectQuarter: (P, k, te) => {
    if (!te) return m.value[k].month = je(tl(P)), c.value.enabled ? re(P) : s.value.enabled ? oe(P) : b(P);
  }, toggleYearPicker: D, handleYearSelect: w, handleYear: L };
}, _D = { class: "dp--quarter-items" }, BD = ["data-test-id", "disabled", "onClick", "onMouseover"], ZD = Ve({ compatConfig: { MODE: 3 }, __name: "QuarterPicker", props: { ...Nn }, emits: ["update:internal-model-value", "reset-flow", "overlay-closed", "auto-apply", "range-start", "range-end", "overlay-toggle", "update-month-year"], setup(t, { expose: e, emit: n }) {
  const r = n, a = t, i = mn(), s = sn(i, "yearMode"), { defaultedMultiCalendars: l, defaultedConfig: o, groupedYears: c, year: u, isDisabled: T, quarters: f, modelValue: m, showYearPicker: v, setHoverDate: E, selectQuarter: A, toggleYearPicker: g, handleYearSelect: O, handleYear: D } = wD(a, r);
  return e({ getSidebarProps: () => ({ modelValue: m, year: u, selectQuarter: A, handleYearSelect: O, handleYear: D }) }), (w, L) => (p(), De(bi, { "multi-calendars": S(l).count, collapse: w.collapse, stretch: "", "is-mobile": w.isMobile }, { default: he(({ instance: _ }) => [j("div", { class: "dp-quarter-picker-wrap", style: Tt({ minHeight: `${S(o).modeHeight}px` }) }, [w.$slots["top-extra"] ? le(w.$slots, "top-extra", { key: 0, value: w.internalModelValue }) : x("", true), j("div", null, [Oe(Gl, Le(w.$props, { items: S(c)(_), instance: _, "show-year-picker": S(v)[_], year: S(u)(_), "is-disabled": (I) => S(T)(_, I), onHandleYear: (I) => S(D)(_, I), onYearSelect: (I) => S(O)(I, _), onToggleYearPicker: (I) => S(g)(_, I?.flow, I?.show) }), wt({ _: 2 }, [rt(S(s), (I, V) => ({ name: I, fn: he((H) => [le(w.$slots, I, bt(Ht(H)))]) }))]), 1040, ["items", "instance", "show-year-picker", "year", "is-disabled", "onHandleYear", "onYearSelect", "onToggleYearPicker"])]), j("div", _D, [(p(true), M(He, null, rt(S(f)(_), (I, V) => (p(), M("div", { key: V }, [j("button", { type: "button", class: ye(["dp--qr-btn", { "dp--qr-btn-active": I.active, "dp--qr-btn-between": I.isBetween, "dp--qr-btn-disabled": I.disabled, "dp--highlighted": I.highlighted }]), "data-test-id": I.value, disabled: I.disabled, onClick: (H) => S(A)(I.value, _, I.disabled), onMouseover: (H) => S(E)(I.value) }, [w.$slots.quarter ? le(w.$slots, "quarter", { key: 0, value: I.value, text: I.text }) : (p(), M(He, { key: 1 }, [Mt(Be(I.text), 1)], 64))], 42, BD)]))), 128))])], 4)]), _: 3 }, 8, ["multi-calendars", "collapse", "is-mobile"]));
} }), ql = (t, e) => {
  const n = se(0);
  gt(() => {
    r(), window.addEventListener("resize", r, { passive: true });
  }), Sr(() => {
    window.removeEventListener("resize", r);
  });
  const r = () => {
    n.value = window.document.documentElement.clientWidth;
  };
  return { isMobile: Q(() => n.value <= t.value.mobileBreakpoint && !e ? true : void 0) };
}, ID = ["id", "tabindex", "role", "aria-label"], LD = { key: 0, class: "dp--menu-load-container" }, kD = { key: 1, class: "dp--menu-header" }, CD = ["data-dp-mobile"], xD = { key: 0, class: "dp__sidebar_left" }, HD = ["data-dp-mobile"], PD = ["data-test-id", "data-dp-mobile", "onClick", "onKeydown"], UD = { key: 2, class: "dp__sidebar_right" }, GD = { key: 3, class: "dp__action_extra" }, Kl = Ve({ compatConfig: { MODE: 3 }, __name: "DatepickerMenu", props: { ...Mi, shadow: { type: Boolean, default: false }, openOnTop: { type: Boolean, default: false }, internalModelValue: { type: [Date, Array], default: null }, noOverlayFocus: { type: Boolean, default: false }, collapse: { type: Boolean, default: false }, getInputRect: { type: Function, default: () => ({}) }, isTextInputDate: { type: Boolean, default: false } }, emits: ["close-picker", "select-date", "auto-apply", "time-update", "flow-step", "update-month-year", "invalid-select", "update:internal-model-value", "recalculate-position", "invalid-fixed-range", "tooltip-open", "tooltip-close", "time-picker-open", "time-picker-close", "am-pm-change", "range-start", "range-end", "auto-apply-invalid", "date-update", "invalid-date", "overlay-toggle", "menu-blur"], setup(t, { expose: e, emit: n }) {
  const r = n, a = t, i = se(null), s = Q(() => {
    const { openOnTop: G, ...Re } = a;
    return { ...Re, isMobile: A.value, flowStep: oe.value, menuWrapRef: i.value };
  }), { setMenuFocused: l, setShiftKey: o, control: c } = Hl(), u = mn(), { defaultedTextInput: T, defaultedInline: f, defaultedConfig: m, defaultedUI: v, handleEventPropagation: E } = dt(a), { isMobile: A } = ql(m, a.shadow), g = se(null), O = se(0), D = se(null), w = se(false), L = se(null), _ = se(false), I = (G) => {
    _.value = true, m.value.allowPreventDefault && G.preventDefault(), ar(G, m.value, true);
  };
  gt(() => {
    if (!a.shadow) {
      w.value = true, V(), window.addEventListener("resize", V);
      const G = Yt(i);
      G && !T.value.enabled && !f.value.enabled && (l(true), Ae()), G && (G.addEventListener("pointerdown", I), G.addEventListener("mousedown", I));
    }
    document.addEventListener("mousedown", ht);
  }), Sr(() => {
    window.removeEventListener("resize", V), document.removeEventListener("mousedown", ht);
    const G = Yt(i);
    G && (G.removeEventListener("pointerdown", I), G.removeEventListener("mousedown", I));
  });
  const V = () => {
    const G = Yt(D);
    G && (O.value = G.getBoundingClientRect().width);
  }, { arrowRight: H, arrowLeft: Z, arrowDown: J, arrowUp: re } = or(), { flowStep: oe, updateFlowStep: b, childMount: P, resetFlow: k, handleFlow: te } = QD(a, r, L), Ee = Q(() => a.monthPicker ? Jp : a.yearPicker ? eD : a.timePicker ? fD : a.quarterPicker ? ZD : YD), ee = Q(() => {
    var G;
    if (m.value.arrowLeft) return m.value.arrowLeft;
    const Re = (G = i.value) == null ? void 0 : G.getBoundingClientRect(), Qe = a.getInputRect();
    return Qe?.width < O?.value && Qe?.left <= (Re?.left ?? 0) ? `${Qe?.width / 2}px` : Qe?.right >= (Re?.right ?? 0) && Qe?.width < O?.value ? `${O?.value - Qe?.width / 2}px` : "50%";
  }), Ae = () => {
    const G = Yt(i);
    G && G.focus({ preventScroll: true });
  }, $ = Q(() => {
    var G;
    return ((G = L.value) == null ? void 0 : G.getSidebarProps()) || {};
  }), Me = () => {
    a.openOnTop && r("recalculate-position");
  }, B = sn(u, "action"), z = Q(() => a.monthPicker || a.yearPicker ? sn(u, "monthYear") : a.timePicker ? sn(u, "timePicker") : sn(u, "shared")), W = Q(() => a.openOnTop ? "dp__arrow_bottom" : "dp__arrow_top"), ie = Q(() => ({ dp__menu_disabled: a.disabled, dp__menu_readonly: a.readonly, "dp-menu-loading": a.loading })), h = Q(() => ({ dp__menu: true, dp__menu_index: !f.value.enabled, dp__relative: f.value.enabled, ...v.value.menu ?? {} })), F = (G) => {
    ar(G, m.value, true);
  }, U = (G) => {
    a.escClose && (r("close-picker"), E(G));
  }, ne = (G) => {
    if (a.arrowNavigation) {
      if (G === Vt.up) return re();
      if (G === Vt.down) return J();
      if (G === Vt.left) return Z();
      if (G === Vt.right) return H();
    } else G === Vt.left || G === Vt.up ? R("handleArrow", Vt.left, 0, G === Vt.up) : R("handleArrow", Vt.right, 0, G === Vt.down);
  }, Y = (G) => {
    o(G.shiftKey), !a.disableMonthYearSelect && G.code === ut.tab && G.target.classList.contains("dp__menu") && c.value.shiftKeyInMenu && (G.preventDefault(), ar(G, m.value, true), r("close-picker"));
  }, pe = () => {
    Ae(), r("time-picker-close");
  }, q = (G) => {
    var Re, Qe, St;
    (Re = L.value) == null || Re.toggleTimePicker(false, false), (Qe = L.value) == null || Qe.toggleMonthPicker(false, false, G), (St = L.value) == null || St.toggleYearPicker(false, false, G);
  }, Te = (G, Re = 0) => {
    var Qe, St, un;
    return G === "month" ? (Qe = L.value) == null ? void 0 : Qe.toggleMonthPicker(false, true, Re) : G === "year" ? (St = L.value) == null ? void 0 : St.toggleYearPicker(false, true, Re) : G === "time" ? (un = L.value) == null ? void 0 : un.toggleTimePicker(true, false) : q(Re);
  }, R = (G, ...Re) => {
    var Qe, St;
    (Qe = L.value) != null && Qe[G] && ((St = L.value) == null || St[G](...Re));
  }, me = () => {
    R("selectCurrentDate");
  }, Se = (G, Re) => {
    R("presetDate", Yc(G), Re);
  }, ve = () => {
    R("clearHoverDate");
  }, ze = (G, Re) => {
    R("updateMonthYear", G, Re);
  }, Ue = (G, Re) => {
    G.preventDefault(), ne(Re);
  }, We = (G) => {
    var Re, Qe, St;
    if (Y(G), G.key === ut.home || G.key === ut.end) return R("selectWeekDate", G.key === ut.home, G.target.getAttribute("id"));
    switch ((G.key === ut.pageUp || G.key === ut.pageDown) && (G.shiftKey ? (R("changeYear", G.key === ut.pageUp), (Re = qs(i.value, "overlay-year")) == null || Re.focus()) : (R("changeMonth", G.key === ut.pageUp), (Qe = qs(i.value, G.key === ut.pageUp ? "action-prev" : "action-next")) == null || Qe.focus()), G.target.getAttribute("id") && ((St = i.value) == null || St.focus({ preventScroll: true }))), G.key) {
      case ut.esc:
        return U(G);
      case ut.arrowLeft:
        return Ue(G, Vt.left);
      case ut.arrowRight:
        return Ue(G, Vt.right);
      case ut.arrowUp:
        return Ue(G, Vt.up);
      case ut.arrowDown:
        return Ue(G, Vt.down);
      default:
        return;
    }
  }, ht = (G) => {
    var Re;
    f.value.enabled && !f.value.input && !((Re = i.value) != null && Re.contains(G.target)) && _.value && (_.value = false, r("menu-blur"));
  };
  return e({ updateMonthYear: ze, switchView: Te, handleFlow: te, onValueCleared: () => {
    var G, Re;
    (Re = (G = L.value) == null ? void 0 : G.setStartTime) == null || Re.call(G);
  } }), (G, Re) => {
    var Qe, St, un;
    return p(), M("div", { id: G.uid ? `dp-menu-${G.uid}` : void 0, ref_key: "dpMenuRef", ref: i, tabindex: S(f).enabled ? void 0 : "0", role: S(f).enabled ? void 0 : "dialog", "aria-label": (Qe = G.ariaLabels) == null ? void 0 : Qe.menu, class: ye(h.value), style: Tt({ "--dp-arrow-left": ee.value }), onMouseleave: ve, onClick: F, onKeydown: We }, [(G.disabled || G.readonly) && S(f).enabled || G.loading ? (p(), M("div", { key: 0, class: ye(ie.value) }, [G.loading ? (p(), M("div", LD, Re[19] || (Re[19] = [j("span", { class: "dp--menu-loader" }, null, -1)]))) : x("", true)], 2)) : x("", true), G.$slots["menu-header"] ? (p(), M("div", kD, [le(G.$slots, "menu-header")])) : x("", true), !S(f).enabled && !G.teleportCenter ? (p(), M("div", { key: 2, class: ye(W.value) }, null, 2)) : x("", true), j("div", { ref_key: "innerMenuRef", ref: D, class: ye({ dp__menu_content_wrapper: ((St = G.presetDates) == null ? void 0 : St.length) || !!G.$slots["left-sidebar"] || !!G.$slots["right-sidebar"], "dp--menu-content-wrapper-collapsed": t.collapse && (((un = G.presetDates) == null ? void 0 : un.length) || !!G.$slots["left-sidebar"] || !!G.$slots["right-sidebar"]) }), "data-dp-mobile": S(A), style: Tt({ "--dp-menu-width": `${O.value}px` }) }, [G.$slots["left-sidebar"] ? (p(), M("div", xD, [le(G.$slots, "left-sidebar", bt(Ht($.value)))])) : x("", true), G.presetDates.length ? (p(), M("div", { key: 1, class: ye({ "dp--preset-dates-collapsed": t.collapse, "dp--preset-dates": true }), "data-dp-mobile": S(A) }, [(p(true), M(He, null, rt(G.presetDates, (we, d) => (p(), M(He, { key: d }, [we.slot ? le(G.$slots, we.slot, { key: 0, presetDate: Se, label: we.label, value: we.value }) : (p(), M("button", { key: 1, type: "button", style: Tt(we.style || {}), class: ye(["dp__btn dp--preset-range", { "dp--preset-range-collapsed": t.collapse }]), "data-test-id": we.testId ?? void 0, "data-dp-mobile": S(A), onClick: at((N) => Se(we.value, we.noTz), ["prevent"]), onKeydown: (N) => S(Qt)(N, () => Se(we.value, we.noTz), true) }, Be(we.label), 47, PD))], 64))), 128))], 10, HD)) : x("", true), j("div", { ref_key: "calendarWrapperRef", ref: g, class: "dp__instance_calendar", role: "document" }, [(p(), De(pr(Ee.value), Le({ ref_key: "dynCmpRef", ref: L }, s.value, { "flow-step": S(oe), onMount: S(P), onUpdateFlowStep: S(b), onResetFlow: S(k), onFocusMenu: Ae, onSelectDate: Re[0] || (Re[0] = (we) => G.$emit("select-date")), onDateUpdate: Re[1] || (Re[1] = (we) => G.$emit("date-update", we)), onTooltipOpen: Re[2] || (Re[2] = (we) => G.$emit("tooltip-open", we)), onTooltipClose: Re[3] || (Re[3] = (we) => G.$emit("tooltip-close", we)), onAutoApply: Re[4] || (Re[4] = (we) => G.$emit("auto-apply", we)), onRangeStart: Re[5] || (Re[5] = (we) => G.$emit("range-start", we)), onRangeEnd: Re[6] || (Re[6] = (we) => G.$emit("range-end", we)), onInvalidFixedRange: Re[7] || (Re[7] = (we) => G.$emit("invalid-fixed-range", we)), onTimeUpdate: Re[8] || (Re[8] = (we) => G.$emit("time-update")), onAmPmChange: Re[9] || (Re[9] = (we) => G.$emit("am-pm-change", we)), onTimePickerOpen: Re[10] || (Re[10] = (we) => G.$emit("time-picker-open", we)), onTimePickerClose: pe, onRecalculatePosition: Me, onUpdateMonthYear: Re[11] || (Re[11] = (we) => G.$emit("update-month-year", we)), onAutoApplyInvalid: Re[12] || (Re[12] = (we) => G.$emit("auto-apply-invalid", we)), onInvalidDate: Re[13] || (Re[13] = (we) => G.$emit("invalid-date", we)), onOverlayToggle: Re[14] || (Re[14] = (we) => G.$emit("overlay-toggle", we)), "onUpdate:internalModelValue": Re[15] || (Re[15] = (we) => G.$emit("update:internal-model-value", we)) }), wt({ _: 2 }, [rt(z.value, (we, d) => ({ name: we, fn: he((N) => [le(G.$slots, we, bt(Ht({ ...N })))]) }))]), 1040, ["flow-step", "onMount", "onUpdateFlowStep", "onResetFlow"]))], 512), G.$slots["right-sidebar"] ? (p(), M("div", UD, [le(G.$slots, "right-sidebar", bt(Ht($.value)))])) : x("", true), G.$slots["action-extra"] ? (p(), M("div", GD, [G.$slots["action-extra"] ? le(G.$slots, "action-extra", { key: 0, selectCurrentDate: me }) : x("", true)])) : x("", true)], 14, CD), !G.autoApply || S(m).keepActionRow ? (p(), De(Gp, Le({ key: 3, "menu-mount": w.value }, s.value, { "calendar-width": O.value, onClosePicker: Re[16] || (Re[16] = (we) => G.$emit("close-picker")), onSelectDate: Re[17] || (Re[17] = (we) => G.$emit("select-date")), onInvalidSelect: Re[18] || (Re[18] = (we) => G.$emit("invalid-select")), onSelectNow: me }), wt({ _: 2 }, [rt(S(B), (we, d) => ({ name: we, fn: he((N) => [le(G.$slots, we, bt(Ht({ ...N })))]) }))]), 1040, ["menu-mount", "calendar-width"])) : x("", true)], 46, ID);
  };
} });
var Jr = ((t) => (t.center = "center", t.left = "left", t.right = "right", t))(Jr || {});
const zD = ({ menuRef: t, menuRefInner: e, inputRef: n, pickerWrapperRef: r, inline: a, emit: i, props: s, slots: l }) => {
  const { defaultedConfig: o } = dt(s), c = se({}), u = se(false), T = se({ top: "0", left: "0" }), f = se(false), m = ra(s, "teleportCenter");
  vt(m, () => {
    T.value = JSON.parse(JSON.stringify({})), L();
  });
  const v = (k) => {
    if (s.teleport) {
      const te = k.getBoundingClientRect();
      return { left: te.left + window.scrollX, top: te.top + window.scrollY };
    }
    return { top: 0, left: 0 };
  }, E = (k, te) => {
    T.value.left = `${k + te - c.value.width}px`;
  }, A = (k) => {
    T.value.left = `${k}px`;
  }, g = (k, te) => {
    s.position === Jr.left && A(k), s.position === Jr.right && E(k, te), s.position === Jr.center && (T.value.left = `${k + te / 2 - c.value.width / 2}px`);
  }, O = (k) => {
    const { width: te, height: Ee } = k.getBoundingClientRect(), { top: ee, left: Ae } = v(k);
    return { top: +ee, left: +Ae, width: te, height: Ee };
  }, D = () => {
    T.value.left = "50%", T.value.top = "50%", T.value.transform = "translate(-50%, -50%)", T.value.position = "fixed", delete T.value.opacity;
  }, w = () => {
    const k = Yt(n);
    T.value = s.altPosition(k);
  }, L = (k = true) => {
    var te;
    if (!a.value.enabled) {
      if (m.value) return D();
      if (s.altPosition !== null) return w();
      if (k) {
        const Ee = s.teleport ? (te = e.value) == null ? void 0 : te.$el : t.value;
        Ee && (c.value = Ee.getBoundingClientRect()), i("recalculate-position");
      }
      return re();
    }
  }, _ = ({ inputEl: k, left: te, width: Ee }) => {
    window.screen.width > 768 && !u.value && g(te, Ee), H(k);
  }, I = (k) => {
    const { top: te, left: Ee, height: ee, width: Ae } = O(k);
    T.value.top = `${ee + te + +s.offset}px`, f.value = false, u.value || (T.value.left = `${Ee + Ae / 2 - c.value.width / 2}px`), _({ inputEl: k, left: Ee, width: Ae });
  }, V = (k) => {
    const { top: te, left: Ee, width: ee } = O(k);
    T.value.top = `${te - +s.offset - c.value.height}px`, f.value = true, _({ inputEl: k, left: Ee, width: ee });
  }, H = (k) => {
    if (s.autoPosition) {
      const { left: te, width: Ee } = O(k), { left: ee, right: Ae } = c.value;
      if (!u.value) {
        if (Math.abs(ee) !== Math.abs(Ae)) {
          if (ee <= 0) return u.value = true, A(te);
          if (Ae >= document.documentElement.clientWidth) return u.value = true, E(te, Ee);
        }
        return g(te, Ee);
      }
    }
  }, Z = () => {
    const k = Yt(n);
    if (k) {
      if (s.autoPosition === gn.top) return gn.top;
      if (s.autoPosition === gn.bottom) return gn.bottom;
      const { height: te } = c.value, { top: Ee, height: ee } = k.getBoundingClientRect(), Ae = window.innerHeight - Ee - ee, $ = Ee;
      return te <= Ae ? gn.bottom : te > Ae && te <= $ ? gn.top : Ae >= $ ? gn.bottom : gn.top;
    }
    return gn.bottom;
  }, J = (k) => Z() === gn.bottom ? I(k) : V(k), re = () => {
    const k = Yt(n);
    if (k) return s.autoPosition ? J(k) : I(k);
  }, oe = function(k) {
    if (k) {
      const te = k.scrollHeight > k.clientHeight, Ee = window.getComputedStyle(k).overflowY.indexOf("hidden") !== -1;
      return te && !Ee;
    }
    return true;
  }, b = function(k) {
    return !k || k === document.body || k.nodeType === Node.DOCUMENT_FRAGMENT_NODE ? window : oe(k) ? k : b(k.assignedSlot && o.value.shadowDom ? k.assignedSlot.parentNode : k.parentNode);
  }, P = (k) => {
    if (k) switch (s.position) {
      case Jr.left:
        return { left: 0, transform: "translateX(0)" };
      case Jr.right:
        return { left: `${k.width}px`, transform: "translateX(-100%)" };
      default:
        return { left: `${k.width / 2}px`, transform: "translateX(-50%)" };
    }
    return {};
  };
  return { openOnTop: f, menuStyle: T, xCorrect: u, setMenuPosition: L, getScrollableParent: b, shadowRender: (k, te, Ee) => {
    var ee, Ae, $;
    const Me = document.createElement("div"), B = (ee = Yt(n)) == null ? void 0 : ee.getBoundingClientRect();
    Me.setAttribute("id", "dp--temp-container");
    const z = (Ae = r.value) != null && Ae.clientWidth ? r.value : document.body;
    z.append(Me);
    const W = P(B), ie = o.value.shadowDom ? Object.keys(l).filter((F) => ["right-sidebar", "left-sidebar", "top-extra", "action-extra"].includes(F)) : Object.keys(l), h = Xo(te, { ...Ee, shadow: true, style: { opacity: 0, position: "absolute", ...W } }, Object.fromEntries(ie.map((F) => [F, l[F]])));
    k != null && (h.appContext = k.appContext), s0(h, Me), c.value = ($ = h.el) == null ? void 0 : $.getBoundingClientRect(), s0(null, Me), z.removeChild(Me);
  } };
}, lr = [{ name: "clock-icon", use: ["time", "calendar", "shared"] }, { name: "arrow-left", use: ["month-year", "calendar", "shared", "year-mode"] }, { name: "arrow-right", use: ["month-year", "calendar", "shared", "year-mode"] }, { name: "arrow-up", use: ["time", "calendar", "month-year", "shared"] }, { name: "arrow-down", use: ["time", "calendar", "month-year", "shared"] }, { name: "calendar-icon", use: ["month-year", "time", "calendar", "shared", "year-mode"] }, { name: "day", use: ["calendar", "shared"] }, { name: "month-overlay-value", use: ["calendar", "month-year", "shared"] }, { name: "year-overlay-value", use: ["calendar", "month-year", "shared", "year-mode"] }, { name: "year-overlay", use: ["month-year", "shared"] }, { name: "month-overlay", use: ["month-year", "shared"] }, { name: "month-overlay-header", use: ["month-year", "shared"] }, { name: "year-overlay-header", use: ["month-year", "shared"] }, { name: "hours-overlay-value", use: ["calendar", "time", "shared"] }, { name: "hours-overlay-header", use: ["calendar", "time", "shared"] }, { name: "minutes-overlay-value", use: ["calendar", "time", "shared"] }, { name: "minutes-overlay-header", use: ["calendar", "time", "shared"] }, { name: "seconds-overlay-value", use: ["calendar", "time", "shared"] }, { name: "seconds-overlay-header", use: ["calendar", "time", "shared"] }, { name: "hours", use: ["calendar", "time", "shared"] }, { name: "minutes", use: ["calendar", "time", "shared"] }, { name: "month", use: ["calendar", "month-year", "shared"] }, { name: "year", use: ["calendar", "month-year", "shared", "year-mode"] }, { name: "action-buttons", use: ["action"] }, { name: "action-preview", use: ["action"] }, { name: "calendar-header", use: ["calendar", "shared"] }, { name: "marker-tooltip", use: ["calendar", "shared"] }, { name: "action-extra", use: ["menu"] }, { name: "time-picker-overlay", use: ["calendar", "time", "shared"] }, { name: "am-pm-button", use: ["calendar", "time", "shared"] }, { name: "left-sidebar", use: ["menu"] }, { name: "right-sidebar", use: ["menu"] }, { name: "month-year", use: ["month-year", "shared"] }, { name: "time-picker", use: ["menu", "shared"] }, { name: "action-row", use: ["action"] }, { name: "marker", use: ["calendar", "shared"] }, { name: "quarter", use: ["shared"] }, { name: "top-extra", use: ["shared", "month-year"] }, { name: "tp-inline-arrow-up", use: ["shared", "time"] }, { name: "tp-inline-arrow-down", use: ["shared", "time"] }, { name: "menu-header", use: ["menu"] }], jD = [{ name: "trigger" }, { name: "input-icon" }, { name: "clear-icon" }, { name: "dp-input" }], $D = { all: () => lr, monthYear: () => lr.filter((t) => t.use.includes("month-year")), input: () => jD, timePicker: () => lr.filter((t) => t.use.includes("time")), action: () => lr.filter((t) => t.use.includes("action")), calendar: () => lr.filter((t) => t.use.includes("calendar")), menu: () => lr.filter((t) => t.use.includes("menu")), shared: () => lr.filter((t) => t.use.includes("shared")), yearMode: () => lr.filter((t) => t.use.includes("year-mode")) }, sn = (t, e, n) => {
  const r = [];
  return $D[e]().forEach((a) => {
    t[a.name] && r.push(a.name);
  }), n != null && n.length && n.forEach((a) => {
    a.slot && r.push(a.slot);
  }), r;
}, ya = (t) => {
  const e = Q(() => (r) => t.value ? r ? t.value.open : t.value.close : ""), n = Q(() => (r) => t.value ? r ? t.value.menuAppearTop : t.value.menuAppearBottom : "");
  return { transitionName: e, showTransition: !!t.value, menuTransition: n };
}, Oa = (t, e, n) => {
  const { defaultedRange: r, defaultedTz: a } = dt(t), i = de(Xt(de(), a.value.timezone)), s = se([{ month: je(i), year: xe(i) }]), l = (f) => {
    const m = { hours: Gn(i), minutes: rr(i), seconds: 0 };
    return r.value.enabled ? [m[f], m[f]] : m[f];
  }, o = na({ hours: l("hours"), minutes: l("minutes"), seconds: l("seconds") });
  vt(r, (f, m) => {
    f.enabled !== m.enabled && (o.hours = l("hours"), o.minutes = l("minutes"), o.seconds = l("seconds"));
  }, { deep: true });
  const c = Q({ get: () => t.internalModelValue, set: (f) => {
    !t.readonly && !t.disabled && e("update:internal-model-value", f);
  } }), u = Q(() => (f) => s.value[f] ? s.value[f].month : 0), T = Q(() => (f) => s.value[f] ? s.value[f].year : 0);
  return vt(c, (f, m) => {
    n && JSON.stringify(f ?? {}) !== JSON.stringify(m ?? {}) && n();
  }, { deep: true }), { calendars: s, time: o, modelValue: c, month: u, year: T, today: i };
}, VD = (t, e) => {
  const { defaultedMultiCalendars: n, defaultedMultiDates: r, defaultedUI: a, defaultedHighlight: i, defaultedTz: s, propDates: l, defaultedRange: o } = dt(e), { isDisabled: c } = ur(e), u = se(null), T = se(Xt(/* @__PURE__ */ new Date(), s.value.timezone)), f = (h) => {
    !h.current && e.hideOffsetDates || (u.value = h.value);
  }, m = () => {
    u.value = null;
  }, v = (h) => Array.isArray(t.value) && o.value.enabled && t.value[0] && u.value ? h ? Ft(u.value, t.value[0]) : pt(u.value, t.value[0]) : true, E = (h, F) => {
    const U = () => t.value ? F ? t.value[0] || null : t.value[1] : null, ne = t.value && Array.isArray(t.value) ? U() : null;
    return $e(de(h.value), ne);
  }, A = (h) => {
    const F = Array.isArray(t.value) ? t.value[0] : null;
    return h ? !pt(u.value ?? null, F) : true;
  }, g = (h, F = true) => (o.value.enabled || e.weekPicker) && Array.isArray(t.value) && t.value.length === 2 ? e.hideOffsetDates && !h.current ? false : $e(de(h.value), t.value[F ? 0 : 1]) : o.value.enabled ? E(h, F) && A(F) || $e(h.value, Array.isArray(t.value) ? t.value[0] : null) && v(F) : false, O = (h, F) => {
    if (Array.isArray(t.value) && t.value[0] && t.value.length === 1) {
      const U = $e(h.value, u.value);
      return F ? Ft(t.value[0], h.value) && U : pt(t.value[0], h.value) && U;
    }
    return false;
  }, D = (h) => !t.value || e.hideOffsetDates && !h.current ? false : o.value.enabled ? e.modelAuto && Array.isArray(t.value) ? $e(h.value, t.value[0] ? t.value[0] : T.value) : false : r.value.enabled && Array.isArray(t.value) ? t.value.some((F) => $e(F, h.value)) : $e(h.value, t.value ? t.value : T.value), w = (h) => {
    if (o.value.autoRange || e.weekPicker) {
      if (u.value) {
        if (e.hideOffsetDates && !h.current) return false;
        const F = dn(u.value, +o.value.autoRange), U = zn(de(u.value), e.weekStart);
        return e.weekPicker ? $e(U[1], de(h.value)) : $e(F, de(h.value));
      }
      return false;
    }
    return false;
  }, L = (h) => {
    if (o.value.autoRange || e.weekPicker) {
      if (u.value) {
        const F = dn(u.value, +o.value.autoRange);
        if (e.hideOffsetDates && !h.current) return false;
        const U = zn(de(u.value), e.weekStart);
        return e.weekPicker ? Ft(h.value, U[0]) && pt(h.value, U[1]) : Ft(h.value, u.value) && pt(h.value, F);
      }
      return false;
    }
    return false;
  }, _ = (h) => {
    if (o.value.autoRange || e.weekPicker) {
      if (u.value) {
        if (e.hideOffsetDates && !h.current) return false;
        const F = zn(de(u.value), e.weekStart);
        return e.weekPicker ? $e(F[0], h.value) : $e(u.value, h.value);
      }
      return false;
    }
    return false;
  }, I = (h) => ga(t.value, u.value, h.value), V = () => e.modelAuto && Array.isArray(e.internalModelValue) ? !!e.internalModelValue[0] : false, H = () => e.modelAuto ? Rl(e.internalModelValue) : true, Z = (h) => {
    if (e.weekPicker) return false;
    const F = o.value.enabled ? !g(h) && !g(h, false) : true;
    return !c(h.value) && !D(h) && !(!h.current && e.hideOffsetDates) && F;
  }, J = (h) => o.value.enabled ? e.modelAuto ? V() && D(h) : false : D(h), re = (h) => i.value ? dp(h.value, l.value.highlight) : false, oe = (h) => {
    const F = c(h.value);
    return F && (typeof i.value == "function" ? !i.value(h.value, F) : !i.value.options.highlightDisabled);
  }, b = (h) => {
    var F;
    return typeof i.value == "function" ? i.value(h.value) : (F = i.value.weekdays) == null ? void 0 : F.includes(h.value.getDay());
  }, P = (h) => (o.value.enabled || e.weekPicker) && (!(n.value.count > 0) || h.current) && H() && !(!h.current && e.hideOffsetDates) && !D(h) ? I(h) : false, k = (h) => {
    if (Array.isArray(t.value) && t.value.length === 1) {
      const { before: F, after: U } = xl(+o.value.maxRange, t.value[0]);
      return zr(h.value, F) || yr(h.value, U);
    }
    return false;
  }, te = (h) => {
    if (Array.isArray(t.value) && t.value.length === 1) {
      const { before: F, after: U } = xl(+o.value.minRange, t.value[0]);
      return ga([F, U], t.value[0], h.value);
    }
    return false;
  }, Ee = (h) => o.value.enabled && (o.value.maxRange || o.value.minRange) ? o.value.maxRange && o.value.minRange ? k(h) || te(h) : o.value.maxRange ? k(h) : te(h) : false, ee = (h) => {
    const { isRangeStart: F, isRangeEnd: U } = B(h), ne = o.value.enabled ? F || U : false;
    return { dp__cell_offset: !h.current, dp__pointer: !e.disabled && !(!h.current && e.hideOffsetDates) && !c(h.value) && !Ee(h), dp__cell_disabled: c(h.value) || Ee(h), dp__cell_highlight: !oe(h) && (re(h) || b(h)) && !J(h) && !ne && !_(h) && !(P(h) && e.weekPicker) && !U, dp__cell_highlight_active: !oe(h) && (re(h) || b(h)) && J(h), dp__today: !e.noToday && $e(h.value, T.value) && h.current, "dp--past": pt(h.value, T.value), "dp--future": Ft(h.value, T.value) };
  }, Ae = (h) => ({ dp__active_date: J(h), dp__date_hover: Z(h) }), $ = (h) => {
    if (t.value && !Array.isArray(t.value)) {
      const F = zn(t.value, e.weekStart);
      return { ...W(h), dp__range_start: $e(F[0], h.value), dp__range_end: $e(F[1], h.value), dp__range_between_week: Ft(h.value, F[0]) && pt(h.value, F[1]) };
    }
    return { ...W(h) };
  }, Me = (h) => {
    if (t.value && Array.isArray(t.value)) {
      const F = zn(t.value[0], e.weekStart), U = t.value[1] ? zn(t.value[1], e.weekStart) : [];
      return { ...W(h), dp__range_start: $e(F[0], h.value) || $e(U[0], h.value), dp__range_end: $e(F[1], h.value) || $e(U[1], h.value), dp__range_between_week: Ft(h.value, F[0]) && pt(h.value, F[1]) || Ft(h.value, U[0]) && pt(h.value, U[1]), dp__range_between: Ft(h.value, F[1]) && pt(h.value, U[0]) };
    }
    return { ...W(h) };
  }, B = (h) => {
    const F = n.value.count > 0 ? h.current && g(h) && H() : g(h) && H(), U = n.value.count > 0 ? h.current && g(h, false) && H() : g(h, false) && H();
    return { isRangeStart: F, isRangeEnd: U };
  }, z = (h) => {
    const { isRangeStart: F, isRangeEnd: U } = B(h);
    return { dp__range_start: F, dp__range_end: U, dp__range_between: P(h), dp__date_hover: $e(h.value, u.value) && !F && !U && !e.weekPicker, dp__date_hover_start: O(h, true), dp__date_hover_end: O(h, false) };
  }, W = (h) => ({ ...z(h), dp__cell_auto_range: L(h), dp__cell_auto_range_start: _(h), dp__cell_auto_range_end: w(h) }), ie = (h) => o.value.enabled ? o.value.autoRange ? W(h) : e.modelAuto ? { ...Ae(h), ...z(h) } : e.weekPicker ? Me(h) : z(h) : e.weekPicker ? $(h) : Ae(h);
  return { setHoverDate: f, clearHoverDate: m, getDayClassData: (h) => e.hideOffsetDates && !h.current ? {} : { ...ee(h), ...ie(h), [e.dayClass ? e.dayClass(h.value, e.internalModelValue) : ""]: true, ...a.value.calendarCell ?? {} } };
}, ur = (t) => {
  const { defaultedFilters: e, defaultedRange: n, propDates: r, defaultedMultiDates: a } = dt(t), i = (b) => r.value.disabledDates ? typeof r.value.disabledDates == "function" ? r.value.disabledDates(de(b)) : !!Fi(b, r.value.disabledDates) : false, s = (b) => r.value.maxDate ? t.yearPicker ? xe(b) > xe(r.value.maxDate) : Ft(b, r.value.maxDate) : false, l = (b) => r.value.minDate ? t.yearPicker ? xe(b) < xe(r.value.minDate) : pt(b, r.value.minDate) : false, o = (b) => {
    const P = s(b), k = l(b), te = i(b), Ee = e.value.months.map((B) => +B).includes(je(b)), ee = t.disabledWeekDays.length ? t.disabledWeekDays.some((B) => +B === Xm(b)) : false, Ae = m(b), $ = xe(b), Me = $ < +t.yearRange[0] || $ > +t.yearRange[1];
    return !(P || k || te || Ee || Me || ee || Ae);
  }, c = (b, P) => pt(...sr(r.value.minDate, b, P)) || $e(...sr(r.value.minDate, b, P)), u = (b, P) => Ft(...sr(r.value.maxDate, b, P)) || $e(...sr(r.value.maxDate, b, P)), T = (b, P, k) => {
    let te = false;
    return r.value.maxDate && k && u(b, P) && (te = true), r.value.minDate && !k && c(b, P) && (te = true), te;
  }, f = (b, P, k, te) => {
    let Ee = false;
    return te && (r.value.minDate || r.value.maxDate) ? r.value.minDate && r.value.maxDate ? Ee = T(b, P, k) : (r.value.minDate && c(b, P) || r.value.maxDate && u(b, P)) && (Ee = true) : Ee = true, Ee;
  }, m = (b) => Array.isArray(r.value.allowedDates) && !r.value.allowedDates.length ? true : r.value.allowedDates ? !Fi(b, r.value.allowedDates, Ml(t.monthPicker, t.yearPicker)) : false, v = (b) => !o(b), E = (b) => n.value.noDisabledRange ? !J0({ start: b[0], end: b[1] }).some((P) => v(P)) : true, A = (b) => {
    if (b) {
      const P = xe(b);
      return P >= +t.yearRange[0] && P <= t.yearRange[1];
    }
    return true;
  }, g = (b, P) => !!(Array.isArray(b) && b[P] && (n.value.maxRange || n.value.minRange) && A(b[P])), O = (b, P, k = 0) => {
    if (g(P, k) && A(b)) {
      const te = V0(b, P[k]), Ee = Bl(P[k], b), ee = Ee.length === 1 ? 0 : Ee.filter(($) => v($)).length, Ae = Math.abs(te) - (n.value.minMaxRawRange ? 0 : ee);
      if (n.value.minRange && n.value.maxRange) return Ae >= +n.value.minRange && Ae <= +n.value.maxRange;
      if (n.value.minRange) return Ae >= +n.value.minRange;
      if (n.value.maxRange) return Ae <= +n.value.maxRange;
    }
    return true;
  }, D = () => !t.enableTimePicker || t.monthPicker || t.yearPicker || t.ignoreTimeValidation, w = (b) => Array.isArray(b) ? [b[0] ? ro(b[0]) : null, b[1] ? ro(b[1]) : null] : ro(b), L = (b, P, k) => b.find((te) => +te.hours === Gn(P) && te.minutes === "*" ? true : +te.minutes === rr(P) && +te.hours === Gn(P)) && k, _ = (b, P, k) => {
    const [te, Ee] = b, [ee, Ae] = P;
    return !L(te, ee, k) && !L(Ee, Ae, k) && k;
  }, I = (b, P) => {
    const k = Array.isArray(P) ? P : [P];
    return Array.isArray(t.disabledTimes) ? Array.isArray(t.disabledTimes[0]) ? _(t.disabledTimes, k, b) : !k.some((te) => L(t.disabledTimes, te, b)) : b;
  }, V = (b, P) => {
    const k = Array.isArray(P) ? [Mr(P[0]), P[1] ? Mr(P[1]) : void 0] : Mr(P), te = !t.disabledTimes(k);
    return b && te;
  }, H = (b, P) => t.disabledTimes ? Array.isArray(t.disabledTimes) ? I(P, b) : V(P, b) : P, Z = (b) => {
    let P = true;
    if (!b || D()) return true;
    const k = !r.value.minDate && !r.value.maxDate ? w(b) : b;
    return (t.maxTime || r.value.maxDate) && (P = kl(t.maxTime, r.value.maxDate, "max", Zt(k), P)), (t.minTime || r.value.minDate) && (P = kl(t.minTime, r.value.minDate, "min", Zt(k), P)), H(b, P);
  }, J = (b) => {
    if (!t.monthPicker) return true;
    let P = true;
    const k = de(Rn(b));
    if (r.value.minDate && r.value.maxDate) {
      const te = de(Rn(r.value.minDate)), Ee = de(Rn(r.value.maxDate));
      return Ft(k, te) && pt(k, Ee) || $e(k, te) || $e(k, Ee);
    }
    if (r.value.minDate) {
      const te = de(Rn(r.value.minDate));
      P = Ft(k, te) || $e(k, te);
    }
    if (r.value.maxDate) {
      const te = de(Rn(r.value.maxDate));
      P = pt(k, te) || $e(k, te);
    }
    return P;
  }, re = Q(() => (b) => !t.enableTimePicker || t.ignoreTimeValidation ? true : Z(b)), oe = Q(() => (b) => t.monthPicker ? Array.isArray(b) && (n.value.enabled || a.value.enabled) ? !b.filter((P) => !J(P)).length : J(b) : true);
  return { isDisabled: v, validateDate: o, validateMonthYearInRange: f, isDateRangeAllowed: E, checkMinMaxRange: O, isValidTime: Z, isTimeValid: re, isMonthValid: oe };
}, wi = () => {
  const t = Q(() => (r, a) => r?.includes(a)), e = Q(() => (r, a) => r.count ? r.solo ? true : a === 0 : true), n = Q(() => (r, a) => r.count ? r.solo ? true : a === r.count - 1 : true);
  return { hideNavigationButtons: t, showLeftIcon: e, showRightIcon: n };
}, QD = (t, e, n) => {
  const r = se(0), a = na({ [Or.timePicker]: !t.enableTimePicker || t.timePicker || t.monthPicker, [Or.calendar]: false, [Or.header]: false }), i = Q(() => t.monthPicker || t.timePicker), s = (T) => {
    var f;
    if ((f = t.flow) != null && f.length) {
      if (!T && i.value) return u();
      a[T] = true, Object.keys(a).filter((m) => !a[m]).length || u();
    }
  }, l = () => {
    var T, f;
    (T = t.flow) != null && T.length && r.value !== -1 && (r.value += 1, e("flow-step", r.value), u()), ((f = t.flow) == null ? void 0 : f.length) === r.value && Bt().then(() => o());
  }, o = () => {
    r.value = -1;
  }, c = (T, f, ...m) => {
    var v, E;
    t.flow[r.value] === T && n.value && ((E = (v = n.value)[f]) == null || E.call(v, ...m));
  }, u = (T = 0) => {
    T && (r.value += T), c(Pt.month, "toggleMonthPicker", true), c(Pt.year, "toggleYearPicker", true), c(Pt.calendar, "toggleTimePicker", false, true), c(Pt.time, "toggleTimePicker", true, true);
    const f = t.flow[r.value];
    (f === Pt.hours || f === Pt.minutes || f === Pt.seconds) && c(f, "toggleTimePicker", true, true, f);
  };
  return { childMount: s, updateFlowStep: l, resetFlow: o, handleFlow: u, flowStep: r };
}, WD = { key: 1, class: "dp__input_wrap" }, qD = ["id", "name", "inputmode", "placeholder", "disabled", "readonly", "required", "value", "autocomplete", "aria-label", "aria-disabled", "aria-invalid"], KD = { key: 2, class: "dp--clear-btn" }, JD = ["aria-label"], XD = Ve({ compatConfig: { MODE: 3 }, __name: "DatepickerInput", props: { isMenuOpen: { type: Boolean, default: false }, inputValue: { type: String, default: "" }, ...Mi }, emits: ["clear", "open", "update:input-value", "set-input-date", "close", "select-date", "set-empty-date", "toggle", "focus-prev", "focus", "blur", "real-blur", "text-input"], setup(t, { expose: e, emit: n }) {
  const r = n, a = t, { defaultedTextInput: i, defaultedAriaLabels: s, defaultedInline: l, defaultedConfig: o, defaultedRange: c, defaultedMultiDates: u, defaultedUI: T, getDefaultPattern: f, getDefaultStartTime: m } = dt(a), { checkMinMaxRange: v } = ur(a), E = se(), A = se(null), g = se(false), O = se(false), D = Q(() => ({ dp__pointer: !a.disabled && !a.readonly && !i.value.enabled, dp__disabled: a.disabled, dp__input_readonly: !i.value.enabled, dp__input: true, dp__input_icon_pad: !a.hideInputIcon, dp__input_valid: typeof a.state == "boolean" ? a.state : false, dp__input_invalid: typeof a.state == "boolean" ? !a.state : false, dp__input_focus: g.value || a.isMenuOpen, dp__input_reg: !i.value.enabled, ...T.value.input ?? {} })), w = () => {
    r("set-input-date", null), a.clearable && a.autoApply && (r("set-empty-date"), E.value = null);
  }, L = ($) => {
    const Me = m();
    return fp($, i.value.format ?? f(), Me ?? Zl({}, a.enableSeconds), a.inputValue, O.value, a.formatLocale);
  }, _ = ($) => {
    const { rangeSeparator: Me } = i.value, [B, z] = $.split(`${Me}`);
    if (B) {
      const W = L(B.trim()), ie = z ? L(z.trim()) : void 0;
      if (yr(W, ie)) return;
      const h = W && ie ? [W, ie] : [W];
      v(ie, h, 0) && (E.value = W ? h : null);
    }
  }, I = () => {
    O.value = true;
  }, V = ($) => {
    if (c.value.enabled) _($);
    else if (u.value.enabled) {
      const Me = $.split(";");
      E.value = Me.map((B) => L(B.trim())).filter((B) => B);
    } else E.value = L($);
  }, H = ($) => {
    var Me;
    const B = typeof $ == "string" ? $ : (Me = $.target) == null ? void 0 : Me.value;
    B !== "" ? (i.value.openMenu && !a.isMenuOpen && r("open"), V(B), r("set-input-date", E.value)) : w(), O.value = false, r("update:input-value", B), r("text-input", $, E.value);
  }, Z = ($) => {
    i.value.enabled ? (V($.target.value), i.value.enterSubmit && eo(E.value) && a.inputValue !== "" ? (r("set-input-date", E.value, true), E.value = null) : i.value.enterSubmit && a.inputValue === "" && (E.value = null, r("clear"))) : oe($);
  }, J = ($, Me) => {
    i.value.enabled && i.value.tabSubmit && !Me && V($.target.value), i.value.tabSubmit && eo(E.value) && a.inputValue !== "" ? (r("set-input-date", E.value, true, true), E.value = null) : i.value.tabSubmit && a.inputValue === "" && (E.value = null, r("clear", true));
  }, re = () => {
    g.value = true, r("focus"), Bt().then(() => {
      var $;
      i.value.enabled && i.value.selectOnFocus && (($ = A.value) == null || $.select());
    });
  }, oe = ($) => {
    if (ar($, o.value, true), i.value.enabled && i.value.openMenu && !l.value.input) {
      if (i.value.openMenu === "open" && !a.isMenuOpen) return r("open");
      if (i.value.openMenu === "toggle") return r("toggle");
    } else i.value.enabled || r("toggle");
  }, b = () => {
    r("real-blur"), g.value = false, (!a.isMenuOpen || l.value.enabled && l.value.input) && r("blur"), a.autoApply && i.value.enabled && E.value && !a.isMenuOpen && (r("set-input-date", E.value), r("select-date"), E.value = null);
  }, P = ($) => {
    ar($, o.value, true), r("clear");
  }, k = () => {
    r("close");
  }, te = ($) => {
    if ($.key === "Tab" && J($), $.key === "Enter" && Z($), $.key === "Escape" && i.value.escClose && k(), !i.value.enabled) {
      if ($.code === "Tab") return;
      $.preventDefault();
    }
  }, Ee = () => {
    var $;
    ($ = A.value) == null || $.focus({ preventScroll: true });
  }, ee = ($) => {
    E.value = $;
  }, Ae = ($) => {
    $.key === ut.tab && J($, true);
  };
  return e({ focusInput: Ee, setParsedDate: ee }), ($, Me) => {
    var B, z, W;
    return p(), M("div", { onClick: oe }, [$.$slots.trigger && !$.$slots["dp-input"] && !S(l).enabled ? le($.$slots, "trigger", { key: 0 }) : x("", true), !$.$slots.trigger && (!S(l).enabled || S(l).input) ? (p(), M("div", WD, [$.$slots["dp-input"] && !$.$slots.trigger && (!S(l).enabled || S(l).enabled && S(l).input) ? le($.$slots, "dp-input", { key: 0, value: t.inputValue, isMenuOpen: t.isMenuOpen, onInput: H, onEnter: Z, onTab: J, onClear: P, onBlur: b, onKeypress: te, onPaste: I, onFocus: re, openMenu: () => $.$emit("open"), closeMenu: () => $.$emit("close"), toggleMenu: () => $.$emit("toggle") }) : x("", true), $.$slots["dp-input"] ? x("", true) : (p(), M("input", { key: 1, id: $.uid ? `dp-input-${$.uid}` : void 0, ref_key: "inputRef", ref: A, "data-test-id": "dp-input", name: $.name, class: ye(D.value), inputmode: S(i).enabled ? "text" : "none", placeholder: $.placeholder, disabled: $.disabled, readonly: $.readonly, required: $.required, value: t.inputValue, autocomplete: $.autocomplete, "aria-label": (B = S(s)) == null ? void 0 : B.input, "aria-disabled": $.disabled || void 0, "aria-invalid": $.state === false ? true : void 0, onInput: H, onBlur: b, onFocus: re, onKeypress: te, onKeydown: Me[0] || (Me[0] = (ie) => te(ie)), onPaste: I }, null, 42, qD)), j("div", { onClick: Me[3] || (Me[3] = (ie) => r("toggle")) }, [$.$slots["input-icon"] && !$.hideInputIcon ? (p(), M("span", { key: 0, class: "dp__input_icon", onClick: Me[1] || (Me[1] = (ie) => r("toggle")) }, [le($.$slots, "input-icon")])) : x("", true), !$.$slots["input-icon"] && !$.hideInputIcon && !$.$slots["dp-input"] ? (p(), De(S(Vr), { key: 1, "aria-label": (z = S(s)) == null ? void 0 : z.calendarIcon, class: "dp__input_icon dp__input_icons", onClick: Me[2] || (Me[2] = (ie) => r("toggle")) }, null, 8, ["aria-label"])) : x("", true)]), $.$slots["clear-icon"] && ($.alwaysClearable || t.inputValue && $.clearable && !$.disabled && !$.readonly) ? (p(), M("span", KD, [le($.$slots, "clear-icon", { clear: P })])) : x("", true), !$.$slots["clear-icon"] && ($.alwaysClearable || $.clearable && t.inputValue && !$.disabled && !$.readonly) ? (p(), M("button", { key: 3, "aria-label": (W = S(s)) == null ? void 0 : W.clearInput, class: "dp--clear-btn", type: "button", onKeydown: Me[4] || (Me[4] = (ie) => S(Qt)(ie, () => P(ie), true, Ae)), onClick: Me[5] || (Me[5] = at((ie) => P(ie), ["prevent"])) }, [Oe(S(Sl), { class: "dp__input_icons", "data-test-id": "clear-icon" })], 40, JD)) : x("", true)])) : x("", true)]);
  };
} }), eS = typeof window < "u" ? window : void 0, fo = () => {
}, tS = (t) => _c() ? (Bc(t), true) : false, nS = (t, e, n, r) => {
  if (!t) return fo;
  let a = fo;
  const i = vt(() => S(t), (l) => {
    a(), l && (l.removeEventListener(e, n), l.addEventListener(e, n, r), a = () => {
      l.removeEventListener(e, n, r), a = fo;
    });
  }, { immediate: true, flush: "post" }), s = () => {
    i(), a();
  };
  return tS(s), s;
}, rS = (t, e, n, r = {}) => {
  const { window: a = eS, event: i = "pointerdown" } = r;
  return a ? nS(a, i, (s) => {
    const l = Yt(t), o = Yt(e);
    !l || !o || l === s.target || s.composedPath().includes(l) || s.composedPath().includes(o) || n(s);
  }, { passive: true }) : void 0;
}, aS = ["data-dp-mobile"], iS = Ve({ compatConfig: { MODE: 3 }, __name: "VueDatePicker", props: { ...Mi }, emits: ["update:model-value", "update:model-timezone-value", "text-submit", "closed", "cleared", "open", "focus", "blur", "internal-model-change", "recalculate-position", "flow-step", "update-month-year", "invalid-select", "invalid-fixed-range", "tooltip-open", "tooltip-close", "time-picker-open", "time-picker-close", "am-pm-change", "range-start", "range-end", "date-update", "invalid-date", "overlay-toggle", "text-input"], setup(t, { expose: e, emit: n }) {
  const r = n, a = t, i = mn(), s = se(false), l = ra(a, "modelValue"), o = ra(a, "timezone"), c = se(null), u = se(null), T = se(null), f = se(false), m = se(null), v = se(false), E = se(false), A = se(false), g = se(false), { setMenuFocused: O, setShiftKey: D } = Hl(), { clearArrowNav: w } = or(), { validateDate: L, isValidTime: _ } = ur(a), { defaultedTransitions: I, defaultedTextInput: V, defaultedInline: H, defaultedConfig: Z, defaultedRange: J, defaultedMultiDates: re } = dt(a), { menuTransition: oe, showTransition: b } = ya(I), { isMobile: P } = ql(Z), k = Jo();
  gt(() => {
    h(a.modelValue), Bt().then(() => {
      if (!H.value.enabled) {
        const X = B(m.value);
        X?.addEventListener("scroll", Se), window?.addEventListener("resize", ve);
      }
    }), H.value.enabled && (s.value = true), window?.addEventListener("keyup", ze), window?.addEventListener("keydown", Ue);
  }), Sr(() => {
    if (!H.value.enabled) {
      const X = B(m.value);
      X?.removeEventListener("scroll", Se), window?.removeEventListener("resize", ve);
    }
    window?.removeEventListener("keyup", ze), window?.removeEventListener("keydown", Ue);
  });
  const te = sn(i, "all", a.presetDates), Ee = sn(i, "input");
  vt([l, o], () => {
    h(l.value);
  }, { deep: true });
  const { openOnTop: ee, menuStyle: Ae, xCorrect: $, setMenuPosition: Me, getScrollableParent: B, shadowRender: z } = zD({ menuRef: c, menuRefInner: u, inputRef: T, pickerWrapperRef: m, inline: H, emit: r, props: a, slots: i }), { inputValue: W, internalModelValue: ie, parseExternalModelValue: h, emitModelValue: F, formatInputValue: U, checkBeforeEmit: ne } = xp(r, a, f), Y = Q(() => ({ dp__main: true, dp__theme_dark: a.dark, dp__theme_light: !a.dark, dp__flex_display: H.value.enabled, "dp--flex-display-collapsed": A.value, dp__flex_display_with_input: H.value.input })), pe = Q(() => a.dark ? "dp__theme_dark" : "dp__theme_light"), q = Q(() => a.teleport ? { to: typeof a.teleport == "boolean" ? "body" : a.teleport, disabled: !a.teleport || H.value.enabled } : {}), Te = Q(() => ({ class: "dp__outer_menu_wrap" })), R = Q(() => H.value.enabled && (a.timePicker || a.monthPicker || a.yearPicker || a.quarterPicker)), me = () => {
    var X, Fe;
    return ((Fe = (X = T.value) == null ? void 0 : X.$el) == null ? void 0 : Fe.getBoundingClientRect()) ?? { width: 0, left: 0, right: 0 };
  }, Se = () => {
    s.value && (Z.value.closeOnScroll ? d() : Me());
  }, ve = () => {
    var X;
    s.value && Me();
    const Fe = ((X = u.value) == null ? void 0 : X.$el.getBoundingClientRect().width) ?? 0;
    A.value = document.body.offsetWidth <= Fe;
  }, ze = (X) => {
    X.key === "Tab" && !H.value.enabled && !a.teleport && Z.value.tabOutClosesMenu && (m.value.contains(document.activeElement) || d()), E.value = X.shiftKey;
  }, Ue = (X) => {
    E.value = X.shiftKey;
  }, We = () => {
    !a.disabled && !a.readonly && (z(k, Kl, a), Me(false), s.value = true, s.value && r("open"), s.value || we(), h(a.modelValue));
  }, ht = () => {
    var X, Fe;
    W.value = "", we(), (X = u.value) == null || X.onValueCleared(), (Fe = T.value) == null || Fe.setParsedDate(null), r("update:model-value", null), r("update:model-timezone-value", null), r("cleared"), Z.value.closeOnClearValue && d();
  }, G = () => {
    const X = ie.value;
    return !X || !Array.isArray(X) && L(X) ? true : Array.isArray(X) ? re.value.enabled || X.length === 2 && L(X[0]) && L(X[1]) ? true : J.value.partialRange && !a.timePicker ? L(X[0]) : false : false;
  }, Re = () => {
    ne() && G() ? (F(), d()) : r("invalid-select", ie.value);
  }, Qe = (X) => {
    St(), F(), Z.value.closeOnAutoApply && !X && d();
  }, St = () => {
    T.value && V.value.enabled && T.value.setParsedDate(ie.value);
  }, un = (X = false) => {
    a.autoApply && _(ie.value) && G() && (J.value.enabled && Array.isArray(ie.value) ? (J.value.partialRange || ie.value.length === 2) && Qe(X) : Qe(X));
  }, we = () => {
    V.value.enabled || (ie.value = null);
  }, d = (X = false) => {
    var Fe, be;
    X && ie.value && Z.value.setDateOnMenuClose && Re(), H.value.enabled || (s.value && (s.value = false, $.value = false, O(false), D(false), w(), r("closed"), W.value && h(l.value)), we(), r("blur"), (be = (Fe = u.value) == null ? void 0 : Fe.$el) == null || be.remove());
  }, N = (X, Fe, be = false) => {
    if (!X) {
      ie.value = null;
      return;
    }
    const hn = Array.isArray(X) ? !X.some((yn) => !L(yn)) : L(X), nn = _(X);
    hn && nn ? (g.value = true, ie.value = X, Fe ? (v.value = be, Re(), r("text-submit")) : a.autoApply && un(), Bt().then(() => {
      g.value = false;
    })) : r("invalid-date", X);
  }, y = () => {
    a.autoApply && _(ie.value) && F(), St();
  }, K = () => s.value ? d() : We(), ge = (X) => {
    ie.value = X;
  }, Ne = () => {
    V.value.enabled && (f.value = true, U()), r("focus");
  }, Ye = () => {
    if (V.value.enabled && (f.value = false, h(a.modelValue), v.value)) {
      const X = Tp(m.value, E.value);
      X?.focus();
    }
    r("blur");
  }, ke = (X) => {
    u.value && u.value.updateMonthYear(0, { month: Nl(X.month), year: Nl(X.year) });
  }, Ze = (X) => {
    h(X ?? a.modelValue);
  }, C = (X, Fe) => {
    var be;
    (be = u.value) == null || be.switchView(X, Fe);
  }, ue = (X, Fe) => Z.value.onClickOutside ? Z.value.onClickOutside(X, Fe) : d(true), _e = (X = 0) => {
    var Fe;
    (Fe = u.value) == null || Fe.handleFlow(X);
  }, Ce = () => c;
  return rS(c, T, (X) => ue(G, X)), e({ closeMenu: d, selectDate: Re, clearValue: ht, openMenu: We, onScroll: Se, formatInputValue: U, updateInternalModelValue: ge, setMonthYear: ke, parseModel: Ze, switchView: C, toggleMenu: K, handleFlow: _e, getDpWrapMenuRef: Ce }), (X, Fe) => (p(), M("div", { ref_key: "pickerWrapperRef", ref: m, class: ye(Y.value), "data-datepicker-instance": "", "data-dp-mobile": S(P) }, [Oe(XD, Le({ ref_key: "inputRef", ref: T, "input-value": S(W), "onUpdate:inputValue": Fe[0] || (Fe[0] = (be) => i0(W) ? W.value = be : null), "is-menu-open": s.value }, X.$props, { onClear: ht, onOpen: We, onSetInputDate: N, onSetEmptyDate: S(F), onSelectDate: Re, onToggle: K, onClose: d, onFocus: Ne, onBlur: Ye, onRealBlur: Fe[1] || (Fe[1] = (be) => f.value = false), onTextInput: Fe[2] || (Fe[2] = (be) => X.$emit("text-input", be)) }), wt({ _: 2 }, [rt(S(Ee), (be, hn) => ({ name: be, fn: he((nn) => [le(X.$slots, be, bt(Ht(nn)))]) }))]), 1040, ["input-value", "is-menu-open", "onSetEmptyDate"]), (p(), De(pr(X.teleport ? Ia : "div"), bt(Ht(q.value)), { default: he(() => [Oe(qn, { name: S(oe)(S(ee)), css: S(b) && !S(H).enabled }, { default: he(() => [s.value ? (p(), M("div", Le({ key: 0, ref_key: "dpWrapMenuRef", ref: c }, Te.value, { class: { "dp--menu-wrapper": !S(H).enabled }, style: S(H).enabled ? void 0 : S(Ae) }), [Oe(Kl, Le({ ref_key: "dpMenuRef", ref: u }, X.$props, { "internal-model-value": S(ie), "onUpdate:internalModelValue": Fe[3] || (Fe[3] = (be) => i0(ie) ? ie.value = be : null), class: { [pe.value]: true, "dp--menu-wrapper": X.teleport }, "open-on-top": S(ee), "no-overlay-focus": R.value, collapse: A.value, "get-input-rect": me, "is-text-input-date": g.value, onClosePicker: d, onSelectDate: Re, onAutoApply: un, onTimeUpdate: y, onFlowStep: Fe[4] || (Fe[4] = (be) => X.$emit("flow-step", be)), onUpdateMonthYear: Fe[5] || (Fe[5] = (be) => X.$emit("update-month-year", be)), onInvalidSelect: Fe[6] || (Fe[6] = (be) => X.$emit("invalid-select", S(ie))), onAutoApplyInvalid: Fe[7] || (Fe[7] = (be) => X.$emit("invalid-select", be)), onInvalidFixedRange: Fe[8] || (Fe[8] = (be) => X.$emit("invalid-fixed-range", be)), onRecalculatePosition: S(Me), onTooltipOpen: Fe[9] || (Fe[9] = (be) => X.$emit("tooltip-open", be)), onTooltipClose: Fe[10] || (Fe[10] = (be) => X.$emit("tooltip-close", be)), onTimePickerOpen: Fe[11] || (Fe[11] = (be) => X.$emit("time-picker-open", be)), onTimePickerClose: Fe[12] || (Fe[12] = (be) => X.$emit("time-picker-close", be)), onAmPmChange: Fe[13] || (Fe[13] = (be) => X.$emit("am-pm-change", be)), onRangeStart: Fe[14] || (Fe[14] = (be) => X.$emit("range-start", be)), onRangeEnd: Fe[15] || (Fe[15] = (be) => X.$emit("range-end", be)), onDateUpdate: Fe[16] || (Fe[16] = (be) => X.$emit("date-update", be)), onInvalidDate: Fe[17] || (Fe[17] = (be) => X.$emit("invalid-date", be)), onOverlayToggle: Fe[18] || (Fe[18] = (be) => X.$emit("overlay-toggle", be)), onMenuBlur: Fe[19] || (Fe[19] = (be) => X.$emit("blur")) }), wt({ _: 2 }, [rt(S(te), (be, hn) => ({ name: be, fn: he((nn) => [le(X.$slots, be, bt(Ht({ ...nn })))]) }))]), 1040, ["internal-model-value", "class", "open-on-top", "no-overlay-focus", "collapse", "is-text-input-date", "onRecalculatePosition"])], 16)) : x("", true)]), _: 3 }, 8, ["name", "css"])]), _: 3 }, 16))], 10, aS));
} }), Ao = (() => {
  const t = iS;
  return t.install = (e) => {
    e.component("Vue3DatePicker", t);
  }, t;
})(), sS = Object.freeze(Object.defineProperty({ __proto__: null, default: Ao }, Symbol.toStringTag, { value: "Module" }));
Object.entries(sS).forEach(([t, e]) => {
  t !== "default" && (Ao[t] = e);
});
class zi {
  static fromString(e) {
    return new zi(e);
  }
  constructor(e) {
    this.value = e;
  }
  icaltype = "binary";
  decodeValue() {
    return this._b64_decode(this.value);
  }
  setEncodedValue(e) {
    this.value = this._b64_encode(e);
  }
  _b64_encode(e) {
    let n = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", r, a, i, s, l, o, c, u, T = 0, f = 0, m = "", v = [];
    if (!e) return e;
    do
      r = e.charCodeAt(T++), a = e.charCodeAt(T++), i = e.charCodeAt(T++), u = r << 16 | a << 8 | i, s = u >> 18 & 63, l = u >> 12 & 63, o = u >> 6 & 63, c = u & 63, v[f++] = n.charAt(s) + n.charAt(l) + n.charAt(o) + n.charAt(c);
    while (T < e.length);
    m = v.join("");
    let E = e.length % 3;
    return (E ? m.slice(0, E - 3) : m) + "===".slice(E || 3);
  }
  _b64_decode(e) {
    let n = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", r, a, i, s, l, o, c, u, T = 0, f = 0, m = "", v = [];
    if (!e) return e;
    e += "";
    do
      s = n.indexOf(e.charAt(T++)), l = n.indexOf(e.charAt(T++)), o = n.indexOf(e.charAt(T++)), c = n.indexOf(e.charAt(T++)), u = s << 18 | l << 12 | o << 6 | c, r = u >> 16 & 255, a = u >> 8 & 255, i = u & 255, o == 64 ? v[f++] = String.fromCharCode(r) : c == 64 ? v[f++] = String.fromCharCode(r, a) : v[f++] = String.fromCharCode(r, a, i);
    while (T < e.length);
    return m = v.join(""), m;
  }
  toString() {
    return this.value;
  }
}
const oS = /([PDWHMTS]{1,1})/, lS = ["weeks", "days", "hours", "minutes", "seconds", "isNegative"];
class zt {
  static fromSeconds(e) {
    return new zt().fromSeconds(e);
  }
  static isValueString(e) {
    return e[0] === "P" || e[1] === "P";
  }
  static fromString(e) {
    let n = 0, r = /* @__PURE__ */ Object.create(null), a = 0;
    for (; (n = e.search(oS)) !== -1; ) {
      let i = e[n], s = e.slice(0, Math.max(0, n));
      e = e.slice(n + 1), a += uS(i, s, r);
    }
    if (a < 2) throw new Error('invalid duration value: Not enough duration components in "' + e + '"');
    return new zt(r);
  }
  static fromData(e) {
    return new zt(e);
  }
  constructor(e) {
    this.wrappedJSObject = this, this.fromData(e);
  }
  weeks = 0;
  days = 0;
  hours = 0;
  minutes = 0;
  seconds = 0;
  isNegative = false;
  icalclass = "icalduration";
  icaltype = "duration";
  clone() {
    return zt.fromData(this);
  }
  toSeconds() {
    let e = this.seconds + 60 * this.minutes + 3600 * this.hours + 86400 * this.days + 604800 * this.weeks;
    return this.isNegative ? -e : e;
  }
  fromSeconds(e) {
    let n = Math.abs(e);
    return this.isNegative = e < 0, this.days = Lt(n / 86400), this.days % 7 == 0 ? (this.weeks = this.days / 7, this.days = 0) : this.weeks = 0, n -= (this.days + 7 * this.weeks) * 86400, this.hours = Lt(n / 3600), n -= this.hours * 3600, this.minutes = Lt(n / 60), n -= this.minutes * 60, this.seconds = n, this;
  }
  fromData(e) {
    for (let n of lS) e && n in e ? this[n] = e[n] : this[n] = 0;
  }
  reset() {
    this.isNegative = false, this.weeks = 0, this.days = 0, this.hours = 0, this.minutes = 0, this.seconds = 0;
  }
  compare(e) {
    let n = this.toSeconds(), r = e.toSeconds();
    return (n > r) - (n < r);
  }
  normalize() {
    this.fromSeconds(this.toSeconds());
  }
  toString() {
    if (this.toSeconds() == 0) return "PT0S";
    {
      let e = "";
      this.isNegative && (e += "-"), e += "P";
      let n = false;
      return this.weeks ? this.days || this.hours || this.minutes || this.seconds ? e += this.weeks * 7 + this.days + "D" : (e += this.weeks + "W", n = true) : this.days && (e += this.days + "D"), n || (this.hours || this.minutes || this.seconds) && (e += "T", this.hours && (e += this.hours + "H"), this.minutes && (e += this.minutes + "M"), this.seconds && (e += this.seconds + "S")), e;
    }
  }
  toICALString() {
    return this.toString();
  }
}
function uS(t, e, n) {
  let r;
  switch (t) {
    case "P":
      e && e === "-" ? n.isNegative = true : n.isNegative = false;
      break;
    case "D":
      r = "days";
      break;
    case "W":
      r = "weeks";
      break;
    case "H":
      r = "hours";
      break;
    case "M":
      r = "minutes";
      break;
    case "S":
      r = "seconds";
      break;
    default:
      return 0;
  }
  if (r) {
    if (!e && e !== 0) throw new Error('invalid duration value: Missing number before "' + t + '"');
    let a = parseInt(e, 10);
    if (Ma(a)) throw new Error('invalid duration value: Invalid number "' + e + '" before "' + t + '"');
    n[r] = a;
  }
  return 1;
}
class Qn {
  static fromString(e, n) {
    let r = e.split("/");
    if (r.length !== 2) throw new Error('Invalid string value: "' + e + '" must contain a "/" char.');
    let a = { start: ae.fromDateTimeString(r[0], n) }, i = r[1];
    return zt.isValueString(i) ? a.duration = zt.fromString(i) : a.end = ae.fromDateTimeString(i, n), new Qn(a);
  }
  static fromData(e) {
    return new Qn(e);
  }
  static fromJSON(e, n, r) {
    function a(i, s) {
      return r ? ae.fromString(i, s) : ae.fromDateTimeString(i, s);
    }
    return zt.isValueString(e[1]) ? Qn.fromData({ start: a(e[0], n), duration: zt.fromString(e[1]) }) : Qn.fromData({ start: a(e[0], n), end: a(e[1], n) });
  }
  constructor(e) {
    if (this.wrappedJSObject = this, e && "start" in e) {
      if (e.start && !(e.start instanceof ae)) throw new TypeError(".start must be an instance of ICAL.Time");
      this.start = e.start;
    }
    if (e && e.end && e.duration) throw new Error("cannot accept both end and duration");
    if (e && "end" in e) {
      if (e.end && !(e.end instanceof ae)) throw new TypeError(".end must be an instance of ICAL.Time");
      this.end = e.end;
    }
    if (e && "duration" in e) {
      if (e.duration && !(e.duration instanceof zt)) throw new TypeError(".duration must be an instance of ICAL.Duration");
      this.duration = e.duration;
    }
  }
  start = null;
  end = null;
  duration = null;
  icalclass = "icalperiod";
  icaltype = "period";
  clone() {
    return Qn.fromData({ start: this.start ? this.start.clone() : null, end: this.end ? this.end.clone() : null, duration: this.duration ? this.duration.clone() : null });
  }
  getDuration() {
    return this.duration ? this.duration : this.end.subtractDate(this.start);
  }
  getEnd() {
    if (this.end) return this.end;
    {
      let e = this.start.clone();
      return e.addDuration(this.duration), e;
    }
  }
  compare(e) {
    return e.compare(this.start) < 0 ? 1 : e.compare(this.getEnd()) > 0 ? -1 : 0;
  }
  toString() {
    return this.start + "/" + (this.end || this.duration);
  }
  toJSON() {
    return [this.start.toString(), (this.end || this.duration).toString()];
  }
  toICALString() {
    return this.start.toICALString() + "/" + (this.end || this.duration).toICALString();
  }
}
class ae {
  static _dowCache = {};
  static _wnCache = {};
  static daysInMonth(e, n) {
    let r = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31], a = 30;
    return e < 1 || e > 12 || (a = r[e], e == 2 && (a += ae.isLeapYear(n))), a;
  }
  static isLeapYear(e) {
    return e <= 1752 ? e % 4 == 0 : e % 4 == 0 && e % 100 != 0 || e % 400 == 0;
  }
  static fromDayOfYear(e, n) {
    let r = n, a = e, i = new ae();
    i.auto_normalize = false;
    let s = ae.isLeapYear(r) ? 1 : 0;
    if (a < 1) return r--, s = ae.isLeapYear(r) ? 1 : 0, a += ae.daysInYearPassedMonth[s][12], ae.fromDayOfYear(a, r);
    if (a > ae.daysInYearPassedMonth[s][12]) return s = ae.isLeapYear(r) ? 1 : 0, a -= ae.daysInYearPassedMonth[s][12], r++, ae.fromDayOfYear(a, r);
    i.year = r, i.isDate = true;
    for (let l = 11; l >= 0; l--) if (a > ae.daysInYearPassedMonth[s][l]) {
      i.month = l + 1, i.day = a - ae.daysInYearPassedMonth[s][l];
      break;
    }
    return i.auto_normalize = true, i;
  }
  static fromStringv2(e) {
    return new ae({ year: parseInt(e.slice(0, 4), 10), month: parseInt(e.slice(5, 7), 10), day: parseInt(e.slice(8, 10), 10), isDate: true });
  }
  static fromDateString(e) {
    return new ae({ year: Gt(e.slice(0, 4)), month: Gt(e.slice(5, 7)), day: Gt(e.slice(8, 10)), isDate: true });
  }
  static fromDateTimeString(e, n) {
    if (e.length < 19) throw new Error('invalid date-time value: "' + e + '"');
    let r, a;
    e.slice(-1) === "Z" ? r = st.utcTimezone : n && (a = n.getParameter("tzid"), n.parent && (n.parent.name === "standard" || n.parent.name === "daylight" ? r = st.localTimezone : a && (r = n.parent.getTimeZoneByID(a))));
    const i = { year: Gt(e.slice(0, 4)), month: Gt(e.slice(5, 7)), day: Gt(e.slice(8, 10)), hour: Gt(e.slice(11, 13)), minute: Gt(e.slice(14, 16)), second: Gt(e.slice(17, 19)) };
    return a && !r && (i.timezone = a), new ae(i, r);
  }
  static fromString(e, n) {
    return e.length > 10 ? ae.fromDateTimeString(e, n) : ae.fromDateString(e);
  }
  static fromJSDate(e, n) {
    return new ae().fromJSDate(e, n);
  }
  static fromData = function(n, r) {
    return new ae().fromData(n, r);
  };
  static now() {
    return ae.fromJSDate(/* @__PURE__ */ new Date(), false);
  }
  static weekOneStarts(e, n) {
    let r = ae.fromData({ year: e, month: 1, day: 1, isDate: true }), a = r.dayOfWeek(), i = n || ae.DEFAULT_WEEK_START;
    return a > ae.THURSDAY && (r.day += 7), i > ae.THURSDAY && (r.day -= 7), r.day -= a - i, r;
  }
  static getDominicalLetter(e) {
    let n = "GFEDCBA", r = (e + (e / 4 | 0) + (e / 400 | 0) - (e / 100 | 0) - 1) % 7;
    return ae.isLeapYear(e) ? n[(r + 6) % 7] + n[r] : n[r];
  }
  static #e = null;
  static get epochTime() {
    return this.#e || (this.#e = ae.fromData({ year: 1970, month: 1, day: 1, hour: 0, minute: 0, second: 0, isDate: false, timezone: "Z" })), this.#e;
  }
  static _cmp_attr(e, n, r) {
    return e[r] > n[r] ? 1 : e[r] < n[r] ? -1 : 0;
  }
  static daysInYearPassedMonth = [[0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365], [0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335, 366]];
  static SUNDAY = 1;
  static MONDAY = 2;
  static TUESDAY = 3;
  static WEDNESDAY = 4;
  static THURSDAY = 5;
  static FRIDAY = 6;
  static SATURDAY = 7;
  static DEFAULT_WEEK_START = 2;
  constructor(e, n) {
    this.wrappedJSObject = this, this._time = /* @__PURE__ */ Object.create(null), this._time.year = 0, this._time.month = 1, this._time.day = 1, this._time.hour = 0, this._time.minute = 0, this._time.second = 0, this._time.isDate = false, this.fromData(e, n);
  }
  icalclass = "icaltime";
  _cachedUnixTime = null;
  get icaltype() {
    return this.isDate ? "date" : "date-time";
  }
  zone = null;
  _pendingNormalization = false;
  get year() {
    return this._getTimeAttr("year");
  }
  set year(e) {
    this._setTimeAttr("year", e);
  }
  get month() {
    return this._getTimeAttr("month");
  }
  set month(e) {
    this._setTimeAttr("month", e);
  }
  get day() {
    return this._getTimeAttr("day");
  }
  set day(e) {
    this._setTimeAttr("day", e);
  }
  get hour() {
    return this._getTimeAttr("hour");
  }
  set hour(e) {
    this._setTimeAttr("hour", e);
  }
  get minute() {
    return this._getTimeAttr("minute");
  }
  set minute(e) {
    this._setTimeAttr("minute", e);
  }
  get second() {
    return this._getTimeAttr("second");
  }
  set second(e) {
    this._setTimeAttr("second", e);
  }
  get isDate() {
    return this._getTimeAttr("isDate");
  }
  set isDate(e) {
    this._setTimeAttr("isDate", e);
  }
  _getTimeAttr(e) {
    return this._pendingNormalization && (this._normalize(), this._pendingNormalization = false), this._time[e];
  }
  _setTimeAttr(e, n) {
    e === "isDate" && n && !this._time.isDate && this.adjust(0, 0, 0, 0), this._cachedUnixTime = null, this._pendingNormalization = true, this._time[e] = n;
  }
  clone() {
    return new ae(this._time, this.zone);
  }
  reset() {
    this.fromData(ae.epochTime), this.zone = st.utcTimezone;
  }
  resetTo(e, n, r, a, i, s, l) {
    this.fromData({ year: e, month: n, day: r, hour: a, minute: i, second: s, zone: l });
  }
  fromJSDate(e, n) {
    return e ? n ? (this.zone = st.utcTimezone, this.year = e.getUTCFullYear(), this.month = e.getUTCMonth() + 1, this.day = e.getUTCDate(), this.hour = e.getUTCHours(), this.minute = e.getUTCMinutes(), this.second = e.getUTCSeconds()) : (this.zone = st.localTimezone, this.year = e.getFullYear(), this.month = e.getMonth() + 1, this.day = e.getDate(), this.hour = e.getHours(), this.minute = e.getMinutes(), this.second = e.getSeconds()) : this.reset(), this._cachedUnixTime = null, this;
  }
  fromData(e, n) {
    if (e) for (let [r, a] of Object.entries(e)) r !== "icaltype" && (this[r] = a);
    if (n && (this.zone = n), e && !("isDate" in e) ? this.isDate = !("hour" in e) : e && "isDate" in e && (this.isDate = e.isDate), e && "timezone" in e) {
      let r = Bi.get(e.timezone);
      this.zone = r || st.localTimezone;
    }
    return e && "zone" in e && (this.zone = e.zone), this.zone || (this.zone = st.localTimezone), this._cachedUnixTime = null, this;
  }
  dayOfWeek(e) {
    let n = e || ae.SUNDAY, r = (this.year << 12) + (this.month << 8) + (this.day << 3) + n;
    if (r in ae._dowCache) return ae._dowCache[r];
    let a = this.day, i = this.month + (this.month < 3 ? 12 : 0), s = this.year - (this.month < 3 ? 1 : 0), l = a + s + Lt((i + 1) * 26 / 10) + Lt(s / 4);
    return l += Lt(s / 100) * 6 + Lt(s / 400), l = (l + 7 - n) % 7 + 1, ae._dowCache[r] = l, l;
  }
  dayOfYear() {
    let e = ae.isLeapYear(this.year) ? 1 : 0;
    return ae.daysInYearPassedMonth[e][this.month - 1] + this.day;
  }
  startOfWeek(e) {
    let n = e || ae.SUNDAY, r = this.clone();
    return r.day -= (this.dayOfWeek() + 7 - n) % 7, r.isDate = true, r.hour = 0, r.minute = 0, r.second = 0, r;
  }
  endOfWeek(e) {
    let n = e || ae.SUNDAY, r = this.clone();
    return r.day += (7 - this.dayOfWeek() + n - ae.SUNDAY) % 7, r.isDate = true, r.hour = 0, r.minute = 0, r.second = 0, r;
  }
  startOfMonth() {
    let e = this.clone();
    return e.day = 1, e.isDate = true, e.hour = 0, e.minute = 0, e.second = 0, e;
  }
  endOfMonth() {
    let e = this.clone();
    return e.day = ae.daysInMonth(e.month, e.year), e.isDate = true, e.hour = 0, e.minute = 0, e.second = 0, e;
  }
  startOfYear() {
    let e = this.clone();
    return e.day = 1, e.month = 1, e.isDate = true, e.hour = 0, e.minute = 0, e.second = 0, e;
  }
  endOfYear() {
    let e = this.clone();
    return e.day = 31, e.month = 12, e.isDate = true, e.hour = 0, e.minute = 0, e.second = 0, e;
  }
  startDoyWeek(e) {
    let n = e || ae.SUNDAY, r = this.dayOfWeek() - n;
    return r < 0 && (r += 7), this.dayOfYear() - r;
  }
  getDominicalLetter() {
    return ae.getDominicalLetter(this.year);
  }
  nthWeekDay(e, n) {
    let r = ae.daysInMonth(this.month, this.year), a, i = n, s = 0, l = this.clone();
    if (i >= 0) {
      l.day = 1, i != 0 && i--, s = l.day;
      let o = l.dayOfWeek(), c = e - o;
      c < 0 && (c += 7), s += c, s -= e, a = e;
    } else {
      l.day = r;
      let o = l.dayOfWeek();
      i++, a = o - e, a < 0 && (a += 7), a = r - a;
    }
    return a += i * 7, s + a;
  }
  isNthWeekDay(e, n) {
    let r = this.dayOfWeek();
    return n === 0 && r === e || this.nthWeekDay(e, n) === this.day;
  }
  weekNumber(e) {
    let n = (this.year << 12) + (this.month << 8) + (this.day << 3) + e;
    if (n in ae._wnCache) return ae._wnCache[n];
    let r, a = this.clone();
    a.isDate = true;
    let i = this.year;
    a.month == 12 && a.day > 25 ? (r = ae.weekOneStarts(i + 1, e), a.compare(r) < 0 ? r = ae.weekOneStarts(i, e) : i++) : (r = ae.weekOneStarts(i, e), a.compare(r) < 0 && (r = ae.weekOneStarts(--i, e)));
    let s = a.subtractDate(r).toSeconds() / 86400, l = Lt(s / 7) + 1;
    return ae._wnCache[n] = l, l;
  }
  addDuration(e) {
    let n = e.isNegative ? -1 : 1, r = this.second, a = this.minute, i = this.hour, s = this.day;
    r += n * e.seconds, a += n * e.minutes, i += n * e.hours, s += n * e.days, s += n * 7 * e.weeks, this.second = r, this.minute = a, this.hour = i, this.day = s, this._cachedUnixTime = null;
  }
  subtractDate(e) {
    let n = this.toUnixTime() + this.utcOffset(), r = e.toUnixTime() + e.utcOffset();
    return zt.fromSeconds(n - r);
  }
  subtractDateTz(e) {
    let n = this.toUnixTime(), r = e.toUnixTime();
    return zt.fromSeconds(n - r);
  }
  compare(e) {
    if (e instanceof Qn) return -1 * e.compare(this);
    {
      let n = this.toUnixTime(), r = e.toUnixTime();
      return n > r ? 1 : r > n ? -1 : 0;
    }
  }
  compareDateOnlyTz(e, n) {
    let r = this.convertToZone(n), a = e.convertToZone(n), i = 0;
    return (i = ae._cmp_attr(r, a, "year")) != 0 || (i = ae._cmp_attr(r, a, "month")) != 0 || (i = ae._cmp_attr(r, a, "day")) != 0, i;
  }
  convertToZone(e) {
    let n = this.clone(), r = this.zone.tzid == e.tzid;
    return !this.isDate && !r && st.convert_time(n, this.zone, e), n.zone = e, n;
  }
  utcOffset() {
    return this.zone == st.localTimezone || this.zone == st.utcTimezone ? 0 : this.zone.utcOffset(this);
  }
  toICALString() {
    let e = this.toString();
    return e.length > 10 ? Dt.icalendar.value["date-time"].toICAL(e) : Dt.icalendar.value.date.toICAL(e);
  }
  toString() {
    let e = this.year + "-" + en(this.month) + "-" + en(this.day);
    return this.isDate || (e += "T" + en(this.hour) + ":" + en(this.minute) + ":" + en(this.second), this.zone === st.utcTimezone && (e += "Z")), e;
  }
  toJSDate() {
    return this.zone == st.localTimezone ? this.isDate ? new Date(this.year, this.month - 1, this.day) : new Date(this.year, this.month - 1, this.day, this.hour, this.minute, this.second, 0) : new Date(this.toUnixTime() * 1e3);
  }
  _normalize() {
    return this._time.isDate && (this._time.hour = 0, this._time.minute = 0, this._time.second = 0), this.adjust(0, 0, 0, 0), this;
  }
  adjust(e, n, r, a, i) {
    let s, l, o = 0, c = 0, u, T, f, m, v, E = i || this._time;
    if (E.isDate || (u = E.second + a, E.second = u % 60, s = Lt(u / 60), E.second < 0 && (E.second += 60, s--), T = E.minute + r + s, E.minute = T % 60, l = Lt(T / 60), E.minute < 0 && (E.minute += 60, l--), f = E.hour + n + l, E.hour = f % 24, o = Lt(f / 24), E.hour < 0 && (E.hour += 24, o--)), E.month > 12 ? c = Lt((E.month - 1) / 12) : E.month < 1 && (c = Lt(E.month / 12) - 1), E.year += c, E.month -= 12 * c, m = E.day + e + o, m > 0) for (; v = ae.daysInMonth(E.month, E.year), !(m <= v); ) E.month++, E.month > 12 && (E.year++, E.month = 1), m -= v;
    else for (; m <= 0; ) E.month == 1 ? (E.year--, E.month = 12) : E.month--, m += ae.daysInMonth(E.month, E.year);
    return E.day = m, this._cachedUnixTime = null, this;
  }
  fromUnixTime(e) {
    this.zone = st.utcTimezone;
    let n = new Date(e * 1e3);
    this.year = n.getUTCFullYear(), this.month = n.getUTCMonth() + 1, this.day = n.getUTCDate(), this._time.isDate ? (this.hour = 0, this.minute = 0, this.second = 0) : (this.hour = n.getUTCHours(), this.minute = n.getUTCMinutes(), this.second = n.getUTCSeconds()), this._cachedUnixTime = null;
  }
  toUnixTime() {
    if (this._cachedUnixTime !== null) return this._cachedUnixTime;
    let e = this.utcOffset(), n = Date.UTC(this.year, this.month - 1, this.day, this.hour, this.minute, this.second - e);
    return this._cachedUnixTime = n / 1e3, this._cachedUnixTime;
  }
  toJSON() {
    let e = ["year", "month", "day", "hour", "minute", "second", "isDate"], n = /* @__PURE__ */ Object.create(null), r = 0, a = e.length, i;
    for (; r < a; r++) i = e[r], n[i] = this[i];
    return this.zone && (n.timezone = this.zone.tzid), n;
  }
}
const cS = /[^ \t]/, _i = ":", mo = ";", TS = "=", dS = "unknown", hS = "text", fS = { "^'": '"', "^n": `
`, "^^": "^" };
function Je(t) {
  let e = {}, n = e.component = [];
  if (e.stack = [n], Je._eachLine(t, function(r, a) {
    Je._handleContentLine(a, e);
  }), e.stack.length > 1) throw new br("invalid ical body. component began but did not end");
  return e = null, n.length == 1 ? n[0] : n;
}
Je.property = function(t, e) {
  let n = { component: [[], []], designSet: e || Dt.defaultSet };
  return Je._handleContentLine(t, n), n.component[1][0];
}, Je.component = function(t) {
  return Je(t);
};
class br extends Error {
  name = this.constructor.name;
}
Je.ParserError = br, Je._handleContentLine = function(t, e) {
  let n = t.indexOf(_i), r = t.indexOf(mo), a, i, s, l, o = {};
  r !== -1 && n !== -1 && r > n && (r = -1);
  let c;
  if (r !== -1) {
    if (s = t.slice(0, Math.max(0, r)).toLowerCase(), c = Je._parseParameters(t.slice(Math.max(0, r)), 0, e.designSet), c[2] == -1) throw new br("Invalid parameters in '" + t + "'");
    o = c[0];
    let g;
    if (typeof c[1] == "string" ? g = c[1].length : g = c[1].reduce((O, D) => O + D.length, 0), a = g + c[2] + r, (i = t.slice(Math.max(0, a)).indexOf(_i)) !== -1) l = t.slice(Math.max(0, a + i + 1));
    else throw new br("Missing parameter value in '" + t + "'");
  } else if (n !== -1) {
    if (s = t.slice(0, Math.max(0, n)).toLowerCase(), l = t.slice(Math.max(0, n + 1)), s === "begin") {
      let g = [l.toLowerCase(), [], []];
      e.stack.length === 1 ? e.component.push(g) : e.component[2].push(g), e.stack.push(e.component), e.component = g, e.designSet || (e.designSet = Dt.getDesignSet(e.component[0]));
      return;
    } else if (s === "end") {
      e.component = e.stack.pop();
      return;
    }
  } else throw new br('invalid line (no token ";" or ":") "' + t + '"');
  let u, T = false, f = false, m, v, E;
  e.designSet.propertyGroups && s.indexOf(".") !== -1 ? (v = s.split("."), o.group = v[0], E = v[1]) : E = s, E in e.designSet.property && (m = e.designSet.property[E], "multiValue" in m && (T = m.multiValue), "structuredValue" in m && (f = m.structuredValue), l && "detectType" in m && (u = m.detectType(l))), u || ("value" in o ? u = o.value.toLowerCase() : m ? u = m.defaultType : u = dS), delete o.value;
  let A;
  T && f ? (l = Je._parseMultiValue(l, f, u, [], T, e.designSet, f), A = [E, o, u, l]) : T ? (A = [E, o, u], Je._parseMultiValue(l, T, u, A, null, e.designSet, false)) : f ? (l = Je._parseMultiValue(l, f, u, [], null, e.designSet, f), A = [E, o, u, l]) : (l = Je._parseValue(l, u, e.designSet, false), A = [E, o, u, l]), e.component[0] === "vcard" && e.component[1].length === 0 && !(s === "version" && l === "4.0") && (e.designSet = Dt.getDesignSet("vcard3")), e.component[1].push(A);
}, Je._parseValue = function(t, e, n, r) {
  return e in n.value && "fromICAL" in n.value[e] ? n.value[e].fromICAL(t, r) : t;
}, Je._parseParameters = function(t, e, n) {
  let r = e, a = 0, i = TS, s = {}, l, o, c, u = -1, T, f, m;
  for (; a !== false && (a = t.indexOf(i, a + 1)) !== -1; ) {
    if (l = t.slice(r + 1, a), l.length == 0) throw new br("Empty parameter name in '" + t + "'");
    if (o = l.toLowerCase(), m = false, f = false, o in n.param && n.param[o].valueType ? T = n.param[o].valueType : T = hS, o in n.param && (f = n.param[o].multiValue, n.param[o].multiValueSeparateDQuote && (m = Je._rfc6868Escape('"' + f + '"'))), t[a + 1] === '"') {
      if (u = a + 2, a = t.indexOf('"', u), f && a != -1) {
        let g = true;
        for (; g; ) t[a + 1] == f && t[a + 2] == '"' ? a = t.indexOf('"', a + 3) : g = false;
      }
      if (a === -1) throw new br('invalid line (no matching double quote) "' + t + '"');
      c = t.slice(u, a), r = t.indexOf(mo, a);
      let A = t.indexOf(_i, a);
      (r === -1 || A !== -1 && r > A) && (a = false);
    } else {
      u = a + 1;
      let A = t.indexOf(mo, u), g = t.indexOf(_i, u);
      g !== -1 && A > g ? (A = g, a = false) : A === -1 ? (g === -1 ? A = t.length : A = g, a = false) : (r = A, a = A), c = t.slice(u, A);
    }
    const E = c.length;
    if (c = Je._rfc6868Escape(c), u += E - c.length, f) {
      let A = m || f;
      c = Je._parseMultiValue(c, A, T, [], null, n);
    } else c = Je._parseValue(c, T, n);
    f && o in s ? Array.isArray(s[o]) ? s[o].push(c) : s[o] = [s[o], c] : s[o] = c;
  }
  return [s, c, u];
}, Je._rfc6868Escape = function(t) {
  return t.replace(/\^['n^]/g, function(e) {
    return fS[e];
  });
}, Je._parseMultiValue = function(t, e, n, r, a, i, s) {
  let l = 0, o = 0, c;
  if (e.length === 0) return t;
  for (; (l = Jl(t, e, o)) !== -1; ) c = t.slice(o, l), a ? c = Je._parseMultiValue(c, a, n, [], null, i, s) : c = Je._parseValue(c, n, i, s), r.push(c), o = l + e.length;
  return c = t.slice(o), a ? c = Je._parseMultiValue(c, a, n, [], null, i, s) : c = Je._parseValue(c, n, i, s), r.push(c), r.length == 1 ? r[0] : r;
}, Je._eachLine = function(t, e) {
  let n = t.length, r = t.search(cS), a = r, i, s, l;
  do
    a = t.indexOf(`
`, r) + 1, a > 1 && t[a - 2] === "\r" ? l = 2 : l = 1, a === 0 && (a = n, l = 0), s = t[r], s === " " || s === "	" ? i += t.slice(r + 1, a - l) : (i && e(null, i), i = t.slice(r, a - l)), r = a;
  while (a !== n);
  i = i.trim(), i.length && e(null, i);
};
const AS = ["tzid", "location", "tznames", "latitude", "longitude"];
let st = class ot {
  static _compare_change_fn(e, n) {
    return e.year < n.year ? -1 : e.year > n.year ? 1 : e.month < n.month ? -1 : e.month > n.month ? 1 : e.day < n.day ? -1 : e.day > n.day ? 1 : e.hour < n.hour ? -1 : e.hour > n.hour ? 1 : e.minute < n.minute ? -1 : e.minute > n.minute ? 1 : e.second < n.second ? -1 : e.second > n.second ? 1 : 0;
  }
  static convert_time(e, n, r) {
    if (e.isDate || n.tzid == r.tzid || n == ot.localTimezone || r == ot.localTimezone) return e.zone = r, e;
    let a = n.utcOffset(e);
    return e.adjust(0, 0, 0, -a), a = r.utcOffset(e), e.adjust(0, 0, 0, a), null;
  }
  static fromData(e) {
    return new ot().fromData(e);
  }
  static #e = null;
  static get utcTimezone() {
    return this.#e || (this.#e = ot.fromData({ tzid: "UTC" })), this.#e;
  }
  static #a = null;
  static get localTimezone() {
    return this.#a || (this.#a = ot.fromData({ tzid: "floating" })), this.#a;
  }
  static adjust_change(e, n, r, a, i) {
    return ae.prototype.adjust.call(e, n, r, a, i, e);
  }
  static _minimumExpansionYear = -1;
  static EXTRA_COVERAGE = 5;
  constructor(e) {
    this.wrappedJSObject = this, this.fromData(e);
  }
  tzid = "";
  location = "";
  tznames = "";
  latitude = 0;
  longitude = 0;
  component = null;
  expandedUntilYear = 0;
  icalclass = "icaltimezone";
  fromData(e) {
    if (this.expandedUntilYear = 0, this.changes = [], e instanceof ln) this.component = e;
    else {
      if (e && "component" in e) if (typeof e.component == "string") {
        let n = Je(e.component);
        this.component = new ln(n);
      } else e.component instanceof ln ? this.component = e.component : this.component = null;
      for (let n of AS) e && n in e && (this[n] = e[n]);
    }
    return this.component instanceof ln && !this.tzid && (this.tzid = this.component.getFirstPropertyValue("tzid")), this;
  }
  utcOffset(e) {
    if (this == ot.utcTimezone || this == ot.localTimezone || (this._ensureCoverage(e.year), !this.changes.length)) return 0;
    let n = { year: e.year, month: e.month, day: e.day, hour: e.hour, minute: e.minute, second: e.second }, r = this._findNearbyChange(n), a = -1, i = 1;
    for (; ; ) {
      let o = wr(this.changes[r], true);
      if (o.utcOffset < o.prevUtcOffset ? ot.adjust_change(o, 0, 0, 0, o.utcOffset) : ot.adjust_change(o, 0, 0, 0, o.prevUtcOffset), ot._compare_change_fn(n, o) >= 0 ? a = r : i = -1, i == -1 && a != -1) break;
      if (r += i, r < 0) return 0;
      if (r >= this.changes.length) break;
    }
    let s = this.changes[a];
    if (s.utcOffset - s.prevUtcOffset < 0 && a > 0) {
      let o = wr(s, true);
      if (ot.adjust_change(o, 0, 0, 0, o.prevUtcOffset), ot._compare_change_fn(n, o) < 0) {
        let c = this.changes[a - 1], u = false;
        s.is_daylight != u && c.is_daylight == u && (s = c);
      }
    }
    return s.utcOffset;
  }
  _findNearbyChange(e) {
    let n = Yr(this.changes, e, ot._compare_change_fn);
    return n >= this.changes.length ? this.changes.length - 1 : n;
  }
  _ensureCoverage(e) {
    if (ot._minimumExpansionYear == -1) {
      let r = ae.now();
      ot._minimumExpansionYear = r.year;
    }
    let n = e;
    if (n < ot._minimumExpansionYear && (n = ot._minimumExpansionYear), n += ot.EXTRA_COVERAGE, !this.changes.length || this.expandedUntilYear < e) {
      let r = this.component.getAllSubcomponents(), a = r.length, i = 0;
      for (; i < a; i++) this._expandComponent(r[i], n, this.changes);
      this.changes.sort(ot._compare_change_fn), this.expandedUntilYear = n;
    }
  }
  _expandComponent(e, n, r) {
    if (!e.hasProperty("dtstart") || !e.hasProperty("tzoffsetto") || !e.hasProperty("tzoffsetfrom")) return null;
    let a = e.getFirstProperty("dtstart").getFirstValue(), i;
    function s(o) {
      return o.factor * (o.hours * 3600 + o.minutes * 60);
    }
    function l() {
      let o = {};
      return o.is_daylight = e.name == "daylight", o.utcOffset = s(e.getFirstProperty("tzoffsetto").getFirstValue()), o.prevUtcOffset = s(e.getFirstProperty("tzoffsetfrom").getFirstValue()), o;
    }
    if (!e.hasProperty("rrule") && !e.hasProperty("rdate")) i = l(), i.year = a.year, i.month = a.month, i.day = a.day, i.hour = a.hour, i.minute = a.minute, i.second = a.second, ot.adjust_change(i, 0, 0, 0, -i.prevUtcOffset), r.push(i);
    else {
      let o = e.getAllProperties("rdate");
      for (let u of o) {
        let T = u.getFirstValue();
        i = l(), i.year = T.year, i.month = T.month, i.day = T.day, T.isDate ? (i.hour = a.hour, i.minute = a.minute, i.second = a.second, a.zone != ot.utcTimezone && ot.adjust_change(i, 0, 0, 0, -i.prevUtcOffset)) : (i.hour = T.hour, i.minute = T.minute, i.second = T.second, T.zone != ot.utcTimezone && ot.adjust_change(i, 0, 0, 0, -i.prevUtcOffset)), r.push(i);
      }
      let c = e.getFirstProperty("rrule");
      if (c) {
        c = c.getFirstValue(), i = l(), c.until && c.until.zone == ot.utcTimezone && (c.until.adjust(0, 0, 0, i.prevUtcOffset), c.until.zone = ot.localTimezone);
        let u = c.iterator(a), T;
        for (; (T = u.next()) && (i = l(), !(T.year > n || !T)); ) i.year = T.year, i.month = T.month, i.day = T.day, i.hour = T.hour, i.minute = T.minute, i.second = T.second, i.isDate = T.isDate, ot.adjust_change(i, 0, 0, 0, -i.prevUtcOffset), r.push(i);
      }
    }
    return r;
  }
  toString() {
    return this.tznames ? this.tznames : this.tzid;
  }
}, Wt = null;
const Bi = { get count() {
  return Wt === null ? 0 : Object.keys(Wt).length;
}, reset: function() {
  Wt = /* @__PURE__ */ Object.create(null);
  let t = st.utcTimezone;
  Wt.Z = t, Wt.UTC = t, Wt.GMT = t;
}, _hard_reset: function() {
  Wt = null;
}, has: function(t) {
  return Wt === null ? false : !!Wt[t];
}, get: function(t) {
  return Wt === null && this.reset(), Wt[t];
}, register: function(t, e) {
  if (Wt === null && this.reset(), typeof t == "string" && e instanceof st && ([t, e] = [e, t]), e || (t instanceof st ? e = t.tzid : t.name === "vtimezone" && (t = new st(t), e = t.tzid)), !e) throw new TypeError("Neither a timezone nor a name was passed");
  if (t instanceof st) Wt[e] = t;
  else throw new TypeError("timezone must be ICAL.Timezone or ICAL.Component");
}, remove: function(t) {
  return Wt === null ? null : delete Wt[t];
} };
function mS(t) {
  let e, n, r, a, i;
  if (!t || t.name !== "vcalendar") return t;
  for (e = t.getAllSubcomponents(), n = [], r = {}, i = 0; i < e.length; i++) if (e[i].name === "vtimezone") {
    let s = e[i].getFirstProperty("tzid").getFirstValue();
    r[s] = e[i];
  } else n = n.concat(e[i].getAllProperties());
  for (a = {}, i = 0; i < n.length; i++) {
    let s = n[i].getParameter("tzid");
    s && (a[s] = true);
  }
  for (let [s, l] of Object.entries(r)) a[s] || t.removeSubcomponent(l);
  for (let s of Object.keys(a)) !r[s] && Bi.has(s) && t.addSubcomponent(Bi.get(s).component);
  return t;
}
function Ma(t) {
  return typeof t == "number" && isNaN(t);
}
function Gt(t) {
  let e = parseInt(t, 10);
  if (Ma(e)) throw new Error('Could not extract integer from "' + t + '"');
  return e;
}
function $n(t, e) {
  if (!(typeof t > "u")) return t instanceof e ? t : new e(t);
}
function Jl(t, e, n) {
  for (; (n = t.indexOf(e, n)) !== -1; ) if (n > 0 && t[n - 1] === "\\") n += 1;
  else return n;
  return -1;
}
function Yr(t, e, n) {
  if (!t.length) return 0;
  let r = 0, a = t.length - 1, i, s;
  for (; r <= a; ) if (i = r + Math.floor((a - r) / 2), s = n(e, t[i]), s < 0) a = i - 1;
  else if (s > 0) r = i + 1;
  else break;
  return s < 0 ? i : s > 0 ? i + 1 : i;
}
function wr(t, e) {
  if (!t || typeof t != "object") return t;
  if (t instanceof Date) return new Date(t.getTime());
  if ("clone" in t) return t.clone();
  if (Array.isArray(t)) {
    let n = [];
    for (let r = 0; r < t.length; r++) n.push(e ? wr(t[r], true) : t[r]);
    return n;
  } else {
    let n = {};
    for (let [r, a] of Object.entries(t)) e ? n[r] = wr(a, true) : n[r] = a;
    return n;
  }
}
function Xl(t) {
  let e = "", n = t || "", r = 0, a = 0;
  for (; n.length; ) {
    let i = n.codePointAt(r);
    i < 128 ? ++a : i < 2048 ? a += 2 : i < 65536 ? a += 3 : a += 4, a < _t.foldLength + 1 ? r += i > 65535 ? 2 : 1 : (e += _t.newLineChar + " " + n.slice(0, Math.max(0, r)), n = n.slice(Math.max(0, r)), r = a = 0);
  }
  return e.slice(_t.newLineChar.length + 1);
}
function en(t) {
  switch (typeof t != "string" && (typeof t == "number" && (t = parseInt(t)), t = String(t)), t.length) {
    case 0:
      return "00";
    case 1:
      return "0" + t;
    default:
      return t;
  }
}
function Lt(t) {
  return t < 0 ? Math.ceil(t) : Math.floor(t);
}
function _r(t, e) {
  for (let n in t) {
    let r = Object.getOwnPropertyDescriptor(t, n);
    r && !Object.getOwnPropertyDescriptor(e, n) && Object.defineProperty(e, n, r);
  }
  return e;
}
var ES = Object.freeze({ __proto__: null, binsearchInsert: Yr, clone: wr, extend: _r, foldline: Xl, formatClassType: $n, isStrictlyNaN: Ma, pad2: en, strictParseInt: Gt, trunc: Lt, unescapedIndexOf: Jl, updateTimezones: mS });
class Fn {
  static fromString(e) {
    let n = {};
    return n.factor = e[0] === "+" ? 1 : -1, n.hours = Gt(e.slice(1, 3)), n.minutes = Gt(e.slice(4, 6)), new Fn(n);
  }
  static fromSeconds(e) {
    let n = new Fn();
    return n.fromSeconds(e), n;
  }
  constructor(e) {
    this.fromData(e);
  }
  hours = 0;
  minutes = 0;
  factor = 1;
  icaltype = "utc-offset";
  clone() {
    return Fn.fromSeconds(this.toSeconds());
  }
  fromData(e) {
    if (e) for (let [n, r] of Object.entries(e)) this[n] = r;
    this._normalize();
  }
  fromSeconds(e) {
    let n = Math.abs(e);
    return this.factor = e < 0 ? -1 : 1, this.hours = Lt(n / 3600), n -= this.hours * 3600, this.minutes = Lt(n / 60), this;
  }
  toSeconds() {
    return this.factor * (60 * this.minutes + 3600 * this.hours);
  }
  compare(e) {
    let n = this.toSeconds(), r = e.toSeconds();
    return (n > r) - (r > n);
  }
  _normalize() {
    let e = this.toSeconds(), n = this.factor;
    for (; e < -43200; ) e += 97200;
    for (; e > 50400; ) e -= 97200;
    this.fromSeconds(e), e == 0 && (this.factor = n);
  }
  toICALString() {
    return Dt.icalendar.value["utc-offset"].toICAL(this.toString());
  }
  toString() {
    return (this.factor == 1 ? "+" : "-") + en(this.hours) + ":" + en(this.minutes);
  }
}
class Ar extends ae {
  static fromDateAndOrTimeString(e, n) {
    function r(E, A, g) {
      return E ? Gt(E.slice(A, A + g)) : null;
    }
    let a = e.split("T"), i = a[0], s = a[1], l = s ? Dt.vcard.value.time._splitZone(s) : [], o = l[0], c = l[1], u = i ? i.length : 0, T = c ? c.length : 0, f = i && i[0] == "-" && i[1] == "-", m = c && c[0] == "-", v = { year: f ? null : r(i, 0, 4), month: f && (u == 4 || u == 7) ? r(i, 2, 2) : u == 7 || u == 10 ? r(i, 5, 2) : null, day: u == 5 ? r(i, 3, 2) : u == 7 && f ? r(i, 5, 2) : u == 10 ? r(i, 8, 2) : null, hour: m ? null : r(c, 0, 2), minute: m && T == 3 ? r(c, 1, 2) : T > 4 ? m ? r(c, 1, 2) : r(c, 3, 2) : null, second: T == 4 ? r(c, 2, 2) : T == 6 ? r(c, 4, 2) : T == 8 ? r(c, 6, 2) : null };
    return o == "Z" ? o = st.utcTimezone : o && o[3] == ":" ? o = Fn.fromString(o) : o = null, new Ar(v, o, n);
  }
  constructor(e, n, r) {
    super(e, n), this.icaltype = r || "date-and-or-time";
  }
  icalclass = "vcardtime";
  icaltype = "date-and-or-time";
  clone() {
    return new Ar(this._time, this.zone, this.icaltype);
  }
  _normalize() {
    return this;
  }
  utcOffset() {
    return this.zone instanceof Fn ? this.zone.toSeconds() : ae.prototype.utcOffset.apply(this, arguments);
  }
  toICALString() {
    return Dt.vcard.value[this.icaltype].toICAL(this.toString());
  }
  toString() {
    let e = this.year, n = this.month, r = this.day, a = this.hour, i = this.minute, s = this.second, l = e !== null, o = n !== null, c = r !== null, u = a !== null, T = i !== null, f = s !== null, m = (l ? en(e) + (o || c ? "-" : "") : o || c ? "--" : "") + (o ? en(n) : "") + (c ? "-" + en(r) : ""), v = (u ? en(a) : "-") + (u && T ? ":" : "") + (T ? en(i) : "") + (!u && !T ? "-" : "") + (T && f ? ":" : "") + (f ? en(s) : ""), E;
    switch (this.zone === st.utcTimezone ? E = "Z" : this.zone instanceof Fn ? E = this.zone.toString() : this.zone === st.localTimezone ? E = "" : this.zone instanceof st ? E = Fn.fromSeconds(this.zone.utcOffset(this)).toString() : E = "", this.icaltype) {
      case "time":
        return v + E;
      case "date-and-or-time":
      case "date-time":
        return m + (v == "--" ? "" : "T" + v + E);
      case "date":
        return m;
    }
    return null;
  }
}
class In {
  static _indexMap = { BYSECOND: 0, BYMINUTE: 1, BYHOUR: 2, BYDAY: 3, BYMONTHDAY: 4, BYYEARDAY: 5, BYWEEKNO: 6, BYMONTH: 7, BYSETPOS: 8 };
  static _expandMap = { SECONDLY: [1, 1, 1, 1, 1, 1, 1, 1], MINUTELY: [2, 1, 1, 1, 1, 1, 1, 1], HOURLY: [2, 2, 1, 1, 1, 1, 1, 1], DAILY: [2, 2, 2, 1, 1, 1, 1, 1], WEEKLY: [2, 2, 2, 2, 3, 3, 1, 1], MONTHLY: [2, 2, 2, 2, 2, 3, 3, 1], YEARLY: [2, 2, 2, 2, 2, 2, 2, 2] };
  static UNKNOWN = 0;
  static CONTRACT = 1;
  static EXPAND = 2;
  static ILLEGAL = 3;
  constructor(e) {
    this.fromData(e);
  }
  completed = false;
  rule = null;
  dtstart = null;
  last = null;
  occurrence_number = 0;
  by_indices = null;
  initialized = false;
  by_data = null;
  days = null;
  days_index = 0;
  fromData(e) {
    if (this.rule = $n(e.rule, jt), !this.rule) throw new Error("iterator requires a (ICAL.Recur) rule");
    if (this.dtstart = $n(e.dtstart, ae), !this.dtstart) throw new Error("iterator requires a (ICAL.Time) dtstart");
    if (e.by_data ? this.by_data = e.by_data : this.by_data = wr(this.rule.parts, true), e.occurrence_number && (this.occurrence_number = e.occurrence_number), this.days = e.days || [], e.last && (this.last = $n(e.last, ae)), this.by_indices = e.by_indices, this.by_indices || (this.by_indices = { BYSECOND: 0, BYMINUTE: 0, BYHOUR: 0, BYDAY: 0, BYMONTH: 0, BYWEEKNO: 0, BYMONTHDAY: 0 }), this.initialized = e.initialized || false, !this.initialized) try {
      this.init();
    } catch (n) {
      if (n instanceof Zi) this.completed = true;
      else throw n;
    }
  }
  init() {
    this.initialized = true, this.last = this.dtstart.clone();
    let e = this.by_data;
    if ("BYDAY" in e && this.sort_byday_rules(e.BYDAY), "BYYEARDAY" in e && ("BYMONTH" in e || "BYWEEKNO" in e || "BYMONTHDAY" in e)) throw new Error("Invalid BYYEARDAY rule");
    if ("BYWEEKNO" in e && "BYMONTHDAY" in e) throw new Error("BYWEEKNO does not fit to BYMONTHDAY");
    if (this.rule.freq == "MONTHLY" && ("BYYEARDAY" in e || "BYWEEKNO" in e)) throw new Error("For MONTHLY recurrences neither BYYEARDAY nor BYWEEKNO may appear");
    if (this.rule.freq == "WEEKLY" && ("BYYEARDAY" in e || "BYMONTHDAY" in e)) throw new Error("For WEEKLY recurrences neither BYMONTHDAY nor BYYEARDAY may appear");
    if (this.rule.freq != "YEARLY" && "BYYEARDAY" in e) throw new Error("BYYEARDAY may only appear in YEARLY rules");
    if (this.last.second = this.setup_defaults("BYSECOND", "SECONDLY", this.dtstart.second), this.last.minute = this.setup_defaults("BYMINUTE", "MINUTELY", this.dtstart.minute), this.last.hour = this.setup_defaults("BYHOUR", "HOURLY", this.dtstart.hour), this.last.day = this.setup_defaults("BYMONTHDAY", "DAILY", this.dtstart.day), this.last.month = this.setup_defaults("BYMONTH", "MONTHLY", this.dtstart.month), this.rule.freq == "WEEKLY") if ("BYDAY" in e) {
      let [, n] = this.ruleDayOfWeek(e.BYDAY[0], this.rule.wkst), r = n - this.last.dayOfWeek(this.rule.wkst);
      (this.last.dayOfWeek(this.rule.wkst) < n && r >= 0 || r < 0) && (this.last.day += r);
    } else {
      let n = jt.numericDayToIcalDay(this.dtstart.dayOfWeek());
      e.BYDAY = [n];
    }
    if (this.rule.freq == "YEARLY") {
      const n = this.rule.until ? this.rule.until.year : 2e4;
      for (; this.last.year <= n && (this.expand_year_days(this.last.year), !(this.days.length > 0)); ) this.increment_year(this.rule.interval);
      if (this.days.length == 0) throw new Zi();
      if (!this._nextByYearDay() && !this.next_year() && !this.next_year() && !this.next_year()) throw new Zi();
    }
    if (this.rule.freq == "MONTHLY") {
      if (this.has_by_data("BYDAY")) {
        let n = null, r = this.last.clone(), a = ae.daysInMonth(this.last.month, this.last.year);
        for (let i of this.by_data.BYDAY) {
          this.last = r.clone();
          let [s, l] = this.ruleDayOfWeek(i), o = this.last.nthWeekDay(l, s);
          if (s >= 6 || s <= -6) throw new Error("Malformed values in BYDAY part");
          if (o > a || o <= 0) {
            if (n && n.month == r.month) continue;
            for (; o > a || o <= 0; ) this.increment_month(), a = ae.daysInMonth(this.last.month, this.last.year), o = this.last.nthWeekDay(l, s);
          }
          this.last.day = o, (!n || this.last.compare(n) < 0) && (n = this.last.clone());
        }
        if (this.last = n.clone(), this.has_by_data("BYMONTHDAY") && this._byDayAndMonthDay(true), this.last.day > a || this.last.day == 0) throw new Error("Malformed values in BYDAY part");
      } else if (this.has_by_data("BYMONTHDAY")) {
        this.last.day = 1;
        let n = this.normalizeByMonthDayRules(this.last.year, this.last.month, this.rule.parts.BYMONTHDAY).filter((r) => r >= this.last.day);
        if (n.length) this.last.day = n[0], this.by_data.BYMONTHDAY = n;
        else if (!this.next_month() && !this.next_month() && !this.next_month()) throw new Zi();
      }
    }
  }
  next(e = false) {
    let n = this.last ? this.last.clone() : null;
    if ((this.rule.count && this.occurrence_number >= this.rule.count || this.rule.until && this.last.compare(this.rule.until) > 0) && (this.completed = true), this.completed) return null;
    if (this.occurrence_number == 0 && this.last.compare(this.dtstart) >= 0) return this.occurrence_number++, this.last;
    let r, a = 0;
    do
      switch (r = 1, this.rule.freq) {
        case "SECONDLY":
          this.next_second();
          break;
        case "MINUTELY":
          this.next_minute();
          break;
        case "HOURLY":
          this.next_hour();
          break;
        case "DAILY":
          this.next_day();
          break;
        case "WEEKLY":
          this.next_week();
          break;
        case "MONTHLY":
          if (r = this.next_month(), r) a = 0;
          else if (++a == 336) return this.completed = true, null;
          break;
        case "YEARLY":
          if (r = this.next_year(), r) a = 0;
          else if (++a == 28) return this.completed = true, null;
          break;
        default:
          return null;
      }
    while (!this.check_contracting_rules() || this.last.compare(this.dtstart) < 0 || !r);
    if (this.last.compare(n) == 0) {
      if (e) throw new Error("Same occurrence found twice, protecting you from death by recursion");
      this.next(true);
    }
    return this.rule.until && this.last.compare(this.rule.until) > 0 ? (this.completed = true, null) : (this.occurrence_number++, this.last);
  }
  next_second() {
    return this.next_generic("BYSECOND", "SECONDLY", "second", "minute");
  }
  increment_second(e) {
    return this.increment_generic(e, "second", 60, "minute");
  }
  next_minute() {
    return this.next_generic("BYMINUTE", "MINUTELY", "minute", "hour", "next_second");
  }
  increment_minute(e) {
    return this.increment_generic(e, "minute", 60, "hour");
  }
  next_hour() {
    return this.next_generic("BYHOUR", "HOURLY", "hour", "monthday", "next_minute");
  }
  increment_hour(e) {
    this.increment_generic(e, "hour", 24, "monthday");
  }
  next_day() {
    let e = this.rule.freq == "DAILY";
    return this.next_hour() == 0 || (e ? this.increment_monthday(this.rule.interval) : this.increment_monthday(1)), 0;
  }
  next_week() {
    let e = 0;
    if (this.next_weekday_by_week() == 0) return e;
    if (this.has_by_data("BYWEEKNO")) {
      this.by_indices.BYWEEKNO++, this.by_indices.BYWEEKNO == this.by_data.BYWEEKNO.length && (this.by_indices.BYWEEKNO = 0, e = 1), this.last.month = 1, this.last.day = 1;
      let n = this.by_data.BYWEEKNO[this.by_indices.BYWEEKNO];
      this.last.day += 7 * n, e && this.increment_year(1);
    } else this.increment_monthday(7 * this.rule.interval);
    return e;
  }
  normalizeByMonthDayRules(e, n, r) {
    let a = ae.daysInMonth(n, e), i = [], s = 0, l = r.length, o;
    for (; s < l; s++) {
      if (o = parseInt(r[s], 10), isNaN(o)) throw new Error("Invalid BYMONTHDAY value");
      if (!(Math.abs(o) > a)) {
        if (o < 0) o = a + (o + 1);
        else if (o === 0) continue;
        i.indexOf(o) === -1 && i.push(o);
      }
    }
    return i.sort(function(c, u) {
      return c - u;
    });
  }
  _byDayAndMonthDay(e) {
    let n, r = this.by_data.BYDAY, a, i = 0, s, l = r.length, o = 0, c, u = this, T = this.last.day;
    function f() {
      for (c = ae.daysInMonth(u.last.month, u.last.year), n = u.normalizeByMonthDayRules(u.last.year, u.last.month, u.by_data.BYMONTHDAY), s = n.length; n[i] <= T && !(e && n[i] == T) && i < s - 1; ) i++;
    }
    function m() {
      T = 0, u.increment_month(), i = 0, f();
    }
    f(), e && (T -= 1);
    let v = 48;
    for (; !o && v; ) {
      if (v--, a = T + 1, a > c) {
        m();
        continue;
      }
      let E = n[i++];
      if (E >= a) T = E;
      else {
        m();
        continue;
      }
      for (let A = 0; A < l; A++) {
        let g = this.ruleDayOfWeek(r[A]), O = g[0], D = g[1];
        if (this.last.day = T, this.last.isNthWeekDay(D, O)) {
          o = 1;
          break;
        }
      }
      if (!o && i === s) {
        m();
        continue;
      }
    }
    if (v <= 0) throw new Error("Malformed values in BYDAY combined with BYMONTHDAY parts");
    return o;
  }
  next_month() {
    let e = 1;
    if (this.next_hour() == 0) return e;
    if (this.has_by_data("BYDAY") && this.has_by_data("BYMONTHDAY")) e = this._byDayAndMonthDay();
    else if (this.has_by_data("BYDAY")) {
      let n = ae.daysInMonth(this.last.month, this.last.year), r = 0, a = 0;
      if (this.has_by_data("BYSETPOS")) {
        let s = this.last.day;
        for (let l = 1; l <= n; l++) this.last.day = l, this.is_day_in_byday(this.last) && (a++, l <= s && r++);
        this.last.day = s;
      }
      e = 0;
      let i;
      for (i = this.last.day + 1; i <= n; i++) if (this.last.day = i, this.is_day_in_byday(this.last) && (!this.has_by_data("BYSETPOS") || this.check_set_position(++r) || this.check_set_position(r - a - 1))) {
        e = 1;
        break;
      }
      i > n && (this.last.day = 1, this.increment_month(), this.is_day_in_byday(this.last) ? (!this.has_by_data("BYSETPOS") || this.check_set_position(1)) && (e = 1) : e = 0);
    } else if (this.has_by_data("BYMONTHDAY")) {
      if (this.by_indices.BYMONTHDAY++, this.by_indices.BYMONTHDAY >= this.by_data.BYMONTHDAY.length && (this.by_indices.BYMONTHDAY = 0, this.increment_month(), this.by_indices.BYMONTHDAY >= this.by_data.BYMONTHDAY.length)) return 0;
      let n = ae.daysInMonth(this.last.month, this.last.year), r = this.by_data.BYMONTHDAY[this.by_indices.BYMONTHDAY];
      r < 0 && (r = n + r + 1), r > n ? (this.last.day = 1, e = this.is_day_in_byday(this.last)) : this.last.day = r;
    } else {
      this.increment_month();
      let n = ae.daysInMonth(this.last.month, this.last.year);
      this.by_data.BYMONTHDAY[0] > n ? e = 0 : this.last.day = this.by_data.BYMONTHDAY[0];
    }
    return e;
  }
  next_weekday_by_week() {
    let e = 0;
    if (this.next_hour() == 0) return e;
    if (!this.has_by_data("BYDAY")) return 1;
    for (; ; ) {
      let n = new ae();
      this.by_indices.BYDAY++, this.by_indices.BYDAY == Object.keys(this.by_data.BYDAY).length && (this.by_indices.BYDAY = 0, e = 1);
      let r = this.by_data.BYDAY[this.by_indices.BYDAY], i = this.ruleDayOfWeek(r)[1];
      i -= this.rule.wkst, i < 0 && (i += 7), n.year = this.last.year, n.month = this.last.month, n.day = this.last.day;
      let s = n.startDoyWeek(this.rule.wkst);
      if (i + s < 1 && !e) continue;
      let l = ae.fromDayOfYear(s + i, this.last.year);
      return this.last.year = l.year, this.last.month = l.month, this.last.day = l.day, e;
    }
  }
  next_year() {
    return this.next_hour() == 0 || (this.days.length == 0 || ++this.days_index == this.days.length) && (this.days_index = 0, this.increment_year(this.rule.interval), this.has_by_data("BYMONTHDAY") && (this.by_data.BYMONTHDAY = this.normalizeByMonthDayRules(this.last.year, this.last.month, this.rule.parts.BYMONTHDAY)), this.expand_year_days(this.last.year), this.days.length == 0) ? 0 : this._nextByYearDay();
  }
  _nextByYearDay() {
    let e = this.days[this.days_index], n = this.last.year;
    if (Math.abs(e) == 366 && !ae.isLeapYear(this.last.year)) return 0;
    e < 1 && (e += 1, n += 1);
    let r = ae.fromDayOfYear(e, n);
    return this.last.day = r.day, this.last.month = r.month, 1;
  }
  ruleDayOfWeek(e, n) {
    let r = e.match(/([+-]?[0-9])?(MO|TU|WE|TH|FR|SA|SU)/);
    if (r) {
      let a = parseInt(r[1] || 0, 10);
      return e = jt.icalDayToNumericDay(r[2], n), [a, e];
    } else return [0, 0];
  }
  next_generic(e, n, r, a, i) {
    let s = e in this.by_data, l = this.rule.freq == n, o = 0;
    if (i && this[i]() == 0) return o;
    if (s) {
      this.by_indices[e]++;
      let c = this.by_data[e];
      this.by_indices[e] == c.length && (this.by_indices[e] = 0, o = 1), this.last[r] = c[this.by_indices[e]];
    } else l && this["increment_" + r](this.rule.interval);
    return s && o && l && this["increment_" + a](1), o;
  }
  increment_monthday(e) {
    for (let n = 0; n < e; n++) {
      let r = ae.daysInMonth(this.last.month, this.last.year);
      this.last.day++, this.last.day > r && (this.last.day -= r, this.increment_month());
    }
  }
  increment_month() {
    if (this.last.day = 1, this.has_by_data("BYMONTH")) this.by_indices.BYMONTH++, this.by_indices.BYMONTH == this.by_data.BYMONTH.length && (this.by_indices.BYMONTH = 0, this.increment_year(1)), this.last.month = this.by_data.BYMONTH[this.by_indices.BYMONTH];
    else {
      this.rule.freq == "MONTHLY" ? this.last.month += this.rule.interval : this.last.month++, this.last.month--;
      let e = Lt(this.last.month / 12);
      this.last.month %= 12, this.last.month++, e != 0 && this.increment_year(e);
    }
    this.has_by_data("BYMONTHDAY") && (this.by_data.BYMONTHDAY = this.normalizeByMonthDayRules(this.last.year, this.last.month, this.rule.parts.BYMONTHDAY));
  }
  increment_year(e) {
    this.last.day = 1, this.last.year += e;
  }
  increment_generic(e, n, r, a) {
    this.last[n] += e;
    let i = Lt(this.last[n] / r);
    this.last[n] %= r, i != 0 && this["increment_" + a](i);
  }
  has_by_data(e) {
    return e in this.rule.parts;
  }
  expand_year_days(e) {
    let n = new ae();
    this.days = [];
    let r = {}, a = ["BYDAY", "BYWEEKNO", "BYMONTHDAY", "BYMONTH", "BYYEARDAY"];
    for (let l of a) l in this.rule.parts && (r[l] = this.rule.parts[l]);
    if ("BYMONTH" in r && "BYWEEKNO" in r) {
      let l = 1, o = {};
      n.year = e, n.isDate = true;
      for (let c = 0; c < this.by_data.BYMONTH.length; c++) {
        let u = this.by_data.BYMONTH[c];
        n.month = u, n.day = 1;
        let T = n.weekNumber(this.rule.wkst);
        n.day = ae.daysInMonth(u, e);
        let f = n.weekNumber(this.rule.wkst);
        for (c = T; c < f; c++) o[c] = 1;
      }
      for (let c = 0; c < this.by_data.BYWEEKNO.length && l; c++) this.by_data.BYWEEKNO[c] < 52 ? l &= o[c] : l = 0;
      l ? delete r.BYMONTH : delete r.BYWEEKNO;
    }
    let i = Object.keys(r).length;
    if (i == 0) {
      let l = this.dtstart.clone();
      l.year = this.last.year, this.days.push(l.dayOfYear());
    } else if (i == 1 && "BYMONTH" in r) for (let l of this.by_data.BYMONTH) {
      let o = this.dtstart.clone();
      o.year = e, o.month = l, o.isDate = true, this.days.push(o.dayOfYear());
    }
    else if (i == 1 && "BYMONTHDAY" in r) for (let l of this.by_data.BYMONTHDAY) {
      let o = this.dtstart.clone();
      if (l < 0) {
        let c = ae.daysInMonth(o.month, e);
        l = l + c + 1;
      }
      o.day = l, o.year = e, o.isDate = true, this.days.push(o.dayOfYear());
    }
    else if (i == 2 && "BYMONTHDAY" in r && "BYMONTH" in r) for (let l of this.by_data.BYMONTH) {
      let o = ae.daysInMonth(l, e);
      for (let c of this.by_data.BYMONTHDAY) c < 0 && (c = c + o + 1), n.day = c, n.month = l, n.year = e, n.isDate = true, this.days.push(n.dayOfYear());
    }
    else if (!(i == 1 && "BYWEEKNO" in r)) {
      if (!(i == 2 && "BYWEEKNO" in r && "BYMONTHDAY" in r)) {
        if (i == 1 && "BYDAY" in r) this.days = this.days.concat(this.expand_by_day(e));
        else if (i == 2 && "BYDAY" in r && "BYMONTH" in r) {
          for (let l of this.by_data.BYMONTH) {
            let o = ae.daysInMonth(l, e);
            n.year = e, n.month = l, n.day = 1, n.isDate = true;
            let c = n.dayOfWeek(), u = n.dayOfYear() - 1;
            n.day = o;
            let T = n.dayOfWeek();
            if (this.has_by_data("BYSETPOS")) {
              let f = [];
              for (let m = 1; m <= o; m++) n.day = m, this.is_day_in_byday(n) && f.push(m);
              for (let m = 0; m < f.length; m++) (this.check_set_position(m + 1) || this.check_set_position(m - f.length)) && this.days.push(u + f[m]);
            } else for (let f of this.by_data.BYDAY) {
              let m = this.ruleDayOfWeek(f), v = m[0], E = m[1], A, g = (E + 7 - c) % 7 + 1, O = o - (T + 7 - E) % 7;
              if (v == 0) for (let D = g; D <= o; D += 7) this.days.push(u + D);
              else v > 0 ? (A = g + (v - 1) * 7, A <= o && this.days.push(u + A)) : (A = O + (v + 1) * 7, A > 0 && this.days.push(u + A));
            }
          }
          this.days.sort(function(l, o) {
            return l - o;
          });
        } else if (i == 2 && "BYDAY" in r && "BYMONTHDAY" in r) {
          let l = this.expand_by_day(e);
          for (let o of l) {
            let c = ae.fromDayOfYear(o, e);
            this.by_data.BYMONTHDAY.indexOf(c.day) >= 0 && this.days.push(o);
          }
        } else if (i == 3 && "BYDAY" in r && "BYMONTHDAY" in r && "BYMONTH" in r) {
          let l = this.expand_by_day(e);
          for (let o of l) {
            let c = ae.fromDayOfYear(o, e);
            this.by_data.BYMONTH.indexOf(c.month) >= 0 && this.by_data.BYMONTHDAY.indexOf(c.day) >= 0 && this.days.push(o);
          }
        } else if (i == 2 && "BYDAY" in r && "BYWEEKNO" in r) {
          let l = this.expand_by_day(e);
          for (let o of l) {
            let u = ae.fromDayOfYear(o, e).weekNumber(this.rule.wkst);
            this.by_data.BYWEEKNO.indexOf(u) && this.days.push(o);
          }
        } else if (!(i == 3 && "BYDAY" in r && "BYWEEKNO" in r && "BYMONTHDAY" in r)) if (i == 1 && "BYYEARDAY" in r) this.days = this.days.concat(this.by_data.BYYEARDAY);
        else if (i == 2 && "BYYEARDAY" in r && "BYDAY" in r) {
          let l = ae.isLeapYear(e) ? 366 : 365, o = new Set(this.expand_by_day(e));
          for (let c of this.by_data.BYYEARDAY) c < 0 && (c += l + 1), o.has(c) && this.days.push(c);
        } else this.days = [];
      }
    }
    let s = ae.isLeapYear(e) ? 366 : 365;
    return this.days.sort((l, o) => (l < 0 && (l += s + 1), o < 0 && (o += s + 1), l - o)), 0;
  }
  expand_by_day(e) {
    let n = [], r = this.last.clone();
    r.year = e, r.month = 1, r.day = 1, r.isDate = true;
    let a = r.dayOfWeek();
    r.month = 12, r.day = 31, r.isDate = true;
    let i = r.dayOfWeek(), s = r.dayOfYear();
    for (let l of this.by_data.BYDAY) {
      let o = this.ruleDayOfWeek(l), c = o[0], u = o[1];
      if (c == 0) {
        let T = (u + 7 - a) % 7 + 1;
        for (let f = T; f <= s; f += 7) n.push(f);
      } else if (c > 0) {
        let T;
        u >= a ? T = u - a + 1 : T = u - a + 8, n.push(T + (c - 1) * 7);
      } else {
        let T;
        c = -c, u <= i ? T = s - i + u : T = s - i + u - 7, n.push(T - (c - 1) * 7);
      }
    }
    return n;
  }
  is_day_in_byday(e) {
    if (this.by_data.BYDAY) for (let n of this.by_data.BYDAY) {
      let r = this.ruleDayOfWeek(n), a = r[0], i = r[1], s = e.dayOfWeek();
      if (a == 0 && i == s || e.nthWeekDay(i, a) == e.day) return 1;
    }
    return 0;
  }
  check_set_position(e) {
    return this.has_by_data("BYSETPOS") ? this.by_data.BYSETPOS.indexOf(e) !== -1 : false;
  }
  sort_byday_rules(e) {
    for (let n = 0; n < e.length; n++) for (let r = 0; r < n; r++) {
      let a = this.ruleDayOfWeek(e[r], this.rule.wkst)[1], i = this.ruleDayOfWeek(e[n], this.rule.wkst)[1];
      if (a > i) {
        let s = e[n];
        e[n] = e[r], e[r] = s;
      }
    }
  }
  check_contract_restriction(e, n) {
    let r = In._indexMap[e], a = In._expandMap[this.rule.freq][r], i = false;
    if (e in this.by_data && a == In.CONTRACT) {
      let s = this.by_data[e];
      for (let l of s) if (l == n) {
        i = true;
        break;
      }
    } else i = true;
    return i;
  }
  check_contracting_rules() {
    let e = this.last.dayOfWeek(), n = this.last.weekNumber(this.rule.wkst), r = this.last.dayOfYear();
    return this.check_contract_restriction("BYSECOND", this.last.second) && this.check_contract_restriction("BYMINUTE", this.last.minute) && this.check_contract_restriction("BYHOUR", this.last.hour) && this.check_contract_restriction("BYDAY", jt.numericDayToIcalDay(e)) && this.check_contract_restriction("BYWEEKNO", n) && this.check_contract_restriction("BYMONTHDAY", this.last.day) && this.check_contract_restriction("BYMONTH", this.last.month) && this.check_contract_restriction("BYYEARDAY", r);
  }
  setup_defaults(e, n, r) {
    let a = In._indexMap[e];
    return In._expandMap[this.rule.freq][a] != In.CONTRACT && (e in this.by_data || (this.by_data[e] = [r]), this.rule.freq != n) ? this.by_data[e][0] : r;
  }
  toJSON() {
    let e = /* @__PURE__ */ Object.create(null);
    return e.initialized = this.initialized, e.rule = this.rule.toJSON(), e.dtstart = this.dtstart.toJSON(), e.by_data = this.by_data, e.days = this.days, e.last = this.last.toJSON(), e.by_indices = this.by_indices, e.occurrence_number = this.occurrence_number, e;
  }
}
class Zi extends Error {
  constructor() {
    super("Recurrence rule has no valid occurrences");
  }
}
const pS = /^(SU|MO|TU|WE|TH|FR|SA)$/, DS = /^([+-])?(5[0-3]|[1-4][0-9]|[1-9])?(SU|MO|TU|WE|TH|FR|SA)$/, eu = { SU: ae.SUNDAY, MO: ae.MONDAY, TU: ae.TUESDAY, WE: ae.WEDNESDAY, TH: ae.THURSDAY, FR: ae.FRIDAY, SA: ae.SATURDAY }, SS = Object.fromEntries(Object.entries(eu).map((t) => t.reverse())), tu = ["SECONDLY", "MINUTELY", "HOURLY", "DAILY", "WEEKLY", "MONTHLY", "YEARLY"];
class jt {
  static fromString(e) {
    let n = this._stringToData(e, false);
    return new jt(n);
  }
  static fromData(e) {
    return new jt(e);
  }
  static _stringToData(e, n) {
    let r = /* @__PURE__ */ Object.create(null), a = e.split(";"), i = a.length;
    for (let s = 0; s < i; s++) {
      let l = a[s].split("="), o = l[0].toUpperCase(), c = l[0].toLowerCase(), u = n ? c : o, T = l[1];
      if (o in po) {
        let f = T.split(","), m = /* @__PURE__ */ new Set();
        for (let v of f) m.add(po[o](v));
        f = [...m], r[u] = f.length == 1 ? f[0] : f;
      } else o in Eo ? Eo[o](T, r, n) : r[c] = T;
    }
    return r;
  }
  static icalDayToNumericDay(e, n) {
    let r = n || ae.SUNDAY;
    return (eu[e] - r + 7) % 7 + 1;
  }
  static numericDayToIcalDay(e, n) {
    let r = n || ae.SUNDAY, a = e + r - ae.SUNDAY;
    return a > 7 && (a -= 7), SS[a];
  }
  constructor(e) {
    this.wrappedJSObject = this, this.parts = {}, e && typeof e == "object" && this.fromData(e);
  }
  parts = null;
  interval = 1;
  wkst = ae.MONDAY;
  until = null;
  count = null;
  freq = null;
  icalclass = "icalrecur";
  icaltype = "recur";
  iterator(e) {
    return new In({ rule: this, dtstart: e });
  }
  clone() {
    return new jt(this.toJSON());
  }
  isFinite() {
    return !!(this.count || this.until);
  }
  isByCount() {
    return !!(this.count && !this.until);
  }
  addComponent(e, n) {
    let r = e.toUpperCase();
    r in this.parts ? this.parts[r].push(n) : this.parts[r] = [n];
  }
  setComponent(e, n) {
    this.parts[e.toUpperCase()] = n.slice();
  }
  getComponent(e) {
    let n = e.toUpperCase();
    return n in this.parts ? this.parts[n].slice() : [];
  }
  getNextOccurrence(e, n) {
    let r = this.iterator(e), a;
    do
      a = r.next();
    while (a && a.compare(n) <= 0);
    return a && n.zone && (a.zone = n.zone), a;
  }
  fromData(e) {
    for (let n in e) {
      let r = n.toUpperCase();
      r in po ? Array.isArray(e[n]) ? this.parts[r] = e[n] : this.parts[r] = [e[n]] : this[n] = e[n];
    }
    this.interval && typeof this.interval != "number" && Eo.INTERVAL(this.interval, this), this.wkst && typeof this.wkst != "number" && (this.wkst = jt.icalDayToNumericDay(this.wkst)), this.until && !(this.until instanceof ae) && (this.until = ae.fromString(this.until));
  }
  toJSON() {
    let e = /* @__PURE__ */ Object.create(null);
    e.freq = this.freq, this.count && (e.count = this.count), this.interval > 1 && (e.interval = this.interval);
    for (let [n, r] of Object.entries(this.parts)) Array.isArray(r) && r.length == 1 ? e[n.toLowerCase()] = r[0] : e[n.toLowerCase()] = wr(r);
    return this.until && (e.until = this.until.toString()), "wkst" in this && this.wkst !== ae.DEFAULT_WEEK_START && (e.wkst = jt.numericDayToIcalDay(this.wkst)), e;
  }
  toString() {
    let e = "FREQ=" + this.freq;
    this.count && (e += ";COUNT=" + this.count), this.interval > 1 && (e += ";INTERVAL=" + this.interval);
    for (let [n, r] of Object.entries(this.parts)) e += ";" + n + "=" + r;
    return this.until && (e += ";UNTIL=" + this.until.toICALString()), "wkst" in this && this.wkst !== ae.DEFAULT_WEEK_START && (e += ";WKST=" + jt.numericDayToIcalDay(this.wkst)), e;
  }
}
function cr(t, e, n, r) {
  let a = r;
  if (r[0] === "+" && (a = r.slice(1)), a = Gt(a), e !== void 0 && r < e) throw new Error(t + ': invalid value "' + r + '" must be > ' + e);
  if (n !== void 0 && r > n) throw new Error(t + ': invalid value "' + r + '" must be < ' + e);
  return a;
}
const Eo = { FREQ: function(t, e, n) {
  if (tu.indexOf(t) !== -1) e.freq = t;
  else throw new Error('invalid frequency "' + t + '" expected: "' + tu.join(", ") + '"');
}, COUNT: function(t, e, n) {
  e.count = Gt(t);
}, INTERVAL: function(t, e, n) {
  e.interval = Gt(t), e.interval < 1 && (e.interval = 1);
}, UNTIL: function(t, e, n) {
  t.length > 10 ? e.until = Dt.icalendar.value["date-time"].fromICAL(t) : e.until = Dt.icalendar.value.date.fromICAL(t), n || (e.until = ae.fromString(e.until));
}, WKST: function(t, e, n) {
  if (pS.test(t)) e.wkst = jt.icalDayToNumericDay(t);
  else throw new Error('invalid WKST value "' + t + '"');
} }, po = { BYSECOND: cr.bind(void 0, "BYSECOND", 0, 60), BYMINUTE: cr.bind(void 0, "BYMINUTE", 0, 59), BYHOUR: cr.bind(void 0, "BYHOUR", 0, 23), BYDAY: function(t) {
  if (DS.test(t)) return t;
  throw new Error('invalid BYDAY value "' + t + '"');
}, BYMONTHDAY: cr.bind(void 0, "BYMONTHDAY", -31, 31), BYYEARDAY: cr.bind(void 0, "BYYEARDAY", -366, 366), BYWEEKNO: cr.bind(void 0, "BYWEEKNO", -53, 53), BYMONTH: cr.bind(void 0, "BYMONTH", 1, 12), BYSETPOS: cr.bind(void 0, "BYSETPOS", -366, 366) }, vS = /\\\\|\\;|\\,|\\[Nn]/g, gS = /\\|;|,|\n/g, nu = /\\\\|\\,|\\[Nn]/g, ru = /\\|,|\n/g;
function Do(t, e) {
  return { matches: /.*/, fromICAL: function(r, a) {
    return NS(r, t, a);
  }, toICAL: function(r, a) {
    let i = e;
    return a && (i = new RegExp(i.source + "|" + a, i.flags)), r.replace(i, function(s) {
      switch (s) {
        case "\\":
          return "\\\\";
        case ";":
          return "\\;";
        case ",":
          return "\\,";
        case `
`:
          return "\\n";
        default:
          return s;
      }
    });
  } };
}
const qe = { defaultType: "text" }, ba = { defaultType: "text", multiValue: "," }, Ii = { defaultType: "text", structuredValue: ";" }, Li = { defaultType: "integer" }, ki = { defaultType: "date-time", allowedTypes: ["date-time", "date"] }, Ci = { defaultType: "date-time" }, tn = { defaultType: "uri" }, au = { defaultType: "utc-offset" }, iu = { defaultType: "recur" }, su = { defaultType: "date-and-or-time", allowedTypes: ["date-time", "date", "text"] };
function RS(t) {
  switch (t) {
    case "\\\\":
      return "\\";
    case "\\;":
      return ";";
    case "\\,":
      return ",";
    case "\\n":
    case "\\N":
      return `
`;
    default:
      return t;
  }
}
function NS(t, e, n) {
  return t.indexOf("\\") === -1 ? t : (n && (e = new RegExp(e.source + "|\\\\" + n, e.flags)), t.replace(e, RS));
}
let So = { categories: ba, url: tn, version: qe, uid: qe }, vo = { boolean: { values: ["TRUE", "FALSE"], fromICAL: function(t) {
  switch (t) {
    case "TRUE":
      return true;
    case "FALSE":
      return false;
    default:
      return false;
  }
}, toICAL: function(t) {
  return t ? "TRUE" : "FALSE";
} }, float: { matches: /^[+-]?\d+\.\d+$/, fromICAL: function(t) {
  let e = parseFloat(t);
  return Ma(e) ? 0 : e;
}, toICAL: function(t) {
  return String(t);
} }, integer: { fromICAL: function(t) {
  let e = parseInt(t);
  return Ma(e) ? 0 : e;
}, toICAL: function(t) {
  return String(t);
} }, "utc-offset": { toICAL: function(t) {
  return t.length < 7 ? t.slice(0, 3) + t.slice(4, 6) : t.slice(0, 3) + t.slice(4, 6) + t.slice(7, 9);
}, fromICAL: function(t) {
  return t.length < 6 ? t.slice(0, 3) + ":" + t.slice(3, 5) : t.slice(0, 3) + ":" + t.slice(3, 5) + ":" + t.slice(5, 7);
}, decorate: function(t) {
  return Fn.fromString(t);
}, undecorate: function(t) {
  return t.toString();
} } }, FS = { cutype: { values: ["INDIVIDUAL", "GROUP", "RESOURCE", "ROOM", "UNKNOWN"], allowXName: true, allowIanaToken: true }, "delegated-from": { valueType: "cal-address", multiValue: ",", multiValueSeparateDQuote: true }, "delegated-to": { valueType: "cal-address", multiValue: ",", multiValueSeparateDQuote: true }, encoding: { values: ["8BIT", "BASE64"] }, fbtype: { values: ["FREE", "BUSY", "BUSY-UNAVAILABLE", "BUSY-TENTATIVE"], allowXName: true, allowIanaToken: true }, member: { valueType: "cal-address", multiValue: ",", multiValueSeparateDQuote: true }, partstat: { values: ["NEEDS-ACTION", "ACCEPTED", "DECLINED", "TENTATIVE", "DELEGATED", "COMPLETED", "IN-PROCESS"], allowXName: true, allowIanaToken: true }, range: { values: ["THISANDFUTURE"] }, related: { values: ["START", "END"] }, reltype: { values: ["PARENT", "CHILD", "SIBLING"], allowXName: true, allowIanaToken: true }, role: { values: ["REQ-PARTICIPANT", "CHAIR", "OPT-PARTICIPANT", "NON-PARTICIPANT"], allowXName: true, allowIanaToken: true }, rsvp: { values: ["TRUE", "FALSE"] }, "sent-by": { valueType: "cal-address" }, tzid: { matches: /^\// }, value: { values: ["binary", "boolean", "cal-address", "date", "date-time", "duration", "float", "integer", "period", "recur", "text", "time", "uri", "utc-offset"], allowXName: true, allowIanaToken: true } };
const qt = _r(vo, { text: Do(vS, gS), uri: {}, binary: { decorate: function(t) {
  return zi.fromString(t);
}, undecorate: function(t) {
  return t.toString();
} }, "cal-address": {}, date: { decorate: function(t, e) {
  return ae.fromDateString(t, e);
}, undecorate: function(t) {
  return t.toString();
}, fromICAL: function(t) {
  return t.slice(0, 4) + "-" + t.slice(4, 6) + "-" + t.slice(6, 8);
}, toICAL: function(t) {
  let e = t.length;
  return e == 10 ? t.slice(0, 4) + t.slice(5, 7) + t.slice(8, 10) : e >= 19 ? qt["date-time"].toICAL(t) : t;
} }, "date-time": { fromICAL: function(t) {
  {
    let e = t.slice(0, 4) + "-" + t.slice(4, 6) + "-" + t.slice(6, 8) + "T" + t.slice(9, 11) + ":" + t.slice(11, 13) + ":" + t.slice(13, 15);
    return t[15] && t[15] === "Z" && (e += "Z"), e;
  }
}, toICAL: function(t) {
  if (t.length >= 19) {
    let n = t.slice(0, 4) + t.slice(5, 7) + t.slice(8, 13) + t.slice(14, 16) + t.slice(17, 19);
    return t[19] && t[19] === "Z" && (n += "Z"), n;
  } else return t;
}, decorate: function(t, e) {
  return ae.fromDateTimeString(t, e);
}, undecorate: function(t) {
  return t.toString();
} }, duration: { decorate: function(t) {
  return zt.fromString(t);
}, undecorate: function(t) {
  return t.toString();
} }, period: { fromICAL: function(t) {
  let e = t.split("/");
  return e[0] = qt["date-time"].fromICAL(e[0]), zt.isValueString(e[1]) || (e[1] = qt["date-time"].fromICAL(e[1])), e;
}, toICAL: function(t) {
  return t = t.slice(), t[0] = qt["date-time"].toICAL(t[0]), zt.isValueString(t[1]) || (t[1] = qt["date-time"].toICAL(t[1])), t.join("/");
}, decorate: function(t, e) {
  return Qn.fromJSON(t, e, false);
}, undecorate: function(t) {
  return t.toJSON();
} }, recur: { fromICAL: function(t) {
  return jt._stringToData(t, true);
}, toICAL: function(t) {
  let e = "";
  for (let [n, r] of Object.entries(t)) n == "until" ? r.length > 10 ? r = qt["date-time"].toICAL(r) : r = qt.date.toICAL(r) : n == "wkst" ? typeof r == "number" && (r = jt.numericDayToIcalDay(r)) : Array.isArray(r) && (r = r.join(",")), e += n.toUpperCase() + "=" + r + ";";
  return e.slice(0, Math.max(0, e.length - 1));
}, decorate: function(e) {
  return jt.fromData(e);
}, undecorate: function(t) {
  return t.toJSON();
} }, time: { fromICAL: function(t) {
  if (t.length < 6) return t;
  let e = t.slice(0, 2) + ":" + t.slice(2, 4) + ":" + t.slice(4, 6);
  return t[6] === "Z" && (e += "Z"), e;
}, toICAL: function(t) {
  if (t.length < 8) return t;
  let e = t.slice(0, 2) + t.slice(3, 5) + t.slice(6, 8);
  return t[8] === "Z" && (e += "Z"), e;
} } });
let yS = _r(So, { action: qe, attach: { defaultType: "uri" }, attendee: { defaultType: "cal-address" }, calscale: qe, class: qe, comment: qe, completed: Ci, contact: qe, created: Ci, description: qe, dtend: ki, dtstamp: Ci, dtstart: ki, due: ki, duration: { defaultType: "duration" }, exdate: { defaultType: "date-time", allowedTypes: ["date-time", "date"], multiValue: "," }, exrule: iu, freebusy: { defaultType: "period", multiValue: "," }, geo: { defaultType: "float", structuredValue: ";" }, "last-modified": Ci, location: qe, method: qe, organizer: { defaultType: "cal-address" }, "percent-complete": Li, priority: Li, prodid: qe, "related-to": qe, repeat: Li, rdate: { defaultType: "date-time", allowedTypes: ["date-time", "date", "period"], multiValue: ",", detectType: function(t) {
  return t.indexOf("/") !== -1 ? "period" : t.indexOf("T") === -1 ? "date" : "date-time";
} }, "recurrence-id": ki, resources: ba, "request-status": Ii, rrule: iu, sequence: Li, status: qe, summary: qe, transp: qe, trigger: { defaultType: "duration", allowedTypes: ["duration", "date-time"] }, tzoffsetfrom: au, tzoffsetto: au, tzurl: tn, tzid: qe, tzname: qe });
const on = _r(vo, { text: Do(nu, ru), uri: Do(nu, ru), date: { decorate: function(t) {
  return Ar.fromDateAndOrTimeString(t, "date");
}, undecorate: function(t) {
  return t.toString();
}, fromICAL: function(t) {
  return t.length == 8 ? qt.date.fromICAL(t) : t[0] == "-" && t.length == 6 ? t.slice(0, 4) + "-" + t.slice(4) : t;
}, toICAL: function(t) {
  return t.length == 10 ? qt.date.toICAL(t) : t[0] == "-" && t.length == 7 ? t.slice(0, 4) + t.slice(5) : t;
} }, time: { decorate: function(t) {
  return Ar.fromDateAndOrTimeString("T" + t, "time");
}, undecorate: function(t) {
  return t.toString();
}, fromICAL: function(t) {
  let e = on.time._splitZone(t, true), n = e[0], r = e[1];
  return r.length == 6 ? r = r.slice(0, 2) + ":" + r.slice(2, 4) + ":" + r.slice(4, 6) : r.length == 4 && r[0] != "-" ? r = r.slice(0, 2) + ":" + r.slice(2, 4) : r.length == 5 && (r = r.slice(0, 3) + ":" + r.slice(3, 5)), n.length == 5 && (n[0] == "-" || n[0] == "+") && (n = n.slice(0, 3) + ":" + n.slice(3)), r + n;
}, toICAL: function(t) {
  let e = on.time._splitZone(t), n = e[0], r = e[1];
  return r.length == 8 ? r = r.slice(0, 2) + r.slice(3, 5) + r.slice(6, 8) : r.length == 5 && r[0] != "-" ? r = r.slice(0, 2) + r.slice(3, 5) : r.length == 6 && (r = r.slice(0, 3) + r.slice(4, 6)), n.length == 6 && (n[0] == "-" || n[0] == "+") && (n = n.slice(0, 3) + n.slice(4)), r + n;
}, _splitZone: function(t, e) {
  let n = t.length - 1, r = t.length - (e ? 5 : 6), a = t[r], i, s;
  return t[n] == "Z" ? (i = t[n], s = t.slice(0, Math.max(0, n))) : t.length > 6 && (a == "-" || a == "+") ? (i = t.slice(r), s = t.slice(0, Math.max(0, r))) : (i = "", s = t), [i, s];
} }, "date-time": { decorate: function(t) {
  return Ar.fromDateAndOrTimeString(t, "date-time");
}, undecorate: function(t) {
  return t.toString();
}, fromICAL: function(t) {
  return on["date-and-or-time"].fromICAL(t);
}, toICAL: function(t) {
  return on["date-and-or-time"].toICAL(t);
} }, "date-and-or-time": { decorate: function(t) {
  return Ar.fromDateAndOrTimeString(t, "date-and-or-time");
}, undecorate: function(t) {
  return t.toString();
}, fromICAL: function(t) {
  let e = t.split("T");
  return (e[0] ? on.date.fromICAL(e[0]) : "") + (e[1] ? "T" + on.time.fromICAL(e[1]) : "");
}, toICAL: function(t) {
  let e = t.split("T");
  return on.date.toICAL(e[0]) + (e[1] ? "T" + on.time.toICAL(e[1]) : "");
} }, timestamp: qt["date-time"], "language-tag": { matches: /^[a-zA-Z0-9-]+$/ }, "phone-number": { fromICAL: function(t) {
  return Array.from(t).filter(function(e) {
    return e === "\\" ? void 0 : e;
  }).join("");
}, toICAL: function(t) {
  return Array.from(t).map(function(e) {
    return e === "," || e === ";" ? "\\" + e : e;
  }).join("");
} } });
let OS = { type: { valueType: "text", multiValue: "," }, value: { values: ["text", "uri", "date", "time", "date-time", "date-and-or-time", "timestamp", "boolean", "integer", "float", "utc-offset", "language-tag"], allowXName: true, allowIanaToken: true } }, MS = _r(So, { adr: { defaultType: "text", structuredValue: ";", multiValue: "," }, anniversary: su, bday: su, caladruri: tn, caluri: tn, clientpidmap: Ii, email: qe, fburl: tn, fn: qe, gender: Ii, geo: tn, impp: tn, key: tn, kind: qe, lang: { defaultType: "language-tag" }, logo: tn, member: tn, n: { defaultType: "text", structuredValue: ";", multiValue: "," }, nickname: ba, note: qe, org: { defaultType: "text", structuredValue: ";" }, photo: tn, related: tn, rev: { defaultType: "timestamp" }, role: qe, sound: tn, source: tn, tel: { defaultType: "uri", allowedTypes: ["uri", "text"] }, title: qe, tz: { defaultType: "text", allowedTypes: ["text", "utc-offset", "uri"] }, xml: qe }), bS = _r(vo, { binary: qt.binary, date: on.date, "date-time": on["date-time"], "phone-number": on["phone-number"], uri: qt.uri, text: on.text, time: qt.time, vcard: qt.text, "utc-offset": { toICAL: function(t) {
  return t.slice(0, 7);
}, fromICAL: function(t) {
  return t.slice(0, 7);
}, decorate: function(t) {
  return Fn.fromString(t);
}, undecorate: function(t) {
  return t.toString();
} } }), YS = { type: { valueType: "text", multiValue: "," }, value: { values: ["text", "uri", "date", "date-time", "phone-number", "time", "boolean", "integer", "float", "utc-offset", "vcard", "binary"], allowXName: true, allowIanaToken: true } }, wS = _r(So, { fn: qe, n: { defaultType: "text", structuredValue: ";", multiValue: "," }, nickname: ba, photo: { defaultType: "binary", allowedTypes: ["binary", "uri"] }, bday: { defaultType: "date-time", allowedTypes: ["date-time", "date"], detectType: function(t) {
  return t.indexOf("T") === -1 ? "date" : "date-time";
} }, adr: { defaultType: "text", structuredValue: ";", multiValue: "," }, label: qe, tel: { defaultType: "phone-number" }, email: qe, mailer: qe, tz: { defaultType: "utc-offset", allowedTypes: ["utc-offset", "text"] }, geo: { defaultType: "float", structuredValue: ";" }, title: qe, role: qe, logo: { defaultType: "binary", allowedTypes: ["binary", "uri"] }, agent: { defaultType: "vcard", allowedTypes: ["vcard", "text", "uri"] }, org: Ii, note: ba, prodid: qe, rev: { defaultType: "date-time", allowedTypes: ["date-time", "date"], detectType: function(t) {
  return t.indexOf("T") === -1 ? "date" : "date-time";
} }, "sort-string": qe, sound: { defaultType: "binary", allowedTypes: ["binary", "uri"] }, class: qe, key: { defaultType: "binary", allowedTypes: ["binary", "text"] } }), Vn = { name: "ical", value: qt, param: FS, property: yS, propertyGroups: false }, ou = { name: "vcard4", value: on, param: OS, property: MS, propertyGroups: true }, lu = { name: "vcard3", value: bS, param: YS, property: wS, propertyGroups: true };
const Dt = { strict: true, defaultSet: Vn, defaultType: "unknown", components: { vcard: ou, vcard3: lu, vevent: Vn, vtodo: Vn, vjournal: Vn, valarm: Vn, vtimezone: Vn, daylight: Vn, standard: Vn }, icalendar: Vn, vcard: ou, vcard3: lu, getDesignSet: function(t) {
  return t && t in Dt.components ? Dt.components[t] : Dt.defaultSet;
} }, xi = `\r
`, uu = "unknown", _S = { '"': "^'", "\n": "^n", "^": "^^" };
function At(t) {
  typeof t[0] == "string" && (t = [t]);
  let e = 0, n = t.length, r = "";
  for (; e < n; e++) r += At.component(t[e]) + xi;
  return r;
}
At.component = function(t, e) {
  let n = t[0].toUpperCase(), r = "BEGIN:" + n + xi, a = t[1], i = 0, s = a.length, l = t[0];
  for (l === "vcard" && t[1].length > 0 && !(t[1][0][0] === "version" && t[1][0][3] === "4.0") && (l = "vcard3"), e = e || Dt.getDesignSet(l); i < s; i++) r += At.property(a[i], e) + xi;
  let o = t[2] || [], c = 0, u = o.length;
  for (; c < u; c++) r += At.component(o[c], e) + xi;
  return r += "END:" + n, r;
}, At.property = function(t, e, n) {
  let r = t[0].toUpperCase(), a = t[0], i = t[1];
  e || (e = Dt.defaultSet);
  let s = i.group, l;
  e.propertyGroups && s ? l = s.toUpperCase() + "." + r : l = r;
  for (let [m, v] of Object.entries(i)) {
    if (e.propertyGroups && m == "group") continue;
    let E = e.param[m], A = E && E.multiValue;
    A && Array.isArray(v) ? (v = v.map(function(g) {
      return g = At._rfc6868Unescape(g), g = At.paramPropertyValue(g, E.multiValueSeparateDQuote), g;
    }), v = At.multiValue(v, A, "unknown", null, e)) : (v = At._rfc6868Unescape(v), v = At.paramPropertyValue(v)), l += ";" + m.toUpperCase() + "=" + v;
  }
  if (t.length === 3) return l + ":";
  let o = t[2], c, u = false, T = false, f = false;
  return a in e.property ? (c = e.property[a], "multiValue" in c && (u = c.multiValue), "structuredValue" in c && Array.isArray(t[3]) && (T = c.structuredValue), "defaultType" in c ? o === c.defaultType && (f = true) : o === uu && (f = true)) : o === uu && (f = true), f || (l += ";VALUE=" + o.toUpperCase()), l += ":", u && T ? l += At.multiValue(t[3], T, o, u, e, T) : u ? l += At.multiValue(t.slice(3), u, o, null, e, false) : T ? l += At.multiValue(t[3], T, o, null, e, T) : l += At.value(t[3], o, e, false), n ? l : Xl(l);
}, At.paramPropertyValue = function(t, e) {
  return !e && t.indexOf(",") === -1 && t.indexOf(":") === -1 && t.indexOf(";") === -1 ? t : '"' + t + '"';
}, At.multiValue = function(t, e, n, r, a, i) {
  let s = "", l = t.length, o = 0;
  for (; o < l; o++) r && Array.isArray(t[o]) ? s += At.multiValue(t[o], r, n, null, a, i) : s += At.value(t[o], n, a, i), o !== l - 1 && (s += e);
  return s;
}, At.value = function(t, e, n, r) {
  return e in n.value && "toICAL" in n.value[e] ? n.value[e].toICAL(t, r) : t;
}, At._rfc6868Unescape = function(t) {
  return t.replace(/[\n^"]/g, function(e) {
    return _S[e];
  });
};
const cu = 0, Hi = 1, Pi = 2, Tr = 3;
class Ir {
  static fromString(e, n) {
    return new Ir(Je.property(e, n));
  }
  constructor(e, n) {
    this._parent = n || null, typeof e == "string" ? (this.jCal = [e, {}, Dt.defaultType], this.jCal[Pi] = this.getDefaultType()) : this.jCal = e, this._updateType();
  }
  get type() {
    return this.jCal[Pi];
  }
  get name() {
    return this.jCal[cu];
  }
  get parent() {
    return this._parent;
  }
  set parent(e) {
    let n = !this._parent || e && e._designSet != this._parent._designSet;
    this._parent = e, this.type == Dt.defaultType && n && (this.jCal[Pi] = this.getDefaultType(), this._updateType());
  }
  get _designSet() {
    return this.parent ? this.parent._designSet : Dt.defaultSet;
  }
  _updateType() {
    let e = this._designSet;
    this.type in e.value && ("decorate" in e.value[this.type] ? this.isDecorated = true : this.isDecorated = false, this.name in e.property && (this.isMultiValue = "multiValue" in e.property[this.name], this.isStructuredValue = "structuredValue" in e.property[this.name]));
  }
  _hydrateValue(e) {
    return this._values && this._values[e] ? this._values[e] : this.jCal.length <= Tr + e ? null : this.isDecorated ? (this._values || (this._values = []), this._values[e] = this._decorate(this.jCal[Tr + e])) : this.jCal[Tr + e];
  }
  _decorate(e) {
    return this._designSet.value[this.type].decorate(e, this);
  }
  _undecorate(e) {
    return this._designSet.value[this.type].undecorate(e, this);
  }
  _setDecoratedValue(e, n) {
    this._values || (this._values = []), typeof e == "object" && "icaltype" in e ? (this.jCal[Tr + n] = this._undecorate(e), this._values[n] = e) : (this.jCal[Tr + n] = e, this._values[n] = this._decorate(e));
  }
  getParameter(e) {
    if (e in this.jCal[Hi]) return this.jCal[Hi][e];
  }
  getFirstParameter(e) {
    let n = this.getParameter(e);
    return Array.isArray(n) ? n[0] : n;
  }
  setParameter(e, n) {
    let r = e.toLowerCase();
    typeof n == "string" && r in this._designSet.param && "multiValue" in this._designSet.param[r] && (n = [n]), this.jCal[Hi][e] = n;
  }
  removeParameter(e) {
    delete this.jCal[Hi][e];
  }
  getDefaultType() {
    let e = this.jCal[cu], n = this._designSet;
    if (e in n.property) {
      let r = n.property[e];
      if ("defaultType" in r) return r.defaultType;
    }
    return Dt.defaultType;
  }
  resetType(e) {
    this.removeAllValues(), this.jCal[Pi] = e, this._updateType();
  }
  getFirstValue() {
    return this._hydrateValue(0);
  }
  getValues() {
    let e = this.jCal.length - Tr;
    if (e < 1) return [];
    let n = 0, r = [];
    for (; n < e; n++) r[n] = this._hydrateValue(n);
    return r;
  }
  removeAllValues() {
    this._values && (this._values.length = 0), this.jCal.length = 3;
  }
  setValues(e) {
    if (!this.isMultiValue) throw new Error(this.name + `: does not not support mulitValue.
override isMultiValue`);
    let n = e.length, r = 0;
    if (this.removeAllValues(), n > 0 && typeof e[0] == "object" && "icaltype" in e[0] && this.resetType(e[0].icaltype), this.isDecorated) for (; r < n; r++) this._setDecoratedValue(e[r], r);
    else for (; r < n; r++) this.jCal[Tr + r] = e[r];
  }
  setValue(e) {
    this.removeAllValues(), typeof e == "object" && "icaltype" in e && this.resetType(e.icaltype), this.isDecorated ? this._setDecoratedValue(e, 0) : this.jCal[Tr] = e;
  }
  toJSON() {
    return this.jCal;
  }
  toICALString() {
    return At.property(this.jCal, this._designSet, true);
  }
}
const dr = 0, Bn = 1, hr = 2, BS = 0, ZS = 3;
class ln {
  static fromString(e) {
    return new ln(Je.component(e));
  }
  constructor(e, n) {
    typeof e == "string" && (e = [e, [], []]), this.jCal = e, this.parent = n || null, !this.parent && this.name === "vcalendar" && (this._timezoneCache = /* @__PURE__ */ new Map());
  }
  _hydratedPropertyCount = 0;
  _hydratedComponentCount = 0;
  _timezoneCache = null;
  _components = null;
  _properties = null;
  get name() {
    return this.jCal[dr];
  }
  get _designSet() {
    let e = this.parent && this.parent._designSet;
    if (!e && this.name == "vcard") {
      let n = this.jCal[Bn]?.[0];
      if (n && n[BS] == "version" && n[ZS] == "3.0") return Dt.getDesignSet("vcard3");
    }
    return e || Dt.getDesignSet(this.name);
  }
  _hydrateComponent(e) {
    if (this._components || (this._components = [], this._hydratedComponentCount = 0), this._components[e]) return this._components[e];
    let n = new ln(this.jCal[hr][e], this);
    return this._hydratedComponentCount++, this._components[e] = n;
  }
  _hydrateProperty(e) {
    if (this._properties || (this._properties = [], this._hydratedPropertyCount = 0), this._properties[e]) return this._properties[e];
    let n = new Ir(this.jCal[Bn][e], this);
    return this._hydratedPropertyCount++, this._properties[e] = n;
  }
  getFirstSubcomponent(e) {
    if (e) {
      let n = 0, r = this.jCal[hr], a = r.length;
      for (; n < a; n++) if (r[n][dr] === e) return this._hydrateComponent(n);
    } else if (this.jCal[hr].length) return this._hydrateComponent(0);
    return null;
  }
  getAllSubcomponents(e) {
    let n = this.jCal[hr].length, r = 0;
    if (e) {
      let a = this.jCal[hr], i = [];
      for (; r < n; r++) e === a[r][dr] && i.push(this._hydrateComponent(r));
      return i;
    } else {
      if (!this._components || this._hydratedComponentCount !== n) for (; r < n; r++) this._hydrateComponent(r);
      return this._components || [];
    }
  }
  hasProperty(e) {
    let n = this.jCal[Bn], r = n.length, a = 0;
    for (; a < r; a++) if (n[a][dr] === e) return true;
    return false;
  }
  getFirstProperty(e) {
    if (e) {
      let n = 0, r = this.jCal[Bn], a = r.length;
      for (; n < a; n++) if (r[n][dr] === e) return this._hydrateProperty(n);
    } else if (this.jCal[Bn].length) return this._hydrateProperty(0);
    return null;
  }
  getFirstPropertyValue(e) {
    let n = this.getFirstProperty(e);
    return n ? n.getFirstValue() : null;
  }
  getAllProperties(e) {
    let n = this.jCal[Bn].length, r = 0;
    if (e) {
      let a = this.jCal[Bn], i = [];
      for (; r < n; r++) e === a[r][dr] && i.push(this._hydrateProperty(r));
      return i;
    } else {
      if (!this._properties || this._hydratedPropertyCount !== n) for (; r < n; r++) this._hydrateProperty(r);
      return this._properties || [];
    }
  }
  _removeObjectByIndex(e, n, r) {
    if (n = n || [], n[r]) {
      let a = n[r];
      "parent" in a && (a.parent = null);
    }
    n.splice(r, 1), this.jCal[e].splice(r, 1);
  }
  _removeObject(e, n, r) {
    let a = 0, i = this.jCal[e], s = i.length, l = this[n];
    if (typeof r == "string") {
      for (; a < s; a++) if (i[a][dr] === r) return this._removeObjectByIndex(e, l, a), true;
    } else if (l) {
      for (; a < s; a++) if (l[a] && l[a] === r) return this._removeObjectByIndex(e, l, a), true;
    }
    return false;
  }
  _removeAllObjects(e, n, r) {
    let a = this[n], i = this.jCal[e], s = i.length - 1;
    for (; s >= 0; s--) (!r || i[s][dr] === r) && this._removeObjectByIndex(e, a, s);
  }
  addSubcomponent(e) {
    this._components || (this._components = [], this._hydratedComponentCount = 0), e.parent && e.parent.removeSubcomponent(e);
    let n = this.jCal[hr].push(e.jCal);
    return this._components[n - 1] = e, this._hydratedComponentCount++, e.parent = this, e;
  }
  removeSubcomponent(e) {
    let n = this._removeObject(hr, "_components", e);
    return n && this._hydratedComponentCount--, n;
  }
  removeAllSubcomponents(e) {
    let n = this._removeAllObjects(hr, "_components", e);
    return this._hydratedComponentCount = 0, n;
  }
  addProperty(e) {
    if (!(e instanceof Ir)) throw new TypeError("must be instance of ICAL.Property");
    this._properties || (this._properties = [], this._hydratedPropertyCount = 0), e.parent && e.parent.removeProperty(e);
    let n = this.jCal[Bn].push(e.jCal);
    return this._properties[n - 1] = e, this._hydratedPropertyCount++, e.parent = this, e;
  }
  addPropertyWithValue(e, n) {
    let r = new Ir(e);
    return r.setValue(n), this.addProperty(r), r;
  }
  updatePropertyWithValue(e, n) {
    let r = this.getFirstProperty(e);
    return r ? r.setValue(n) : r = this.addPropertyWithValue(e, n), r;
  }
  removeProperty(e) {
    let n = this._removeObject(Bn, "_properties", e);
    return n && this._hydratedPropertyCount--, n;
  }
  removeAllProperties(e) {
    let n = this._removeAllObjects(Bn, "_properties", e);
    return this._hydratedPropertyCount = 0, n;
  }
  toJSON() {
    return this.jCal;
  }
  toString() {
    return At.component(this.jCal, this._designSet);
  }
  getTimeZoneByID(e) {
    if (this.parent) return this.parent.getTimeZoneByID(e);
    if (!this._timezoneCache) return null;
    if (this._timezoneCache.has(e)) return this._timezoneCache.get(e);
    const n = this.getAllSubcomponents("vtimezone");
    for (const r of n) if (r.getFirstProperty("tzid").getFirstValue() === e) {
      const a = new st({ component: r, tzid: e });
      return this._timezoneCache.set(e, a), a;
    }
    return null;
  }
}
class Tu {
  constructor(e) {
    this.ruleDates = [], this.exDates = [], this.fromData(e);
  }
  complete = false;
  ruleIterators = null;
  ruleDates = null;
  exDates = null;
  ruleDateInc = 0;
  exDateInc = 0;
  exDate = null;
  ruleDate = null;
  dtstart = null;
  last = null;
  fromData(e) {
    let n = $n(e.dtstart, ae);
    if (n) this.dtstart = n;
    else throw new Error(".dtstart (ICAL.Time) must be given");
    if (e.component) this._init(e.component);
    else {
      if (this.last = $n(e.last, ae) || n.clone(), !e.ruleIterators) throw new Error(".ruleIterators or .component must be given");
      this.ruleIterators = e.ruleIterators.map(function(r) {
        return $n(r, In);
      }), this.ruleDateInc = e.ruleDateInc, this.exDateInc = e.exDateInc, e.ruleDates && (this.ruleDates = e.ruleDates.map((r) => $n(r, ae)), this.ruleDate = this.ruleDates[this.ruleDateInc]), e.exDates && (this.exDates = e.exDates.map((r) => $n(r, ae)), this.exDate = this.exDates[this.exDateInc]), typeof e.complete < "u" && (this.complete = e.complete);
    }
  }
  _compare_special(e, n) {
    return !e.isDate && n.isDate ? new ae({ year: e.year, month: e.month, day: e.day }).compare(n) : e.compare(n);
  }
  next() {
    let e, n, r, a = 500, i = 0;
    for (; ; ) {
      if (i++ > a) throw new Error("max tries have occurred, rule may be impossible to fulfill.");
      if (n = this.ruleDate, e = this._nextRecurrenceIter(this.last), !n && !e) {
        this.complete = true;
        break;
      }
      if ((!n || e && n.compare(e.last) > 0) && (n = e.last.clone(), e.next()), this.ruleDate === n && this._nextRuleDay(), this.last = n, this.exDate && (r = this._compare_special(this.last, this.exDate), r > 0 && this._nextExDay(), r === 0)) {
        this._nextExDay();
        continue;
      }
      return this.last;
    }
  }
  toJSON() {
    function e(r) {
      return r.toJSON();
    }
    let n = /* @__PURE__ */ Object.create(null);
    return n.ruleIterators = this.ruleIterators.map(e), this.ruleDates && (n.ruleDates = this.ruleDates.map(e)), this.exDates && (n.exDates = this.exDates.map(e)), n.ruleDateInc = this.ruleDateInc, n.exDateInc = this.exDateInc, n.last = this.last.toJSON(), n.dtstart = this.dtstart.toJSON(), n.complete = this.complete, n;
  }
  _extractDates(e, n) {
    let r = [], a = e.getAllProperties(n);
    for (let i = 0, s = a.length; i < s; i++) for (let l of a[i].getValues()) {
      let o = Yr(r, l, (c, u) => c.compare(u));
      r.splice(o, 0, l);
    }
    return r;
  }
  _init(e) {
    if (this.ruleIterators = [], this.last = this.dtstart.clone(), !e.hasProperty("rdate") && !e.hasProperty("rrule") && !e.hasProperty("recurrence-id")) {
      this.ruleDate = this.last.clone(), this.complete = true;
      return;
    }
    if (e.hasProperty("rdate") && (this.ruleDates = this._extractDates(e, "rdate"), this.ruleDates[0] && this.ruleDates[0].compare(this.dtstart) < 0 ? (this.ruleDateInc = 0, this.last = this.ruleDates[0].clone()) : this.ruleDateInc = Yr(this.ruleDates, this.last, (n, r) => n.compare(r)), this.ruleDate = this.ruleDates[this.ruleDateInc]), e.hasProperty("rrule")) {
      let n = e.getAllProperties("rrule"), r = 0, a = n.length, i, s;
      for (; r < a; r++) i = n[r].getFirstValue(), s = i.iterator(this.dtstart), this.ruleIterators.push(s), s.next();
    }
    e.hasProperty("exdate") && (this.exDates = this._extractDates(e, "exdate"), this.exDateInc = Yr(this.exDates, this.last, this._compare_special), this.exDate = this.exDates[this.exDateInc]);
  }
  _nextExDay() {
    this.exDate = this.exDates[++this.exDateInc];
  }
  _nextRuleDay() {
    this.ruleDate = this.ruleDates[++this.ruleDateInc];
  }
  _nextRecurrenceIter() {
    let e = this.ruleIterators;
    if (e.length === 0) return null;
    let n = e.length, r, a, i = 0, s;
    for (; i < n; i++) {
      if (r = e[i], a = r.last, r.completed) {
        n--, i !== 0 && i--, e.splice(i, 1);
        continue;
      }
      (!s || s.last.compare(a) > 0) && (s = r);
    }
    return s;
  }
}
class _a {
  constructor(e, n) {
    e instanceof ln || (n = e, e = null), e ? this.component = e : this.component = new ln("vevent"), this._rangeExceptionCache = /* @__PURE__ */ Object.create(null), this.exceptions = /* @__PURE__ */ Object.create(null), this.rangeExceptions = [], n && n.strictExceptions && (this.strictExceptions = n.strictExceptions), n && n.exceptions ? n.exceptions.forEach(this.relateException, this) : this.component.parent && !this.isRecurrenceException() && this.component.parent.getAllSubcomponents("vevent").forEach(function(r) {
      r.hasProperty("recurrence-id") && this.relateException(r);
    }, this);
  }
  static THISANDFUTURE = "THISANDFUTURE";
  exceptions = null;
  strictExceptions = false;
  relateException(e) {
    if (this.isRecurrenceException()) throw new Error("cannot relate exception to exceptions");
    if (e instanceof ln && (e = new _a(e)), this.strictExceptions && e.uid !== this.uid) throw new Error("attempted to relate unrelated exception");
    let n = e.recurrenceId.toString();
    if (this.exceptions[n] = e, e.modifiesFuture()) {
      let r = [e.recurrenceId.toUnixTime(), n], a = Yr(this.rangeExceptions, r, du);
      this.rangeExceptions.splice(a, 0, r);
    }
  }
  modifiesFuture() {
    return this.component.hasProperty("recurrence-id") ? this.component.getFirstProperty("recurrence-id").getParameter("range") === _a.THISANDFUTURE : false;
  }
  findRangeException(e) {
    if (!this.rangeExceptions.length) return null;
    let n = e.toUnixTime(), r = Yr(this.rangeExceptions, [n], du);
    if (r -= 1, r < 0) return null;
    let a = this.rangeExceptions[r];
    return n < a[0] ? null : a[1];
  }
  getOccurrenceDetails(e) {
    let n = e.toString(), r = e.convertToZone(st.utcTimezone).toString(), a, i = { recurrenceId: e };
    if (n in this.exceptions) a = i.item = this.exceptions[n], i.startDate = a.startDate, i.endDate = a.endDate, i.item = a;
    else if (r in this.exceptions) a = this.exceptions[r], i.startDate = a.startDate, i.endDate = a.endDate, i.item = a;
    else {
      let s = this.findRangeException(e), l;
      if (s) {
        let o = this.exceptions[s];
        i.item = o;
        let c = this._rangeExceptionCache[s];
        if (!c) {
          let T = o.recurrenceId.clone(), f = o.startDate.clone();
          T.zone = f.zone, c = f.subtractDate(T), this._rangeExceptionCache[s] = c;
        }
        let u = e.clone();
        u.zone = o.startDate.zone, u.addDuration(c), l = u.clone(), l.addDuration(o.duration), i.startDate = u, i.endDate = l;
      } else l = e.clone(), l.addDuration(this.duration), i.endDate = l, i.startDate = e, i.item = this;
    }
    return i;
  }
  iterator(e) {
    return new Tu({ component: this.component, dtstart: e || this.startDate });
  }
  isRecurring() {
    let e = this.component;
    return e.hasProperty("rrule") || e.hasProperty("rdate");
  }
  isRecurrenceException() {
    return this.component.hasProperty("recurrence-id");
  }
  getRecurrenceTypes() {
    let e = this.component.getAllProperties("rrule"), n = 0, r = e.length, a = /* @__PURE__ */ Object.create(null);
    for (; n < r; n++) {
      let i = e[n].getFirstValue();
      a[i.freq] = true;
    }
    return a;
  }
  get uid() {
    return this._firstProp("uid");
  }
  set uid(e) {
    this._setProp("uid", e);
  }
  get startDate() {
    return this._firstProp("dtstart");
  }
  set startDate(e) {
    this._setTime("dtstart", e);
  }
  get endDate() {
    let e = this._firstProp("dtend");
    if (!e) {
      let n = this._firstProp("duration");
      e = this.startDate.clone(), n ? e.addDuration(n) : e.isDate && (e.day += 1);
    }
    return e;
  }
  set endDate(e) {
    this.component.hasProperty("duration") && this.component.removeProperty("duration"), this._setTime("dtend", e);
  }
  get duration() {
    let e = this._firstProp("duration");
    return e || this.endDate.subtractDateTz(this.startDate);
  }
  set duration(e) {
    this.component.hasProperty("dtend") && this.component.removeProperty("dtend"), this._setProp("duration", e);
  }
  get location() {
    return this._firstProp("location");
  }
  set location(e) {
    this._setProp("location", e);
  }
  get attendees() {
    return this.component.getAllProperties("attendee");
  }
  get summary() {
    return this._firstProp("summary");
  }
  set summary(e) {
    this._setProp("summary", e);
  }
  get description() {
    return this._firstProp("description");
  }
  set description(e) {
    this._setProp("description", e);
  }
  get color() {
    return this._firstProp("color");
  }
  set color(e) {
    this._setProp("color", e);
  }
  get organizer() {
    return this._firstProp("organizer");
  }
  set organizer(e) {
    this._setProp("organizer", e);
  }
  get sequence() {
    return this._firstProp("sequence");
  }
  set sequence(e) {
    this._setProp("sequence", e);
  }
  get recurrenceId() {
    return this._firstProp("recurrence-id");
  }
  set recurrenceId(e) {
    this._setTime("recurrence-id", e);
  }
  _setTime(e, n) {
    let r = this.component.getFirstProperty(e);
    r || (r = new Ir(e), this.component.addProperty(r)), n.zone === st.localTimezone || n.zone === st.utcTimezone ? r.removeParameter("tzid") : r.setParameter("tzid", n.zone.tzid), r.setValue(n);
  }
  _setProp(e, n) {
    this.component.updatePropertyWithValue(e, n);
  }
  _firstProp(e) {
    return this.component.getFirstPropertyValue(e);
  }
  toString() {
    return this.component.toString();
  }
}
function du(t, e) {
  return t[0] > e[0] ? 1 : e[0] > t[0] ? -1 : 0;
}
class IS {
  constructor(e) {
    typeof e > "u" && (e = {});
    for (let [n, r] of Object.entries(e)) this[n] = r;
  }
  parseEvent = true;
  parseTimezone = true;
  oncomplete = function() {
  };
  onerror = function(e) {
  };
  ontimezone = function(e) {
  };
  onevent = function(e) {
  };
  process(e) {
    typeof e == "string" && (e = Je(e)), e instanceof ln || (e = new ln(e));
    let n = e.getAllSubcomponents(), r = 0, a = n.length, i;
    for (; r < a; r++) switch (i = n[r], i.name) {
      case "vtimezone":
        if (this.parseTimezone) {
          let s = i.getFirstPropertyValue("tzid");
          s && this.ontimezone(new st({ tzid: s, component: i }));
        }
        break;
      case "vevent":
        this.parseEvent && this.onevent(new _a(i));
        break;
      default:
        continue;
    }
    this.oncomplete();
  }
}
var _t = { foldLength: 75, debug: false, newLineChar: `\r
`, Binary: zi, Component: ln, ComponentParser: IS, Duration: zt, Event: _a, Period: Qn, Property: Ir, Recur: jt, RecurExpansion: Tu, RecurIterator: In, Time: ae, Timezone: st, TimezoneService: Bi, UtcOffset: Fn, VCardTime: Ar, parse: Je, stringify: At, design: Dt, helpers: ES };
function LS(t = [], e = [], n = "Global") {
  const r = /* @__PURE__ */ new Map();
  for (const i of t) {
    const s = i.split("/");
    let [l, o] = [s.shift(), s.join("/")];
    o || (o = l, l = n), r.has(l) || r.set(l, { continent: l, regions: [] }), r.get(l).regions.push({ label: hu(o), cities: [], timezoneId: i });
  }
  for (const { continent: i, label: s, timezoneId: l } of e) r.has(i) || r.set(i, { continent: i, regions: [] }), r.get(i).regions.push({ label: s, cities: [], timezoneId: l });
  const a = [...r.values()].sort((i, s) => i.continent.localeCompare(s.continent));
  for (const { regions: i } of a) i.sort((s, l) => s.label.localeCompare(l.label));
  return a;
}
function hu(t) {
  return t.split("_").join(" ").replace("St ", "St. ").split("/").join(" - ");
}
class mr {
  _timezoneId;
  _ics;
  _timezone;
  _initialized;
  constructor(e, n) {
    e instanceof _t.Timezone ? (this._timezone = e, this._initialized = true) : e instanceof _t.Component ? (this._timezone = new _t.Timezone(e), this._initialized = true) : (this._timezoneId = e, this._ics = n, this._initialized = false);
  }
  get timezoneId() {
    return this._initialized ? this._timezone.tzid : this._timezoneId;
  }
  offsetForArray(e, n, r, a, i, s) {
    const l = new _t.Time({ year: e, month: n, day: r, hour: a, minute: i, second: s, isDate: false });
    return this.timezone.utcOffset(l);
  }
  timestampToArray(e) {
    const n = _t.Time.fromData({ year: 1970, month: 1, day: 1, hour: 0, minute: 0, second: 0 });
    n.fromUnixTime(Math.floor(e / 1e3));
    const r = n.convertToZone(this.timezone);
    return [r.year, r.month, r.day, r.hour, r.minute, r.second];
  }
  toICALTimezone() {
    return this.timezone;
  }
  toICALJs() {
    return this.timezone.component;
  }
  get timezone() {
    if (!this._initialized) {
      const e = _t.parse(this._ics), n = new _t.Component(e);
      this._timezone = new _t.Timezone(n), this._initialized = true;
    }
    return this._timezone;
  }
  static get utc() {
    return new mr(_t.Timezone.utcTimezone);
  }
  static get floating() {
    return new mr(_t.Timezone.localTimezone);
  }
}
const kS = "2.2024a", CS = { "AUS Central Standard Time": { aliasTo: "Australia/Darwin" }, "AUS Eastern Standard Time": { aliasTo: "Australia/Sydney" }, "Afghanistan Standard Time": { aliasTo: "Asia/Kabul" }, "Africa/Asmera": { aliasTo: "Africa/Asmara" }, "Africa/Timbuktu": { aliasTo: "Africa/Bamako" }, "Alaskan Standard Time": { aliasTo: "America/Anchorage" }, "America/Argentina/ComodRivadavia": { aliasTo: "America/Argentina/Catamarca" }, "America/Buenos_Aires": { aliasTo: "America/Argentina/Buenos_Aires" }, "America/Louisville": { aliasTo: "America/Kentucky/Louisville" }, "America/Montreal": { aliasTo: "America/Toronto" }, "America/Santa_Isabel": { aliasTo: "America/Tijuana" }, "Arab Standard Time": { aliasTo: "Asia/Riyadh" }, "Arabian Standard Time": { aliasTo: "Asia/Dubai" }, "Arabic Standard Time": { aliasTo: "Asia/Baghdad" }, "Argentina Standard Time": { aliasTo: "America/Argentina/Buenos_Aires" }, "Asia/Calcutta": { aliasTo: "Asia/Kolkata" }, "Asia/Katmandu": { aliasTo: "Asia/Kathmandu" }, "Asia/Rangoon": { aliasTo: "Asia/Yangon" }, "Asia/Saigon": { aliasTo: "Asia/Ho_Chi_Minh" }, "Atlantic Standard Time": { aliasTo: "America/Halifax" }, "Atlantic/Faeroe": { aliasTo: "Atlantic/Faroe" }, "Atlantic/Jan_Mayen": { aliasTo: "Europe/Oslo" }, "Azerbaijan Standard Time": { aliasTo: "Asia/Baku" }, "Azores Standard Time": { aliasTo: "Atlantic/Azores" }, "Bahia Standard Time": { aliasTo: "America/Bahia" }, "Bangladesh Standard Time": { aliasTo: "Asia/Dhaka" }, "Belarus Standard Time": { aliasTo: "Europe/Minsk" }, "Canada Central Standard Time": { aliasTo: "America/Regina" }, "Cape Verde Standard Time": { aliasTo: "Atlantic/Cape_Verde" }, "Caucasus Standard Time": { aliasTo: "Asia/Yerevan" }, "Cen. Australia Standard Time": { aliasTo: "Australia/Adelaide" }, "Central America Standard Time": { aliasTo: "America/Guatemala" }, "Central Asia Standard Time": { aliasTo: "Asia/Almaty" }, "Central Brazilian Standard Time": { aliasTo: "America/Cuiaba" }, "Central Europe Standard Time": { aliasTo: "Europe/Budapest" }, "Central European Standard Time": { aliasTo: "Europe/Warsaw" }, "Central Pacific Standard Time": { aliasTo: "Pacific/Guadalcanal" }, "Central Standard Time": { aliasTo: "America/Chicago" }, "Central Standard Time (Mexico)": { aliasTo: "America/Mexico_City" }, "China Standard Time": { aliasTo: "Asia/Shanghai" }, "E. Africa Standard Time": { aliasTo: "Africa/Nairobi" }, "E. Australia Standard Time": { aliasTo: "Australia/Brisbane" }, "E. South America Standard Time": { aliasTo: "America/Sao_Paulo" }, "Eastern Standard Time": { aliasTo: "America/New_York" }, "Egypt Standard Time": { aliasTo: "Africa/Cairo" }, "Ekaterinburg Standard Time": { aliasTo: "Asia/Yekaterinburg" }, "Etc/GMT": { aliasTo: "UTC" }, "Etc/GMT+0": { aliasTo: "UTC" }, "Etc/UCT": { aliasTo: "UTC" }, "Etc/UTC": { aliasTo: "UTC" }, "Etc/Unversal": { aliasTo: "UTC" }, "Etc/Zulu": { aliasTo: "UTC" }, "Europe/Belfast": { aliasTo: "Europe/London" }, "FLE Standard Time": { aliasTo: "Europe/Kiev" }, "Fiji Standard Time": { aliasTo: "Pacific/Fiji" }, GMT: { aliasTo: "UTC" }, "GMT Standard Time": { aliasTo: "Europe/London" }, "GMT+0": { aliasTo: "UTC" }, GMT0: { aliasTo: "UTC" }, "GTB Standard Time": { aliasTo: "Europe/Bucharest" }, "Georgian Standard Time": { aliasTo: "Asia/Tbilisi" }, "Greenland Standard Time": { aliasTo: "America/Godthab" }, Greenwich: { aliasTo: "UTC" }, "Greenwich Standard Time": { aliasTo: "Atlantic/Reykjavik" }, "Hawaiian Standard Time": { aliasTo: "Pacific/Honolulu" }, "India Standard Time": { aliasTo: "Asia/Calcutta" }, "Iran Standard Time": { aliasTo: "Asia/Tehran" }, "Israel Standard Time": { aliasTo: "Asia/Jerusalem" }, "Jordan Standard Time": { aliasTo: "Asia/Amman" }, "Kaliningrad Standard Time": { aliasTo: "Europe/Kaliningrad" }, "Korea Standard Time": { aliasTo: "Asia/Seoul" }, "Libya Standard Time": { aliasTo: "Africa/Tripoli" }, "Line Islands Standard Time": { aliasTo: "Pacific/Kiritimati" }, "Magadan Standard Time": { aliasTo: "Asia/Magadan" }, "Mauritius Standard Time": { aliasTo: "Indian/Mauritius" }, "Middle East Standard Time": { aliasTo: "Asia/Beirut" }, "Montevideo Standard Time": { aliasTo: "America/Montevideo" }, "Morocco Standard Time": { aliasTo: "Africa/Casablanca" }, "Mountain Standard Time": { aliasTo: "America/Denver" }, "Mountain Standard Time (Mexico)": { aliasTo: "America/Chihuahua" }, "Myanmar Standard Time": { aliasTo: "Asia/Rangoon" }, "N. Central Asia Standard Time": { aliasTo: "Asia/Novosibirsk" }, "Namibia Standard Time": { aliasTo: "Africa/Windhoek" }, "Nepal Standard Time": { aliasTo: "Asia/Katmandu" }, "New Zealand Standard Time": { aliasTo: "Pacific/Auckland" }, "Newfoundland Standard Time": { aliasTo: "America/St_Johns" }, "North Asia East Standard Time": { aliasTo: "Asia/Irkutsk" }, "North Asia Standard Time": { aliasTo: "Asia/Krasnoyarsk" }, "Pacific SA Standard Time": { aliasTo: "America/Santiago" }, "Pacific Standard Time": { aliasTo: "America/Los_Angeles" }, "Pacific Standard Time (Mexico)": { aliasTo: "America/Santa_Isabel" }, "Pacific/Johnston": { aliasTo: "Pacific/Honolulu" }, "Pakistan Standard Time": { aliasTo: "Asia/Karachi" }, "Paraguay Standard Time": { aliasTo: "America/Asuncion" }, "Romance Standard Time": { aliasTo: "Europe/Paris" }, "Russia Time Zone 10": { aliasTo: "Asia/Srednekolymsk" }, "Russia Time Zone 11": { aliasTo: "Asia/Kamchatka" }, "Russia Time Zone 3": { aliasTo: "Europe/Samara" }, "Russian Standard Time": { aliasTo: "Europe/Moscow" }, "SA Eastern Standard Time": { aliasTo: "America/Cayenne" }, "SA Pacific Standard Time": { aliasTo: "America/Bogota" }, "SA Western Standard Time": { aliasTo: "America/La_Paz" }, "SE Asia Standard Time": { aliasTo: "Asia/Bangkok" }, "Samoa Standard Time": { aliasTo: "Pacific/Apia" }, "Singapore Standard Time": { aliasTo: "Asia/Singapore" }, "South Africa Standard Time": { aliasTo: "Africa/Johannesburg" }, "Sri Lanka Standard Time": { aliasTo: "Asia/Colombo" }, "Syria Standard Time": { aliasTo: "Asia/Damascus" }, "Taipei Standard Time": { aliasTo: "Asia/Taipei" }, "Tasmania Standard Time": { aliasTo: "Australia/Hobart" }, "Tokyo Standard Time": { aliasTo: "Asia/Tokyo" }, "Tonga Standard Time": { aliasTo: "Pacific/Tongatapu" }, "Turkey Standard Time": { aliasTo: "Europe/Istanbul" }, UCT: { aliasTo: "UTC" }, "US Eastern Standard Time": { aliasTo: "America/Indiana/Indianapolis" }, "US Mountain Standard Time": { aliasTo: "America/Phoenix" }, "US/Central": { aliasTo: "America/Chicago" }, "US/Eastern": { aliasTo: "America/New_York" }, "US/Mountain": { aliasTo: "America/Denver" }, "US/Pacific": { aliasTo: "America/Los_Angeles" }, "US/Pacific-New": { aliasTo: "America/Los_Angeles" }, "Ulaanbaatar Standard Time": { aliasTo: "Asia/Ulaanbaatar" }, Universal: { aliasTo: "UTC" }, "Venezuela Standard Time": { aliasTo: "America/Caracas" }, "Vladivostok Standard Time": { aliasTo: "Asia/Vladivostok" }, "W. Australia Standard Time": { aliasTo: "Australia/Perth" }, "W. Central Africa Standard Time": { aliasTo: "Africa/Lagos" }, "W. Europe Standard Time": { aliasTo: "Europe/Berlin" }, "West Asia Standard Time": { aliasTo: "Asia/Tashkent" }, "West Pacific Standard Time": { aliasTo: "Pacific/Port_Moresby" }, "Yakutsk Standard Time": { aliasTo: "Asia/Yakutsk" }, Z: { aliasTo: "UTC" }, Zulu: { aliasTo: "UTC" }, utc: { aliasTo: "UTC" } }, xS = { "Africa/Abidjan": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0000\r
TZOFFSETTO:+0000\r
TZNAME:GMT\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0051900", longitude: "-0040200" }, "Africa/Accra": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0000\r
TZOFFSETTO:+0000\r
TZNAME:GMT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Africa/Addis_Ababa": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0300\r
TZNAME:EAT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Africa/Algiers": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0364700", longitude: "+0030300" }, "Africa/Asmara": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0300\r
TZNAME:EAT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Africa/Asmera": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0300\r
TZNAME:EAT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Africa/Bamako": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0000\r
TZOFFSETTO:+0000\r
TZNAME:GMT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Africa/Bangui": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0100\r
TZNAME:WAT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Africa/Banjul": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0000\r
TZOFFSETTO:+0000\r
TZNAME:GMT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Africa/Bissau": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0000\r
TZOFFSETTO:+0000\r
TZNAME:GMT\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0115100", longitude: "-0153500" }, "Africa/Blantyre": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0200\r
TZNAME:CAT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Africa/Brazzaville": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0100\r
TZNAME:WAT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Africa/Bujumbura": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0200\r
TZNAME:CAT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Africa/Cairo": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0300\r
TZNAME:EEST\r
DTSTART:19700424T000000\r
RRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=-1FR\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0200\r
TZNAME:EET\r
DTSTART:19701030T000000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1FR\r
END:STANDARD`], latitude: "+0300300", longitude: "+0311500" }, "Africa/Casablanca": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0100\r
TZNAME:+01\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0333900", longitude: "-0073500" }, "Africa/Ceuta": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0200\r
TZNAME:CEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`], latitude: "+0355300", longitude: "-0051900" }, "Africa/Conakry": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0000\r
TZOFFSETTO:+0000\r
TZNAME:GMT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Africa/Dakar": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0000\r
TZOFFSETTO:+0000\r
TZNAME:GMT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Africa/Dar_es_Salaam": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0300\r
TZNAME:EAT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Africa/Djibouti": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0300\r
TZNAME:EAT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Africa/Douala": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0100\r
TZNAME:WAT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Africa/El_Aaiun": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0100\r
TZNAME:+01\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0270900", longitude: "-0131200" }, "Africa/Freetown": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0000\r
TZOFFSETTO:+0000\r
TZNAME:GMT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Africa/Gaborone": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0200\r
TZNAME:CAT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Africa/Harare": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0200\r
TZNAME:CAT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Africa/Johannesburg": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0200\r
TZNAME:SAST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0261500", longitude: "+0280000" }, "Africa/Juba": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0200\r
TZNAME:CAT\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0045100", longitude: "+0313700" }, "Africa/Kampala": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0300\r
TZNAME:EAT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Africa/Khartoum": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0200\r
TZNAME:CAT\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0153600", longitude: "+0323200" }, "Africa/Kigali": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0200\r
TZNAME:CAT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Africa/Kinshasa": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0100\r
TZNAME:WAT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Africa/Lagos": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0100\r
TZNAME:WAT\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0062700", longitude: "+0032400" }, "Africa/Libreville": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0100\r
TZNAME:WAT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Africa/Lome": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0000\r
TZOFFSETTO:+0000\r
TZNAME:GMT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Africa/Luanda": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0100\r
TZNAME:WAT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Africa/Lubumbashi": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0200\r
TZNAME:CAT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Africa/Lusaka": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0200\r
TZNAME:CAT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Africa/Malabo": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0100\r
TZNAME:WAT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Africa/Maputo": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0200\r
TZNAME:CAT\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0255800", longitude: "+0323500" }, "Africa/Maseru": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0200\r
TZNAME:SAST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Africa/Mbabane": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0200\r
TZNAME:SAST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Africa/Mogadishu": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0300\r
TZNAME:EAT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Africa/Monrovia": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0000\r
TZOFFSETTO:+0000\r
TZNAME:GMT\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0061800", longitude: "-0104700" }, "Africa/Nairobi": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0300\r
TZNAME:EAT\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0011700", longitude: "+0364900" }, "Africa/Ndjamena": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0100\r
TZNAME:WAT\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0120700", longitude: "+0150300" }, "Africa/Niamey": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0100\r
TZNAME:WAT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Africa/Nouakchott": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0000\r
TZOFFSETTO:+0000\r
TZNAME:GMT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Africa/Ouagadougou": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0000\r
TZOFFSETTO:+0000\r
TZNAME:GMT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Africa/Porto-Novo": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0100\r
TZNAME:WAT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Africa/Sao_Tome": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0000\r
TZOFFSETTO:+0000\r
TZNAME:GMT\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0002000", longitude: "+0064400" }, "Africa/Timbuktu": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0000\r
TZOFFSETTO:+0000\r
TZNAME:GMT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Africa/Tripoli": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0200\r
TZNAME:EET\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0325400", longitude: "+0131100" }, "Africa/Tunis": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0364800", longitude: "+0101100" }, "Africa/Windhoek": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0200\r
TZNAME:CAT\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0223400", longitude: "+0170600" }, "America/Adak": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-1000\r
TZOFFSETTO:-0900\r
TZNAME:HDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0900\r
TZOFFSETTO:-1000\r
TZNAME:HST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0515248", longitude: "-1763929" }, "America/Anchorage": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0900\r
TZOFFSETTO:-0800\r
TZNAME:AKDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0800\r
TZOFFSETTO:-0900\r
TZNAME:AKST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0611305", longitude: "-1495401" }, "America/Anguilla": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0400\r
TZNAME:AST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "America/Antigua": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0400\r
TZNAME:AST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "America/Araguaina": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0071200", longitude: "-0481200" }, "America/Argentina/Buenos_Aires": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0343600", longitude: "-0582700" }, "America/Argentina/Catamarca": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0282800", longitude: "-0654700" }, "America/Argentina/ComodRivadavia": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "America/Argentina/Cordoba": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0312400", longitude: "-0641100" }, "America/Argentina/Jujuy": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0241100", longitude: "-0651800" }, "America/Argentina/La_Rioja": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0292600", longitude: "-0665100" }, "America/Argentina/Mendoza": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0325300", longitude: "-0684900" }, "America/Argentina/Rio_Gallegos": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0513800", longitude: "-0691300" }, "America/Argentina/Salta": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0244700", longitude: "-0652500" }, "America/Argentina/San_Juan": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0313200", longitude: "-0683100" }, "America/Argentina/San_Luis": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0331900", longitude: "-0662100" }, "America/Argentina/Tucuman": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0264900", longitude: "-0651300" }, "America/Argentina/Ushuaia": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0544800", longitude: "-0681800" }, "America/Aruba": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0400\r
TZNAME:AST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "America/Asuncion": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19701004T000000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0400\r
TZNAME:-04\r
DTSTART:19700322T000000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=4SU\r
END:STANDARD`], latitude: "-0251600", longitude: "-0574000" }, "America/Atikokan": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0500\r
TZNAME:EST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "America/Atka": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-1000\r
TZOFFSETTO:-0900\r
TZNAME:HDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0900\r
TZOFFSETTO:-1000\r
TZNAME:HST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`] }, "America/Bahia": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0125900", longitude: "-0383100" }, "America/Bahia_Banderas": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0600\r
TZNAME:CST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0204800", longitude: "-1051500" }, "America/Barbados": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0400\r
TZNAME:AST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0130600", longitude: "-0593700" }, "America/Belem": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0012700", longitude: "-0482900" }, "America/Belize": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0600\r
TZNAME:CST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0173000", longitude: "-0881200" }, "America/Blanc-Sablon": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0400\r
TZNAME:AST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "America/Boa_Vista": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0400\r
TZNAME:-04\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0024900", longitude: "-0604000" }, "America/Bogota": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0500\r
TZNAME:-05\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0043600", longitude: "-0740500" }, "America/Boise": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0700\r
TZOFFSETTO:-0600\r
TZNAME:MDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0700\r
TZNAME:MST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0433649", longitude: "-1161209" }, "America/Buenos_Aires": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "America/Cambridge_Bay": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0700\r
TZOFFSETTO:-0600\r
TZNAME:MDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0700\r
TZNAME:MST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0690650", longitude: "-1050310" }, "America/Campo_Grande": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0400\r
TZNAME:-04\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0202700", longitude: "-0543700" }, "America/Cancun": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0500\r
TZNAME:EST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0210500", longitude: "-0864600" }, "America/Caracas": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0400\r
TZNAME:-04\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0103000", longitude: "-0665600" }, "America/Catamarca": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "America/Cayenne": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0045600", longitude: "-0522000" }, "America/Cayman": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0500\r
TZNAME:EST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "America/Chicago": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0500\r
TZNAME:CDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0600\r
TZNAME:CST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0415100", longitude: "-0873900" }, "America/Chihuahua": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0600\r
TZNAME:CST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0283800", longitude: "-1060500" }, "America/Ciudad_Juarez": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0700\r
TZOFFSETTO:-0600\r
TZNAME:MDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0700\r
TZNAME:MST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0314400", longitude: "-1062900" }, "America/Coral_Harbour": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0500\r
TZNAME:EST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "America/Cordoba": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "America/Costa_Rica": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0600\r
TZNAME:CST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0095600", longitude: "-0840500" }, "America/Creston": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0700\r
TZOFFSETTO:-0700\r
TZNAME:MST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "America/Cuiaba": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0400\r
TZNAME:-04\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0153500", longitude: "-0560500" }, "America/Curacao": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0400\r
TZNAME:AST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "America/Danmarkshavn": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0000\r
TZOFFSETTO:+0000\r
TZNAME:GMT\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0764600", longitude: "-0184000" }, "America/Dawson": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0700\r
TZOFFSETTO:-0700\r
TZNAME:MST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0640400", longitude: "-1392500" }, "America/Dawson_Creek": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0700\r
TZOFFSETTO:-0700\r
TZNAME:MST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0554600", longitude: "-1201400" }, "America/Denver": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0700\r
TZOFFSETTO:-0600\r
TZNAME:MDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0700\r
TZNAME:MST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0394421", longitude: "-1045903" }, "America/Detroit": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0400\r
TZNAME:EDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0500\r
TZNAME:EST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0421953", longitude: "-0830245" }, "America/Dominica": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0400\r
TZNAME:AST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "America/Edmonton": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0700\r
TZOFFSETTO:-0600\r
TZNAME:MDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0700\r
TZNAME:MST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0533300", longitude: "-1132800" }, "America/Eirunepe": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0500\r
TZNAME:-05\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0064000", longitude: "-0695200" }, "America/El_Salvador": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0600\r
TZNAME:CST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0134200", longitude: "-0891200" }, "America/Ensenada": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0800\r
TZOFFSETTO:-0700\r
TZNAME:PDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0700\r
TZOFFSETTO:-0800\r
TZNAME:PST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`] }, "America/Fort_Nelson": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0700\r
TZOFFSETTO:-0700\r
TZNAME:MST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0584800", longitude: "-1224200" }, "America/Fort_Wayne": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0400\r
TZNAME:EDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0500\r
TZNAME:EST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`] }, "America/Fortaleza": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0034300", longitude: "-0383000" }, "America/Glace_Bay": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0300\r
TZNAME:ADT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0400\r
TZNAME:AST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0461200", longitude: "-0595700" }, "America/Godthab": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0200\r
TZOFFSETTO:-0100\r
TZNAME:-01\r
DTSTART:19700328T230000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SA\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0100\r
TZOFFSETTO:-0200\r
TZNAME:-02\r
DTSTART:19701025T000000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`] }, "America/Goose_Bay": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0400\r
TZNAME:AST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`, `BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0300\r
TZNAME:ADT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`], latitude: "+0532000", longitude: "-0602500" }, "America/Grand_Turk": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0500\r
TZNAME:EST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`, `BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0400\r
TZNAME:EDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`], latitude: "+0212800", longitude: "-0710800" }, "America/Grenada": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0400\r
TZNAME:AST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "America/Guadeloupe": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0400\r
TZNAME:AST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "America/Guatemala": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0600\r
TZNAME:CST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0143800", longitude: "-0903100" }, "America/Guayaquil": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0500\r
TZNAME:-05\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0021000", longitude: "-0795000" }, "America/Guyana": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0400\r
TZNAME:-04\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0064800", longitude: "-0581000" }, "America/Halifax": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0300\r
TZNAME:ADT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0400\r
TZNAME:AST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0443900", longitude: "-0633600" }, "America/Havana": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0500\r
TZNAME:CST\r
DTSTART:19701101T010000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`, `BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0400\r
TZNAME:CDT\r
DTSTART:19700308T000000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`], latitude: "+0230800", longitude: "-0822200" }, "America/Hermosillo": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0700\r
TZOFFSETTO:-0700\r
TZNAME:MST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0290400", longitude: "-1105800" }, "America/Indiana/Indianapolis": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0400\r
TZNAME:EDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0500\r
TZNAME:EST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0394606", longitude: "-0860929" }, "America/Indiana/Knox": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0500\r
TZNAME:CDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0600\r
TZNAME:CST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0411745", longitude: "-0863730" }, "America/Indiana/Marengo": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0400\r
TZNAME:EDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0500\r
TZNAME:EST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0382232", longitude: "-0862041" }, "America/Indiana/Petersburg": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0400\r
TZNAME:EDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0500\r
TZNAME:EST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0382931", longitude: "-0871643" }, "America/Indiana/Tell_City": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0500\r
TZNAME:CDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0600\r
TZNAME:CST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0375711", longitude: "-0864541" }, "America/Indiana/Vevay": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0400\r
TZNAME:EDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0500\r
TZNAME:EST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0384452", longitude: "-0850402" }, "America/Indiana/Vincennes": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0400\r
TZNAME:EDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0500\r
TZNAME:EST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0384038", longitude: "-0873143" }, "America/Indiana/Winamac": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0500\r
TZNAME:EST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`, `BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0400\r
TZNAME:EDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`], latitude: "+0410305", longitude: "-0863611" }, "America/Indianapolis": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0400\r
TZNAME:EDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0500\r
TZNAME:EST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`] }, "America/Inuvik": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0700\r
TZOFFSETTO:-0600\r
TZNAME:MDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0700\r
TZNAME:MST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0682059", longitude: "-1334300" }, "America/Iqaluit": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0400\r
TZNAME:EDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0500\r
TZNAME:EST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0634400", longitude: "-0682800" }, "America/Jamaica": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0500\r
TZNAME:EST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0175805", longitude: "-0764736" }, "America/Jujuy": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "America/Juneau": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0900\r
TZOFFSETTO:-0800\r
TZNAME:AKDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0800\r
TZOFFSETTO:-0900\r
TZNAME:AKST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0581807", longitude: "-1342511" }, "America/Kentucky/Louisville": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0400\r
TZNAME:EDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0500\r
TZNAME:EST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0381515", longitude: "-0854534" }, "America/Kentucky/Monticello": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0400\r
TZNAME:EDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0500\r
TZNAME:EST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0364947", longitude: "-0845057" }, "America/Knox_IN": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0500\r
TZNAME:CDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0600\r
TZNAME:CST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`] }, "America/Kralendijk": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0400\r
TZNAME:AST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "America/La_Paz": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0400\r
TZNAME:-04\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0163000", longitude: "-0680900" }, "America/Lima": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0500\r
TZNAME:-05\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0120300", longitude: "-0770300" }, "America/Los_Angeles": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0800\r
TZOFFSETTO:-0700\r
TZNAME:PDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0700\r
TZOFFSETTO:-0800\r
TZNAME:PST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0340308", longitude: "-1181434" }, "America/Louisville": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0400\r
TZNAME:EDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0500\r
TZNAME:EST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`] }, "America/Lower_Princes": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0400\r
TZNAME:AST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "America/Maceio": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0094000", longitude: "-0354300" }, "America/Managua": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0600\r
TZNAME:CST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0120900", longitude: "-0861700" }, "America/Manaus": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0400\r
TZNAME:-04\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0030800", longitude: "-0600100" }, "America/Marigot": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0400\r
TZNAME:AST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "America/Martinique": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0400\r
TZNAME:AST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0143600", longitude: "-0610500" }, "America/Matamoros": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0500\r
TZNAME:CDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0600\r
TZNAME:CST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0255000", longitude: "-0973000" }, "America/Mazatlan": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0700\r
TZOFFSETTO:-0700\r
TZNAME:MST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0231300", longitude: "-1062500" }, "America/Mendoza": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "America/Menominee": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0500\r
TZNAME:CDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0600\r
TZNAME:CST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0450628", longitude: "-0873651" }, "America/Merida": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0600\r
TZNAME:CST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0205800", longitude: "-0893700" }, "America/Metlakatla": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0900\r
TZOFFSETTO:-0800\r
TZNAME:AKDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0800\r
TZOFFSETTO:-0900\r
TZNAME:AKST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0550737", longitude: "-1313435" }, "America/Mexico_City": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0600\r
TZNAME:CST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0192400", longitude: "-0990900" }, "America/Miquelon": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0200\r
TZNAME:-02\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0200\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0470300", longitude: "-0562000" }, "America/Moncton": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0300\r
TZNAME:ADT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0400\r
TZNAME:AST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0460600", longitude: "-0644700" }, "America/Monterrey": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0600\r
TZNAME:CST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0254000", longitude: "-1001900" }, "America/Montevideo": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0345433", longitude: "-0561245" }, "America/Montreal": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0400\r
TZNAME:EDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0500\r
TZNAME:EST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`] }, "America/Montserrat": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0400\r
TZNAME:AST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "America/Nassau": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0400\r
TZNAME:EDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0500\r
TZNAME:EST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`] }, "America/New_York": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0400\r
TZNAME:EDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0500\r
TZNAME:EST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0404251", longitude: "-0740023" }, "America/Nipigon": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0400\r
TZNAME:EDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0500\r
TZNAME:EST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`] }, "America/Nome": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0900\r
TZOFFSETTO:-0800\r
TZNAME:AKDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0800\r
TZOFFSETTO:-0900\r
TZNAME:AKST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0643004", longitude: "-1652423" }, "America/Noronha": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0200\r
TZOFFSETTO:-0200\r
TZNAME:-02\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0035100", longitude: "-0322500" }, "America/North_Dakota/Beulah": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0500\r
TZNAME:CDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0600\r
TZNAME:CST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0471551", longitude: "-1014640" }, "America/North_Dakota/Center": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0500\r
TZNAME:CDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0600\r
TZNAME:CST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0470659", longitude: "-1011757" }, "America/North_Dakota/New_Salem": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0500\r
TZNAME:CDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0600\r
TZNAME:CST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0465042", longitude: "-1012439" }, "America/Nuuk": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0200\r
TZOFFSETTO:-0100\r
TZNAME:-01\r
DTSTART:19700328T230000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SA\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0100\r
TZOFFSETTO:-0200\r
TZNAME:-02\r
DTSTART:19701025T000000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`], latitude: "+0641100", longitude: "-0514400" }, "America/Ojinaga": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0500\r
TZNAME:CDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0600\r
TZNAME:CST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0293400", longitude: "-1042500" }, "America/Panama": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0500\r
TZNAME:EST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0085800", longitude: "-0793200" }, "America/Pangnirtung": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0400\r
TZNAME:EDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0500\r
TZNAME:EST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`] }, "America/Paramaribo": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0055000", longitude: "-0551000" }, "America/Phoenix": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0700\r
TZOFFSETTO:-0700\r
TZNAME:MST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0332654", longitude: "-1120424" }, "America/Port-au-Prince": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0400\r
TZNAME:EDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0500\r
TZNAME:EST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0183200", longitude: "-0722000" }, "America/Port_of_Spain": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0400\r
TZNAME:AST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "America/Porto_Acre": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0500\r
TZNAME:-05\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "America/Porto_Velho": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0400\r
TZNAME:-04\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0084600", longitude: "-0635400" }, "America/Puerto_Rico": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0400\r
TZNAME:AST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0182806", longitude: "-0660622" }, "America/Punta_Arenas": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0530900", longitude: "-0705500" }, "America/Rainy_River": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0500\r
TZNAME:CDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0600\r
TZNAME:CST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`] }, "America/Rankin_Inlet": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0500\r
TZNAME:CDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0600\r
TZNAME:CST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0624900", longitude: "-0920459" }, "America/Recife": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0080300", longitude: "-0345400" }, "America/Regina": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0600\r
TZNAME:CST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0502400", longitude: "-1043900" }, "America/Resolute": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0600\r
TZNAME:CST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`, `BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0500\r
TZNAME:CDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`], latitude: "+0744144", longitude: "-0944945" }, "America/Rio_Branco": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0500\r
TZNAME:-05\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0095800", longitude: "-0674800" }, "America/Rosario": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "America/Santa_Isabel": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0800\r
TZOFFSETTO:-0700\r
TZNAME:PDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0700\r
TZOFFSETTO:-0800\r
TZNAME:PST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`] }, "America/Santarem": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0022600", longitude: "-0545200" }, "America/Santiago": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0400\r
TZNAME:-04\r
DTSTART:19700405T000000\r
RRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r
END:STANDARD`, `BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700906T000000\r
RRULE:FREQ=YEARLY;BYMONTH=9;BYDAY=1SU\r
END:DAYLIGHT`], latitude: "-0332700", longitude: "-0704000" }, "America/Santo_Domingo": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0400\r
TZNAME:AST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0182800", longitude: "-0695400" }, "America/Sao_Paulo": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0233200", longitude: "-0463700" }, "America/Scoresbysund": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0100\r
TZOFFSETTO:-0200\r
TZNAME:-02\r
DTSTART:19701025T000000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`, `BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0200\r
TZOFFSETTO:-0100\r
TZNAME:-01\r
DTSTART:19700328T230000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SA\r
END:DAYLIGHT`], latitude: "+0702900", longitude: "-0215800" }, "America/Shiprock": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0700\r
TZOFFSETTO:-0600\r
TZNAME:MDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0700\r
TZNAME:MST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`] }, "America/Sitka": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0900\r
TZOFFSETTO:-0800\r
TZNAME:AKDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0800\r
TZOFFSETTO:-0900\r
TZNAME:AKST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0571035", longitude: "-1351807" }, "America/St_Barthelemy": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0400\r
TZNAME:AST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "America/St_Johns": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0230\r
TZOFFSETTO:-0330\r
TZNAME:NST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`, `BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0330\r
TZOFFSETTO:-0230\r
TZNAME:NDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`], latitude: "+0473400", longitude: "-0524300" }, "America/St_Kitts": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0400\r
TZNAME:AST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "America/St_Lucia": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0400\r
TZNAME:AST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "America/St_Thomas": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0400\r
TZNAME:AST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "America/St_Vincent": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0400\r
TZNAME:AST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "America/Swift_Current": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0600\r
TZNAME:CST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0501700", longitude: "-1075000" }, "America/Tegucigalpa": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0600\r
TZNAME:CST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0140600", longitude: "-0871300" }, "America/Thule": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0300\r
TZNAME:ADT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0400\r
TZNAME:AST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0763400", longitude: "-0684700" }, "America/Thunder_Bay": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0400\r
TZNAME:EDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0500\r
TZNAME:EST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`] }, "America/Tijuana": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0800\r
TZOFFSETTO:-0700\r
TZNAME:PDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0700\r
TZOFFSETTO:-0800\r
TZNAME:PST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0323200", longitude: "-1170100" }, "America/Toronto": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0400\r
TZNAME:EDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0500\r
TZNAME:EST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0433900", longitude: "-0792300" }, "America/Tortola": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0400\r
TZNAME:AST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "America/Vancouver": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0800\r
TZOFFSETTO:-0700\r
TZNAME:PDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0700\r
TZOFFSETTO:-0800\r
TZNAME:PST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0491600", longitude: "-1230700" }, "America/Virgin": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0400\r
TZNAME:AST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "America/Whitehorse": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0700\r
TZOFFSETTO:-0700\r
TZNAME:MST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0604300", longitude: "-1350300" }, "America/Winnipeg": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0500\r
TZNAME:CDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0600\r
TZNAME:CST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0495300", longitude: "-0970900" }, "America/Yakutat": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0900\r
TZOFFSETTO:-0800\r
TZNAME:AKDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0800\r
TZOFFSETTO:-0900\r
TZNAME:AKST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0593249", longitude: "-1394338" }, "America/Yellowknife": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0700\r
TZOFFSETTO:-0600\r
TZNAME:MDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0700\r
TZNAME:MST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`] }, "Antarctica/Casey": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0800\r
TZOFFSETTO:+0800\r
TZNAME:+08\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0661700", longitude: "+1103100" }, "Antarctica/Davis": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0700\r
TZOFFSETTO:+0700\r
TZNAME:+07\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0683500", longitude: "+0775800" }, "Antarctica/DumontDUrville": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1000\r
TZOFFSETTO:+1000\r
TZNAME:+10\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Antarctica/Macquarie": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1100\r
TZOFFSETTO:+1000\r
TZNAME:AEST\r
DTSTART:19700405T030000\r
RRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r
END:STANDARD`, `BEGIN:DAYLIGHT\r
TZOFFSETFROM:+1000\r
TZOFFSETTO:+1100\r
TZNAME:AEDT\r
DTSTART:19701004T020000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=1SU\r
END:DAYLIGHT`], latitude: "-0543000", longitude: "+1585700" }, "Antarctica/Mawson": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0500\r
TZOFFSETTO:+0500\r
TZNAME:+05\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0673600", longitude: "+0625300" }, "Antarctica/McMurdo": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+1200\r
TZOFFSETTO:+1300\r
TZNAME:NZDT\r
DTSTART:19700927T020000\r
RRULE:FREQ=YEARLY;BYMONTH=9;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+1300\r
TZOFFSETTO:+1200\r
TZNAME:NZST\r
DTSTART:19700405T030000\r
RRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r
END:STANDARD`] }, "Antarctica/Palmer": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0644800", longitude: "-0640600" }, "Antarctica/Rothera": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0673400", longitude: "-0680800" }, "Antarctica/South_Pole": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+1200\r
TZOFFSETTO:+1300\r
TZNAME:NZDT\r
DTSTART:19700927T020000\r
RRULE:FREQ=YEARLY;BYMONTH=9;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+1300\r
TZOFFSETTO:+1200\r
TZNAME:NZST\r
DTSTART:19700405T030000\r
RRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r
END:STANDARD`] }, "Antarctica/Syowa": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0300\r
TZNAME:+03\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Antarctica/Troll": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0000\r
TZOFFSETTO:+0200\r
TZNAME:+02\r
DTSTART:19700329T010000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0000\r
TZNAME:+00\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`], latitude: "-0720041", longitude: "+0023206" }, "Antarctica/Vostok": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0500\r
TZOFFSETTO:+0500\r
TZNAME:+05\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0782400", longitude: "+1065400" }, "Arctic/Longyearbyen": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0200\r
TZNAME:CEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`] }, "Asia/Aden": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0300\r
TZNAME:+03\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Asia/Almaty": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0500\r
TZOFFSETTO:+0500\r
TZNAME:+05\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0431500", longitude: "+0765700" }, "Asia/Amman": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0300\r
TZNAME:+03\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0315700", longitude: "+0355600" }, "Asia/Anadyr": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1200\r
TZOFFSETTO:+1200\r
TZNAME:+12\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0644500", longitude: "+1772900" }, "Asia/Aqtau": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0500\r
TZOFFSETTO:+0500\r
TZNAME:+05\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0443100", longitude: "+0501600" }, "Asia/Aqtobe": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0500\r
TZOFFSETTO:+0500\r
TZNAME:+05\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0501700", longitude: "+0571000" }, "Asia/Ashgabat": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0500\r
TZOFFSETTO:+0500\r
TZNAME:+05\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0375700", longitude: "+0582300" }, "Asia/Ashkhabad": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0500\r
TZOFFSETTO:+0500\r
TZNAME:+05\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Asia/Atyrau": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0500\r
TZOFFSETTO:+0500\r
TZNAME:+05\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0470700", longitude: "+0515600" }, "Asia/Baghdad": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0300\r
TZNAME:+03\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0332100", longitude: "+0442500" }, "Asia/Bahrain": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0300\r
TZNAME:+03\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Asia/Baku": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0400\r
TZOFFSETTO:+0400\r
TZNAME:+04\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0402300", longitude: "+0495100" }, "Asia/Bangkok": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0700\r
TZOFFSETTO:+0700\r
TZNAME:+07\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0134500", longitude: "+1003100" }, "Asia/Barnaul": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0700\r
TZOFFSETTO:+0700\r
TZNAME:+07\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0532200", longitude: "+0834500" }, "Asia/Beirut": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0300\r
TZNAME:EEST\r
DTSTART:19700329T000000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0200\r
TZNAME:EET\r
DTSTART:19701025T000000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`], latitude: "+0335300", longitude: "+0353000" }, "Asia/Bishkek": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0600\r
TZOFFSETTO:+0600\r
TZNAME:+06\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0425400", longitude: "+0743600" }, "Asia/Brunei": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0800\r
TZOFFSETTO:+0800\r
TZNAME:+08\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Asia/Calcutta": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0530\r
TZOFFSETTO:+0530\r
TZNAME:IST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Asia/Chita": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0900\r
TZOFFSETTO:+0900\r
TZNAME:+09\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0520300", longitude: "+1132800" }, "Asia/Choibalsan": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0800\r
TZOFFSETTO:+0800\r
TZNAME:+08\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0480400", longitude: "+1143000" }, "Asia/Chongqing": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0800\r
TZOFFSETTO:+0800\r
TZNAME:CST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Asia/Chungking": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0800\r
TZOFFSETTO:+0800\r
TZNAME:CST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Asia/Colombo": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0530\r
TZOFFSETTO:+0530\r
TZNAME:+0530\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0065600", longitude: "+0795100" }, "Asia/Dacca": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0600\r
TZOFFSETTO:+0600\r
TZNAME:+06\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Asia/Damascus": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0300\r
TZNAME:+03\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0333000", longitude: "+0361800" }, "Asia/Dhaka": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0600\r
TZOFFSETTO:+0600\r
TZNAME:+06\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0234300", longitude: "+0902500" }, "Asia/Dili": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0900\r
TZOFFSETTO:+0900\r
TZNAME:+09\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0083300", longitude: "+1253500" }, "Asia/Dubai": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0400\r
TZOFFSETTO:+0400\r
TZNAME:+04\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0251800", longitude: "+0551800" }, "Asia/Dushanbe": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0500\r
TZOFFSETTO:+0500\r
TZNAME:+05\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0383500", longitude: "+0684800" }, "Asia/Famagusta": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0300\r
TZNAME:EEST\r
DTSTART:19700329T030000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0200\r
TZNAME:EET\r
DTSTART:19701025T040000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`], latitude: "+0350700", longitude: "+0335700" }, "Asia/Gaza": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0300\r
TZNAME:EEST\r
DTSTART:19700328T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SA\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0200\r
TZNAME:EET\r
DTSTART:19701031T020000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SA\r
END:STANDARD`], latitude: "+0313000", longitude: "+0342800" }, "Asia/Harbin": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0800\r
TZOFFSETTO:+0800\r
TZNAME:CST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Asia/Hebron": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0300\r
TZNAME:EEST\r
DTSTART:19700328T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SA\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0200\r
TZNAME:EET\r
DTSTART:19701031T020000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SA\r
END:STANDARD`], latitude: "+0313200", longitude: "+0350542" }, "Asia/Ho_Chi_Minh": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0700\r
TZOFFSETTO:+0700\r
TZNAME:+07\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0104500", longitude: "+1064000" }, "Asia/Hong_Kong": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0800\r
TZOFFSETTO:+0800\r
TZNAME:HKT\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0221700", longitude: "+1140900" }, "Asia/Hovd": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0700\r
TZOFFSETTO:+0700\r
TZNAME:+07\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0480100", longitude: "+0913900" }, "Asia/Irkutsk": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0800\r
TZOFFSETTO:+0800\r
TZNAME:+08\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0521600", longitude: "+1042000" }, "Asia/Istanbul": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0300\r
TZNAME:+03\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Asia/Jakarta": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0700\r
TZOFFSETTO:+0700\r
TZNAME:WIB\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0061000", longitude: "+1064800" }, "Asia/Jayapura": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0900\r
TZOFFSETTO:+0900\r
TZNAME:WIT\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0023200", longitude: "+1404200" }, "Asia/Jerusalem": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0300\r
TZNAME:IDT\r
DTSTART:19700327T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1FR\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0200\r
TZNAME:IST\r
DTSTART:19701025T020000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`], latitude: "+0314650", longitude: "+0351326" }, "Asia/Kabul": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0430\r
TZOFFSETTO:+0430\r
TZNAME:+0430\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0343100", longitude: "+0691200" }, "Asia/Kamchatka": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1200\r
TZOFFSETTO:+1200\r
TZNAME:+12\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0530100", longitude: "+1583900" }, "Asia/Karachi": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0500\r
TZOFFSETTO:+0500\r
TZNAME:PKT\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0245200", longitude: "+0670300" }, "Asia/Kashgar": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0600\r
TZOFFSETTO:+0600\r
TZNAME:+06\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Asia/Kathmandu": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0545\r
TZOFFSETTO:+0545\r
TZNAME:+0545\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0274300", longitude: "+0851900" }, "Asia/Katmandu": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0545\r
TZOFFSETTO:+0545\r
TZNAME:+0545\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Asia/Khandyga": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0900\r
TZOFFSETTO:+0900\r
TZNAME:+09\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0623923", longitude: "+1353314" }, "Asia/Kolkata": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0530\r
TZOFFSETTO:+0530\r
TZNAME:IST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0223200", longitude: "+0882200" }, "Asia/Krasnoyarsk": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0700\r
TZOFFSETTO:+0700\r
TZNAME:+07\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0560100", longitude: "+0925000" }, "Asia/Kuala_Lumpur": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0800\r
TZOFFSETTO:+0800\r
TZNAME:+08\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Asia/Kuching": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0800\r
TZOFFSETTO:+0800\r
TZNAME:+08\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0013300", longitude: "+1102000" }, "Asia/Kuwait": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0300\r
TZNAME:+03\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Asia/Macao": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0800\r
TZOFFSETTO:+0800\r
TZNAME:CST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Asia/Macau": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0800\r
TZOFFSETTO:+0800\r
TZNAME:CST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0221150", longitude: "+1133230" }, "Asia/Magadan": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1100\r
TZOFFSETTO:+1100\r
TZNAME:+11\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0593400", longitude: "+1504800" }, "Asia/Makassar": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0800\r
TZOFFSETTO:+0800\r
TZNAME:WITA\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0050700", longitude: "+1192400" }, "Asia/Manila": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0800\r
TZOFFSETTO:+0800\r
TZNAME:PST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0143500", longitude: "+1210000" }, "Asia/Muscat": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0400\r
TZOFFSETTO:+0400\r
TZNAME:+04\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Asia/Nicosia": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0200\r
TZNAME:EET\r
DTSTART:19701025T040000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`, `BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0300\r
TZNAME:EEST\r
DTSTART:19700329T030000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`], latitude: "+0351000", longitude: "+0332200" }, "Asia/Novokuznetsk": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0700\r
TZOFFSETTO:+0700\r
TZNAME:+07\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0534500", longitude: "+0870700" }, "Asia/Novosibirsk": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0700\r
TZOFFSETTO:+0700\r
TZNAME:+07\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0550200", longitude: "+0825500" }, "Asia/Omsk": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0600\r
TZOFFSETTO:+0600\r
TZNAME:+06\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0550000", longitude: "+0732400" }, "Asia/Oral": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0500\r
TZOFFSETTO:+0500\r
TZNAME:+05\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0511300", longitude: "+0512100" }, "Asia/Phnom_Penh": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0700\r
TZOFFSETTO:+0700\r
TZNAME:+07\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Asia/Pontianak": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0700\r
TZOFFSETTO:+0700\r
TZNAME:WIB\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0000200", longitude: "+1092000" }, "Asia/Pyongyang": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0900\r
TZOFFSETTO:+0900\r
TZNAME:KST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0390100", longitude: "+1254500" }, "Asia/Qatar": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0300\r
TZNAME:+03\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0251700", longitude: "+0513200" }, "Asia/Qostanay": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0500\r
TZOFFSETTO:+0500\r
TZNAME:+05\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0531200", longitude: "+0633700" }, "Asia/Qyzylorda": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0500\r
TZOFFSETTO:+0500\r
TZNAME:+05\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0444800", longitude: "+0652800" }, "Asia/Rangoon": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0630\r
TZOFFSETTO:+0630\r
TZNAME:+0630\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Asia/Riyadh": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0300\r
TZNAME:+03\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0243800", longitude: "+0464300" }, "Asia/Saigon": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0700\r
TZOFFSETTO:+0700\r
TZNAME:+07\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Asia/Sakhalin": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1100\r
TZOFFSETTO:+1100\r
TZNAME:+11\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0465800", longitude: "+1424200" }, "Asia/Samarkand": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0500\r
TZOFFSETTO:+0500\r
TZNAME:+05\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0394000", longitude: "+0664800" }, "Asia/Seoul": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0900\r
TZOFFSETTO:+0900\r
TZNAME:KST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0373300", longitude: "+1265800" }, "Asia/Shanghai": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0800\r
TZOFFSETTO:+0800\r
TZNAME:CST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0311400", longitude: "+1212800" }, "Asia/Singapore": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0800\r
TZOFFSETTO:+0800\r
TZNAME:+08\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0011700", longitude: "+1035100" }, "Asia/Srednekolymsk": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1100\r
TZOFFSETTO:+1100\r
TZNAME:+11\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0672800", longitude: "+1534300" }, "Asia/Taipei": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0800\r
TZOFFSETTO:+0800\r
TZNAME:CST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0250300", longitude: "+1213000" }, "Asia/Tashkent": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0500\r
TZOFFSETTO:+0500\r
TZNAME:+05\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0412000", longitude: "+0691800" }, "Asia/Tbilisi": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0400\r
TZOFFSETTO:+0400\r
TZNAME:+04\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0414300", longitude: "+0444900" }, "Asia/Tehran": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0330\r
TZOFFSETTO:+0330\r
TZNAME:+0330\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0354000", longitude: "+0512600" }, "Asia/Tel_Aviv": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0300\r
TZNAME:IDT\r
DTSTART:19700327T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1FR\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0200\r
TZNAME:IST\r
DTSTART:19701025T020000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`] }, "Asia/Thimbu": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0600\r
TZOFFSETTO:+0600\r
TZNAME:+06\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Asia/Thimphu": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0600\r
TZOFFSETTO:+0600\r
TZNAME:+06\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0272800", longitude: "+0893900" }, "Asia/Tokyo": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0900\r
TZOFFSETTO:+0900\r
TZNAME:JST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0353916", longitude: "+1394441" }, "Asia/Tomsk": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0700\r
TZOFFSETTO:+0700\r
TZNAME:+07\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0563000", longitude: "+0845800" }, "Asia/Ujung_Pandang": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0800\r
TZOFFSETTO:+0800\r
TZNAME:WITA\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Asia/Ulaanbaatar": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0800\r
TZOFFSETTO:+0800\r
TZNAME:+08\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0475500", longitude: "+1065300" }, "Asia/Ulan_Bator": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0800\r
TZOFFSETTO:+0800\r
TZNAME:+08\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Asia/Urumqi": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0600\r
TZOFFSETTO:+0600\r
TZNAME:+06\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0434800", longitude: "+0873500" }, "Asia/Ust-Nera": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1000\r
TZOFFSETTO:+1000\r
TZNAME:+10\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0643337", longitude: "+1431336" }, "Asia/Vientiane": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0700\r
TZOFFSETTO:+0700\r
TZNAME:+07\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Asia/Vladivostok": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1000\r
TZOFFSETTO:+1000\r
TZNAME:+10\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0431000", longitude: "+1315600" }, "Asia/Yakutsk": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0900\r
TZOFFSETTO:+0900\r
TZNAME:+09\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0620000", longitude: "+1294000" }, "Asia/Yangon": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0630\r
TZOFFSETTO:+0630\r
TZNAME:+0630\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0164700", longitude: "+0961000" }, "Asia/Yekaterinburg": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0500\r
TZOFFSETTO:+0500\r
TZNAME:+05\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0565100", longitude: "+0603600" }, "Asia/Yerevan": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0400\r
TZOFFSETTO:+0400\r
TZNAME:+04\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0401100", longitude: "+0443000" }, "Atlantic/Azores": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0100\r
TZOFFSETTO:+0000\r
TZNAME:+00\r
DTSTART:19700329T000000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0000\r
TZOFFSETTO:-0100\r
TZNAME:-01\r
DTSTART:19701025T010000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`], latitude: "+0374400", longitude: "-0254000" }, "Atlantic/Bermuda": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0300\r
TZNAME:ADT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0400\r
TZNAME:AST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`], latitude: "+0321700", longitude: "-0644600" }, "Atlantic/Canary": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0000\r
TZOFFSETTO:+0100\r
TZNAME:WEST\r
DTSTART:19700329T010000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0000\r
TZNAME:WET\r
DTSTART:19701025T020000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`], latitude: "+0280600", longitude: "-0152400" }, "Atlantic/Cape_Verde": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0100\r
TZOFFSETTO:-0100\r
TZNAME:-01\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0145500", longitude: "-0233100" }, "Atlantic/Faeroe": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0000\r
TZOFFSETTO:+0100\r
TZNAME:WEST\r
DTSTART:19700329T010000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0000\r
TZNAME:WET\r
DTSTART:19701025T020000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`] }, "Atlantic/Faroe": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0000\r
TZOFFSETTO:+0100\r
TZNAME:WEST\r
DTSTART:19700329T010000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0000\r
TZNAME:WET\r
DTSTART:19701025T020000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`], latitude: "+0620100", longitude: "-0064600" }, "Atlantic/Jan_Mayen": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0200\r
TZNAME:CEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`] }, "Atlantic/Madeira": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0000\r
TZOFFSETTO:+0100\r
TZNAME:WEST\r
DTSTART:19700329T010000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0000\r
TZNAME:WET\r
DTSTART:19701025T020000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`], latitude: "+0323800", longitude: "-0165400" }, "Atlantic/Reykjavik": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0000\r
TZOFFSETTO:+0000\r
TZNAME:GMT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Atlantic/South_Georgia": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0200\r
TZOFFSETTO:-0200\r
TZNAME:-02\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0541600", longitude: "-0363200" }, "Atlantic/St_Helena": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0000\r
TZOFFSETTO:+0000\r
TZNAME:GMT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Atlantic/Stanley": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0514200", longitude: "-0575100" }, "Australia/ACT": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1100\r
TZOFFSETTO:+1000\r
TZNAME:AEST\r
DTSTART:19700405T030000\r
RRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r
END:STANDARD`, `BEGIN:DAYLIGHT\r
TZOFFSETFROM:+1000\r
TZOFFSETTO:+1100\r
TZNAME:AEDT\r
DTSTART:19701004T020000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=1SU\r
END:DAYLIGHT`] }, "Australia/Adelaide": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1030\r
TZOFFSETTO:+0930\r
TZNAME:ACST\r
DTSTART:19700405T030000\r
RRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r
END:STANDARD`, `BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0930\r
TZOFFSETTO:+1030\r
TZNAME:ACDT\r
DTSTART:19701004T020000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=1SU\r
END:DAYLIGHT`], latitude: "-0345500", longitude: "+1383500" }, "Australia/Brisbane": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1000\r
TZOFFSETTO:+1000\r
TZNAME:AEST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0272800", longitude: "+1530200" }, "Australia/Broken_Hill": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1030\r
TZOFFSETTO:+0930\r
TZNAME:ACST\r
DTSTART:19700405T030000\r
RRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r
END:STANDARD`, `BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0930\r
TZOFFSETTO:+1030\r
TZNAME:ACDT\r
DTSTART:19701004T020000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=1SU\r
END:DAYLIGHT`], latitude: "-0315700", longitude: "+1412700" }, "Australia/Canberra": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1100\r
TZOFFSETTO:+1000\r
TZNAME:AEST\r
DTSTART:19700405T030000\r
RRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r
END:STANDARD`, `BEGIN:DAYLIGHT\r
TZOFFSETFROM:+1000\r
TZOFFSETTO:+1100\r
TZNAME:AEDT\r
DTSTART:19701004T020000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=1SU\r
END:DAYLIGHT`] }, "Australia/Currie": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+1000\r
TZOFFSETTO:+1100\r
TZNAME:AEDT\r
DTSTART:19701004T020000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+1100\r
TZOFFSETTO:+1000\r
TZNAME:AEST\r
DTSTART:19700405T030000\r
RRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r
END:STANDARD`] }, "Australia/Darwin": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0930\r
TZOFFSETTO:+0930\r
TZNAME:ACST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0122800", longitude: "+1305000" }, "Australia/Eucla": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0845\r
TZOFFSETTO:+0845\r
TZNAME:+0845\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0314300", longitude: "+1285200" }, "Australia/Hobart": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+1000\r
TZOFFSETTO:+1100\r
TZNAME:AEDT\r
DTSTART:19701004T020000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+1100\r
TZOFFSETTO:+1000\r
TZNAME:AEST\r
DTSTART:19700405T030000\r
RRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r
END:STANDARD`], latitude: "-0425300", longitude: "+1471900" }, "Australia/LHI": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1100\r
TZOFFSETTO:+1030\r
TZNAME:+1030\r
DTSTART:19700405T020000\r
RRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r
END:STANDARD`, `BEGIN:DAYLIGHT\r
TZOFFSETFROM:+1030\r
TZOFFSETTO:+1100\r
TZNAME:+11\r
DTSTART:19701004T020000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=1SU\r
END:DAYLIGHT`] }, "Australia/Lindeman": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1000\r
TZOFFSETTO:+1000\r
TZNAME:AEST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0201600", longitude: "+1490000" }, "Australia/Lord_Howe": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1100\r
TZOFFSETTO:+1030\r
TZNAME:+1030\r
DTSTART:19700405T020000\r
RRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r
END:STANDARD`, `BEGIN:DAYLIGHT\r
TZOFFSETFROM:+1030\r
TZOFFSETTO:+1100\r
TZNAME:+11\r
DTSTART:19701004T020000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=1SU\r
END:DAYLIGHT`], latitude: "-0313300", longitude: "+1590500" }, "Australia/Melbourne": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1100\r
TZOFFSETTO:+1000\r
TZNAME:AEST\r
DTSTART:19700405T030000\r
RRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r
END:STANDARD`, `BEGIN:DAYLIGHT\r
TZOFFSETFROM:+1000\r
TZOFFSETTO:+1100\r
TZNAME:AEDT\r
DTSTART:19701004T020000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=1SU\r
END:DAYLIGHT`], latitude: "-0374900", longitude: "+1445800" }, "Australia/NSW": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1100\r
TZOFFSETTO:+1000\r
TZNAME:AEST\r
DTSTART:19700405T030000\r
RRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r
END:STANDARD`, `BEGIN:DAYLIGHT\r
TZOFFSETFROM:+1000\r
TZOFFSETTO:+1100\r
TZNAME:AEDT\r
DTSTART:19701004T020000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=1SU\r
END:DAYLIGHT`] }, "Australia/North": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0930\r
TZOFFSETTO:+0930\r
TZNAME:ACST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Australia/Perth": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0800\r
TZOFFSETTO:+0800\r
TZNAME:AWST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0315700", longitude: "+1155100" }, "Australia/Queensland": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1000\r
TZOFFSETTO:+1000\r
TZNAME:AEST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Australia/South": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1030\r
TZOFFSETTO:+0930\r
TZNAME:ACST\r
DTSTART:19700405T030000\r
RRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r
END:STANDARD`, `BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0930\r
TZOFFSETTO:+1030\r
TZNAME:ACDT\r
DTSTART:19701004T020000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=1SU\r
END:DAYLIGHT`] }, "Australia/Sydney": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1100\r
TZOFFSETTO:+1000\r
TZNAME:AEST\r
DTSTART:19700405T030000\r
RRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r
END:STANDARD`, `BEGIN:DAYLIGHT\r
TZOFFSETFROM:+1000\r
TZOFFSETTO:+1100\r
TZNAME:AEDT\r
DTSTART:19701004T020000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=1SU\r
END:DAYLIGHT`], latitude: "-0335200", longitude: "+1511300" }, "Australia/Tasmania": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+1000\r
TZOFFSETTO:+1100\r
TZNAME:AEDT\r
DTSTART:19701004T020000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+1100\r
TZOFFSETTO:+1000\r
TZNAME:AEST\r
DTSTART:19700405T030000\r
RRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r
END:STANDARD`] }, "Australia/Victoria": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1100\r
TZOFFSETTO:+1000\r
TZNAME:AEST\r
DTSTART:19700405T030000\r
RRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r
END:STANDARD`, `BEGIN:DAYLIGHT\r
TZOFFSETFROM:+1000\r
TZOFFSETTO:+1100\r
TZNAME:AEDT\r
DTSTART:19701004T020000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=1SU\r
END:DAYLIGHT`] }, "Australia/West": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0800\r
TZOFFSETTO:+0800\r
TZNAME:AWST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Australia/Yancowinna": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1030\r
TZOFFSETTO:+0930\r
TZNAME:ACST\r
DTSTART:19700405T030000\r
RRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r
END:STANDARD`, `BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0930\r
TZOFFSETTO:+1030\r
TZNAME:ACDT\r
DTSTART:19701004T020000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=1SU\r
END:DAYLIGHT`] }, "Brazil/Acre": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0500\r
TZNAME:-05\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Brazil/DeNoronha": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0200\r
TZOFFSETTO:-0200\r
TZNAME:-02\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Brazil/East": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Brazil/West": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0400\r
TZNAME:-04\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Canada/Atlantic": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0300\r
TZNAME:ADT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0400\r
TZNAME:AST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`] }, "Canada/Central": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0500\r
TZNAME:CDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0600\r
TZNAME:CST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`] }, "Canada/Eastern": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0400\r
TZNAME:EDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0500\r
TZNAME:EST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`] }, "Canada/Mountain": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0700\r
TZOFFSETTO:-0600\r
TZNAME:MDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0700\r
TZNAME:MST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`] }, "Canada/Newfoundland": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0230\r
TZOFFSETTO:-0330\r
TZNAME:NST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`, `BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0330\r
TZOFFSETTO:-0230\r
TZNAME:NDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`] }, "Canada/Pacific": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0800\r
TZOFFSETTO:-0700\r
TZNAME:PDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0700\r
TZOFFSETTO:-0800\r
TZNAME:PST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`] }, "Canada/Saskatchewan": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0600\r
TZNAME:CST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Canada/Yukon": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0700\r
TZOFFSETTO:-0700\r
TZNAME:MST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Chile/Continental": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0300\r
TZOFFSETTO:-0400\r
TZNAME:-04\r
DTSTART:19700405T000000\r
RRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r
END:STANDARD`, `BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0300\r
TZNAME:-03\r
DTSTART:19700906T000000\r
RRULE:FREQ=YEARLY;BYMONTH=9;BYDAY=1SU\r
END:DAYLIGHT`] }, "Chile/EasterIsland": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0600\r
TZNAME:-06\r
DTSTART:19700404T220000\r
RRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SA\r
END:STANDARD`, `BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0500\r
TZNAME:-05\r
DTSTART:19700905T220000\r
RRULE:FREQ=YEARLY;BYMONTH=9;BYDAY=1SA\r
END:DAYLIGHT`] }, "Europe/Amsterdam": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0200\r
TZNAME:CEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`] }, "Europe/Andorra": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0200\r
TZNAME:CEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`], latitude: "+0423000", longitude: "+0013100" }, "Europe/Astrakhan": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0400\r
TZOFFSETTO:+0400\r
TZNAME:+04\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0462100", longitude: "+0480300" }, "Europe/Athens": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0300\r
TZNAME:EEST\r
DTSTART:19700329T030000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0200\r
TZNAME:EET\r
DTSTART:19701025T040000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`], latitude: "+0375800", longitude: "+0234300" }, "Europe/Belfast": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0000\r
TZOFFSETTO:+0100\r
TZNAME:BST\r
DTSTART:19700329T010000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0000\r
TZNAME:GMT\r
DTSTART:19701025T020000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`] }, "Europe/Belgrade": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0200\r
TZNAME:CEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`], latitude: "+0445000", longitude: "+0203000" }, "Europe/Berlin": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0200\r
TZNAME:CEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`], latitude: "+0523000", longitude: "+0132200" }, "Europe/Bratislava": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0200\r
TZNAME:CEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`] }, "Europe/Brussels": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0200\r
TZNAME:CEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`], latitude: "+0505000", longitude: "+0042000" }, "Europe/Bucharest": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0300\r
TZNAME:EEST\r
DTSTART:19700329T030000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0200\r
TZNAME:EET\r
DTSTART:19701025T040000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`], latitude: "+0442600", longitude: "+0260600" }, "Europe/Budapest": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0200\r
TZNAME:CEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`], latitude: "+0473000", longitude: "+0190500" }, "Europe/Busingen": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0200\r
TZNAME:CEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`] }, "Europe/Chisinau": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0300\r
TZNAME:EEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0200\r
TZNAME:EET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`], latitude: "+0470000", longitude: "+0285000" }, "Europe/Copenhagen": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0200\r
TZNAME:CEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`] }, "Europe/Dublin": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0000\r
TZOFFSETTO:+0100\r
TZNAME:IST\r
DTSTART:19700329T010000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:STANDARD`, `BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0000\r
TZNAME:GMT\r
DTSTART:19701025T020000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:DAYLIGHT`], latitude: "+0532000", longitude: "-0061500" }, "Europe/Gibraltar": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0200\r
TZNAME:CEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`], latitude: "+0360800", longitude: "-0052100" }, "Europe/Guernsey": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0000\r
TZOFFSETTO:+0100\r
TZNAME:BST\r
DTSTART:19700329T010000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0000\r
TZNAME:GMT\r
DTSTART:19701025T020000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`] }, "Europe/Helsinki": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0300\r
TZNAME:EEST\r
DTSTART:19700329T030000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0200\r
TZNAME:EET\r
DTSTART:19701025T040000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`], latitude: "+0601000", longitude: "+0245800" }, "Europe/Isle_of_Man": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0000\r
TZOFFSETTO:+0100\r
TZNAME:BST\r
DTSTART:19700329T010000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0000\r
TZNAME:GMT\r
DTSTART:19701025T020000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`] }, "Europe/Istanbul": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0300\r
TZNAME:+03\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0410100", longitude: "+0285800" }, "Europe/Jersey": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0000\r
TZOFFSETTO:+0100\r
TZNAME:BST\r
DTSTART:19700329T010000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0000\r
TZNAME:GMT\r
DTSTART:19701025T020000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`] }, "Europe/Kaliningrad": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0200\r
TZNAME:EET\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0544300", longitude: "+0203000" }, "Europe/Kiev": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0200\r
TZNAME:EET\r
DTSTART:19701025T040000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`, `BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0300\r
TZNAME:EEST\r
DTSTART:19700329T030000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`] }, "Europe/Kirov": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0300\r
TZNAME:MSK\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0583600", longitude: "+0493900" }, "Europe/Kyiv": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0200\r
TZNAME:EET\r
DTSTART:19701025T040000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`, `BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0300\r
TZNAME:EEST\r
DTSTART:19700329T030000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`], latitude: "+0502600", longitude: "+0303100" }, "Europe/Lisbon": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0000\r
TZNAME:WET\r
DTSTART:19701025T020000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`, `BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0000\r
TZOFFSETTO:+0100\r
TZNAME:WEST\r
DTSTART:19700329T010000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`], latitude: "+0384300", longitude: "-0090800" }, "Europe/Ljubljana": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0200\r
TZNAME:CEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`] }, "Europe/London": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0000\r
TZOFFSETTO:+0100\r
TZNAME:BST\r
DTSTART:19700329T010000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0000\r
TZNAME:GMT\r
DTSTART:19701025T020000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`], latitude: "+0513030", longitude: "+0000731" }, "Europe/Luxembourg": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0200\r
TZNAME:CEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`] }, "Europe/Madrid": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0200\r
TZNAME:CEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`], latitude: "+0402400", longitude: "-0034100" }, "Europe/Malta": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0200\r
TZNAME:CEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`], latitude: "+0355400", longitude: "+0143100" }, "Europe/Mariehamn": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0300\r
TZNAME:EEST\r
DTSTART:19700329T030000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0200\r
TZNAME:EET\r
DTSTART:19701025T040000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`] }, "Europe/Minsk": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0300\r
TZNAME:+03\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0535400", longitude: "+0273400" }, "Europe/Monaco": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0200\r
TZNAME:CEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`] }, "Europe/Moscow": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0300\r
TZNAME:MSK\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0554521", longitude: "+0373704" }, "Europe/Nicosia": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0200\r
TZNAME:EET\r
DTSTART:19701025T040000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`, `BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0300\r
TZNAME:EEST\r
DTSTART:19700329T030000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`] }, "Europe/Oslo": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0200\r
TZNAME:CEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`] }, "Europe/Paris": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0200\r
TZNAME:CEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`], latitude: "+0485200", longitude: "+0022000" }, "Europe/Podgorica": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0200\r
TZNAME:CEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`] }, "Europe/Prague": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0200\r
TZNAME:CEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`], latitude: "+0500500", longitude: "+0142600" }, "Europe/Riga": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0300\r
TZNAME:EEST\r
DTSTART:19700329T030000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0200\r
TZNAME:EET\r
DTSTART:19701025T040000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`], latitude: "+0565700", longitude: "+0240600" }, "Europe/Rome": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0200\r
TZNAME:CEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`], latitude: "+0415400", longitude: "+0122900" }, "Europe/Samara": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0400\r
TZOFFSETTO:+0400\r
TZNAME:+04\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0531200", longitude: "+0500900" }, "Europe/San_Marino": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0200\r
TZNAME:CEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`] }, "Europe/Sarajevo": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0200\r
TZNAME:CEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`] }, "Europe/Saratov": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0400\r
TZOFFSETTO:+0400\r
TZNAME:+04\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0513400", longitude: "+0460200" }, "Europe/Simferopol": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0300\r
TZNAME:MSK\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0445700", longitude: "+0340600" }, "Europe/Skopje": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0200\r
TZNAME:CEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`] }, "Europe/Sofia": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0300\r
TZNAME:EEST\r
DTSTART:19700329T030000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0200\r
TZNAME:EET\r
DTSTART:19701025T040000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`], latitude: "+0424100", longitude: "+0231900" }, "Europe/Stockholm": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0200\r
TZNAME:CEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`] }, "Europe/Tallinn": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0300\r
TZNAME:EEST\r
DTSTART:19700329T030000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0200\r
TZNAME:EET\r
DTSTART:19701025T040000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`], latitude: "+0592500", longitude: "+0244500" }, "Europe/Tirane": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0200\r
TZNAME:CEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`], latitude: "+0412000", longitude: "+0195000" }, "Europe/Tiraspol": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0300\r
TZNAME:EEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0200\r
TZNAME:EET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`] }, "Europe/Ulyanovsk": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0400\r
TZOFFSETTO:+0400\r
TZNAME:+04\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0542000", longitude: "+0482400" }, "Europe/Uzhgorod": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0200\r
TZNAME:EET\r
DTSTART:19701025T040000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`, `BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0300\r
TZNAME:EEST\r
DTSTART:19700329T030000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`] }, "Europe/Vaduz": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0200\r
TZNAME:CEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`] }, "Europe/Vatican": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0200\r
TZNAME:CEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`] }, "Europe/Vienna": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0200\r
TZNAME:CEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`], latitude: "+0481300", longitude: "+0162000" }, "Europe/Vilnius": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0300\r
TZNAME:EEST\r
DTSTART:19700329T030000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0200\r
TZNAME:EET\r
DTSTART:19701025T040000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`], latitude: "+0544100", longitude: "+0251900" }, "Europe/Volgograd": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0300\r
TZNAME:MSK\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0484400", longitude: "+0442500" }, "Europe/Warsaw": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0200\r
TZNAME:CEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`], latitude: "+0521500", longitude: "+0210000" }, "Europe/Zagreb": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0200\r
TZNAME:CEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`] }, "Europe/Zaporozhye": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0200\r
TZNAME:EET\r
DTSTART:19701025T040000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`, `BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0300\r
TZNAME:EEST\r
DTSTART:19700329T030000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`] }, "Europe/Zurich": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+0100\r
TZOFFSETTO:+0200\r
TZNAME:CEST\r
DTSTART:19700329T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+0200\r
TZOFFSETTO:+0100\r
TZNAME:CET\r
DTSTART:19701025T030000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r
END:STANDARD`], latitude: "+0472300", longitude: "+0083200" }, "Indian/Antananarivo": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0300\r
TZNAME:EAT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Indian/Chagos": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0600\r
TZOFFSETTO:+0600\r
TZNAME:+06\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0072000", longitude: "+0722500" }, "Indian/Christmas": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0700\r
TZOFFSETTO:+0700\r
TZNAME:+07\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Indian/Cocos": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0630\r
TZOFFSETTO:+0630\r
TZNAME:+0630\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Indian/Comoro": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0300\r
TZNAME:EAT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Indian/Kerguelen": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0500\r
TZOFFSETTO:+0500\r
TZNAME:+05\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Indian/Mahe": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0400\r
TZOFFSETTO:+0400\r
TZNAME:+04\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Indian/Maldives": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0500\r
TZOFFSETTO:+0500\r
TZNAME:+05\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0041000", longitude: "+0733000" }, "Indian/Mauritius": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0400\r
TZOFFSETTO:+0400\r
TZNAME:+04\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0201000", longitude: "+0573000" }, "Indian/Mayotte": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0300\r
TZOFFSETTO:+0300\r
TZNAME:EAT\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Indian/Reunion": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0400\r
TZOFFSETTO:+0400\r
TZNAME:+04\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Mexico/BajaNorte": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0800\r
TZOFFSETTO:-0700\r
TZNAME:PDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0700\r
TZOFFSETTO:-0800\r
TZNAME:PST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`] }, "Mexico/BajaSur": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0700\r
TZOFFSETTO:-0700\r
TZNAME:MST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Mexico/General": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0600\r
TZNAME:CST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Pacific/Apia": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1300\r
TZOFFSETTO:+1300\r
TZNAME:+13\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0135000", longitude: "-1714400" }, "Pacific/Auckland": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+1200\r
TZOFFSETTO:+1300\r
TZNAME:NZDT\r
DTSTART:19700927T020000\r
RRULE:FREQ=YEARLY;BYMONTH=9;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+1300\r
TZOFFSETTO:+1200\r
TZNAME:NZST\r
DTSTART:19700405T030000\r
RRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r
END:STANDARD`], latitude: "-0365200", longitude: "+1744600" }, "Pacific/Bougainville": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1100\r
TZOFFSETTO:+1100\r
TZNAME:+11\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0061300", longitude: "+1553400" }, "Pacific/Chatham": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+1245\r
TZOFFSETTO:+1345\r
TZNAME:+1345\r
DTSTART:19700927T024500\r
RRULE:FREQ=YEARLY;BYMONTH=9;BYDAY=-1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+1345\r
TZOFFSETTO:+1245\r
TZNAME:+1245\r
DTSTART:19700405T034500\r
RRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r
END:STANDARD`], latitude: "-0435700", longitude: "-1763300" }, "Pacific/Chuuk": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1000\r
TZOFFSETTO:+1000\r
TZNAME:+10\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Pacific/Easter": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0600\r
TZNAME:-06\r
DTSTART:19700404T220000\r
RRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SA\r
END:STANDARD`, `BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0500\r
TZNAME:-05\r
DTSTART:19700905T220000\r
RRULE:FREQ=YEARLY;BYMONTH=9;BYDAY=1SA\r
END:DAYLIGHT`], latitude: "-0270900", longitude: "-1092600" }, "Pacific/Efate": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1100\r
TZOFFSETTO:+1100\r
TZNAME:+11\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0174000", longitude: "+1682500" }, "Pacific/Enderbury": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1300\r
TZOFFSETTO:+1300\r
TZNAME:+13\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Pacific/Fakaofo": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1300\r
TZOFFSETTO:+1300\r
TZNAME:+13\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0092200", longitude: "-1711400" }, "Pacific/Fiji": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1200\r
TZOFFSETTO:+1200\r
TZNAME:+12\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0180800", longitude: "+1782500" }, "Pacific/Funafuti": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1200\r
TZOFFSETTO:+1200\r
TZNAME:+12\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Pacific/Galapagos": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0600\r
TZNAME:-06\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0005400", longitude: "-0893600" }, "Pacific/Gambier": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0900\r
TZOFFSETTO:-0900\r
TZNAME:-09\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0230800", longitude: "-1345700" }, "Pacific/Guadalcanal": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1100\r
TZOFFSETTO:+1100\r
TZNAME:+11\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0093200", longitude: "+1601200" }, "Pacific/Guam": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1000\r
TZOFFSETTO:+1000\r
TZNAME:ChST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0132800", longitude: "+1444500" }, "Pacific/Honolulu": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-1000\r
TZOFFSETTO:-1000\r
TZNAME:HST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0211825", longitude: "-1575130" }, "Pacific/Johnston": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-1000\r
TZOFFSETTO:-1000\r
TZNAME:HST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Pacific/Kanton": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1300\r
TZOFFSETTO:+1300\r
TZNAME:+13\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0024700", longitude: "-1714300" }, "Pacific/Kiritimati": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1400\r
TZOFFSETTO:+1400\r
TZNAME:+14\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0015200", longitude: "-1572000" }, "Pacific/Kosrae": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1100\r
TZOFFSETTO:+1100\r
TZNAME:+11\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0051900", longitude: "+1625900" }, "Pacific/Kwajalein": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1200\r
TZOFFSETTO:+1200\r
TZNAME:+12\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0090500", longitude: "+1672000" }, "Pacific/Majuro": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1200\r
TZOFFSETTO:+1200\r
TZNAME:+12\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Pacific/Marquesas": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0930\r
TZOFFSETTO:-0930\r
TZNAME:-0930\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0090000", longitude: "-1393000" }, "Pacific/Midway": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-1100\r
TZOFFSETTO:-1100\r
TZNAME:SST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Pacific/Nauru": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1200\r
TZOFFSETTO:+1200\r
TZNAME:+12\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0003100", longitude: "+1665500" }, "Pacific/Niue": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-1100\r
TZOFFSETTO:-1100\r
TZNAME:-11\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0190100", longitude: "-1695500" }, "Pacific/Norfolk": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:+1100\r
TZOFFSETTO:+1200\r
TZNAME:+12\r
DTSTART:19701004T020000\r
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=1SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:+1200\r
TZOFFSETTO:+1100\r
TZNAME:+11\r
DTSTART:19700405T030000\r
RRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=1SU\r
END:STANDARD`], latitude: "-0290300", longitude: "+1675800" }, "Pacific/Noumea": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1100\r
TZOFFSETTO:+1100\r
TZNAME:+11\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0221600", longitude: "+1662700" }, "Pacific/Pago_Pago": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-1100\r
TZOFFSETTO:-1100\r
TZNAME:SST\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0141600", longitude: "-1704200" }, "Pacific/Palau": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+0900\r
TZOFFSETTO:+0900\r
TZNAME:+09\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0072000", longitude: "+1342900" }, "Pacific/Pitcairn": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0800\r
TZOFFSETTO:-0800\r
TZNAME:-08\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0250400", longitude: "-1300500" }, "Pacific/Pohnpei": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1100\r
TZOFFSETTO:+1100\r
TZNAME:+11\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Pacific/Ponape": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1100\r
TZOFFSETTO:+1100\r
TZNAME:+11\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Pacific/Port_Moresby": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1000\r
TZOFFSETTO:+1000\r
TZNAME:+10\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0093000", longitude: "+1471000" }, "Pacific/Rarotonga": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-1000\r
TZOFFSETTO:-1000\r
TZNAME:-10\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0211400", longitude: "-1594600" }, "Pacific/Saipan": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1000\r
TZOFFSETTO:+1000\r
TZNAME:ChST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Pacific/Samoa": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-1100\r
TZOFFSETTO:-1100\r
TZNAME:SST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Pacific/Tahiti": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-1000\r
TZOFFSETTO:-1000\r
TZNAME:-10\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0173200", longitude: "-1493400" }, "Pacific/Tarawa": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1200\r
TZOFFSETTO:+1200\r
TZNAME:+12\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "+0012500", longitude: "+1730000" }, "Pacific/Tongatapu": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1300\r
TZOFFSETTO:+1300\r
TZNAME:+13\r
DTSTART:19700101T000000\r
END:STANDARD`], latitude: "-0210800", longitude: "-1751200" }, "Pacific/Truk": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1000\r
TZOFFSETTO:+1000\r
TZNAME:+10\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Pacific/Wake": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1200\r
TZOFFSETTO:+1200\r
TZNAME:+12\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Pacific/Wallis": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1200\r
TZOFFSETTO:+1200\r
TZNAME:+12\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "Pacific/Yap": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:+1000\r
TZOFFSETTO:+1000\r
TZNAME:+10\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "US/Alaska": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0900\r
TZOFFSETTO:-0800\r
TZNAME:AKDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0800\r
TZOFFSETTO:-0900\r
TZNAME:AKST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`] }, "US/Aleutian": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-1000\r
TZOFFSETTO:-0900\r
TZNAME:HDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0900\r
TZOFFSETTO:-1000\r
TZNAME:HST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`] }, "US/Arizona": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-0700\r
TZOFFSETTO:-0700\r
TZNAME:MST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "US/Central": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0500\r
TZNAME:CDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0600\r
TZNAME:CST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`] }, "US/East-Indiana": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0400\r
TZNAME:EDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0500\r
TZNAME:EST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`] }, "US/Eastern": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0400\r
TZNAME:EDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0500\r
TZNAME:EST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`] }, "US/Hawaii": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-1000\r
TZOFFSETTO:-1000\r
TZNAME:HST\r
DTSTART:19700101T000000\r
END:STANDARD`] }, "US/Indiana-Starke": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0500\r
TZNAME:CDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0600\r
TZNAME:CST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`] }, "US/Michigan": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0500\r
TZOFFSETTO:-0400\r
TZNAME:EDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0400\r
TZOFFSETTO:-0500\r
TZNAME:EST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`] }, "US/Mountain": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0700\r
TZOFFSETTO:-0600\r
TZNAME:MDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0600\r
TZOFFSETTO:-0700\r
TZNAME:MST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`] }, "US/Pacific": { ics: [`BEGIN:DAYLIGHT\r
TZOFFSETFROM:-0800\r
TZOFFSETTO:-0700\r
TZNAME:PDT\r
DTSTART:19700308T020000\r
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=2SU\r
END:DAYLIGHT`, `BEGIN:STANDARD\r
TZOFFSETFROM:-0700\r
TZOFFSETTO:-0800\r
TZNAME:PST\r
DTSTART:19701101T020000\r
RRULE:FREQ=YEARLY;BYMONTH=11;BYDAY=1SU\r
END:STANDARD`] }, "US/Samoa": { ics: [`BEGIN:STANDARD\r
TZOFFSETFROM:-1100\r
TZOFFSETTO:-1100\r
TZNAME:SST\r
DTSTART:19700101T000000\r
END:STANDARD`] } }, Ya = { version: kS, aliases: CS, zones: xS };
class HS {
  _aliases = /* @__PURE__ */ new Map();
  _timezones = /* @__PURE__ */ new Map();
  _pendingAliases = [];
  getTimezoneForId(e) {
    let n = 0;
    for (; n++ < 20; ) {
      if (this._timezones.has(e)) return this._timezones.get(e);
      if (this._aliases.has(e)) e = this._aliases.get(e);
      else return null;
    }
    return console.error("TimezoneManager.getTimezoneForIdRec() exceeds recursion limits"), null;
  }
  hasTimezoneForId(e) {
    return this._timezones.has(e) || this._aliases.has(e);
  }
  isAlias(e) {
    return !this._timezones.has(e) && this._aliases.has(e);
  }
  listAllTimezones(e = false) {
    const n = Array.from(this._timezones.keys());
    return e ? n.concat(Array.from(this._aliases.keys())) : n;
  }
  registerTimezone(e) {
    this._timezones.set(e.timezoneId, e), _t.TimezoneService.register(e.toICALTimezone(), e.timezoneId), this._pendingAliases = this._pendingAliases.filter(([n, r]) => r !== e.timezoneId ? true : (_t.TimezoneService.register(e.toICALTimezone(), n), false));
  }
  registerDefaultTimezones() {
    console.debug(`@nextcloud/calendar-js app is using version ${Ya.version} of the timezone database`);
    for (const e in Ya.zones) {
      const n = ["BEGIN:VTIMEZONE", "TZID:" + e, ...Ya.zones[e].ics, "END:VTIMEZONE"].join(`\r
`);
      this.registerTimezoneFromICS(e, n);
    }
    for (const e in Ya.aliases) this.registerAlias(e, Ya.aliases[e].aliasTo);
  }
  registerTimezoneFromICS(e, n) {
    const r = new mr(e, n);
    this.registerTimezone(r);
  }
  registerAlias(e, n) {
    this._aliases.set(e, n);
    const r = this.getTimezoneForId(n);
    if (!r) {
      this._pendingAliases.push([e, n]);
      return;
    }
    _t.TimezoneService.register(r.toICALTimezone(), e);
  }
  unregisterTimezones(e) {
    this._timezones.delete(e), _t.TimezoneService.remove(e);
  }
  unregisterAlias(e) {
    this._aliases.delete(e), this._pendingAliases = this._pendingAliases.filter(([n]) => n !== e), _t.TimezoneService.remove(e);
  }
  clearAllTimezones() {
    this._aliases = /* @__PURE__ */ new Map(), this._pendingAliases = [], this._timezones = /* @__PURE__ */ new Map(), _t.TimezoneService.reset(), Xr.registerTimezone(mr.utc), Xr.registerTimezone(mr.floating), Xr.registerAlias("GMT", mr.utc.timezoneId), Xr.registerAlias("Z", mr.utc.timezoneId);
  }
}
const Xr = new HS();
Xr.clearAllTimezones();
function PS() {
  return Xr;
}
Xe();
const fu = PS();
let Au = false;
function US() {
  return Au || (fu.registerDefaultTimezones(), Au = true), fu;
}
const GS = Ve({ __name: "NcTimezonePicker", props: rn({ additionalTimezones: { default: () => [] }, uid: { default: kn() } }, { modelValue: { default: "floating" }, modelModifiers: {} }), emits: ["update:modelValue"], setup(t) {
  const e = t, n = An(t, "modelValue"), r = Q({ set(o) {
    n.value = o.timezoneId;
  }, get() {
    for (const o of e.additionalTimezones) if (o.timezoneId === n.value) return { cities: [], ...o };
    return { label: hu(n.value), timezoneId: n.value, cities: [] };
  } }), a = Q(() => {
    const o = US(), c = LS(o.listAllTimezones(), e.additionalTimezones, ce("Global")), u = [];
    for (const T of Object.values(c)) u.push(...T.regions);
    return u;
  });
  function i(o) {
    return !o.timezoneId.startsWith("tz-group__");
  }
  function s(o, c, u) {
    const T = u.trim().split(" ");
    return "continent" in o ? o.regions.some((f) => l(f.timezoneId, T)) : l(o.timezoneId, T);
  }
  function l(o, c) {
    return c.every((u) => o.toLowerCase().includes(u.toLowerCase()));
  }
  return (o, c) => (p(), De(S(Xi), { modelValue: r.value, "onUpdate:modelValue": c[0] || (c[0] = (u) => r.value = u), "aria-label-combobox": S(ce)("Search for timezone"), clearable: false, "filter-by": s, multiple: false, options: a.value, placeholder: S(ce)("Type to search time zone"), selectable: i, uid: o.uid, label: "label" }, null, 8, ["modelValue", "aria-label-combobox", "options", "placeholder", "uid"]));
} });
Xe();
const zS = { class: "vue-date-time-picker__wrapper" }, jS = { ref: "target-key", class: "vue-date-time-picker__wrapper" }, $S = Ve({ __name: "NcDateTimePicker", props: rn({ appendToBody: { type: Boolean }, ariaLabel: { default: ce("Datepicker input") }, ariaLabelMenu: { default: ce("Datepicker menu") }, clearable: { type: Boolean }, confirm: { type: Boolean }, format: { type: [String, Function], default: void 0 }, locale: { default: Ln() }, minuteStep: { default: 10 }, modelValue: { default: null }, placeholder: { default: void 0 }, showTimezoneSelect: { type: Boolean }, showWeekNumber: { type: Boolean }, type: { default: "date" } }, { timezoneId: { default: "UTC" }, timezoneIdModifiers: {} }), emits: rn(["update:modelValue", "update:timezoneId"], ["update:timezoneId"]), setup(t, { emit: e }) {
  const n = t, r = An(t, "timezoneId"), a = Er("target-key"), i = Er("picker-key"), s = e, l = Q(() => {
    if (n.modelValue === null && n.clearable) return null;
    if (n.type === "week") {
      const D = n.modelValue instanceof Date ? n.modelValue : /* @__PURE__ */ new Date(), w = new Date(D);
      return w.setUTCDate(D.getUTCDate() + 6), [D, w];
    } else {
      if (n.type === "year") return (n.modelValue instanceof Date ? n.modelValue : /* @__PURE__ */ new Date()).getUTCFullYear();
      if (n.type === "month") {
        const D = n.modelValue instanceof Date ? n.modelValue : /* @__PURE__ */ new Date();
        return { year: D.getUTCFullYear(), month: D.getUTCMonth() };
      } else if (n.type === "time") {
        const D = n.modelValue instanceof Date ? n.modelValue : /* @__PURE__ */ new Date();
        return { hours: D.getHours(), minutes: D.getMinutes(), seconds: D.getSeconds() };
      } else if (n.type === "time-range") {
        const D = [n.modelValue].flat();
        if (D.length !== 2) {
          const w = /* @__PURE__ */ new Date(), L = new Date(w);
          L.setHours(L.getHours() + 1), D.splice(0, 2, w, L);
        }
        return D.map((w) => ({ hours: w.getHours(), minutes: w.getMinutes(), seconds: w.getSeconds() }));
      } else if (n.type.endsWith("-range")) {
        if (n.modelValue === void 0) {
          const D = /* @__PURE__ */ new Date(), w = new Date(D);
          return w.setUTCDate(D.getUTCDate() + 7), [D, w];
        }
        return n.modelValue;
      }
    }
    return n.modelValue ?? /* @__PURE__ */ new Date();
  }), o = Q(() => n.type === "date" ? ce("Select date") : n.type === "time" ? ce("Select time") : n.type === "datetime" ? ce("Select date and time") : n.type === "week" ? ce("Select week") : n.type === "month" ? ce("Select month") : n.type === "year" ? ce("Select year") : n.type.endsWith("-range") ? ce("Select time range") : ce("Select date and time")), c = Q(() => {
    if (n.format) return n.format;
    if (n.type === "week") return "RR-II";
    let D;
    if (n.type === "date" || n.type === "date-range" ? D = new Intl.DateTimeFormat(Ln(), { dateStyle: "medium" }) : n.type === "time" || n.type === "time-range" ? D = new Intl.DateTimeFormat(Ln(), { timeStyle: "short" }) : n.type === "datetime" || n.type === "datetime-range" ? D = new Intl.DateTimeFormat(Ln(), { dateStyle: "medium", timeStyle: "short" }) : n.type === "month" ? D = new Intl.DateTimeFormat(Ln(), { year: "numeric", month: "2-digit" }) : n.type === "year" && (D = new Intl.DateTimeFormat(Ln(), { year: "numeric" })), D) return (w) => Array.isArray(w) ? D.formatRange(w[0], w[1]) : D.format(w);
  }), u = Q(() => ({ timePicker: n.type === "time" || n.type === "time-range", yearPicker: n.type === "year", monthPicker: n.type === "month", weekPicker: n.type === "week", range: n.type.endsWith("-range") && { partialRange: false }, enableTimePicker: !(n.type === "date" || n.type === "date-range"), flow: n.type === "datetime" ? ["calendar", "time"] : void 0 }));
  function T(D) {
    if (D === null) return s("update:modelValue", null);
    if (n.type === "time") s("update:modelValue", f(D));
    else if (n.type === "time-range") {
      const w = f(D[0]), L = f(D[1]);
      L.getTime() < w.getTime() && L.setDate(L.getDate() + 1), s("update:modelValue", [w, L]);
    } else if (n.type === "month") {
      const w = D;
      s("update:modelValue", new Date(w.year, w.month, 1));
    } else n.type === "year" ? s("update:modelValue", new Date(D, 0)) : n.type === "week" ? s("update:modelValue", D[0]) : s("update:modelValue", D);
  }
  function f(D) {
    const w = /* @__PURE__ */ new Date();
    return w.setHours(D.hours), w.setMinutes(D.minutes), w.setSeconds(D.seconds), w;
  }
  const m = iT(), v = rT(), E = ce("W"), A = Q(() => ({ toggleOverlay: ce("Toggle overlay"), menu: n.ariaLabelMenu, input: n.ariaLabel, openTimePicker: ce("Open time picker"), closeTimePicker: ce("Close time Picker"), incrementValue: (D) => D === "hours" ? ce("Increment hours") : D === "minutes" ? ce("Increment minutes") : ce("Increment seconds"), decrementValue: (D) => D === "hours" ? ce("Decrement hours") : D === "minutes" ? ce("Decrement minutes") : ce("Decrement seconds"), openTpOverlay: (D) => D === "hours" ? ce("Open hours overlay") : D === "minutes" ? ce("Open minutes overlay") : ce("Open seconds overlay"), amPmButton: ce("Switch AM/PM mode"), openYearsOverlay: ce("Open years overlay"), openMonthsOverlay: ce("Open months overlay"), nextMonth: ce("Next month"), prevMonth: ce("Previous month"), nextYear: ce("Next year"), prevYear: ce("Previous year"), weekDay: (D) => aT()[D], clearInput: ce("Clear value"), calendarIcon: ce("Calendar icon"), timePicker: ce("Time picker"), monthPicker: (D) => D ? ce("Month picker overlay") : ce("Month picker"), yearPicker: (D) => D ? ce("Year picker overlay") : ce("Year picker") }));
  function g() {
    i.value.selectDate();
  }
  function O() {
    i.value.closeMenu();
  }
  return (D, w) => (p(), M("div", zS, [Oe(S(Ao), Le({ ref: "picker-key", "aria-labels": A.value, "auto-apply": !D.confirm, class: ["vue-date-time-picker", { "vue-date-time-picker--clearable": D.clearable }], "cancel-text": S(ce)("Cancel"), clearable: D.clearable, "day-names": S(m), placeholder: D.placeholder ?? o.value, format: c.value, locale: D.locale, "minutes-increment": D.minuteStep, "model-value": l.value, "now-button-label": S(ce)("Now"), "select-text": S(ce)("Pick"), "six-weeks": "fair", teleport: D.appendToBody ? a.value || void 0 : false, "text-input": "", "week-num-name": S(E), "week-numbers": D.showWeekNumber ? { type: "iso" } : void 0, "week-start": S(v) }, u.value, { "onUpdate:modelValue": T }), wt({ "action-buttons": he(() => [Oe(S($t), { size: "small", variant: "tertiary", onClick: O }, { default: he(() => [Mt(Be(S(ce)("Cancel")), 1)]), _: 1 }), Oe(S($t), { size: "small", variant: "primary", onClick: g }, { default: he(() => [Mt(Be(S(ce)("Pick")), 1)]), _: 1 })]), "clear-icon": he(({ clear: L }) => [Oe(S($t), { "aria-label": S(ce)("Clear value"), variant: "tertiary-no-background", onClick: L }, { icon: he(() => [Oe(xt, { inline: "", path: S(r0), size: 20 }, null, 8, ["path"])]), _: 2 }, 1032, ["aria-label", "onClick"])]), "input-icon": he(() => [Oe(xt, { path: S(Hc), size: 20 }, null, 8, ["path"])]), "clock-icon": he(() => [Oe(xt, { inline: "", path: S(xc), size: 20 }, null, 8, ["path"])]), "arrow-left": he(() => [Oe(xt, { inline: "", path: S(Cc), size: 20 }, null, 8, ["path"])]), "arrow-right": he(() => [Oe(xt, { inline: "", path: S(kc), size: 20 }, null, 8, ["path"])]), "arrow-down": he(() => [Oe(xt, { inline: "", path: S(Lc), size: 20 }, null, 8, ["path"])]), "arrow-up": he(() => [Oe(xt, { inline: "", path: S(Ic), size: 20 }, null, 8, ["path"])]), _: 2 }, [D.showTimezoneSelect ? { name: "action-extra", fn: he(() => [Oe(GS, { modelValue: r.value, "onUpdate:modelValue": w[0] || (w[0] = (L) => r.value = L), class: "vue-date-time-picker__timezone", "append-to-body": false, "input-label": S(ce)("Timezone") }, null, 8, ["modelValue", "input-label"])]), key: "0" } : void 0]), 1040, ["aria-labels", "auto-apply", "class", "cancel-text", "clearable", "day-names", "placeholder", "format", "locale", "minutes-increment", "model-value", "now-button-label", "select-text", "teleport", "week-num-name", "week-numbers", "week-start"]), (p(), De(Ia, { to: "body", disabled: !D.appendToBody }, [j("div", jS, null, 512)], 8, ["disabled"]))]));
} }), VS = nt($S, [["__scopeId", "data-v-27474da0"]]);
var QS = typeof window < "u";
QS && (function() {
  for (var t = 0, e = ["ms", "moz", "webkit", "o"], n = 0; n < e.length && !window.requestAnimationFrame; ++n) window.requestAnimationFrame = window[e[n] + "RequestAnimationFrame"], window.cancelAnimationFrame = window[e[n] + "CancelAnimationFrame"] || window[e[n] + "CancelRequestAnimationFrame"];
  window.requestAnimationFrame || (window.requestAnimationFrame = function(r, a) {
    var i = (/* @__PURE__ */ new Date()).getTime(), s = Math.max(0, 16 - (i - t)), l = window.setTimeout(function() {
      r(i + s);
    }, s);
    return t = i + s, l;
  }), window.cancelAnimationFrame || (window.cancelAnimationFrame = function(r) {
    clearTimeout(r);
  });
})();
var Ui = { exports: {} }, WS = Ui.exports, mu;
function qS() {
  return mu || (mu = 1, (function(t, e) {
    (function(n, r) {
      t.exports = r();
    })(typeof self < "u" ? self : WS, (function() {
      return (function() {
        var n = { 537: function() {
          typeof window < "u" && (function() {
            for (var s = 0, l = ["ms", "moz", "webkit", "o"], o = 0; o < l.length && !window.requestAnimationFrame; ++o) window.requestAnimationFrame = window[l[o] + "RequestAnimationFrame"], window.cancelAnimationFrame = window[l[o] + "CancelAnimationFrame"] || window[l[o] + "CancelRequestAnimationFrame"];
            window.requestAnimationFrame || (window.requestAnimationFrame = function(c, u) {
              var T = (/* @__PURE__ */ new Date()).getTime(), f = Math.max(0, 16 - (T - s)), m = window.setTimeout((function() {
                c(T + f);
              }), f);
              return s = T + f, m;
            }), window.cancelAnimationFrame || (window.cancelAnimationFrame = function(c) {
              clearTimeout(c);
            });
          })();
        } }, r = {};
        function a(s) {
          var l = r[s];
          if (l !== void 0) return l.exports;
          var o = r[s] = { exports: {} };
          return n[s](o, o.exports, a), o.exports;
        }
        a.d = function(s, l) {
          for (var o in l) a.o(l, o) && !a.o(s, o) && Object.defineProperty(s, o, { enumerable: true, get: l[o] });
        }, a.o = function(s, l) {
          return Object.prototype.hasOwnProperty.call(s, l);
        }, a.r = function(s) {
          typeof Symbol < "u" && Symbol.toStringTag && Object.defineProperty(s, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(s, "__esModule", { value: true });
        };
        var i = {};
        return (function() {
          a.r(i), a.d(i, { Anchors: function() {
            return re;
          }, Category: function() {
            return me;
          }, Emoji: function() {
            return R;
          }, EmojiData: function() {
            return h;
          }, EmojiIndex: function() {
            return ie;
          }, EmojiView: function() {
            return F;
          }, Picker: function() {
            return we;
          }, Preview: function() {
            return ve;
          }, Search: function() {
            return Ue;
          }, Skins: function() {
            return Se;
          }, frequently: function() {
            return V;
          }, sanitize: function() {
            return U;
          }, store: function() {
            return f;
          }, uncompress: function() {
            return w;
          } });
          var s, l, o = "emoji-mart", c = JSON, u = typeof window < "u" && "localStorage" in window;
          function T(d, N) {
            if (l) l(d, N);
            else {
              if (!u) return;
              try {
                window.localStorage["".concat(o, ".").concat(d)] = c.stringify(N);
              } catch {
              }
            }
          }
          var f = { update: function(d) {
            for (var N in d) T(N, d[N]);
          }, set: T, get: function(d) {
            if (s) return s(d);
            if (u) {
              try {
                var N = window.localStorage["".concat(o, ".").concat(d)];
              } catch {
                return;
              }
              return N ? JSON.parse(N) : void 0;
            }
          }, setNamespace: function(d) {
            o = d;
          }, setHandlers: function(d) {
            d || (d = {}), s = d.getter, l = d.setter;
          } };
          function m(d) {
            return m = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(N) {
              return typeof N;
            } : function(N) {
              return N && typeof Symbol == "function" && N.constructor === Symbol && N !== Symbol.prototype ? "symbol" : typeof N;
            }, m(d);
          }
          function v(d, N) {
            (N == null || N > d.length) && (N = d.length);
            for (var y = 0, K = new Array(N); y < N; y++) K[y] = d[y];
            return K;
          }
          var E = { name: "a", unified: "b", non_qualified: "c", has_img_apple: "d", has_img_google: "e", has_img_twitter: "f", has_img_facebook: "h", keywords: "j", sheet: "k", emoticons: "l", text: "m", short_names: "n", added_in: "o" }, A = function(d) {
            var N = [], y = function(K, ge) {
              K && (Array.isArray(K) ? K : [K]).forEach((function(Ne) {
                (ge ? Ne.split(/[-|_|\s]+/) : [Ne]).forEach((function(Ye) {
                  Ye = Ye.toLowerCase(), N.indexOf(Ye) == -1 && N.push(Ye);
                }));
              }));
            };
            return y(d.short_names, true), y(d.name, true), y(d.keywords, false), y(d.emoticons, false), N.join(",");
          };
          function g(d) {
            var N, y = (function(Ne, Ye) {
              var ke = typeof Symbol < "u" && Ne[Symbol.iterator] || Ne["@@iterator"];
              if (!ke) {
                if (Array.isArray(Ne) || (ke = (function(X, Fe) {
                  if (X) {
                    if (typeof X == "string") return v(X, Fe);
                    var be = Object.prototype.toString.call(X).slice(8, -1);
                    return be === "Object" && X.constructor && (be = X.constructor.name), be === "Map" || be === "Set" ? Array.from(X) : be === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(be) ? v(X, Fe) : void 0;
                  }
                })(Ne)) || Ye) {
                  ke && (Ne = ke);
                  var Ze = 0, C = function() {
                  };
                  return { s: C, n: function() {
                    return Ze >= Ne.length ? { done: true } : { done: false, value: Ne[Ze++] };
                  }, e: function(X) {
                    throw X;
                  }, f: C };
                }
                throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
              }
              var ue, _e = true, Ce = false;
              return { s: function() {
                ke = ke.call(Ne);
              }, n: function() {
                var X = ke.next();
                return _e = X.done, X;
              }, e: function(X) {
                Ce = true, ue = X;
              }, f: function() {
                try {
                  _e || ke.return == null || ke.return();
                } finally {
                  if (Ce) throw ue;
                }
              } };
            })(Object.getOwnPropertyNames(d));
            try {
              for (y.s(); !(N = y.n()).done; ) {
                var K = N.value, ge = d[K];
                d[K] = ge && m(ge) === "object" ? g(ge) : ge;
              }
            } catch (Ne) {
              y.e(Ne);
            } finally {
              y.f();
            }
            return Object.freeze(d);
          }
          var O, D, w = function(d) {
            if (!d.compressed) return d;
            for (var N in d.compressed = false, d.emojis) {
              var y = d.emojis[N];
              for (var K in E) y[K] = y[E[K]], delete y[E[K]];
              y.short_names || (y.short_names = []), y.short_names.unshift(N), y.sheet_x = y.sheet[0], y.sheet_y = y.sheet[1], delete y.sheet, y.text || (y.text = ""), y.added_in || (y.added_in = 6), y.added_in = y.added_in.toFixed(1), y.search = A(y);
            }
            return g(d);
          }, L = ["+1", "grinning", "kissing_heart", "heart_eyes", "laughing", "stuck_out_tongue_winking_eye", "sweat_smile", "joy", "scream", "disappointed", "unamused", "weary", "sob", "sunglasses", "heart", "hankey"], _ = {};
          function I() {
            D = true, O = f.get("frequently");
          }
          var V = { add: function(d) {
            D || I();
            var N = d.id;
            O || (O = _), O[N] || (O[N] = 0), O[N] += 1, f.set("last", N), f.set("frequently", O);
          }, get: function(d) {
            if (D || I(), !O) {
              _ = {};
              for (var N = [], y = Math.min(d, L.length), K = 0; K < y; K++) _[L[K]] = parseInt((y - K) / 4, 10) + 1, N.push(L[K]);
              return N;
            }
            var ge = d, Ne = [];
            for (var Ye in O) O.hasOwnProperty(Ye) && Ne.push(Ye);
            var ke = Ne.sort((function(C, ue) {
              return O[C] - O[ue];
            })).reverse().slice(0, ge), Ze = f.get("last");
            return Ze && ke.indexOf(Ze) == -1 && (ke.pop(), ke.push(Ze)), ke;
          } }, H = { activity: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><path d="M12 0C5.373 0 0 5.372 0 12c0 6.627 5.373 12 12 12 6.628 0 12-5.373 12-12 0-6.628-5.372-12-12-12m9.949 11H17.05c.224-2.527 1.232-4.773 1.968-6.113A9.966 9.966 0 0 1 21.949 11M13 11V2.051a9.945 9.945 0 0 1 4.432 1.564c-.858 1.491-2.156 4.22-2.392 7.385H13zm-2 0H8.961c-.238-3.165-1.536-5.894-2.393-7.385A9.95 9.95 0 0 1 11 2.051V11zm0 2v8.949a9.937 9.937 0 0 1-4.432-1.564c.857-1.492 2.155-4.221 2.393-7.385H11zm4.04 0c.236 3.164 1.534 5.893 2.392 7.385A9.92 9.92 0 0 1 13 21.949V13h2.04zM4.982 4.887C5.718 6.227 6.726 8.473 6.951 11h-4.9a9.977 9.977 0 0 1 2.931-6.113M2.051 13h4.9c-.226 2.527-1.233 4.771-1.969 6.113A9.972 9.972 0 0 1 2.051 13m16.967 6.113c-.735-1.342-1.744-3.586-1.968-6.113h4.899a9.961 9.961 0 0 1-2.931 6.113"/></svg>', custom: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><g transform="translate(2.000000, 1.000000)"><rect id="Rectangle" x="8" y="0" width="3" height="21" rx="1.5"></rect><rect id="Rectangle" transform="translate(9.843, 10.549) rotate(60) translate(-9.843, -10.549) " x="8.343" y="0.049" width="3" height="21" rx="1.5"></rect><rect id="Rectangle" transform="translate(9.843, 10.549) rotate(-60) translate(-9.843, -10.549) " x="8.343" y="0.049" width="3" height="21" rx="1.5"></rect></g></svg>', flags: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><path d="M0 0l6.084 24H8L1.916 0zM21 5h-4l-1-4H4l3 12h3l1 4h13L21 5zM6.563 3h7.875l2 8H8.563l-2-8zm8.832 10l-2.856 1.904L12.063 13h3.332zM19 13l-1.5-6h1.938l2 8H16l3-2z"/></svg>', foods: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><path d="M17 4.978c-1.838 0-2.876.396-3.68.934.513-1.172 1.768-2.934 4.68-2.934a1 1 0 0 0 0-2c-2.921 0-4.629 1.365-5.547 2.512-.064.078-.119.162-.18.244C11.73 1.838 10.798.023 9.207.023 8.579.022 7.85.306 7 .978 5.027 2.54 5.329 3.902 6.492 4.999 3.609 5.222 0 7.352 0 12.969c0 4.582 4.961 11.009 9 11.009 1.975 0 2.371-.486 3-1 .629.514 1.025 1 3 1 4.039 0 9-6.418 9-11 0-5.953-4.055-8-7-8M8.242 2.546c.641-.508.943-.523.965-.523.426.169.975 1.405 1.357 3.055-1.527-.629-2.741-1.352-2.98-1.846.059-.112.241-.356.658-.686M15 21.978c-1.08 0-1.21-.109-1.559-.402l-.176-.146c-.367-.302-.816-.452-1.266-.452s-.898.15-1.266.452l-.176.146c-.347.292-.477.402-1.557.402-2.813 0-7-5.389-7-9.009 0-5.823 4.488-5.991 5-5.991 1.939 0 2.484.471 3.387 1.251l.323.276a1.995 1.995 0 0 0 2.58 0l.323-.276c.902-.78 1.447-1.251 3.387-1.251.512 0 5 .168 5 6 0 3.617-4.187 9-7 9"/></svg>', nature: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><path d="M15.5 8a1.5 1.5 0 1 0 .001 3.001A1.5 1.5 0 0 0 15.5 8M8.5 8a1.5 1.5 0 1 0 .001 3.001A1.5 1.5 0 0 0 8.5 8"/><path d="M18.933 0h-.027c-.97 0-2.138.787-3.018 1.497-1.274-.374-2.612-.51-3.887-.51-1.285 0-2.616.133-3.874.517C7.245.79 6.069 0 5.093 0h-.027C3.352 0 .07 2.67.002 7.026c-.039 2.479.276 4.238 1.04 5.013.254.258.882.677 1.295.882.191 3.177.922 5.238 2.536 6.38.897.637 2.187.949 3.2 1.102C8.04 20.6 8 20.795 8 21c0 1.773 2.35 3 4 3 1.648 0 4-1.227 4-3 0-.201-.038-.393-.072-.586 2.573-.385 5.435-1.877 5.925-7.587.396-.22.887-.568 1.104-.788.763-.774 1.079-2.534 1.04-5.013C23.929 2.67 20.646 0 18.933 0M3.223 9.135c-.237.281-.837 1.155-.884 1.238-.15-.41-.368-1.349-.337-3.291.051-3.281 2.478-4.972 3.091-5.031.256.015.731.27 1.265.646-1.11 1.171-2.275 2.915-2.352 5.125-.133.546-.398.858-.783 1.313M12 22c-.901 0-1.954-.693-2-1 0-.654.475-1.236 1-1.602V20a1 1 0 1 0 2 0v-.602c.524.365 1 .947 1 1.602-.046.307-1.099 1-2 1m3-3.48v.02a4.752 4.752 0 0 0-1.262-1.02c1.092-.516 2.239-1.334 2.239-2.217 0-1.842-1.781-2.195-3.977-2.195-2.196 0-3.978.354-3.978 2.195 0 .883 1.148 1.701 2.238 2.217A4.8 4.8 0 0 0 9 18.539v-.025c-1-.076-2.182-.281-2.973-.842-1.301-.92-1.838-3.045-1.853-6.478l.023-.041c.496-.826 1.49-1.45 1.804-3.102 0-2.047 1.357-3.631 2.362-4.522C9.37 3.178 10.555 3 11.948 3c1.447 0 2.685.192 3.733.57 1 .9 2.316 2.465 2.316 4.48.313 1.651 1.307 2.275 1.803 3.102.035.058.068.117.102.178-.059 5.967-1.949 7.01-4.902 7.19m6.628-8.202c-.037-.065-.074-.13-.113-.195a7.587 7.587 0 0 0-.739-.987c-.385-.455-.648-.768-.782-1.313-.076-2.209-1.241-3.954-2.353-5.124.531-.376 1.004-.63 1.261-.647.636.071 3.044 1.764 3.096 5.031.027 1.81-.347 3.218-.37 3.235"/></svg>', objects: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><path d="M12 0a9 9 0 0 0-5 16.482V21s2.035 3 5 3 5-3 5-3v-4.518A9 9 0 0 0 12 0zm0 2c3.86 0 7 3.141 7 7s-3.14 7-7 7-7-3.141-7-7 3.14-7 7-7zM9 17.477c.94.332 1.946.523 3 .523s2.06-.19 3-.523v.834c-.91.436-1.925.689-3 .689a6.924 6.924 0 0 1-3-.69v-.833zm.236 3.07A8.854 8.854 0 0 0 12 21c.965 0 1.888-.167 2.758-.451C14.155 21.173 13.153 22 12 22c-1.102 0-2.117-.789-2.764-1.453z"/><path d="M14.745 12.449h-.004c-.852-.024-1.188-.858-1.577-1.824-.421-1.061-.703-1.561-1.182-1.566h-.009c-.481 0-.783.497-1.235 1.537-.436.982-.801 1.811-1.636 1.791l-.276-.043c-.565-.171-.853-.691-1.284-1.794-.125-.313-.202-.632-.27-.913-.051-.213-.127-.53-.195-.634C7.067 9.004 7.039 9 6.99 9A1 1 0 0 1 7 7h.01c1.662.017 2.015 1.373 2.198 2.134.486-.981 1.304-2.058 2.797-2.075 1.531.018 2.28 1.153 2.731 2.141l.002-.008C14.944 8.424 15.327 7 16.979 7h.032A1 1 0 1 1 17 9h-.011c-.149.076-.256.474-.319.709a6.484 6.484 0 0 1-.311.951c-.429.973-.79 1.789-1.614 1.789"/></svg>', smileys: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0m0 22C6.486 22 2 17.514 2 12S6.486 2 12 2s10 4.486 10 10-4.486 10-10 10"/><path d="M8 7a2 2 0 1 0-.001 3.999A2 2 0 0 0 8 7M16 7a2 2 0 1 0-.001 3.999A2 2 0 0 0 16 7M15.232 15c-.693 1.195-1.87 2-3.349 2-1.477 0-2.655-.805-3.347-2H15m3-2H6a6 6 0 1 0 12 0"/></svg>', people: '<svg xmlns:svg="http://www.w3.org/2000/svg" height="24" width="24" viewBox="0 0 24 24"> <path id="path3814" d="m 3.3591089,21.17726 c 0.172036,0.09385 4.265994,2.29837 8.8144451,2.29837 4.927767,0 8.670894,-2.211883 8.82782,-2.306019 0.113079,-0.06785 0.182268,-0.190051 0.182267,-0.321923 0,-3.03119 -0.929494,-5.804936 -2.617196,-7.810712 -1.180603,-1.403134 -2.661918,-2.359516 -4.295699,-2.799791 4.699118,-2.236258 3.102306,-9.28617162 -2.097191,-9.28617162 -5.1994978,0 -6.7963103,7.04991362 -2.097192,9.28617162 -1.6337821,0.440275 -3.1150971,1.396798 -4.2956991,2.799791 -1.687703,2.005776 -2.617196,4.779522 -2.617196,7.810712 1.2e-6,0.137378 0.075039,0.263785 0.195641,0.329572 z M 8.0439319,5.8308783 C 8.0439309,2.151521 12.492107,0.30955811 15.093491,2.9109411 17.694874,5.5123241 15.852911,9.9605006 12.173554,9.9605 9.8938991,9.9579135 8.0465186,8.1105332 8.0439319,5.8308783 Z m -1.688782,7.6894977 c 1.524535,-1.811449 3.5906601,-2.809035 5.8184041,-2.809035 2.227744,0 4.293869,0.997586 5.818404,2.809035 1.533639,1.822571 2.395932,4.339858 2.439152,7.108301 -0.803352,0.434877 -4.141636,2.096112 -8.257556,2.096112 -3.8062921,0 -7.3910861,-1.671043 -8.2573681,-2.104981 0.04505,-2.765017 0.906968,-5.278785 2.438964,-7.099432 z" /> <path id="path3816" d="M 12.173828 0.38867188 C 9.3198513 0.38867187 7.3770988 2.3672285 6.8652344 4.6308594 C 6.4218608 6.5916015 7.1153562 8.7676117 8.9648438 10.126953 C 7.6141249 10.677376 6.3550511 11.480944 5.3496094 12.675781 C 3.5629317 14.799185 2.6015625 17.701475 2.6015625 20.847656 C 2.6015654 21.189861 2.7894276 21.508002 3.0898438 21.671875 C 3.3044068 21.788925 7.4436239 24.039062 12.173828 24.039062 C 17.269918 24.039062 21.083568 21.776786 21.291016 21.652344 C 21.57281 21.483266 21.746097 21.176282 21.746094 20.847656 C 21.746094 17.701475 20.78277 14.799185 18.996094 12.675781 C 17.990455 11.480591 16.733818 10.675362 15.382812 10.125 C 17.231132 8.7655552 17.925675 6.5910701 17.482422 4.6308594 C 16.970557 2.3672285 15.027805 0.38867188 12.173828 0.38867188 z M 12.792969 2.3007812 C 13.466253 2.4161792 14.125113 2.7383941 14.695312 3.3085938 C 15.835712 4.4489931 15.985604 5.9473549 15.46875 7.1953125 C 14.951896 8.4432701 13.786828 9.3984378 12.173828 9.3984375 C 10.197719 9.3961954 8.607711 7.806187 8.6054688 5.8300781 C 8.6054683 4.2170785 9.5606362 3.0520102 10.808594 2.5351562 C 11.432573 2.2767293 12.119685 2.1853833 12.792969 2.3007812 z M 12.173828 11.273438 C 14.233647 11.273438 16.133674 12.185084 17.5625 13.882812 C 18.93069 15.508765 19.698347 17.776969 19.808594 20.283203 C 18.807395 20.800235 15.886157 22.162109 12.173828 22.162109 C 8.7614632 22.162109 5.6245754 20.787069 4.5390625 20.265625 C 4.6525896 17.766717 5.4203315 15.504791 6.7851562 13.882812 C 8.2139827 12.185084 10.11401 11.273438 12.173828 11.273438 z " /> </svg>', places: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><path d="M6.5 12C5.122 12 4 13.121 4 14.5S5.122 17 6.5 17 9 15.879 9 14.5 7.878 12 6.5 12m0 3c-.275 0-.5-.225-.5-.5s.225-.5.5-.5.5.225.5.5-.225.5-.5.5M17.5 12c-1.378 0-2.5 1.121-2.5 2.5s1.122 2.5 2.5 2.5 2.5-1.121 2.5-2.5-1.122-2.5-2.5-2.5m0 3c-.275 0-.5-.225-.5-.5s.225-.5.5-.5.5.225.5.5-.225.5-.5.5"/><path d="M22.482 9.494l-1.039-.346L21.4 9h.6c.552 0 1-.439 1-.992 0-.006-.003-.008-.003-.008H23c0-1-.889-2-1.984-2h-.642l-.731-1.717C19.262 3.012 18.091 2 16.764 2H7.236C5.909 2 4.738 3.012 4.357 4.283L3.626 6h-.642C1.889 6 1 7 1 8h.003S1 8.002 1 8.008C1 8.561 1.448 9 2 9h.6l-.043.148-1.039.346a2.001 2.001 0 0 0-1.359 2.097l.751 7.508a1 1 0 0 0 .994.901H3v1c0 1.103.896 2 2 2h2c1.104 0 2-.897 2-2v-1h6v1c0 1.103.896 2 2 2h2c1.104 0 2-.897 2-2v-1h1.096a.999.999 0 0 0 .994-.901l.751-7.508a2.001 2.001 0 0 0-1.359-2.097M6.273 4.857C6.402 4.43 6.788 4 7.236 4h9.527c.448 0 .834.43.963.857L19.313 9H4.688l1.585-4.143zM7 21H5v-1h2v1zm12 0h-2v-1h2v1zm2.189-3H2.811l-.662-6.607L3 11h18l.852.393L21.189 18z"/></svg>', recent: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><path d="M13 4h-2l-.001 7H9v2h2v2h2v-2h4v-2h-4z"/><path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0m0 22C6.486 22 2 17.514 2 12S6.486 2 12 2s10 4.486 10 10-4.486 10-10 10"/></svg>', symbols: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><path d="M0 0h11v2H0zM4 11h3V6h4V4H0v2h4zM15.5 17c1.381 0 2.5-1.116 2.5-2.493s-1.119-2.493-2.5-2.493S13 13.13 13 14.507 14.119 17 15.5 17m0-2.986c.276 0 .5.222.5.493 0 .272-.224.493-.5.493s-.5-.221-.5-.493.224-.493.5-.493M21.5 19.014c-1.381 0-2.5 1.116-2.5 2.493S20.119 24 21.5 24s2.5-1.116 2.5-2.493-1.119-2.493-2.5-2.493m0 2.986a.497.497 0 0 1-.5-.493c0-.271.224-.493.5-.493s.5.222.5.493a.497.497 0 0 1-.5.493M22 13l-9 9 1.513 1.5 8.99-9.009zM17 11c2.209 0 4-1.119 4-2.5V2s.985-.161 1.498.949C23.01 4.055 23 6 23 6s1-1.119 1-3.135C24-.02 21 0 21 0h-2v6.347A5.853 5.853 0 0 0 17 6c-2.209 0-4 1.119-4 2.5s1.791 2.5 4 2.5M10.297 20.482l-1.475-1.585a47.54 47.54 0 0 1-1.442 1.129c-.307-.288-.989-1.016-2.045-2.183.902-.836 1.479-1.466 1.729-1.892s.376-.871.376-1.336c0-.592-.273-1.178-.818-1.759-.546-.581-1.329-.871-2.349-.871-1.008 0-1.79.293-2.344.879-.556.587-.832 1.181-.832 1.784 0 .813.419 1.748 1.256 2.805-.847.614-1.444 1.208-1.794 1.784a3.465 3.465 0 0 0-.523 1.833c0 .857.308 1.56.924 2.107.616.549 1.423.823 2.42.823 1.173 0 2.444-.379 3.813-1.137L8.235 24h2.819l-2.09-2.383 1.333-1.135zm-6.736-6.389a1.02 1.02 0 0 1 .73-.286c.31 0 .559.085.747.254a.849.849 0 0 1 .283.659c0 .518-.419 1.112-1.257 1.784-.536-.651-.805-1.231-.805-1.742a.901.901 0 0 1 .302-.669M3.74 22c-.427 0-.778-.116-1.057-.349-.279-.232-.418-.487-.418-.766 0-.594.509-1.288 1.527-2.083.968 1.134 1.717 1.946 2.248 2.438-.921.507-1.686.76-2.3.76"/></svg>' };
          function Z(d, N, y, K, ge, Ne, Ye, ke) {
            var Ze, C = typeof d == "function" ? d.options : d;
            return N && (C.render = N, C.staticRenderFns = y, C._compiled = true), { exports: d, options: C };
          }
          var J = Z({ props: { i18n: { type: Object, required: true }, color: { type: String }, categories: { type: Array, required: true }, activeCategory: { type: Object, default: function() {
            return {};
          } } }, emits: ["click"], created: function() {
            this.svgs = H;
          } }, (function() {
            var d = this, N = d._self._c;
            return N("div", { staticClass: "emoji-mart-anchors", attrs: { role: "tablist" } }, d._l(d.categories, (function(y) {
              return N("button", { key: y.id, class: { "emoji-mart-anchor": true, "emoji-mart-anchor-selected": y.id == d.activeCategory.id }, style: { color: y.id == d.activeCategory.id ? d.color : "" }, attrs: { role: "tab", type: "button", "aria-label": y.name, "aria-selected": y.id == d.activeCategory.id, "data-title": d.i18n.categories[y.id] }, on: { click: function(K) {
                return d.$emit("click", y);
              } } }, [N("div", { attrs: { "aria-hidden": "true" }, domProps: { innerHTML: d._s(d.svgs[y.id]) } }), d._v(" "), N("span", { staticClass: "emoji-mart-anchor-bar", style: { backgroundColor: d.color }, attrs: { "aria-hidden": "true" } })]);
            })), 0);
          }), []), re = J.exports;
          function oe(d, N) {
            if (!(d instanceof N)) throw new TypeError("Cannot call a class as a function");
          }
          function b(d) {
            var N = (function(y, K) {
              if (m(y) != "object" || !y) return y;
              var ge = y[Symbol.toPrimitive];
              if (ge !== void 0) {
                var Ne = ge.call(y, "string");
                if (m(Ne) != "object") return Ne;
                throw new TypeError("@@toPrimitive must return a primitive value.");
              }
              return String(y);
            })(d);
            return m(N) == "symbol" ? N : N + "";
          }
          function P(d, N) {
            for (var y = 0; y < N.length; y++) {
              var K = N[y];
              K.enumerable = K.enumerable || false, K.configurable = true, "value" in K && (K.writable = true), Object.defineProperty(d, b(K.key), K);
            }
          }
          function k(d, N, y) {
            return N && P(d.prototype, N), Object.defineProperty(d, "prototype", { writable: false }), d;
          }
          var te = String.fromCodePoint || function() {
            var d, N, y = [], K = -1, ge = arguments.length;
            if (!ge) return "";
            for (var Ne = ""; ++K < ge; ) {
              var Ye = Number(arguments[K]);
              if (!isFinite(Ye) || Ye < 0 || Ye > 1114111 || Math.floor(Ye) != Ye) throw RangeError("Invalid code point: " + Ye);
              Ye <= 65535 ? y.push(Ye) : (d = 55296 + ((Ye -= 65536) >> 10), N = Ye % 1024 + 56320, y.push(d, N)), (K + 1 === ge || y.length > 16384) && (Ne += String.fromCharCode.apply(null, y), y.length = 0);
            }
            return Ne;
          };
          function Ee(d) {
            var N = d.split("-").map((function(y) {
              return "0x".concat(y);
            }));
            return te.apply(null, N);
          }
          function ee(d) {
            return d.reduce((function(N, y) {
              return N.indexOf(y) === -1 && N.push(y), N;
            }), []);
          }
          function Ae(d, N) {
            var y = ee(d), K = ee(N);
            return y.filter((function(ge) {
              return K.indexOf(ge) >= 0;
            }));
          }
          function $(d, N) {
            var y = {};
            for (var K in d) {
              var ge = d[K], Ne = ge;
              Object.prototype.hasOwnProperty.call(N, K) && (Ne = N[K]), m(Ne) === "object" && (Ne = $(ge, Ne)), y[K] = Ne;
            }
            return y;
          }
          function Me(d, N) {
            var y = typeof Symbol < "u" && d[Symbol.iterator] || d["@@iterator"];
            if (!y) {
              if (Array.isArray(d) || (y = (function(Ze, C) {
                if (Ze) {
                  if (typeof Ze == "string") return B(Ze, C);
                  var ue = Object.prototype.toString.call(Ze).slice(8, -1);
                  return ue === "Object" && Ze.constructor && (ue = Ze.constructor.name), ue === "Map" || ue === "Set" ? Array.from(Ze) : ue === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(ue) ? B(Ze, C) : void 0;
                }
              })(d)) || N) {
                y && (d = y);
                var K = 0, ge = function() {
                };
                return { s: ge, n: function() {
                  return K >= d.length ? { done: true } : { done: false, value: d[K++] };
                }, e: function(Ze) {
                  throw Ze;
                }, f: ge };
              }
              throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
            }
            var Ne, Ye = true, ke = false;
            return { s: function() {
              y = y.call(d);
            }, n: function() {
              var Ze = y.next();
              return Ye = Ze.done, Ze;
            }, e: function(Ze) {
              ke = true, Ne = Ze;
            }, f: function() {
              try {
                Ye || y.return == null || y.return();
              } finally {
                if (ke) throw Ne;
              }
            } };
          }
          function B(d, N) {
            (N == null || N > d.length) && (N = d.length);
            for (var y = 0, K = new Array(N); y < N; y++) K[y] = d[y];
            return K;
          }
          var z = /^(?:\:([^\:]+)\:)(?:\:skin-tone-(\d)\:)?$/, W = ["1F3FA", "1F3FB", "1F3FC", "1F3FD", "1F3FE", "1F3FF"], ie = (function() {
            return k((function d(N) {
              var y = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, K = y.emojisToShowFilter, ge = y.include, Ne = y.exclude, Ye = y.custom, ke = y.recent, Ze = y.recentLength, C = Ze === void 0 ? 20 : Ze;
              oe(this, d), this._data = w(N), this._emojisFilter = K || null, this._include = ge || null, this._exclude = Ne || null, this._custom = Ye || [], this._recent = ke || V.get(C), this._emojis = {}, this._nativeEmojis = {}, this._emoticons = {}, this._categories = [], this._recentCategory = { id: "recent", name: "Recent", emojis: [] }, this._customCategory = { id: "custom", name: "Custom", emojis: [] }, this._searchIndex = {}, this.buildIndex(), Object.freeze(this);
            }), [{ key: "buildIndex", value: function() {
              var d = this, N = this._data.categories;
              if (this._include && (N = (N = N.filter((function(Ne) {
                return d._include.includes(Ne.id);
              }))).sort((function(Ne, Ye) {
                var ke = d._include.indexOf(Ne.id), Ze = d._include.indexOf(Ye.id);
                return ke < Ze ? -1 : ke > Ze ? 1 : 0;
              }))), N.forEach((function(Ne) {
                if (d.isCategoryNeeded(Ne.id)) {
                  var Ye = { id: Ne.id, name: Ne.name, emojis: [] };
                  Ne.emojis.forEach((function(ke) {
                    var Ze = d.addEmoji(ke);
                    Ze && Ye.emojis.push(Ze);
                  })), Ye.emojis.length && d._categories.push(Ye);
                }
              })), this.isCategoryNeeded("custom")) {
                if (this._custom.length > 0) {
                  var y, K = Me(this._custom);
                  try {
                    for (K.s(); !(y = K.n()).done; ) {
                      var ge = y.value;
                      this.addCustomEmoji(ge);
                    }
                  } catch (Ne) {
                    K.e(Ne);
                  } finally {
                    K.f();
                  }
                }
                this._customCategory.emojis.length && this._categories.push(this._customCategory);
              }
              this.isCategoryNeeded("recent") && (this._recent.length && this._recent.map((function(Ne) {
                var Ye, ke = Me(d._customCategory.emojis);
                try {
                  for (ke.s(); !(Ye = ke.n()).done; ) {
                    var Ze = Ye.value;
                    if (Ze.id === Ne) return void d._recentCategory.emojis.push(Ze);
                  }
                } catch (C) {
                  ke.e(C);
                } finally {
                  ke.f();
                }
                d.hasEmoji(Ne) && d._recentCategory.emojis.push(d.emoji(Ne));
              })), this._recentCategory.emojis.length && this._categories.unshift(this._recentCategory));
            } }, { key: "findEmoji", value: function(d, N) {
              var y = d.match(z);
              if (y && (d = y[1], y[2] && (N = parseInt(y[2], 10))), this._data.aliases.hasOwnProperty(d) && (d = this._data.aliases[d]), this._emojis.hasOwnProperty(d)) {
                var K = this._emojis[d];
                return N ? K.getSkin(N) : K;
              }
              return this._nativeEmojis.hasOwnProperty(d) ? this._nativeEmojis[d] : null;
            } }, { key: "categories", value: function() {
              return this._categories;
            } }, { key: "emoji", value: function(d) {
              this._data.aliases.hasOwnProperty(d) && (d = this._data.aliases[d]);
              var N = this._emojis[d];
              if (!N) throw new Error("Can not find emoji by id: " + d);
              return N;
            } }, { key: "firstEmoji", value: function() {
              var d = this._emojis[Object.keys(this._emojis)[0]];
              if (!d) throw new Error("Can not get first emoji");
              return d;
            } }, { key: "hasEmoji", value: function(d) {
              return this._data.aliases.hasOwnProperty(d) && (d = this._data.aliases[d]), !!this._emojis[d];
            } }, { key: "nativeEmoji", value: function(d) {
              return this._nativeEmojis.hasOwnProperty(d) ? this._nativeEmojis[d] : null;
            } }, { key: "search", value: function(d, N) {
              var y = this;
              if (N || (N = 75), !d.length) return null;
              if (d == "-" || d == "-1") return [this.emoji("-1")];
              var K, ge = d.toLowerCase().split(/[\s|,|\-|_]+/);
              ge.length > 2 && (ge = [ge[0], ge[1]]), K = ge.map((function(Ye) {
                for (var ke = y._emojis, Ze = y._searchIndex, C = 0, ue = function() {
                  var Ce = Ye[_e];
                  if (C++, Ze[Ce] || (Ze[Ce] = {}), !(Ze = Ze[Ce]).results) {
                    var X = {};
                    for (var Fe in Ze.results = [], Ze.emojis = {}, ke) {
                      var be = ke[Fe], hn = be._data.search, nn = Ye.substr(0, C), yn = hn.indexOf(nn);
                      if (yn != -1) {
                        var fn = yn + 1;
                        nn == Fe && (fn = 0), Ze.results.push(be), Ze.emojis[Fe] = be, X[Fe] = fn;
                      }
                    }
                    Ze.results.sort((function(ta, ji) {
                      return X[ta.id] - X[ji.id];
                    }));
                  }
                  ke = Ze.emojis;
                }, _e = 0; _e < Ye.length; _e++) ue();
                return Ze.results;
              })).filter((function(Ye) {
                return Ye;
              }));
              var Ne = null;
              return (Ne = K.length > 1 ? Ae.apply(null, K) : K.length ? K[0] : []) && Ne.length > N && (Ne = Ne.slice(0, N)), Ne;
            } }, { key: "addCustomEmoji", value: function(d) {
              var N = Object.assign({}, d, { id: d.short_names[0], custom: true });
              N.search || (N.search = A(N));
              var y = new h(N);
              return this._emojis[y.id] = y, this._customCategory.emojis.push(y), y;
            } }, { key: "addEmoji", value: function(d) {
              var N = this, y = this._data.emojis[d];
              if (!this.isEmojiNeeded(y)) return false;
              var K = new h(y);
              if (this._emojis[d] = K, K.native && (this._nativeEmojis[K.native] = K), K._skins) for (var ge in K._skins) {
                var Ne = K._skins[ge];
                Ne.native && (this._nativeEmojis[Ne.native] = Ne);
              }
              return K.emoticons && K.emoticons.forEach((function(Ye) {
                N._emoticons[Ye] || (N._emoticons[Ye] = d);
              })), K;
            } }, { key: "isCategoryNeeded", value: function(d) {
              var N = !this._include || !this._include.length || this._include.indexOf(d) > -1, y = !(!this._exclude || !this._exclude.length) && this._exclude.indexOf(d) > -1;
              return !(!N || y);
            } }, { key: "isEmojiNeeded", value: function(d) {
              return !this._emojisFilter || this._emojisFilter(d);
            } }]);
          })(), h = (function() {
            return k((function d(N) {
              if (oe(this, d), this._data = Object.assign({}, N), this._skins = null, this._data.skin_variations) for (var y in this._skins = [], W) {
                var K = W[y], ge = this._data.skin_variations[K], Ne = Object.assign({}, N);
                for (var Ye in ge) Ne[Ye] = ge[Ye];
                delete Ne.skin_variations, Ne.skin_tone = parseInt(y) + 1, this._skins.push(new d(Ne));
              }
              for (var ke in this._sanitized = U(this._data), this._sanitized) this[ke] = this._sanitized[ke];
              this.short_names = this._data.short_names, this.short_name = this._data.short_names[0], Object.freeze(this);
            }), [{ key: "getSkin", value: function(d) {
              return d && d != "native" && this._skins ? this._skins[d - 1] : this;
            } }, { key: "getPosition", value: function() {
              var d = +(1.6666666666666667 * this._data.sheet_x).toFixed(2), N = +(100 / 60 * this._data.sheet_y).toFixed(2);
              return "".concat(d, "% ").concat(N, "%");
            } }, { key: "ariaLabel", value: function() {
              return [this.native].concat(this.short_names).filter(Boolean).join(", ");
            } }]);
          })(), F = (function() {
            return k((function d(N, y, K, ge, Ne, Ye, ke) {
              oe(this, d), this._emoji = N, this._native = ge, this._skin = y, this._set = K, this._fallback = Ne, this.canRender = this._canRender(), this.cssClass = this._cssClass(), this.cssStyle = this._cssStyle(ke), this.content = this._content(), this.title = Ye === true ? N.short_name : null, this.ariaLabel = N.ariaLabel(), Object.freeze(this);
            }), [{ key: "getEmoji", value: function() {
              return this._emoji.getSkin(this._skin);
            } }, { key: "_canRender", value: function() {
              return this._isCustom() || this._isNative() || this._hasEmoji() || this._fallback;
            } }, { key: "_cssClass", value: function() {
              return ["emoji-set-" + this._set, "emoji-type-" + this._emojiType()];
            } }, { key: "_cssStyle", value: function(d) {
              var N = {};
              return this._isCustom() ? N = { backgroundImage: "url(" + this.getEmoji()._data.imageUrl + ")", backgroundSize: "100%", width: d + "px", height: d + "px" } : this._hasEmoji() && !this._isNative() && (N = { backgroundPosition: this.getEmoji().getPosition() }), d && (N = this._isNative() ? Object.assign(N, { fontSize: Math.round(0.95 * d * 10) / 10 + "px" }) : Object.assign(N, { width: d + "px", height: d + "px" })), N;
            } }, { key: "_content", value: function() {
              return this._isCustom() ? "" : this._isNative() ? this.getEmoji().native : this._hasEmoji() ? "" : this._fallback ? this._fallback(this.getEmoji()) : null;
            } }, { key: "_isNative", value: function() {
              return this._native;
            } }, { key: "_isCustom", value: function() {
              return this.getEmoji().custom;
            } }, { key: "_hasEmoji", value: function() {
              if (!this.getEmoji()._data) return false;
              var d = this.getEmoji()._data["has_img_" + this._set];
              return d === void 0 || d;
            } }, { key: "_emojiType", value: function() {
              return this._isCustom() ? "custom" : this._isNative() ? "native" : this._hasEmoji() ? "image" : "fallback";
            } }]);
          })();
          function U(d) {
            var N = d.name, y = d.short_names, K = d.skin_tone, ge = d.skin_variations, Ne = d.emoticons, Ye = d.unified, ke = d.custom, Ze = d.imageUrl, C = d.id || y[0], ue = ":".concat(C, ":");
            return ke ? { id: C, name: N, colons: ue, emoticons: Ne, custom: ke, imageUrl: Ze } : (K && (ue += ":skin-tone-".concat(K, ":")), { id: C, name: N, colons: ue, emoticons: Ne, unified: Ye.toLowerCase(), skin: K || (ge ? 1 : null), native: Ee(Ye) });
          }
          function ne(d, N, y) {
            return (N = b(N)) in d ? Object.defineProperty(d, N, { value: y, enumerable: true, configurable: true, writable: true }) : d[N] = y, d;
          }
          var Y = { native: { type: Boolean, default: false }, tooltip: { type: Boolean, default: false }, fallback: { type: Function }, skin: { type: Number, default: 1 }, set: { type: String, default: "apple" }, emoji: { type: [String, Object], required: true }, size: { type: Number, default: null }, tag: { type: String, default: "span" } }, pe = { perLine: { type: Number, default: 9 }, maxSearchResults: { type: Number, default: 75 }, emojiSize: { type: Number, default: 24 }, title: { type: String, default: "Emoji Mart™" }, emoji: { type: String, default: "department_store" }, color: { type: String, default: "#ae65c5" }, set: { type: String, default: "apple" }, skin: { type: Number, default: null }, defaultSkin: { type: Number, default: 1 }, native: { type: Boolean, default: false }, emojiTooltip: { type: Boolean, default: false }, autoFocus: { type: Boolean, default: false }, i18n: { type: Object, default: function() {
            return {};
          } }, showPreview: { type: Boolean, default: true }, showSearch: { type: Boolean, default: true }, showCategories: { type: Boolean, default: true }, showSkinTones: { type: Boolean, default: true }, infiniteScroll: { type: Boolean, default: true }, pickerStyles: { type: Object, default: function() {
            return {};
          } } };
          function q(d, N) {
            var y = Object.keys(d);
            if (Object.getOwnPropertySymbols) {
              var K = Object.getOwnPropertySymbols(d);
              N && (K = K.filter((function(ge) {
                return Object.getOwnPropertyDescriptor(d, ge).enumerable;
              }))), y.push.apply(y, K);
            }
            return y;
          }
          function Te(d) {
            for (var N = 1; N < arguments.length; N++) {
              var y = arguments[N] != null ? arguments[N] : {};
              N % 2 ? q(Object(y), true).forEach((function(K) {
                ne(d, K, y[K]);
              })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(d, Object.getOwnPropertyDescriptors(y)) : q(Object(y)).forEach((function(K) {
                Object.defineProperty(d, K, Object.getOwnPropertyDescriptor(y, K));
              }));
            }
            return d;
          }
          var R = Z({ props: Te(Te({}, Y), {}, { data: { type: Object, required: true } }), emits: ["click", "mouseenter", "mouseleave"], computed: { view: function() {
            return new F(this.emojiObject, this.skin, this.set, this.native, this.fallback, this.tooltip, this.size);
          }, sanitizedData: function() {
            return this.emojiObject._sanitized;
          }, title: function() {
            return this.tooltip ? this.emojiObject.short_name : null;
          }, emojiObject: function() {
            return typeof this.emoji == "string" ? this.data.findEmoji(this.emoji) : this.emoji;
          } }, created: function() {
          }, methods: { onClick: function() {
            this.$emit("click", this.emojiObject);
          }, onMouseEnter: function() {
            this.$emit("mouseenter", this.emojiObject);
          }, onMouseLeave: function() {
            this.$emit("mouseleave", this.emojiObject);
          } } }, (function() {
            var d = this, N = d._self._c;
            return d.view.canRender ? N(d.tag, { tag: "component", staticClass: "emoji-mart-emoji", attrs: { title: d.view.title, "aria-label": d.view.ariaLabel, "data-title": d.title }, on: { mouseenter: d.onMouseEnter, mouseleave: d.onMouseLeave, click: d.onClick } }, [N("span", { class: d.view.cssClass, style: d.view.cssStyle }, [d._v(d._s(d.view.content))])]) : d._e();
          }), []).exports, me = Z({ props: { data: { type: Object, required: true }, i18n: { type: Object, required: true }, id: { type: String, required: true }, name: { type: String, required: true }, emojis: { type: Array }, emojiProps: { type: Object, required: true } }, methods: { activeClass: function(d) {
            return this.emojiProps.selectedEmoji && this.emojiProps.selectedEmojiCategory && this.emojiProps.selectedEmoji.id == d.id && this.emojiProps.selectedEmojiCategory.id == this.id ? "emoji-mart-emoji-selected" : "";
          } }, computed: { isVisible: function() {
            return !!this.emojis;
          }, isSearch: function() {
            return this.name == "Search";
          }, hasResults: function() {
            return this.emojis.length > 0;
          }, emojiObjects: function() {
            var d = this;
            return this.emojis.map((function(N) {
              return { emojiObject: N, emojiView: new F(N, d.emojiProps.skin, d.emojiProps.set, d.emojiProps.native, d.emojiProps.fallback, d.emojiProps.emojiTooltip, d.emojiProps.emojiSize) };
            }));
          } }, components: { Emoji: R } }, (function() {
            var d = this, N = d._self._c;
            return d.isVisible && (d.isSearch || d.hasResults) ? N("section", { class: { "emoji-mart-category": true, "emoji-mart-no-results": !d.hasResults }, attrs: { "aria-label": d.i18n.categories[d.id] } }, [N("div", { staticClass: "emoji-mart-category-label" }, [N("h3", { staticClass: "emoji-mart-category-label" }, [d._v(d._s(d.i18n.categories[d.id]))])]), d._v(" "), d._l(d.emojiObjects, (function(y) {
              var K = y.emojiObject, ge = y.emojiView;
              return [ge.canRender ? N("button", { key: K.id, staticClass: "emoji-mart-emoji", class: d.activeClass(K), attrs: { "aria-label": ge.ariaLabel, role: "option", "aria-selected": "false", "aria-posinset": "1", "aria-setsize": "1812", type: "button", "data-title": K.short_name, title: ge.title }, on: { mouseenter: function(Ne) {
                d.emojiProps.onEnter(ge.getEmoji());
              }, mouseleave: function(Ne) {
                d.emojiProps.onLeave(ge.getEmoji());
              }, click: function(Ne) {
                d.emojiProps.onClick(ge.getEmoji());
              } } }, [N("span", { class: ge.cssClass, style: ge.cssStyle }, [d._v(d._s(ge.content))])]) : d._e()];
            })), d._v(" "), d.hasResults ? d._e() : N("div", [N("emoji", { attrs: { data: d.data, emoji: "sleuth_or_spy", native: d.emojiProps.native, skin: d.emojiProps.skin, set: d.emojiProps.set } }), d._v(" "), N("div", { staticClass: "emoji-mart-no-results-label" }, [d._v(d._s(d.i18n.notfound))])], 1)], 2) : d._e();
          }), []).exports, Se = Z({ props: { skin: { type: Number, required: true } }, emits: ["change"], data: function() {
            return { opened: false };
          }, methods: { onClick: function(d) {
            this.opened && d != this.skin && this.$emit("change", d), this.opened = !this.opened;
          } } }, (function() {
            var d = this, N = d._self._c;
            return N("div", { class: { "emoji-mart-skin-swatches": true, "emoji-mart-skin-swatches-opened": d.opened } }, d._l(6, (function(y) {
              return N("span", { key: y, class: { "emoji-mart-skin-swatch": true, "emoji-mart-skin-swatch-selected": d.skin == y } }, [N("span", { class: "emoji-mart-skin emoji-mart-skin-tone-" + y, on: { click: function(K) {
                return d.onClick(y);
              } } })]);
            })), 0);
          }), []).exports, ve = Z({ props: { data: { type: Object, required: true }, title: { type: String, required: true }, emoji: { type: [String, Object] }, idleEmoji: { type: [String, Object], required: true }, showSkinTones: { type: Boolean, default: true }, emojiProps: { type: Object, required: true }, skinProps: { type: Object, required: true }, onSkinChange: { type: Function, required: true } }, computed: { emojiData: function() {
            return this.emoji ? this.emoji : {};
          }, emojiShortNames: function() {
            return this.emojiData.short_names;
          }, emojiEmoticons: function() {
            return this.emojiData.emoticons;
          } }, components: { Emoji: R, Skins: Se } }, (function() {
            var d = this, N = d._self._c;
            return N("div", { staticClass: "emoji-mart-preview" }, [d.emoji ? [N("div", { staticClass: "emoji-mart-preview-emoji" }, [N("emoji", { attrs: { data: d.data, emoji: d.emoji, native: d.emojiProps.native, skin: d.emojiProps.skin, set: d.emojiProps.set } })], 1), d._v(" "), N("div", { staticClass: "emoji-mart-preview-data" }, [N("div", { staticClass: "emoji-mart-preview-name" }, [d._v(d._s(d.emoji.name))]), d._v(" "), N("div", { staticClass: "emoji-mart-preview-shortnames" }, d._l(d.emojiShortNames, (function(y) {
              return N("span", { key: y, staticClass: "emoji-mart-preview-shortname" }, [d._v(":" + d._s(y) + ":")]);
            })), 0), d._v(" "), N("div", { staticClass: "emoji-mart-preview-emoticons" }, d._l(d.emojiEmoticons, (function(y) {
              return N("span", { key: y, staticClass: "emoji-mart-preview-emoticon" }, [d._v(d._s(y))]);
            })), 0)])] : [N("div", { staticClass: "emoji-mart-preview-emoji" }, [N("emoji", { attrs: { data: d.data, emoji: d.idleEmoji, native: d.emojiProps.native, skin: d.emojiProps.skin, set: d.emojiProps.set } })], 1), d._v(" "), N("div", { staticClass: "emoji-mart-preview-data" }, [N("span", { staticClass: "emoji-mart-title-label" }, [d._v(d._s(d.title))])]), d._v(" "), d.showSkinTones ? N("div", { staticClass: "emoji-mart-preview-skins" }, [N("skins", { attrs: { skin: d.skinProps.skin }, on: { change: function(y) {
              return d.onSkinChange(y);
            } } })], 1) : d._e()]], 2);
          }), []).exports, ze = Z({ props: { data: { type: Object, required: true }, i18n: { type: Object, required: true }, autoFocus: { type: Boolean, default: false }, onSearch: { type: Function, required: true }, onArrowLeft: { type: Function, required: false }, onArrowRight: { type: Function, required: false }, onArrowDown: { type: Function, required: false }, onArrowUp: { type: Function, required: false }, onEnter: { type: Function, required: false } }, emits: ["search", "enter", "arrowUp", "arrowDown", "arrowRight", "arrowLeft"], data: function() {
            return { value: "" };
          }, computed: { emojiIndex: function() {
            return this.data;
          } }, watch: { value: function() {
            this.$emit("search", this.value);
          } }, methods: { clear: function() {
            this.value = "";
          } }, mounted: function() {
            var d = this.$el.querySelector("input");
            this.autoFocus && d.focus();
          } }, (function() {
            var d = this, N = d._self._c;
            return N("div", { staticClass: "emoji-mart-search" }, [N("input", { directives: [{ name: "model", rawName: "v-model", value: d.value, expression: "value" }], attrs: { type: "text", placeholder: d.i18n.search, role: "textbox", "aria-autocomplete": "list", "aria-owns": "emoji-mart-list", "aria-label": "Search for an emoji", "aria-describedby": "emoji-mart-search-description" }, domProps: { value: d.value }, on: { keydown: [function(y) {
              return !y.type.indexOf("key") && d._k(y.keyCode, "left", 37, y.key, ["Left", "ArrowLeft"]) || "button" in y && y.button !== 0 ? null : function(K) {
                return d.$emit("arrowLeft", K);
              }.apply(null, arguments);
            }, function(y) {
              return !y.type.indexOf("key") && d._k(y.keyCode, "right", 39, y.key, ["Right", "ArrowRight"]) || "button" in y && y.button !== 2 ? null : function() {
                return d.$emit("arrowRight");
              }.apply(null, arguments);
            }, function(y) {
              return !y.type.indexOf("key") && d._k(y.keyCode, "down", 40, y.key, ["Down", "ArrowDown"]) ? null : function() {
                return d.$emit("arrowDown");
              }.apply(null, arguments);
            }, function(y) {
              return !y.type.indexOf("key") && d._k(y.keyCode, "up", 38, y.key, ["Up", "ArrowUp"]) ? null : function(K) {
                return d.$emit("arrowUp", K);
              }.apply(null, arguments);
            }, function(y) {
              return !y.type.indexOf("key") && d._k(y.keyCode, "enter", 13, y.key, "Enter") ? null : function() {
                return d.$emit("enter");
              }.apply(null, arguments);
            }], input: function(y) {
              y.target.composing || (d.value = y.target.value);
            } } }), d._v(" "), N("span", { staticClass: "hidden", attrs: { id: "emoji-picker-search-description" } }, [d._v(`Use the left, right, up and down arrow keys to navigate the emoji search
    results.`)])]);
          }), []), Ue = ze.exports;
          function We(d, N) {
            (N == null || N > d.length) && (N = d.length);
            for (var y = 0, K = new Array(N); y < N; y++) K[y] = d[y];
            return K;
          }
          a(537);
          var ht = (function() {
            return k((function d(N) {
              var y, K;
              oe(this, d), this._vm = N, this._data = N.data, this._perLine = N.perLine, this._categories = [], (y = this._categories).push.apply(y, (function(ge) {
                if (Array.isArray(ge)) return We(ge);
              })(K = this._data.categories()) || (function(ge) {
                if (typeof Symbol < "u" && ge[Symbol.iterator] != null || ge["@@iterator"] != null) return Array.from(ge);
              })(K) || (function(ge, Ne) {
                if (ge) {
                  if (typeof ge == "string") return We(ge, Ne);
                  var Ye = Object.prototype.toString.call(ge).slice(8, -1);
                  return Ye === "Object" && ge.constructor && (Ye = ge.constructor.name), Ye === "Map" || Ye === "Set" ? Array.from(ge) : Ye === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(Ye) ? We(ge, Ne) : void 0;
                }
              })(K) || (function() {
                throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
              })()), this._categories = this._categories.filter((function(ge) {
                return ge.emojis.length > 0;
              })), this._categories[0].first = true, Object.freeze(this._categories), this.activeCategory = this._categories[0], this.searchEmojis = null, this.previewEmoji = null, this.previewEmojiCategoryIdx = 0, this.previewEmojiIdx = -1;
            }), [{ key: "onScroll", value: function() {
              for (var d = this._vm.$refs.scroll.scrollTop, N = this.filteredCategories[0], y = 0, K = this.filteredCategories.length; y < K; y++) {
                var ge = this.filteredCategories[y], Ne = this._vm.getCategoryComponent(y);
                if (Ne && Ne.$el.offsetTop - 50 > d) break;
                N = ge;
              }
              this.activeCategory = N;
            } }, { key: "allCategories", get: function() {
              return this._categories;
            } }, { key: "filteredCategories", get: function() {
              return this.searchEmojis ? [{ id: "search", name: "Search", emojis: this.searchEmojis }] : this._categories.filter((function(d) {
                return d.emojis.length > 0;
              }));
            } }, { key: "previewEmojiCategory", get: function() {
              return this.previewEmojiCategoryIdx >= 0 ? this.filteredCategories[this.previewEmojiCategoryIdx] : null;
            } }, { key: "onAnchorClick", value: function(d) {
              var N = this;
              if (!this.searchEmojis) {
                var y = this.filteredCategories.indexOf(d), K = this._vm.getCategoryComponent(y);
                this._vm.infiniteScroll ? (function() {
                  if (K) {
                    var ge = K.$el.offsetTop;
                    d.first && (ge = 0), N._vm.$refs.scroll.scrollTop = ge;
                  }
                })() : this.activeCategory = this.filteredCategories[y];
              }
            } }, { key: "onSearch", value: function(d) {
              var N = this._data.search(d, this.maxSearchResults);
              this.searchEmojis = N, this.previewEmojiCategoryIdx = 0, this.previewEmojiIdx = 0, this.updatePreviewEmoji();
            } }, { key: "onEmojiEnter", value: function(d) {
              this.previewEmoji = d, this.previewEmojiIdx = -1, this.previewEmojiCategoryIdx = -1;
            } }, { key: "onEmojiLeave", value: function(d) {
              this.previewEmoji = null;
            } }, { key: "onArrowLeft", value: function() {
              this.previewEmojiIdx > 0 ? this.previewEmojiIdx -= 1 : (this.previewEmojiCategoryIdx -= 1, this.previewEmojiCategoryIdx < 0 ? this.previewEmojiCategoryIdx = 0 : this.previewEmojiIdx = this.filteredCategories[this.previewEmojiCategoryIdx].emojis.length - 1), this.updatePreviewEmoji();
            } }, { key: "onArrowRight", value: function() {
              this.previewEmojiIdx < this.emojisLength(this.previewEmojiCategoryIdx) - 1 ? this.previewEmojiIdx += 1 : (this.previewEmojiCategoryIdx += 1, this.previewEmojiCategoryIdx >= this.filteredCategories.length ? this.previewEmojiCategoryIdx = this.filteredCategories.length - 1 : this.previewEmojiIdx = 0), this.updatePreviewEmoji();
            } }, { key: "onArrowDown", value: function() {
              if (this.previewEmojiIdx == -1) return this.onArrowRight();
              var d = this.filteredCategories[this.previewEmojiCategoryIdx].emojis.length, N = this._perLine;
              this.previewEmojiIdx + N > d && (N = d % this._perLine);
              for (var y = 0; y < N; y++) this.onArrowRight();
              this.updatePreviewEmoji();
            } }, { key: "onArrowUp", value: function() {
              var d = this._perLine;
              this.previewEmojiIdx - d < 0 && (d = this.previewEmojiCategoryIdx > 0 ? this.filteredCategories[this.previewEmojiCategoryIdx - 1].emojis.length % this._perLine : 0);
              for (var N = 0; N < d; N++) this.onArrowLeft();
              this.updatePreviewEmoji();
            } }, { key: "updatePreviewEmoji", value: function() {
              var d = this;
              this.previewEmoji = this.filteredCategories[this.previewEmojiCategoryIdx].emojis[this.previewEmojiIdx], this._vm.$nextTick((function() {
                var N = d._vm.$refs.scroll, y = N.querySelector(".emoji-mart-emoji-selected"), K = N.offsetTop - N.offsetHeight;
                y && y.offsetTop + y.offsetHeight > K + N.scrollTop && (N.scrollTop += y.offsetHeight), y && y.offsetTop < N.scrollTop && (N.scrollTop -= y.offsetHeight);
              }));
            } }, { key: "emojisLength", value: function(d) {
              return d == -1 ? 0 : this.filteredCategories[d].emojis.length;
            } }]);
          })();
          function G(d, N) {
            var y = Object.keys(d);
            if (Object.getOwnPropertySymbols) {
              var K = Object.getOwnPropertySymbols(d);
              N && (K = K.filter((function(ge) {
                return Object.getOwnPropertyDescriptor(d, ge).enumerable;
              }))), y.push.apply(y, K);
            }
            return y;
          }
          function Re(d) {
            for (var N = 1; N < arguments.length; N++) {
              var y = arguments[N] != null ? arguments[N] : {};
              N % 2 ? G(Object(y), true).forEach((function(K) {
                ne(d, K, y[K]);
              })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(d, Object.getOwnPropertyDescriptors(y)) : G(Object(y)).forEach((function(K) {
                Object.defineProperty(d, K, Object.getOwnPropertyDescriptor(y, K));
              }));
            }
            return d;
          }
          var Qe = { search: "Search", notfound: "No Emoji Found", categories: { search: "Search Results", recent: "Frequently Used", smileys: "Smileys & Emotion", people: "People & Body", nature: "Animals & Nature", foods: "Food & Drink", activity: "Activity", places: "Travel & Places", objects: "Objects", symbols: "Symbols", flags: "Flags", custom: "Custom" } }, St = { props: Re(Re({}, pe), {}, { data: { type: Object, required: true } }), emits: ["select", "skin-change"], data: function() {
            return { activeSkin: this.skin || f.get("skin") || this.defaultSkin, view: new ht(this) };
          }, computed: { customStyles: function() {
            return Re({ width: this.calculateWidth + "px" }, this.pickerStyles);
          }, emojiProps: function() {
            return { native: this.native, skin: this.activeSkin, set: this.set, emojiTooltip: this.emojiTooltip, emojiSize: this.emojiSize, selectedEmoji: this.view.previewEmoji, selectedEmojiCategory: this.view.previewEmojiCategory, onEnter: this.onEmojiEnter.bind(this), onLeave: this.onEmojiLeave.bind(this), onClick: this.onEmojiClick.bind(this) };
          }, skinProps: function() {
            return { skin: this.activeSkin };
          }, calculateWidth: function() {
            return this.perLine * (this.emojiSize + 12) + 12 + 2 + (function() {
              if (typeof document > "u") return 0;
              var d = document.createElement("div");
              d.style.width = "100px", d.style.height = "100px", d.style.overflow = "scroll", d.style.position = "absolute", d.style.top = "-9999px", document.body.appendChild(d);
              var N = d.offsetWidth - d.clientWidth;
              return document.body.removeChild(d), N;
            })();
          }, filteredCategories: function() {
            return this.view.filteredCategories;
          }, mergedI18n: function() {
            return Object.freeze($(Qe, this.i18n));
          }, idleEmoji: function() {
            try {
              return this.data.emoji(this.emoji);
            } catch (d) {
              return console.error("Default preview emoji `" + this.emoji + "` is not available, check the Picker `emoji` property"), console.error(d), this.data.firstEmoji();
            }
          }, isSearching: function() {
            return this.view.searchEmojis != null;
          } }, watch: { skin: function() {
            this.onSkinChange(this.skin);
          } }, methods: { onScroll: function() {
            this.infiniteScroll && !this.waitingForPaint && (this.waitingForPaint = true, window.requestAnimationFrame(this.onScrollPaint.bind(this)));
          }, onScrollPaint: function() {
            this.waitingForPaint = false, this.view.onScroll();
          }, onAnchorClick: function(d) {
            this.view.onAnchorClick(d);
          }, onSearch: function(d) {
            this.view.onSearch(d);
          }, onEmojiEnter: function(d) {
            this.view.onEmojiEnter(d);
          }, onEmojiLeave: function(d) {
            this.view.onEmojiLeave(d);
          }, onArrowLeft: function(d) {
            var N = this.view.previewEmojiIdx;
            this.view.onArrowLeft(), d && this.view.previewEmojiIdx !== N && d.preventDefault();
          }, onArrowRight: function() {
            this.view.onArrowRight();
          }, onArrowDown: function() {
            this.view.onArrowDown();
          }, onArrowUp: function(d) {
            this.view.onArrowUp(), d.preventDefault();
          }, onEnter: function() {
            this.view.previewEmoji && (this.$emit("select", this.view.previewEmoji), V.add(this.view.previewEmoji));
          }, onEmojiClick: function(d) {
            this.$emit("select", d), V.add(d);
          }, onTextSelect: function(d) {
            d.stopPropagation();
          }, onSkinChange: function(d) {
            this.activeSkin = d, f.update({ skin: d }), this.$emit("skin-change", d);
          }, getCategoryComponent: function(d) {
            var N = this.$refs["categories_" + d];
            return N && "0" in N ? N[0] : N;
          } }, components: { Anchors: re, Category: me, Preview: ve, Search: Ue } }, un = Z(St, (function() {
            var d = this, N = d._self._c;
            return N("section", { staticClass: "emoji-mart emoji-mart-static", style: d.customStyles }, [d.showCategories ? N("div", { staticClass: "emoji-mart-bar emoji-mart-bar-anchors" }, [N("anchors", { attrs: { data: d.data, i18n: d.mergedI18n, color: d.color, categories: d.view.allCategories, "active-category": d.view.activeCategory }, on: { click: d.onAnchorClick } })], 1) : d._e(), d._v(" "), d._t("searchTemplate", (function() {
              return [d.showSearch ? N("search", { ref: "search", attrs: { data: d.data, i18n: d.mergedI18n, "auto-focus": d.autoFocus, "on-search": d.onSearch }, on: { search: d.onSearch, arrowLeft: d.onArrowLeft, arrowRight: d.onArrowRight, arrowDown: d.onArrowDown, arrowUp: d.onArrowUp, enter: d.onEnter, select: d.onTextSelect } }) : d._e()];
            }), { data: d.data, i18n: d.i18n, autoFocus: d.autoFocus, onSearch: d.onSearch }), d._v(" "), N("div", { ref: "scroll", staticClass: "emoji-mart-scroll", attrs: { role: "tabpanel" }, on: { scroll: d.onScroll } }, [N("div", { ref: "scrollContent", attrs: { id: "emoji-mart-list", role: "listbox", "aria-expanded": "true" } }, [d._t("customCategory"), d._v(" "), d._l(d.view.filteredCategories, (function(y, K) {
              return N("category", { directives: [{ name: "show", rawName: "v-show", value: d.infiniteScroll || y == d.view.activeCategory || d.isSearching, expression: "infiniteScroll || category == view.activeCategory || isSearching" }], key: y.id, ref: "categories_" + K, refInFor: true, attrs: { data: d.data, i18n: d.mergedI18n, id: y.id, name: y.name, emojis: y.emojis, "emoji-props": d.emojiProps } });
            }))], 2)]), d._v(" "), d._t("previewTemplate", (function() {
              return [d.showPreview ? N("div", { staticClass: "emoji-mart-bar emoji-mart-bar-preview" }, [N("preview", { attrs: { data: d.data, title: d.title, emoji: d.view.previewEmoji, "idle-emoji": d.idleEmoji, "show-skin-tones": d.showSkinTones, "emoji-props": d.emojiProps, "skin-props": d.skinProps, "on-skin-change": d.onSkinChange } })], 1) : d._e()];
            }), { data: d.data, title: d.title, emoji: d.view.previewEmoji, idleEmoji: d.idleEmoji, showSkinTones: d.showSkinTones, emojiProps: d.emojiProps, skinProps: d.skinProps, onSkinChange: d.onSkinChange })], 2);
          }), []), we = un.exports;
        })(), i;
      })();
    }));
  })(Ui)), Ui.exports;
}
if (qS(), e0.getBuilder("nextcloud-vue").persist(true).build(), Xe(Gc, Uc, o0, Pc), ce("Search emoji"), ce("No emoji found"), ce("Search results"), ce("Frequently used"), ce("Smileys & Emotion"), ce("People & Body"), ce("Animals & Nature"), ce("Food & Drink"), ce("Activities"), ce("Travel & Places"), ce("Objects"), ce("Symbols"), ce("Flags"), ce("Custom"), new kr(255, 222, 52, ce("Neutral skin color")), new kr(228, 205, 166, ce("Light skin tone")), new kr(250, 221, 192, ce("Medium light skin tone")), new kr(174, 129, 87, ce("Medium skin tone")), new kr(158, 113, 88, ce("Medium dark skin tone")), new kr(96, 79, 69, ce("Dark skin tone")), ce("Pick an emoji"), Number.parseInt(window.getComputedStyle(document.body).getPropertyValue("--default-grid-baseline")), Number.parseInt(window.getComputedStyle(document.body).getPropertyValue("--default-clickable-area")), Number.parseInt(window.getComputedStyle(document.body).getPropertyValue("--clickable-area-small")), Xe(zc), Wi()?.circles?.teamResourceProviders, Xe(jc), Xe($c), ce("Related resources"), ce("Anything shared with the same group of people will show up here"), Array.prototype.find || (Array.prototype.find = function(t) {
  if (this === null) throw new TypeError("Array.prototype.find called on null or undefined");
  if (typeof t != "function") throw new TypeError("predicate must be a function");
  for (var e = Object(this), n = e.length >>> 0, r = arguments[1], a, i = 0; i < n; i++) if (a = e[i], t.call(r, a, i, e)) return a;
}), window && typeof window.CustomEvent != "function") {
  let t = function(e, n) {
    n = n || { bubbles: false, cancelable: false, detail: void 0 };
    var r = document.createEvent("CustomEvent");
    return r.initCustomEvent(e, n.bubbles, n.cancelable, n.detail), r;
  };
  typeof window.Event < "u" && (t.prototype = window.Event.prototype), window.CustomEvent = t;
}
Xe(Vc, o0), ce("Write a message …"), Xe(Qc), { ...Xi.props, placeholder: ce("Select a tag") }, Xe(Ko);
const KS = { name: "HelpCircleIcon", emits: ["click"], props: { title: { type: String }, fillColor: { type: String, default: "currentColor" }, size: { type: Number, default: 24 } } }, JS = ["aria-hidden", "aria-label"], XS = ["fill", "width", "height"], ev = { d: "M15.07,11.25L14.17,12.17C13.45,12.89 13,13.5 13,15H11V14.5C11,13.39 11.45,12.39 12.17,11.67L13.41,10.41C13.78,10.05 14,9.55 14,9C14,7.89 13.1,7 12,7A2,2 0 0,0 10,9H8A4,4 0 0,1 12,5A4,4 0 0,1 16,9C16,9.88 15.64,10.67 15.07,11.25M13,19H11V17H13M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12C22,6.47 17.5,2 12,2Z" }, tv = { key: 0 };
function nv(t, e, n, r, a, i) {
  return p(), M("span", Le(t.$attrs, { "aria-hidden": n.title ? null : "true", "aria-label": n.title, class: "material-design-icon help-circle-icon", role: "img", onClick: e[0] || (e[0] = (s) => t.$emit("click", s)) }), [(p(), M("svg", { fill: n.fillColor, class: "material-design-icon__svg", width: n.size, height: n.size, viewBox: "0 0 24 24" }, [j("path", ev, [n.title ? (p(), M("title", tv, Be(n.title), 1)) : x("", true)])], 8, XS))], 16, JS);
}
const rv = nt(KS, [["render", nv]]);
Xe();
const av = { class: "settings-section" }, iv = { class: "settings-section__name" }, sv = ["aria-label", "href", "title"], ov = { key: 0, class: "settings-section__desc" }, lv = Ve({ __name: "NcSettingsSection", props: { name: {}, description: { default: "" }, docUrl: { default: "" } }, setup(t) {
  const e = ce("External documentation");
  return (n, r) => (p(), M("div", av, [j("h2", iv, [Mt(Be(n.name) + " ", 1), n.docUrl ? (p(), M("a", { key: 0, "aria-label": S(e), class: "settings-section__info", href: n.docUrl, rel: "noreferrer nofollow", target: "_blank", title: S(e) }, [Oe(rv, { size: 20 })], 8, sv)) : x("", true)]), n.description ? (p(), M("p", ov, Be(n.description), 1)) : x("", true), le(n.$slots, "default", {}, void 0, true)]));
} }), uv = nt(lv, [["__scopeId", "data-v-dbbb3fd7"]]);
Xe(Wc), ts(function(t) {
  this.loadGroup(t);
}, 200);
const cv = { key: 0 }, Tv = { class: "input-wrapper" }, dv = ["disabled", "type", "inputmode", "placeholder"], hv = Ve({ __name: "InputDiv", props: rn({ signalingClass: { default: "" }, placeholder: { default: "" }, type: { default: "text" }, inputmode: {}, useNumModifiers: { type: Boolean, default: false }, modifierStepValue: { default: 1 }, numMax: {}, numMin: {}, numWrap: { type: Boolean, default: false }, focus: { type: Boolean, default: false }, submit: { type: Boolean, default: false }, helperText: { default: null }, label: { default: null }, useNumericVariant: { type: Boolean, default: false }, disabled: { type: Boolean, default: false } }, { modelValue: { required: true }, modelModifiers: {} }), emits: rn(["input", "change", "submit"], ["update:modelValue"]), setup(t, { emit: e }) {
  const n = An(t, "modelValue"), r = { mounted: (E) => {
    t.focus && E.focus();
  } }, a = e, i = Q(() => typeof n.value == "number" ? n.value : parseInt(n.value)), s = Q(() => t.signalingClass === "valid" ? "success" : t.signalingClass === "invalid" ? "error" : t.signalingClass), l = Q(() => !t.useNumModifiers && s.value === "checking"), o = Q(() => !l.value && !t.useNumModifiers && s.value === "error"), c = Q(() => !l.value && !t.useNumModifiers && s.value === "success" && !t.submit), u = Q(() => !l.value && !t.useNumModifiers && t.submit && s.value !== "error");
  function T() {
    return t.numMin && t.numMax && t.numMin >= t.numMax ? (Xc.warn("numMin is greater or equal than numMax. Validation will be skipped."), false) : true;
  }
  function f(E) {
    return t.numMax && E > t.numMax && (t.numWrap && t.numMin && T() && i.value === t.numMax ? E = t.numMin : E = t.numMax), t.numMin && E < t.numMin && (t.numWrap && t.numMax && T() && i.value === t.numMin ? E = t.numMax : E = t.numMin), E;
  }
  function m() {
    const E = f(i.value + t.modifierStepValue);
    n.value !== E && (n.value = E, a("change"));
  }
  function v() {
    const E = f(i.value - t.modifierStepValue);
    n.value !== E && (n.value = E, a("change"));
  }
  return gt(() => {
    T();
  }), (E, A) => (p(), M("div", { class: ye(["input-div", { numeric: E.useNumModifiers || E.inputmode === "numeric" }]) }, [E.label ? (p(), M("label", cv, Be(E.label), 1)) : x("", true), j("div", Tv, [E.useNumModifiers && !E.useNumericVariant ? (p(), De(S($t), { key: 0, class: "date-add-button", title: S(Vi)("agora", "minus"), variant: "tertiary-no-background", onClick: v }, { icon: he(() => [Oe(bd)]), _: 1 }, 8, ["title"])) : x("", true), Ot(j("input", { "onUpdate:modelValue": A[0] || (A[0] = (g) => n.value = g), disabled: E.disabled, type: E.type, inputmode: E.inputmode, placeholder: E.placeholder, class: ye([{ "has-modifier": E.useNumModifiers && E.useNumericVariant, "has-submit": E.submit }, s.value]), onInput: A[1] || (A[1] = (g) => a("input")), onChange: A[2] || (A[2] = (g) => a("change")), onKeyup: A[3] || (A[3] = Ct((g) => a("submit"), ["enter"])) }, null, 42, dv), [[qc, n.value], [r]]), l.value ? (p(), De(S(f0), { key: 1, class: "signaling-icon spinner" })) : o.value ? (p(), De(uh, { key: 2, class: "signaling-icon error" })) : c.value ? (p(), De(d0, { key: 3, class: "signaling-icon success" })) : u.value ? (p(), De(nh, { key: 4, class: "signaling-icon submit", onClick: A[4] || (A[4] = (g) => a("submit")) })) : x("", true), E.useNumModifiers && !E.useNumericVariant ? (p(), De(S($t), { key: 5, title: S(Vi)("agora", "plus"), variant: "tertiary-no-background", onClick: m }, { icon: he(() => [Oe(Ld)]), _: 1 }, 8, ["title"])) : x("", true), E.useNumModifiers && E.useNumericVariant ? (p(), De(Wd, { key: 6, class: "modifier subtract", onClick: A[5] || (A[5] = (g) => v()) })) : x("", true), E.useNumModifiers && E.useNumericVariant ? (p(), De(h0, { key: 7, class: "modifier add", onClick: A[6] || (A[6] = (g) => m()) })) : x("", true)]), E.helperText !== null ? (p(), M("div", { key: 1, class: ye(["helper", s.value]) }, Be(E.helperText), 3)) : x("", true)], 2));
} }), fv = Cn(hv, [["__scopeId", "data-v-014cf401"]]);
var ea = {}, go, Eu;
function Av() {
  return Eu || (Eu = 1, go = function() {
    return typeof Promise == "function" && Promise.prototype && Promise.prototype.then;
  }), go;
}
var Ro = {}, fr = {}, pu;
function Br() {
  if (pu) return fr;
  pu = 1;
  let t;
  const e = [0, 26, 44, 70, 100, 134, 172, 196, 242, 292, 346, 404, 466, 532, 581, 655, 733, 815, 901, 991, 1085, 1156, 1258, 1364, 1474, 1588, 1706, 1828, 1921, 2051, 2185, 2323, 2465, 2611, 2761, 2876, 3034, 3196, 3362, 3532, 3706];
  return fr.getSymbolSize = function(r) {
    if (!r) throw new Error('"version" cannot be null or undefined');
    if (r < 1 || r > 40) throw new Error('"version" should be in range from 1 to 40');
    return r * 4 + 17;
  }, fr.getSymbolTotalCodewords = function(r) {
    return e[r];
  }, fr.getBCHDigit = function(n) {
    let r = 0;
    for (; n !== 0; ) r++, n >>>= 1;
    return r;
  }, fr.setToSJISFunction = function(r) {
    if (typeof r != "function") throw new Error('"toSJISFunc" is not a valid function.');
    t = r;
  }, fr.isKanjiModeEnabled = function() {
    return typeof t < "u";
  }, fr.toSJIS = function(r) {
    return t(r);
  }, fr;
}
var No = {}, Du;
function Fo() {
  return Du || (Du = 1, (function(t) {
    t.L = { bit: 1 }, t.M = { bit: 0 }, t.Q = { bit: 3 }, t.H = { bit: 2 };
    function e(n) {
      if (typeof n != "string") throw new Error("Param is not a string");
      switch (n.toLowerCase()) {
        case "l":
        case "low":
          return t.L;
        case "m":
        case "medium":
          return t.M;
        case "q":
        case "quartile":
          return t.Q;
        case "h":
        case "high":
          return t.H;
        default:
          throw new Error("Unknown EC Level: " + n);
      }
    }
    t.isValid = function(r) {
      return r && typeof r.bit < "u" && r.bit >= 0 && r.bit < 4;
    }, t.from = function(r, a) {
      if (t.isValid(r)) return r;
      try {
        return e(r);
      } catch {
        return a;
      }
    };
  })(No)), No;
}
var yo, Su;
function mv() {
  if (Su) return yo;
  Su = 1;
  function t() {
    this.buffer = [], this.length = 0;
  }
  return t.prototype = { get: function(e) {
    const n = Math.floor(e / 8);
    return (this.buffer[n] >>> 7 - e % 8 & 1) === 1;
  }, put: function(e, n) {
    for (let r = 0; r < n; r++) this.putBit((e >>> n - r - 1 & 1) === 1);
  }, getLengthInBits: function() {
    return this.length;
  }, putBit: function(e) {
    const n = Math.floor(this.length / 8);
    this.buffer.length <= n && this.buffer.push(0), e && (this.buffer[n] |= 128 >>> this.length % 8), this.length++;
  } }, yo = t, yo;
}
var Oo, vu;
function Ev() {
  if (vu) return Oo;
  vu = 1;
  function t(e) {
    if (!e || e < 1) throw new Error("BitMatrix size must be defined and greater than 0");
    this.size = e, this.data = new Uint8Array(e * e), this.reservedBit = new Uint8Array(e * e);
  }
  return t.prototype.set = function(e, n, r, a) {
    const i = e * this.size + n;
    this.data[i] = r, a && (this.reservedBit[i] = true);
  }, t.prototype.get = function(e, n) {
    return this.data[e * this.size + n];
  }, t.prototype.xor = function(e, n, r) {
    this.data[e * this.size + n] ^= r;
  }, t.prototype.isReserved = function(e, n) {
    return this.reservedBit[e * this.size + n];
  }, Oo = t, Oo;
}
var Mo = {}, gu;
function pv() {
  return gu || (gu = 1, (function(t) {
    const e = Br().getSymbolSize;
    t.getRowColCoords = function(r) {
      if (r === 1) return [];
      const a = Math.floor(r / 7) + 2, i = e(r), s = i === 145 ? 26 : Math.ceil((i - 13) / (2 * a - 2)) * 2, l = [i - 7];
      for (let o = 1; o < a - 1; o++) l[o] = l[o - 1] - s;
      return l.push(6), l.reverse();
    }, t.getPositions = function(r) {
      const a = [], i = t.getRowColCoords(r), s = i.length;
      for (let l = 0; l < s; l++) for (let o = 0; o < s; o++) l === 0 && o === 0 || l === 0 && o === s - 1 || l === s - 1 && o === 0 || a.push([i[l], i[o]]);
      return a;
    };
  })(Mo)), Mo;
}
var bo = {}, Ru;
function Dv() {
  if (Ru) return bo;
  Ru = 1;
  const t = Br().getSymbolSize, e = 7;
  return bo.getPositions = function(r) {
    const a = t(r);
    return [[0, 0], [a - e, 0], [0, a - e]];
  }, bo;
}
var Yo = {}, Nu;
function Sv() {
  return Nu || (Nu = 1, (function(t) {
    t.Patterns = { PATTERN000: 0, PATTERN001: 1, PATTERN010: 2, PATTERN011: 3, PATTERN100: 4, PATTERN101: 5, PATTERN110: 6, PATTERN111: 7 };
    const e = { N1: 3, N2: 3, N3: 40, N4: 10 };
    t.isValid = function(a) {
      return a != null && a !== "" && !isNaN(a) && a >= 0 && a <= 7;
    }, t.from = function(a) {
      return t.isValid(a) ? parseInt(a, 10) : void 0;
    }, t.getPenaltyN1 = function(a) {
      const i = a.size;
      let s = 0, l = 0, o = 0, c = null, u = null;
      for (let T = 0; T < i; T++) {
        l = o = 0, c = u = null;
        for (let f = 0; f < i; f++) {
          let m = a.get(T, f);
          m === c ? l++ : (l >= 5 && (s += e.N1 + (l - 5)), c = m, l = 1), m = a.get(f, T), m === u ? o++ : (o >= 5 && (s += e.N1 + (o - 5)), u = m, o = 1);
        }
        l >= 5 && (s += e.N1 + (l - 5)), o >= 5 && (s += e.N1 + (o - 5));
      }
      return s;
    }, t.getPenaltyN2 = function(a) {
      const i = a.size;
      let s = 0;
      for (let l = 0; l < i - 1; l++) for (let o = 0; o < i - 1; o++) {
        const c = a.get(l, o) + a.get(l, o + 1) + a.get(l + 1, o) + a.get(l + 1, o + 1);
        (c === 4 || c === 0) && s++;
      }
      return s * e.N2;
    }, t.getPenaltyN3 = function(a) {
      const i = a.size;
      let s = 0, l = 0, o = 0;
      for (let c = 0; c < i; c++) {
        l = o = 0;
        for (let u = 0; u < i; u++) l = l << 1 & 2047 | a.get(c, u), u >= 10 && (l === 1488 || l === 93) && s++, o = o << 1 & 2047 | a.get(u, c), u >= 10 && (o === 1488 || o === 93) && s++;
      }
      return s * e.N3;
    }, t.getPenaltyN4 = function(a) {
      let i = 0;
      const s = a.data.length;
      for (let o = 0; o < s; o++) i += a.data[o];
      return Math.abs(Math.ceil(i * 100 / s / 5) - 10) * e.N4;
    };
    function n(r, a, i) {
      switch (r) {
        case t.Patterns.PATTERN000:
          return (a + i) % 2 === 0;
        case t.Patterns.PATTERN001:
          return a % 2 === 0;
        case t.Patterns.PATTERN010:
          return i % 3 === 0;
        case t.Patterns.PATTERN011:
          return (a + i) % 3 === 0;
        case t.Patterns.PATTERN100:
          return (Math.floor(a / 2) + Math.floor(i / 3)) % 2 === 0;
        case t.Patterns.PATTERN101:
          return a * i % 2 + a * i % 3 === 0;
        case t.Patterns.PATTERN110:
          return (a * i % 2 + a * i % 3) % 2 === 0;
        case t.Patterns.PATTERN111:
          return (a * i % 3 + (a + i) % 2) % 2 === 0;
        default:
          throw new Error("bad maskPattern:" + r);
      }
    }
    t.applyMask = function(a, i) {
      const s = i.size;
      for (let l = 0; l < s; l++) for (let o = 0; o < s; o++) i.isReserved(o, l) || i.xor(o, l, n(a, o, l));
    }, t.getBestMask = function(a, i) {
      const s = Object.keys(t.Patterns).length;
      let l = 0, o = 1 / 0;
      for (let c = 0; c < s; c++) {
        i(c), t.applyMask(c, a);
        const u = t.getPenaltyN1(a) + t.getPenaltyN2(a) + t.getPenaltyN3(a) + t.getPenaltyN4(a);
        t.applyMask(c, a), u < o && (o = u, l = c);
      }
      return l;
    };
  })(Yo)), Yo;
}
var Gi = {}, Fu;
function yu() {
  if (Fu) return Gi;
  Fu = 1;
  const t = Fo(), e = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 2, 2, 4, 1, 2, 4, 4, 2, 4, 4, 4, 2, 4, 6, 5, 2, 4, 6, 6, 2, 5, 8, 8, 4, 5, 8, 8, 4, 5, 8, 11, 4, 8, 10, 11, 4, 9, 12, 16, 4, 9, 16, 16, 6, 10, 12, 18, 6, 10, 17, 16, 6, 11, 16, 19, 6, 13, 18, 21, 7, 14, 21, 25, 8, 16, 20, 25, 8, 17, 23, 25, 9, 17, 23, 34, 9, 18, 25, 30, 10, 20, 27, 32, 12, 21, 29, 35, 12, 23, 34, 37, 12, 25, 34, 40, 13, 26, 35, 42, 14, 28, 38, 45, 15, 29, 40, 48, 16, 31, 43, 51, 17, 33, 45, 54, 18, 35, 48, 57, 19, 37, 51, 60, 19, 38, 53, 63, 20, 40, 56, 66, 21, 43, 59, 70, 22, 45, 62, 74, 24, 47, 65, 77, 25, 49, 68, 81], n = [7, 10, 13, 17, 10, 16, 22, 28, 15, 26, 36, 44, 20, 36, 52, 64, 26, 48, 72, 88, 36, 64, 96, 112, 40, 72, 108, 130, 48, 88, 132, 156, 60, 110, 160, 192, 72, 130, 192, 224, 80, 150, 224, 264, 96, 176, 260, 308, 104, 198, 288, 352, 120, 216, 320, 384, 132, 240, 360, 432, 144, 280, 408, 480, 168, 308, 448, 532, 180, 338, 504, 588, 196, 364, 546, 650, 224, 416, 600, 700, 224, 442, 644, 750, 252, 476, 690, 816, 270, 504, 750, 900, 300, 560, 810, 960, 312, 588, 870, 1050, 336, 644, 952, 1110, 360, 700, 1020, 1200, 390, 728, 1050, 1260, 420, 784, 1140, 1350, 450, 812, 1200, 1440, 480, 868, 1290, 1530, 510, 924, 1350, 1620, 540, 980, 1440, 1710, 570, 1036, 1530, 1800, 570, 1064, 1590, 1890, 600, 1120, 1680, 1980, 630, 1204, 1770, 2100, 660, 1260, 1860, 2220, 720, 1316, 1950, 2310, 750, 1372, 2040, 2430];
  return Gi.getBlocksCount = function(a, i) {
    switch (i) {
      case t.L:
        return e[(a - 1) * 4 + 0];
      case t.M:
        return e[(a - 1) * 4 + 1];
      case t.Q:
        return e[(a - 1) * 4 + 2];
      case t.H:
        return e[(a - 1) * 4 + 3];
      default:
        return;
    }
  }, Gi.getTotalCodewordsCount = function(a, i) {
    switch (i) {
      case t.L:
        return n[(a - 1) * 4 + 0];
      case t.M:
        return n[(a - 1) * 4 + 1];
      case t.Q:
        return n[(a - 1) * 4 + 2];
      case t.H:
        return n[(a - 1) * 4 + 3];
      default:
        return;
    }
  }, Gi;
}
var wo = {}, wa = {}, Ou;
function vv() {
  if (Ou) return wa;
  Ou = 1;
  const t = new Uint8Array(512), e = new Uint8Array(256);
  return (function() {
    let r = 1;
    for (let a = 0; a < 255; a++) t[a] = r, e[r] = a, r <<= 1, r & 256 && (r ^= 285);
    for (let a = 255; a < 512; a++) t[a] = t[a - 255];
  })(), wa.log = function(r) {
    if (r < 1) throw new Error("log(" + r + ")");
    return e[r];
  }, wa.exp = function(r) {
    return t[r];
  }, wa.mul = function(r, a) {
    return r === 0 || a === 0 ? 0 : t[e[r] + e[a]];
  }, wa;
}
var Mu;
function gv() {
  return Mu || (Mu = 1, (function(t) {
    const e = vv();
    t.mul = function(r, a) {
      const i = new Uint8Array(r.length + a.length - 1);
      for (let s = 0; s < r.length; s++) for (let l = 0; l < a.length; l++) i[s + l] ^= e.mul(r[s], a[l]);
      return i;
    }, t.mod = function(r, a) {
      let i = new Uint8Array(r);
      for (; i.length - a.length >= 0; ) {
        const s = i[0];
        for (let o = 0; o < a.length; o++) i[o] ^= e.mul(a[o], s);
        let l = 0;
        for (; l < i.length && i[l] === 0; ) l++;
        i = i.slice(l);
      }
      return i;
    }, t.generateECPolynomial = function(r) {
      let a = new Uint8Array([1]);
      for (let i = 0; i < r; i++) a = t.mul(a, new Uint8Array([1, e.exp(i)]));
      return a;
    };
  })(wo)), wo;
}
var _o, bu;
function Rv() {
  if (bu) return _o;
  bu = 1;
  const t = gv();
  function e(n) {
    this.genPoly = void 0, this.degree = n, this.degree && this.initialize(this.degree);
  }
  return e.prototype.initialize = function(r) {
    this.degree = r, this.genPoly = t.generateECPolynomial(this.degree);
  }, e.prototype.encode = function(r) {
    if (!this.genPoly) throw new Error("Encoder not initialized");
    const a = new Uint8Array(r.length + this.degree);
    a.set(r);
    const i = t.mod(a, this.genPoly), s = this.degree - i.length;
    if (s > 0) {
      const l = new Uint8Array(this.degree);
      return l.set(i, s), l;
    }
    return i;
  }, _o = e, _o;
}
var Bo = {}, Zo = {}, Io = {}, Yu;
function wu() {
  return Yu || (Yu = 1, Io.isValid = function(e) {
    return !isNaN(e) && e >= 1 && e <= 40;
  }), Io;
}
var Zn = {}, _u;
function Bu() {
  if (_u) return Zn;
  _u = 1;
  const t = "[0-9]+", e = "[A-Z $%*+\\-./:]+";
  let n = "(?:[u3000-u303F]|[u3040-u309F]|[u30A0-u30FF]|[uFF00-uFFEF]|[u4E00-u9FAF]|[u2605-u2606]|[u2190-u2195]|u203B|[u2010u2015u2018u2019u2025u2026u201Cu201Du2225u2260]|[u0391-u0451]|[u00A7u00A8u00B1u00B4u00D7u00F7])+";
  n = n.replace(/u/g, "\\u");
  const r = "(?:(?![A-Z0-9 $%*+\\-./:]|" + n + `)(?:.|[\r
]))+`;
  Zn.KANJI = new RegExp(n, "g"), Zn.BYTE_KANJI = new RegExp("[^A-Z0-9 $%*+\\-./:]+", "g"), Zn.BYTE = new RegExp(r, "g"), Zn.NUMERIC = new RegExp(t, "g"), Zn.ALPHANUMERIC = new RegExp(e, "g");
  const a = new RegExp("^" + n + "$"), i = new RegExp("^" + t + "$"), s = new RegExp("^[A-Z0-9 $%*+\\-./:]+$");
  return Zn.testKanji = function(o) {
    return a.test(o);
  }, Zn.testNumeric = function(o) {
    return i.test(o);
  }, Zn.testAlphanumeric = function(o) {
    return s.test(o);
  }, Zn;
}
var Zu;
function Zr() {
  return Zu || (Zu = 1, (function(t) {
    const e = wu(), n = Bu();
    t.NUMERIC = { id: "Numeric", bit: 1, ccBits: [10, 12, 14] }, t.ALPHANUMERIC = { id: "Alphanumeric", bit: 2, ccBits: [9, 11, 13] }, t.BYTE = { id: "Byte", bit: 4, ccBits: [8, 16, 16] }, t.KANJI = { id: "Kanji", bit: 8, ccBits: [8, 10, 12] }, t.MIXED = { bit: -1 }, t.getCharCountIndicator = function(i, s) {
      if (!i.ccBits) throw new Error("Invalid mode: " + i);
      if (!e.isValid(s)) throw new Error("Invalid version: " + s);
      return s >= 1 && s < 10 ? i.ccBits[0] : s < 27 ? i.ccBits[1] : i.ccBits[2];
    }, t.getBestModeForData = function(i) {
      return n.testNumeric(i) ? t.NUMERIC : n.testAlphanumeric(i) ? t.ALPHANUMERIC : n.testKanji(i) ? t.KANJI : t.BYTE;
    }, t.toString = function(i) {
      if (i && i.id) return i.id;
      throw new Error("Invalid mode");
    }, t.isValid = function(i) {
      return i && i.bit && i.ccBits;
    };
    function r(a) {
      if (typeof a != "string") throw new Error("Param is not a string");
      switch (a.toLowerCase()) {
        case "numeric":
          return t.NUMERIC;
        case "alphanumeric":
          return t.ALPHANUMERIC;
        case "kanji":
          return t.KANJI;
        case "byte":
          return t.BYTE;
        default:
          throw new Error("Unknown mode: " + a);
      }
    }
    t.from = function(i, s) {
      if (t.isValid(i)) return i;
      try {
        return r(i);
      } catch {
        return s;
      }
    };
  })(Zo)), Zo;
}
var Iu;
function Nv() {
  return Iu || (Iu = 1, (function(t) {
    const e = Br(), n = yu(), r = Fo(), a = Zr(), i = wu(), s = 7973, l = e.getBCHDigit(s);
    function o(f, m, v) {
      for (let E = 1; E <= 40; E++) if (m <= t.getCapacity(E, v, f)) return E;
    }
    function c(f, m) {
      return a.getCharCountIndicator(f, m) + 4;
    }
    function u(f, m) {
      let v = 0;
      return f.forEach(function(E) {
        const A = c(E.mode, m);
        v += A + E.getBitsLength();
      }), v;
    }
    function T(f, m) {
      for (let v = 1; v <= 40; v++) if (u(f, v) <= t.getCapacity(v, m, a.MIXED)) return v;
    }
    t.from = function(m, v) {
      return i.isValid(m) ? parseInt(m, 10) : v;
    }, t.getCapacity = function(m, v, E) {
      if (!i.isValid(m)) throw new Error("Invalid QR Code version");
      typeof E > "u" && (E = a.BYTE);
      const A = e.getSymbolTotalCodewords(m), g = n.getTotalCodewordsCount(m, v), O = (A - g) * 8;
      if (E === a.MIXED) return O;
      const D = O - c(E, m);
      switch (E) {
        case a.NUMERIC:
          return Math.floor(D / 10 * 3);
        case a.ALPHANUMERIC:
          return Math.floor(D / 11 * 2);
        case a.KANJI:
          return Math.floor(D / 13);
        case a.BYTE:
        default:
          return Math.floor(D / 8);
      }
    }, t.getBestVersionForData = function(m, v) {
      let E;
      const A = r.from(v, r.M);
      if (Array.isArray(m)) {
        if (m.length > 1) return T(m, A);
        if (m.length === 0) return 1;
        E = m[0];
      } else E = m;
      return o(E.mode, E.getLength(), A);
    }, t.getEncodedBits = function(m) {
      if (!i.isValid(m) || m < 7) throw new Error("Invalid QR Code version");
      let v = m << 12;
      for (; e.getBCHDigit(v) - l >= 0; ) v ^= s << e.getBCHDigit(v) - l;
      return m << 12 | v;
    };
  })(Bo)), Bo;
}
var Lo = {}, Lu;
function Fv() {
  if (Lu) return Lo;
  Lu = 1;
  const t = Br(), e = 1335, n = 21522, r = t.getBCHDigit(e);
  return Lo.getEncodedBits = function(i, s) {
    const l = i.bit << 3 | s;
    let o = l << 10;
    for (; t.getBCHDigit(o) - r >= 0; ) o ^= e << t.getBCHDigit(o) - r;
    return (l << 10 | o) ^ n;
  }, Lo;
}
var ko = {}, Co, ku;
function yv() {
  if (ku) return Co;
  ku = 1;
  const t = Zr();
  function e(n) {
    this.mode = t.NUMERIC, this.data = n.toString();
  }
  return e.getBitsLength = function(r) {
    return 10 * Math.floor(r / 3) + (r % 3 ? r % 3 * 3 + 1 : 0);
  }, e.prototype.getLength = function() {
    return this.data.length;
  }, e.prototype.getBitsLength = function() {
    return e.getBitsLength(this.data.length);
  }, e.prototype.write = function(r) {
    let a, i, s;
    for (a = 0; a + 3 <= this.data.length; a += 3) i = this.data.substr(a, 3), s = parseInt(i, 10), r.put(s, 10);
    const l = this.data.length - a;
    l > 0 && (i = this.data.substr(a), s = parseInt(i, 10), r.put(s, l * 3 + 1));
  }, Co = e, Co;
}
var xo, Cu;
function Ov() {
  if (Cu) return xo;
  Cu = 1;
  const t = Zr(), e = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", " ", "$", "%", "*", "+", "-", ".", "/", ":"];
  function n(r) {
    this.mode = t.ALPHANUMERIC, this.data = r;
  }
  return n.getBitsLength = function(a) {
    return 11 * Math.floor(a / 2) + 6 * (a % 2);
  }, n.prototype.getLength = function() {
    return this.data.length;
  }, n.prototype.getBitsLength = function() {
    return n.getBitsLength(this.data.length);
  }, n.prototype.write = function(a) {
    let i;
    for (i = 0; i + 2 <= this.data.length; i += 2) {
      let s = e.indexOf(this.data[i]) * 45;
      s += e.indexOf(this.data[i + 1]), a.put(s, 11);
    }
    this.data.length % 2 && a.put(e.indexOf(this.data[i]), 6);
  }, xo = n, xo;
}
var Ho, xu;
function Mv() {
  if (xu) return Ho;
  xu = 1;
  const t = Zr();
  function e(n) {
    this.mode = t.BYTE, typeof n == "string" ? this.data = new TextEncoder().encode(n) : this.data = new Uint8Array(n);
  }
  return e.getBitsLength = function(r) {
    return r * 8;
  }, e.prototype.getLength = function() {
    return this.data.length;
  }, e.prototype.getBitsLength = function() {
    return e.getBitsLength(this.data.length);
  }, e.prototype.write = function(n) {
    for (let r = 0, a = this.data.length; r < a; r++) n.put(this.data[r], 8);
  }, Ho = e, Ho;
}
var Po, Hu;
function bv() {
  if (Hu) return Po;
  Hu = 1;
  const t = Zr(), e = Br();
  function n(r) {
    this.mode = t.KANJI, this.data = r;
  }
  return n.getBitsLength = function(a) {
    return a * 13;
  }, n.prototype.getLength = function() {
    return this.data.length;
  }, n.prototype.getBitsLength = function() {
    return n.getBitsLength(this.data.length);
  }, n.prototype.write = function(r) {
    let a;
    for (a = 0; a < this.data.length; a++) {
      let i = e.toSJIS(this.data[a]);
      if (i >= 33088 && i <= 40956) i -= 33088;
      else if (i >= 57408 && i <= 60351) i -= 49472;
      else throw new Error("Invalid SJIS character: " + this.data[a] + `
Make sure your charset is UTF-8`);
      i = (i >>> 8 & 255) * 192 + (i & 255), r.put(i, 13);
    }
  }, Po = n, Po;
}
var Uo = { exports: {} }, Pu;
function Yv() {
  return Pu || (Pu = 1, (function(t) {
    var e = { single_source_shortest_paths: function(n, r, a) {
      var i = {}, s = {};
      s[r] = 0;
      var l = e.PriorityQueue.make();
      l.push(r, 0);
      for (var o, c, u, T, f, m, v, E, A; !l.empty(); ) {
        o = l.pop(), c = o.value, T = o.cost, f = n[c] || {};
        for (u in f) f.hasOwnProperty(u) && (m = f[u], v = T + m, E = s[u], A = typeof s[u] > "u", (A || E > v) && (s[u] = v, l.push(u, v), i[u] = c));
      }
      if (typeof a < "u" && typeof s[a] > "u") {
        var g = ["Could not find a path from ", r, " to ", a, "."].join("");
        throw new Error(g);
      }
      return i;
    }, extract_shortest_path_from_predecessor_list: function(n, r) {
      for (var a = [], i = r; i; ) a.push(i), n[i], i = n[i];
      return a.reverse(), a;
    }, find_path: function(n, r, a) {
      var i = e.single_source_shortest_paths(n, r, a);
      return e.extract_shortest_path_from_predecessor_list(i, a);
    }, PriorityQueue: { make: function(n) {
      var r = e.PriorityQueue, a = {}, i;
      n = n || {};
      for (i in r) r.hasOwnProperty(i) && (a[i] = r[i]);
      return a.queue = [], a.sorter = n.sorter || r.default_sorter, a;
    }, default_sorter: function(n, r) {
      return n.cost - r.cost;
    }, push: function(n, r) {
      var a = { value: n, cost: r };
      this.queue.push(a), this.queue.sort(this.sorter);
    }, pop: function() {
      return this.queue.shift();
    }, empty: function() {
      return this.queue.length === 0;
    } } };
    t.exports = e;
  })(Uo)), Uo.exports;
}
var Uu;
function wv() {
  return Uu || (Uu = 1, (function(t) {
    const e = Zr(), n = yv(), r = Ov(), a = Mv(), i = bv(), s = Bu(), l = Br(), o = Yv();
    function c(g) {
      return unescape(encodeURIComponent(g)).length;
    }
    function u(g, O, D) {
      const w = [];
      let L;
      for (; (L = g.exec(D)) !== null; ) w.push({ data: L[0], index: L.index, mode: O, length: L[0].length });
      return w;
    }
    function T(g) {
      const O = u(s.NUMERIC, e.NUMERIC, g), D = u(s.ALPHANUMERIC, e.ALPHANUMERIC, g);
      let w, L;
      return l.isKanjiModeEnabled() ? (w = u(s.BYTE, e.BYTE, g), L = u(s.KANJI, e.KANJI, g)) : (w = u(s.BYTE_KANJI, e.BYTE, g), L = []), O.concat(D, w, L).sort(function(I, V) {
        return I.index - V.index;
      }).map(function(I) {
        return { data: I.data, mode: I.mode, length: I.length };
      });
    }
    function f(g, O) {
      switch (O) {
        case e.NUMERIC:
          return n.getBitsLength(g);
        case e.ALPHANUMERIC:
          return r.getBitsLength(g);
        case e.KANJI:
          return i.getBitsLength(g);
        case e.BYTE:
          return a.getBitsLength(g);
      }
    }
    function m(g) {
      return g.reduce(function(O, D) {
        const w = O.length - 1 >= 0 ? O[O.length - 1] : null;
        return w && w.mode === D.mode ? (O[O.length - 1].data += D.data, O) : (O.push(D), O);
      }, []);
    }
    function v(g) {
      const O = [];
      for (let D = 0; D < g.length; D++) {
        const w = g[D];
        switch (w.mode) {
          case e.NUMERIC:
            O.push([w, { data: w.data, mode: e.ALPHANUMERIC, length: w.length }, { data: w.data, mode: e.BYTE, length: w.length }]);
            break;
          case e.ALPHANUMERIC:
            O.push([w, { data: w.data, mode: e.BYTE, length: w.length }]);
            break;
          case e.KANJI:
            O.push([w, { data: w.data, mode: e.BYTE, length: c(w.data) }]);
            break;
          case e.BYTE:
            O.push([{ data: w.data, mode: e.BYTE, length: c(w.data) }]);
        }
      }
      return O;
    }
    function E(g, O) {
      const D = {}, w = { start: {} };
      let L = ["start"];
      for (let _ = 0; _ < g.length; _++) {
        const I = g[_], V = [];
        for (let H = 0; H < I.length; H++) {
          const Z = I[H], J = "" + _ + H;
          V.push(J), D[J] = { node: Z, lastCount: 0 }, w[J] = {};
          for (let re = 0; re < L.length; re++) {
            const oe = L[re];
            D[oe] && D[oe].node.mode === Z.mode ? (w[oe][J] = f(D[oe].lastCount + Z.length, Z.mode) - f(D[oe].lastCount, Z.mode), D[oe].lastCount += Z.length) : (D[oe] && (D[oe].lastCount = Z.length), w[oe][J] = f(Z.length, Z.mode) + 4 + e.getCharCountIndicator(Z.mode, O));
          }
        }
        L = V;
      }
      for (let _ = 0; _ < L.length; _++) w[L[_]].end = 0;
      return { map: w, table: D };
    }
    function A(g, O) {
      let D;
      const w = e.getBestModeForData(g);
      if (D = e.from(O, w), D !== e.BYTE && D.bit < w.bit) throw new Error('"' + g + '" cannot be encoded with mode ' + e.toString(D) + `.
 Suggested mode is: ` + e.toString(w));
      switch (D === e.KANJI && !l.isKanjiModeEnabled() && (D = e.BYTE), D) {
        case e.NUMERIC:
          return new n(g);
        case e.ALPHANUMERIC:
          return new r(g);
        case e.KANJI:
          return new i(g);
        case e.BYTE:
          return new a(g);
      }
    }
    t.fromArray = function(O) {
      return O.reduce(function(D, w) {
        return typeof w == "string" ? D.push(A(w, null)) : w.data && D.push(A(w.data, w.mode)), D;
      }, []);
    }, t.fromString = function(O, D) {
      const w = T(O, l.isKanjiModeEnabled()), L = v(w), _ = E(L, D), I = o.find_path(_.map, "start", "end"), V = [];
      for (let H = 1; H < I.length - 1; H++) V.push(_.table[I[H]].node);
      return t.fromArray(m(V));
    }, t.rawSplit = function(O) {
      return t.fromArray(T(O, l.isKanjiModeEnabled()));
    };
  })(ko)), ko;
}
var Gu;
function _v() {
  if (Gu) return Ro;
  Gu = 1;
  const t = Br(), e = Fo(), n = mv(), r = Ev(), a = pv(), i = Dv(), s = Sv(), l = yu(), o = Rv(), c = Nv(), u = Fv(), T = Zr(), f = wv();
  function m(_, I) {
    const V = _.size, H = i.getPositions(I);
    for (let Z = 0; Z < H.length; Z++) {
      const J = H[Z][0], re = H[Z][1];
      for (let oe = -1; oe <= 7; oe++) if (!(J + oe <= -1 || V <= J + oe)) for (let b = -1; b <= 7; b++) re + b <= -1 || V <= re + b || (oe >= 0 && oe <= 6 && (b === 0 || b === 6) || b >= 0 && b <= 6 && (oe === 0 || oe === 6) || oe >= 2 && oe <= 4 && b >= 2 && b <= 4 ? _.set(J + oe, re + b, true, true) : _.set(J + oe, re + b, false, true));
    }
  }
  function v(_) {
    const I = _.size;
    for (let V = 8; V < I - 8; V++) {
      const H = V % 2 === 0;
      _.set(V, 6, H, true), _.set(6, V, H, true);
    }
  }
  function E(_, I) {
    const V = a.getPositions(I);
    for (let H = 0; H < V.length; H++) {
      const Z = V[H][0], J = V[H][1];
      for (let re = -2; re <= 2; re++) for (let oe = -2; oe <= 2; oe++) re === -2 || re === 2 || oe === -2 || oe === 2 || re === 0 && oe === 0 ? _.set(Z + re, J + oe, true, true) : _.set(Z + re, J + oe, false, true);
    }
  }
  function A(_, I) {
    const V = _.size, H = c.getEncodedBits(I);
    let Z, J, re;
    for (let oe = 0; oe < 18; oe++) Z = Math.floor(oe / 3), J = oe % 3 + V - 8 - 3, re = (H >> oe & 1) === 1, _.set(Z, J, re, true), _.set(J, Z, re, true);
  }
  function g(_, I, V) {
    const H = _.size, Z = u.getEncodedBits(I, V);
    let J, re;
    for (J = 0; J < 15; J++) re = (Z >> J & 1) === 1, J < 6 ? _.set(J, 8, re, true) : J < 8 ? _.set(J + 1, 8, re, true) : _.set(H - 15 + J, 8, re, true), J < 8 ? _.set(8, H - J - 1, re, true) : J < 9 ? _.set(8, 15 - J - 1 + 1, re, true) : _.set(8, 15 - J - 1, re, true);
    _.set(H - 8, 8, 1, true);
  }
  function O(_, I) {
    const V = _.size;
    let H = -1, Z = V - 1, J = 7, re = 0;
    for (let oe = V - 1; oe > 0; oe -= 2) for (oe === 6 && oe--; ; ) {
      for (let b = 0; b < 2; b++) if (!_.isReserved(Z, oe - b)) {
        let P = false;
        re < I.length && (P = (I[re] >>> J & 1) === 1), _.set(Z, oe - b, P), J--, J === -1 && (re++, J = 7);
      }
      if (Z += H, Z < 0 || V <= Z) {
        Z -= H, H = -H;
        break;
      }
    }
  }
  function D(_, I, V) {
    const H = new n();
    V.forEach(function(b) {
      H.put(b.mode.bit, 4), H.put(b.getLength(), T.getCharCountIndicator(b.mode, _)), b.write(H);
    });
    const Z = t.getSymbolTotalCodewords(_), J = l.getTotalCodewordsCount(_, I), re = (Z - J) * 8;
    for (H.getLengthInBits() + 4 <= re && H.put(0, 4); H.getLengthInBits() % 8 !== 0; ) H.putBit(0);
    const oe = (re - H.getLengthInBits()) / 8;
    for (let b = 0; b < oe; b++) H.put(b % 2 ? 17 : 236, 8);
    return w(H, _, I);
  }
  function w(_, I, V) {
    const H = t.getSymbolTotalCodewords(I), Z = l.getTotalCodewordsCount(I, V), J = H - Z, re = l.getBlocksCount(I, V), oe = H % re, b = re - oe, P = Math.floor(H / re), k = Math.floor(J / re), te = k + 1, Ee = P - k, ee = new o(Ee);
    let Ae = 0;
    const $ = new Array(re), Me = new Array(re);
    let B = 0;
    const z = new Uint8Array(_.buffer);
    for (let U = 0; U < re; U++) {
      const ne = U < b ? k : te;
      $[U] = z.slice(Ae, Ae + ne), Me[U] = ee.encode($[U]), Ae += ne, B = Math.max(B, ne);
    }
    const W = new Uint8Array(H);
    let ie = 0, h, F;
    for (h = 0; h < B; h++) for (F = 0; F < re; F++) h < $[F].length && (W[ie++] = $[F][h]);
    for (h = 0; h < Ee; h++) for (F = 0; F < re; F++) W[ie++] = Me[F][h];
    return W;
  }
  function L(_, I, V, H) {
    let Z;
    if (Array.isArray(_)) Z = f.fromArray(_);
    else if (typeof _ == "string") {
      let P = I;
      if (!P) {
        const k = f.rawSplit(_);
        P = c.getBestVersionForData(k, V);
      }
      Z = f.fromString(_, P || 40);
    } else throw new Error("Invalid data");
    const J = c.getBestVersionForData(Z, V);
    if (!J) throw new Error("The amount of data is too big to be stored in a QR Code");
    if (!I) I = J;
    else if (I < J) throw new Error(`
The chosen QR Code version cannot contain this amount of data.
Minimum version required to store current data is: ` + J + `.
`);
    const re = D(I, V, Z), oe = t.getSymbolSize(I), b = new r(oe);
    return m(b, I), v(b), E(b, I), g(b, V, 0), I >= 7 && A(b, I), O(b, re), isNaN(H) && (H = s.getBestMask(b, g.bind(null, b, V))), s.applyMask(H, b), g(b, V, H), { modules: b, version: I, errorCorrectionLevel: V, maskPattern: H, segments: Z };
  }
  return Ro.create = function(I, V) {
    if (typeof I > "u" || I === "") throw new Error("No input text");
    let H = e.M, Z, J;
    return typeof V < "u" && (H = e.from(V.errorCorrectionLevel, e.M), Z = c.from(V.version), J = s.from(V.maskPattern), V.toSJISFunc && t.setToSJISFunction(V.toSJISFunc)), L(I, Z, H, J);
  }, Ro;
}
var Go = {}, zo = {}, zu;
function ju() {
  return zu || (zu = 1, (function(t) {
    function e(n) {
      if (typeof n == "number" && (n = n.toString()), typeof n != "string") throw new Error("Color should be defined as hex string");
      let r = n.slice().replace("#", "").split("");
      if (r.length < 3 || r.length === 5 || r.length > 8) throw new Error("Invalid hex color: " + n);
      (r.length === 3 || r.length === 4) && (r = Array.prototype.concat.apply([], r.map(function(i) {
        return [i, i];
      }))), r.length === 6 && r.push("F", "F");
      const a = parseInt(r.join(""), 16);
      return { r: a >> 24 & 255, g: a >> 16 & 255, b: a >> 8 & 255, a: a & 255, hex: "#" + r.slice(0, 6).join("") };
    }
    t.getOptions = function(r) {
      r || (r = {}), r.color || (r.color = {});
      const a = typeof r.margin > "u" || r.margin === null || r.margin < 0 ? 4 : r.margin, i = r.width && r.width >= 21 ? r.width : void 0, s = r.scale || 4;
      return { width: i, scale: i ? 4 : s, margin: a, color: { dark: e(r.color.dark || "#000000ff"), light: e(r.color.light || "#ffffffff") }, type: r.type, rendererOpts: r.rendererOpts || {} };
    }, t.getScale = function(r, a) {
      return a.width && a.width >= r + a.margin * 2 ? a.width / (r + a.margin * 2) : a.scale;
    }, t.getImageWidth = function(r, a) {
      const i = t.getScale(r, a);
      return Math.floor((r + a.margin * 2) * i);
    }, t.qrToImageData = function(r, a, i) {
      const s = a.modules.size, l = a.modules.data, o = t.getScale(s, i), c = Math.floor((s + i.margin * 2) * o), u = i.margin * o, T = [i.color.light, i.color.dark];
      for (let f = 0; f < c; f++) for (let m = 0; m < c; m++) {
        let v = (f * c + m) * 4, E = i.color.light;
        if (f >= u && m >= u && f < c - u && m < c - u) {
          const A = Math.floor((f - u) / o), g = Math.floor((m - u) / o);
          E = T[l[A * s + g] ? 1 : 0];
        }
        r[v++] = E.r, r[v++] = E.g, r[v++] = E.b, r[v] = E.a;
      }
    };
  })(zo)), zo;
}
var $u;
function Bv() {
  return $u || ($u = 1, (function(t) {
    const e = ju();
    function n(a, i, s) {
      a.clearRect(0, 0, i.width, i.height), i.style || (i.style = {}), i.height = s, i.width = s, i.style.height = s + "px", i.style.width = s + "px";
    }
    function r() {
      try {
        return document.createElement("canvas");
      } catch {
        throw new Error("You need to specify a canvas element");
      }
    }
    t.render = function(i, s, l) {
      let o = l, c = s;
      typeof o > "u" && (!s || !s.getContext) && (o = s, s = void 0), s || (c = r()), o = e.getOptions(o);
      const u = e.getImageWidth(i.modules.size, o), T = c.getContext("2d"), f = T.createImageData(u, u);
      return e.qrToImageData(f.data, i, o), n(T, c, u), T.putImageData(f, 0, 0), c;
    }, t.renderToDataURL = function(i, s, l) {
      let o = l;
      typeof o > "u" && (!s || !s.getContext) && (o = s, s = void 0), o || (o = {});
      const c = t.render(i, s, o), u = o.type || "image/png", T = o.rendererOpts || {};
      return c.toDataURL(u, T.quality);
    };
  })(Go)), Go;
}
var jo = {}, Vu;
function Zv() {
  if (Vu) return jo;
  Vu = 1;
  const t = ju();
  function e(a, i) {
    const s = a.a / 255, l = i + '="' + a.hex + '"';
    return s < 1 ? l + " " + i + '-opacity="' + s.toFixed(2).slice(1) + '"' : l;
  }
  function n(a, i, s) {
    let l = a + i;
    return typeof s < "u" && (l += " " + s), l;
  }
  function r(a, i, s) {
    let l = "", o = 0, c = false, u = 0;
    for (let T = 0; T < a.length; T++) {
      const f = Math.floor(T % i), m = Math.floor(T / i);
      !f && !c && (c = true), a[T] ? (u++, T > 0 && f > 0 && a[T - 1] || (l += c ? n("M", f + s, 0.5 + m + s) : n("m", o, 0), o = 0, c = false), f + 1 < i && a[T + 1] || (l += n("h", u), u = 0)) : o++;
    }
    return l;
  }
  return jo.render = function(i, s, l) {
    const o = t.getOptions(s), c = i.modules.size, u = i.modules.data, T = c + o.margin * 2, f = o.color.light.a ? "<path " + e(o.color.light, "fill") + ' d="M0 0h' + T + "v" + T + 'H0z"/>' : "", m = "<path " + e(o.color.dark, "stroke") + ' d="' + r(u, c, o.margin) + '"/>', v = 'viewBox="0 0 ' + T + " " + T + '"', A = '<svg xmlns="http://www.w3.org/2000/svg" ' + (o.width ? 'width="' + o.width + '" height="' + o.width + '" ' : "") + v + ' shape-rendering="crispEdges">' + f + m + `</svg>
`;
    return typeof l == "function" && l(null, A), A;
  }, jo;
}
var Qu;
function Iv() {
  if (Qu) return ea;
  Qu = 1;
  const t = Av(), e = _v(), n = Bv(), r = Zv();
  function a(i, s, l, o, c) {
    const u = [].slice.call(arguments, 1), T = u.length, f = typeof u[T - 1] == "function";
    if (!f && !t()) throw new Error("Callback required as last argument");
    if (f) {
      if (T < 2) throw new Error("Too few arguments provided");
      T === 2 ? (c = l, l = s, s = o = void 0) : T === 3 && (s.getContext && typeof c > "u" ? (c = o, o = void 0) : (c = o, o = l, l = s, s = void 0));
    } else {
      if (T < 1) throw new Error("Too few arguments provided");
      return T === 1 ? (l = s, s = o = void 0) : T === 2 && !s.getContext && (o = l, l = s, s = void 0), new Promise(function(m, v) {
        try {
          const E = e.create(l, o);
          m(i(E, s, o));
        } catch (E) {
          v(E);
        }
      });
    }
    try {
      const m = e.create(l, o);
      c(null, i(m, s, o));
    } catch (m) {
      c(m);
    }
  }
  return ea.create = e.create, ea.toCanvas = a.bind(null, n.render), ea.toDataURL = a.bind(null, n.renderToDataURL), ea.toString = a.bind(null, function(i, s, l) {
    return r.render(i, l);
  }), ea;
}
var Lv = Iv();
const kv = Qi(Lv), Cv = Object.freeze(Object.defineProperty({ __proto__: null, default: Xi }, Symbol.toStringTag, { value: "Module" })), xv = Object.freeze(Object.defineProperty({ __proto__: null, default: UA }, Symbol.toStringTag, { value: "Module" })), Hv = Object.freeze(Object.defineProperty({ __proto__: null, default: VS }, Symbol.toStringTag, { value: "Module" }));
export {
  d0 as C,
  fv as I,
  uv as N,
  fa as O,
  h0 as P,
  kv as Q,
  f0 as S,
  dd as a,
  c0 as b,
  vT as c,
  $h as d,
  Dh as e,
  Zh as f,
  D1 as g,
  m1 as h,
  Tf as i,
  e1 as j,
  WA as k,
  E1 as r,
  Ai as t
};
//# sourceMappingURL=index-CnGEXeag.chunk.mjs.map
