const l = "agora", p = "1.0.0rc4";
import "./index-CnGEXeag.chunk.mjs";
import { _ as s, c as t, o, r } from "./NcEmptyContent-q-geAf0w-DsDiM4c8.chunk.mjs";
const c = {}, n = { class: "flex_settings" };
function a(e, i) {
  return o(), t("div", n, [r(e.$slots, "default")]);
}
const _ = s(c, [["render", a]]);
export {
  _ as F
};
//# sourceMappingURL=FlexSettings-Dk7Etco1.chunk.mjs.map
