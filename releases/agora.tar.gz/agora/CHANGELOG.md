<!--
  - SPDX-FileCopyrightText: 2017 Nextcloud contributors
  - SPDX-License-Identifier: CC0-1.0
-->
# Changelog
All notable changes to this project will be documented in this file.

# [1.0.0rc4] - 2025-09-06
- Uptate screenshoot
- Fix support implementation.
- Permissions update, 
- Package update
- User Manual in doc directory

# [1.0.0rc3] - 2025-09-03
- Fix logo
- Debate
- Permissions update, need to be finalized

# [1.0.0rc2] - 2025-08-29
Several bug fix

# [1.0.0rc1] - 2025-08-15
First Draft
