<?php

return [
    'appVersion' => '0.1',
    'migrations' => [
	    '\OCA\Agora\Migration\Version20250715120000',
	    '<disable-internet-connection>true</disable-internet-connection>':,
    ],
];

